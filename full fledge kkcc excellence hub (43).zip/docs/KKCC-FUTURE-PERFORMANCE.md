# KKCC futuristic surfaces and device-performance update

## Visual direction
Retained the KKCC logo, gold highlights, actual CMS content, course thumbnails and existing routes. Replaced muted green surfaces with cleaner ice-blue neutrals, deep ink/teal panels and brighter mint accents. Updated light and dark defaults together; custom admin palette overrides remain supported. The welcome surface has static CSS illumination and a subtle grid, not a video, canvas, animation loop or downloaded illustration. Exams keep their restrained neutral paper style.

## Performance changes
- Global search metadata now uses the shared React Query cache: 5-minute freshness, 10-minute inactive retention. Reopening search no longer refetches all three datasets while fresh. Pending and retry states are explicit.
- Search uses a deferred input value, pre-normalized searchable text and stops scanning once 24 matching results (8 defaults) are collected, rather than allocating all matches.
- Branding normalization is memoized, avoiding new context values and redundant localStorage/CSS writes on unrelated provider renders.
- Speculative route intent preloading is disabled when the existing boot detector marks a device as constrained or data-saving. Actual clicks still load normally.
- Skip refresh-rate sampling on constrained devices.
- Mobile/coarse-pointer and constrained-device headers use opaque surfaces rather than backdrop blur. Low-end hero/card shadows and decorative grid are removed.
- Native `content-visibility` lets supported browsers skip off-screen course-card rendering; unsupported browsers retain normal rendering. Printing explicitly renders all cards.
- Mobile text inputs/selects/textareas have a 16px minimum to avoid focus zoom; bottom navigation respects safe-area insets. Reduced-motion users retain minimal motion and automatic scrolling.
- Existing lazy route/search loading, image lazy loading and vendor splitting retained; no dependencies added.

## Evidence
- `npm test`: **135 passed**.
- Targeted Playwright suite: **13 passed together**. Auth/login/logout/recovery, notes language/navigation/edit/delete/paid gate, quiz submission, themes, course navigation, study-intention controls, search-cache behavior and constrained-device interactions covered.
- Home layout widths: **320, 360, 390, 430, 768, 844 landscape, 1024, 1440, 2560px**. Additional existing responsive suite checks courses, notes, tests, dashboard and admin at 320/390/768/1440px. No horizontal-overflow failures.
- Constrained-device test: Chromium CDP 4x CPU slowdown, 150ms network latency, 200KB/s download; emulated 2GB RAM, two cores and save-data. Verified lite classes, no header backdrop blur, no hero shadow, study intention interaction and navigation.
- `docs/audit/kkcc-future/constrained-device.json` contains a **warm authenticated reload** trace/resource totals, not cold-start data, a before/after benchmark or a Core Web Vitals score. Local fixture data is much smaller than some production catalogs.
- Search test verifies three initial server-function requests and no repeated requests for those same functions when reopened while fresh.
- TypeScript: passed. Full ESLint: **0 errors, 12 existing Fast Refresh warnings**.
- Production client/server build: passed. Existing large-chunk and plugin-timing warnings remain; this is not a claim that every route bundle is small.
- Actual browser screenshots inspected: `docs/audit/kkcc-future/home-1440.png`, `home-390.png`, `home-768.png`, `home-dark.png`.

## Limits and deployment
Physical devices, Safari/WebKit and Firefox were not tested. The responsive and constrained-device checks use Chromium emulation, not a guarantee of zero lag on every device. Server response time, catalog size, network, browser age and hosting still affect production speed. No external-preview-access or live-payment/cloud-storage claim.

No database schema, SQL, RLS, storage, pricing, scoring or authentication-handler changes. **No new SQL required**; see `SQL-UPDATE-STATUS.txt`. Previous SQL files remain in the full project archive for existing setup/history, not instructions to rerun cleanup.

`kkcc-future-update.patch` applies to the preceding local aesthetic revision. The full ZIP is the accumulated local workspace, not a new export of remote main. Dependencies, build output, private runtime state and secrets are excluded. The named preview uses explicitly enabled local student fixtures; production remains login-first.

Remote GitHub operations are closed for this session. No push, PR or deployment performed. Start a new coding session to review/integrate against current main.
