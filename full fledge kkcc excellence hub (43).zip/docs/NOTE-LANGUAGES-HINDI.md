# Notes mein Hindi / Punjabi / English typing

Admin → Materials → Add/Edit note → **Typing language**.
- English, हिन्दी, ਪੰਜਾਬੀ (Gurmukhi) aur اردو (Urdu/Shahmukhi) ke on-screen Unicode keys available hain.
- **Other languages** se device keyboard/paste use karein: mixed scripts ko restrict nahi kiya jata.
- Consonant pehle, matra/vowel sign baad: क + ि → कि; ਕ + ਿ → ਕਿ. Punjabi addak/tippi/bindi aur Hindi halant/nukta available hain.
- Cursor position / selected text par insertion, Space, New line aur Backspace supported. Language change existing text translate/replace nahi karta.
- Physical keyboard layout browser automatically switch nahi kar sakta. Android Gboard/iPhone/Windows/macOS mein Hindi/Punjabi keyboard enable karein. Roman-to-script transliteration device keyboard se hoti hai, is app palette se nahi.
- Notes canvas ke “Text to place on page” box mein bhi same controls hain.
- Save/read flow unchanged: Unicode text existing Supabase Storage note-body path se save hota hai. Naya SQL ya database migration required nahi.

Verification: TypeScript and targeted lint passed; production fixture build succeeded; dedicated browser test checks keys/matras, composition handling, mixed-language save/reload and 390px layout. Pure text-edit unit tests cover Unicode, selection replacement, limits and surrogate-safe Backspace. No production data modified.

GitHub delivery: previous coding session is closed. Start a new coding session for this repository to apply/push these changes to the current main branch via its assigned working branch. The accompanying note-language-update.patch contains only this feature, not the older workspace's unrelated changes.
