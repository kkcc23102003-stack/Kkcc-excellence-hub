# Paid Notes Series purchase setup — v43

## V43 local verification addendum (19 October 2026)

- `npm run typecheck`: passed.
- Targeted ESLint on the changed pricing, purchase, coupon, Admin UI, and test files: passed.
- Focused shared-pricing, coupon eligibility/idempotency and Notes/Batch purchase tests: 9/9 passed.
- Signed-in coupon preview and final claim both check the student's own use limit before success. Repeated and concurrent/double-tap successful 100% Notes Series claims recover idempotently.
- Production `npm run build`: passed; Vite emitted its existing large-chunk advisory.
- Full `npm test`: 267/272 passed. The same 5 unrelated SQL-mirror and note-parser tests failed: private/test-body migration mirror checks, two note-follow-up parser expectations, and the 200-question capacity expectation.
- Repository-wide lint was not re-run for this update. The prior full-repository lint had 866 Prettier errors; it is not represented as passing here.
- No live pricing setting, payment, database migration, or production deployment was changed.

## Student access rules

- The **first published note in each subject** of a published paid Notes Series is a free preview for everyone.
- Admin can independently set the complete-series price in rupees and/or 23KAAT coins.
- Buying the **complete Notes Series** unlocks its included notes. It does **not** enroll the student in the linked course or unlock its videos.
- Buying the **linked full batch/course** unlocks its included notes and course/video access.
- The Notes section offers **Buy Notes Only** for the complete Notes Series; it does not offer batch/video purchase. Use the separate Batch section for course and video purchases.
- A note included in a paid series is not sold individually, including through the normal checkout, coin wallet, or coupon-redemption path. Existing individual note purchases still open after the usual server-side access check.
- Paid-note coupon discounts remain enabled for eligible series/batch purchase routes.

## Admin configuration

1. Open the Admin Notes Series editor.
2. Under **Notes Series pricing control**, choose one shared price for all paid series or individual prices per series. In shared mode, enter the global INR and/or 23KAAT amount; in individual mode, select a series and set its full-series price. At least one amount must be greater than zero. Neither currency is inferred from the other.
3. Under **Batch pricing control**, choose one shared INR/23KAAT price for every linked Batch or per-Batch prices. Individual Batch prices are set on each linked course in its course editor. Shared Batch mode overrides those two course price fields; the Admin editor makes that explicit.
4. These controls affect displayed prices, coupon calculations and server-side checkout/payment routes. Shared mode only applies to Batch courses linked to a Notes Series; unrelated courses are unchanged.
5. Save and publish the series. The free-preview note is the first published note found in each subject's authored chapter/topic order.

## Database prerequisite for coin purchases

If students will buy Notes Series with 23KAAT, review and apply this additive migration to the existing Supabase project before enabling the coin option:

`supabase/migrations/20261019120000_notes_series_purchase_access.sql`

It adds a server-only, atomic purchase RPC. It spends the configured coin amount and writes a `notes-series:<series UUID>` grant using the existing `series_access_grants` table. The notes-series namespace is kept separate from test-series grants. The migration does not migrate content, delete data, or change student records. Do not run it without your normal backup and schema review. The migration has **not** been applied to a live database by this local verification.

Rupee checkout and coupon-based grant flows use the existing payment/access tables and do not invoke this coin RPC. Do not enable coin checkout for complete series until the migration has been applied and verified in the target environment.

## Verification status

- `npm run typecheck`: passed.
- Production `npm run build`: passed (large-chunk advisory remains).
- Repository quality gate: passed.
- Focused Notes Series, batch-access and paid-note coupon tests: 11/11 passed.
- Full unit suite: 262 passed, 5 failed. The failures were outside the Notes Series purchase files: two SQL mirror-equality checks, two existing note-follow-up MCQ parser expectations, and one 200-question parser limit expectation. See the test output in the development workspace before interpreting those existing failures.
- No live Supabase migration, payment, user account, or production deployment was performed.
