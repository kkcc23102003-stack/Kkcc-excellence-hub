# Notes formatting studio and printable branding

## Admin use
Open Admin → Materials → your Notes Series → subject → chapter/topic → edit/add a note. The existing individual-note manager also uses the same editor.

Select text and use the new toolbar: bold, italic, underline, highlight, five text colours, eight font sizes, alignment, superscript/subscript, important boxes, headings, bullets, numbering and formula insertion. Ctrl/Cmd+B/I/U are supported outside IME composition. Undo/redo covers typing and formatting within the mounted editor. Multi-line formatting preserves Unicode and can toggle its own markers off.

Expand **Table builder / Find and replace** to edit cells, add/remove final rows/columns, and insert a table with a shaded header and alternating rows. Table cells remain tab-separated text inside `:::table` blocks, so they can be edited without a new database format. Exact, case-sensitive replace-all asks for confirmation.

This is a lightweight **source + live preview editor**, not embedded Microsoft Word or a WYSIWYG Office clone. Formatting markers such as `[b]...[/b]` remain visible/editable in the input; the student preview and PDF show the formatted result. No DOCX import/export or rich clipboard-layout preservation is included. Pasted text, Unicode, existing image uploads, handwriting, diagram controls and formula rendering remain available. The handwriting canvas's plain-text input intentionally does not insert formatting markers into images.

## Automatic appearance
Headings use colourful shaded panels; short `Term: explanation` prefixes are bold/highlighted without changing their wording. Existing automatic diagrams/formulas remain subject to the existing controls. The renderer does not generate new facts or infer which arbitrary sentence is most important. Use Highlight/Important box to mark those yourself.

## Draft recovery
Note text is debounced into **sessionStorage**, scoped to admin user + note ID. A reload offers Restore/Discard instead of overwriting the server note automatically. It covers text/formatting only, not prices, titles or other metadata. Backup failures are shown explicitly. Saving, publishing and access rules are unchanged. Use **Save changes** for permanent server/Storage saving. Closing the tab or signing out clears recovery; this is not cloud autosave or cross-device sync. Account changes/sign-out clear these recovery entries.

A late material-query refresh no longer replaces fresh edits typed just after pressing Save.

## PDF / printing
The generated note document uses repeating table header/footer groups that reserve layout space, rather than fixed overlays over note text. Every tested page has:
- The original KKCC logo at the upper-left corner, embedded into the document so data-URL/offline printing does not depend on an asset request.
- **Kusum Kartik Coaching Centre** centred above the note content.
- Branding below the content, with separate spacing.

The old diagonal body watermark is no longer painted over the first/last lines. Tables repeat their own column headers. Generated diagrams/images are constrained to a printable height without an overflow-hidden content crop.

Use **A4**, default margins, turn off the browser's own **Headers and footers**, and enable **Background graphics** for colour. App code cannot force browser print-dialog settings. Chromium's print-to-PDF was checked; Firefox/Safari, physical printers and unusual user-selected margins still require device testing. Existing uploaded PDF files are not rewritten or stamped by this change—branding applies to notes generated from the app's text editor.

## Verification
- 149 unit tests passed, including six office-formatting/escaping/table/layout tests.
- Eight targeted browser tests passed together: login/session gates, Hindi/Punjabi IME and mobile layout, formatting/save/reload/draft recovery, notes-series organisation/access and free sample reading. Notes/editor tests were rerun after final changes and passed.
- Typecheck and production build passed. Lint: 0 errors, 12 existing warnings. Existing large-chunk build warning remains.
- Actual Chromium-generated **17-page PDF** checked with PyMuPDF: original logo painted on every page; repeated header/footer; 180 identifiable paragraphs plus 40 table rows and end marker preserved; checked content lines clear of branding. Evidence: `docs/audit/notes-office/`.
- Reproduce PDF: `npx tsx scripts/audit-notes-print.ts` (Playwright Chromium required; optional `PLAYWRIGHT_CHROMIUM_EXECUTABLE_PATH`). Geometry check: `python3 scripts/check-notes-print.py` (optional local PyMuPDF installation). Both use synthetic content, not private/student notes.
- Not a full cross-browser/physical-device suite or a production cloud deployment test.

## Migration and delivery
No new SQL or cleanup required. Existing descriptions/Storage bodies carry the portable formatting; no schema, paid entitlement, course access or billing changes. Existing plain notes keep working. Prior source changes are preserved. No GitHub push, merge or deployment was performed from this closed coding session.
