# Notes Series update

## Student flow

Paid Notes Series → Series → Subject → Chapter → optional Topic → Notes.

- The default library contains paid/coin-priced or course-access notes only. No eligible published notes means an empty paid library.
- “View Sample Notes” is a separate opt-in section. Existing free notes are grouped there; their underlying records are not relabelled or rewritten. Paid prices/coin prices take precedence over a contradictory free flag.
- Existing unassigned notes remain reachable through fallback series. Draft-linked notes are intentionally hidden from this fallback until the series is published.
- Empty branches are hidden publicly; admin can save empty subjects/chapters/topics.
- Cards remain paginated and metadata-only. Readers still load bodies on demand through existing access checks.

## Admin flow

Open Admin → Materials. Create a notes series, set its optional image/text thumbnail, then add subjects, chapters and optional topics. Add a new note or attach an existing note at chapter/topic level. Use the complete existing note editor for text, languages, diagrams, handwriting, files and pricing.

Publish both the individual note and the series. New notes default to unpublished. Series publication does not grant access or introduce a new bundle price: existing per-note/course entitlements remain authoritative.

Names can be edited in place. Removing a subject/chapter/topic/series removes organisation only; it preserves note records and purchases. The separate “Delete note” action is destructive and requires confirmation. The existing individual-note manager and storage controls remain under “My notes · search, edit and publish”; the former built-in sample import is removed. Existing saved notes and purchases are not deleted by this source update.

## Persistence / SQL

Series and Batch configurations are immutable JSON objects in the private Supabase `course-content` bucket at `notes-catalog/{series|batch}/{uuid}/{sha256}.json`. `kkcc_site_settings` and `kkcc_private_settings` keep only a compact versioned pointer; the exact `notes_batch_course_v1:<course UUID>` index remains a small lookup row. Trusted server code alone reads/writes catalogue objects using the server-only service-role client. Browser roles receive no catalogue read access. Paid note bodies, purchases, grants and videos keep their existing access gates and storage paths.

Apply both reviewed additive migrations in order:

- `supabase/migrations/20261019160000_managed_notes_free_preview.sql` adds/backfills the managed `kkcc_materials.is_free_preview` field used by the catalogue query.
- `supabase/migrations/20261019170000_private_notes_catalog_storage.sql` ensures `course-content` remains private and denies browser-role SELECT on catalogue paths.

Back up the existing Supabase settings and Storage configuration before rollout. Existing JSON values are migrated lazily: the server uploads and hash-verifies the object, then compare-and-swaps only that row to its pointer. If upload or CAS fails, the old row remains authoritative; simultaneous edits are not overwritten. Old immutable objects are retained to protect in-flight readers. No data cleanup or purchase/grant mutation is required. Do not overwrite live runtime content with the seed file.

Saving validates linked note IDs and access modes, requires authenticated admin access, and checks revision plus previous stored value. Stale saves are rejected rather than silently replacing a later revision. Configure the server-only `SUPABASE_SERVICE_ROLE_KEY`; never expose it in browser variables.

The builtin public-note reader now recognises its UUID IDs, checks stored records first, respects unpublished records, and does not restore adopted/deleted builtin samples through fallback.

## Verification

- 143 unit tests passed, including five new hierarchy/classification/schema tests.
- Six targeted browser tests passed: four login/session gate regressions and two notes-series flows.
- The two notes-series tests were rerun after adding real server-function replay assertions: stale revision rejected; student admin-write attempt rejected. Both passed.
- Browser flow covers Unicode hierarchy persistence/reload, optional topic creation, direct chapter note creation, paid-note gate, free/sample separation, free reader, 390px student viewport and series deletion preserving notes.
- TypeScript check and production build passed. Lint: zero errors, 12 existing warnings. Build retains its existing large-chunk warning.
- Not a full browser-suite run. Older tests asserting the superseded flat student notes UI need navigation updates. Actual production cloud persistence, purchases and physical devices were not exercised.

No production data cleanup, GitHub push/merge or deployment was performed. Download page serves release files only, not an application preview.
