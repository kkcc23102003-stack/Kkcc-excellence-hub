-- READ-ONLY export for a consistent, isolated restored backup ONLY.
-- SELECT produces one JSON object per row (no student ID, email, answers or paper text).
-- The output still contains private attempt IDs/paths: keep the exported NDJSON
-- and all bucket objects OUTSIDE the source repository and its review ZIP.
-- Do not run against live Supabase without a verified backup and owner approval.
-- Compare output line count with active_snapshot_references from the separate
-- readiness query on the SAME restored backup. No backfill/deletion is performed.
SELECT json_build_object(
  'attempt_id', paper.attempt_id,
  'path', paper.path,
  'sha256', paper.sha256,
  'bytes', paper.bytes,
  'question_count', attempt.question_count,
  'source_refs', attempt.source_refs
)::text AS manifest_line
FROM public.kkcc_attempt_papers AS paper
JOIN public.learning_attempts AS attempt ON attempt.id = paper.attempt_id
ORDER BY paper.attempt_id;
