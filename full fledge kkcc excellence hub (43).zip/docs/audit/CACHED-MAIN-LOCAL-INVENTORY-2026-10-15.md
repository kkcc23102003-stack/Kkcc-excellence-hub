# Cached main / PR #2 — local source inventory (not a merge approval)

Read-only blob comparison of this **working tree**, on fixed branch `arena/01a10030-kkcc-excellence-hub`, against the **locally cached** `main` at `5415b976eddb1ccb85dfc41c00be9074b459bffb` (merge of PR #2). The remote current state was not checked; this session cannot reach GitHub. The starting commit here is `8e53a45158341568057e3d3cbd3897d76700cbae`.

Of **599 source/non-archive paths** in cached main: **488 identical / 99 differing / 12 absent**, plus **476 local-only tracked or unignored paths** (including this inventory, the offline result-paper checks, existing-Vercel guide and saved-attempt safety/regression files). The 600th cached-main path is a historical ZIP, excluded from this source comparison: the earlier untracked repository-root archive was not restored into this sandbox. Do not treat either ZIP as merged source or attempt to replace it. Generated audit files and tests count as differences; these counts say nothing about semantic compatibility. Working-tree changes, including untracked files, were included in the comparison.

## Absent from this branch — deliberately withheld, not silently restored

Eleven Content Reset-related paths were not imported: historical saved results are not yet proven safe after deleting source questions. Restoring any migration, admin control or cleaner requires an approved backup, data-retention policy and a verified live migration plan. The twelfth, the `rich-text-field.tsx` on-screen keyboard, was omitted to keep native phone IME; the strict rich-text **reader** was restored separately and its browser regression passed.

- `KKCC-Excellence-Hub-CONTENT-RESET.sql`
- `docs/CONTENT-RESET-HINDI.md`
- `docs/audit/CONTENT-RESET-2026-10-09.md`
- `docs/audit/CONTENT-RESET.png`
- `public/KKCC-Excellence-Hub-CONTENT-RESET.sql`
- `public/downloads/CONTENT-RESET-HINDI.md`
- `src/components/kkcc/content-reset-panel.tsx`
- `src/components/kkcc/rich-text-field.tsx`
- `src/lib/content-reset.functions.ts`
- `supabase/migrations/20261009190000_content_reset.sql`
- `tests/e2e/zz-content-reset.spec.ts`
- `tests/unit/content-reset.test.ts`

## Differing files — **not** individually approved

The following paths need real content review against the target branch, with special care for SQL/RLS, authentication, grading, payments, role gates, native keyboard and privacy. **Do not resolve them by wholesale extraction or by uploading a ZIP as one repository file.** One narrow exception has now been reviewed against the cached blob: `src/lib/learning.server.ts` restores the two generated-series price assignments from cached main and differs there only by explanatory comments. A new disposable-fixture test checks free/paid, both price currencies, overrides and archived attempts. The separately reviewed saved-attempt server function now looks up owner-scoped retries before current-price discovery; its access checks, foreign owner isolation, fail-closed versioned RPC and post-insert paper-write failure behavior passed disposable HTTP regressions. This is **not** an approval of the other differences or evidence about the remote current main or previously saved production papers.

### App source and styles (59)

- `src/components/kkcc/admin-command-bar.tsx`
- `src/components/kkcc/auth-shell.tsx`
- `src/components/kkcc/bottom-nav.tsx`
- `src/components/kkcc/branding-provider.tsx`
- `src/components/kkcc/content-protection.tsx`
- `src/components/kkcc/content-thumbnail.tsx`
- `src/components/kkcc/course-card.tsx`
- `src/components/kkcc/course-thumb.tsx`
- `src/components/kkcc/easy-text-test-builder.tsx`
- `src/components/kkcc/global-search.tsx`
- `src/components/kkcc/logo.tsx`
- `src/components/kkcc/material-access-button.tsx`
- `src/components/kkcc/notes-canvas-editor.tsx`
- `src/components/kkcc/sandbox-preview-bar.tsx`
- `src/components/kkcc/site-header.tsx`
- `src/components/kkcc/site-layout.tsx`
- `src/components/kkcc/test-card.tsx`
- `src/components/kkcc/test-retention-panel.tsx`
- `src/components/kkcc/theme-toggle.tsx`
- `src/components/kkcc/website-content-provider.tsx`
- `src/components/ui/button.tsx`
- `src/components/ui/progress.tsx`
- `src/hooks/use-auth-user.ts`
- `src/integrations/supabase/db.ts`
- `src/lib/admin.functions.ts`
- `src/lib/content.functions.ts`
- `src/lib/learning.server.ts`
- `src/lib/notes-visuals/analyze.ts`
- `src/lib/notes-visuals/index.ts`
- `src/lib/project-content.server.ts`
- `src/lib/result-paper.server.ts`
- `src/lib/test-attempts.functions.ts`
- `src/lib/test-body.functions.ts`
- `src/lib/test-body.server.ts`
- `src/lib/video.ts`
- `src/routeTree.gen.ts`
- `src/router.tsx`
- `src/routes/__root.tsx`
- `src/routes/_authenticated/admin.courses.$id.tsx`
- `src/routes/_authenticated/admin.index.tsx`
- `src/routes/_authenticated/admin.materials.tsx`
- `src/routes/_authenticated/admin.storage.tsx`
- `src/routes/_authenticated/admin.tests.tsx`
- `src/routes/auth.callback.tsx`
- `src/routes/checkout.tsx`
- `src/routes/classes.tsx`
- `src/routes/courses.index.tsx`
- `src/routes/dashboard.index.tsx`
- `src/routes/dashboard.materials.tsx`
- `src/routes/dashboard.tsx`
- `src/routes/downloads.tsx`
- `src/routes/games.tsx`
- `src/routes/index.tsx`
- `src/routes/learn.tsx`
- `src/routes/login.tsx`
- `src/routes/study-material.tsx`
- `src/routes/test-series.tsx`
- `src/routes/test.$id.tsx`
- `src/styles.css`

### Build settings, scripts, SQL and public assets (13)

- `.gitignore`
- `.prettierignore`
- `KKCC-Excellence-Hub-PRODUCTION-SQL.sql`
- `eslint.config.js`
- `package-lock.json`
- `package.json`
- `public/KKCC-Excellence-Hub-PRODUCTION-SQL.sql`
- `public/downloads/index.html`
- `public/secure-video.html`
- `scripts/repository-quality-check.mjs`
- `scripts/serve.mjs`
- `scripts/sync-release-sql.mjs`
- `supabase/STUDENT_ONLY_SCHEMA.sql`

### QA, fixtures and regression tests (14)

- `tests/e2e/app-audit.spec.ts`
- `tests/e2e/diagram-library.spec.ts`
- `tests/e2e/learning.spec.ts`
- `tests/e2e/note-body-storage.spec.ts`
- `tests/e2e/test-body-storage.spec.ts`
- `tests/e2e/test-builders.spec.ts`
- `tests/e2e/test-folders.spec.ts`
- `tests/e2e/test-paper-style.spec.ts`
- `tests/e2e/test-retention.spec.ts`
- `tests/e2e/thumbnails.spec.ts`
- `tests/fixtures/database.ts`
- `tests/fixtures/dev-server.ts`
- `tests/unit/notes-visuals.test.ts`
- `tests/unit/test-retention.test.ts`

### Documentation and audit outputs (13)

- `README.md`
- `RELEASE_VERIFICATION.md`
- `docs/TEST-PRIVACY-HINDI.md`
- `docs/audit/NOTE-BODY-STORAGE.png`
- `docs/audit/TEMPORARY-TEST-RESULT.png`
- `docs/audit/TEST-BODY-STORAGE.png`
- `docs/audit/TEST-PAPER-DESKTOP.png`
- `docs/audit/TEST-PAPER-LIGHT.png`
- `docs/audit/TEST-PAPER-MOBILE.png`
- `docs/audit/TEST-RETENTION-ADMIN.png`
- `docs/audit/THUMBNAIL-TEXT-CARD.png`
- `docs/audit/browser-results.json`
- `docs/audit/question-bank-sample.json`

## Current evidence and next gate

Local full Chromium fixture run: **131 passed / 1 intentionally skipped / 0 failed**. Unit tests: **194 passed**; three disposable HTTP fixture tests passed (normal replay after repricing, simulated missing-RPC failure and post-insert snapshot-metadata failure); local build, typecheck, lint (0 errors), PWA and release-SQL checks passed. The 131-pass Chromium suite predates the latest source changes. This supports the local implementation, not PR #2/main parity or a production cutover. The 11 withheld reset files and historical-attempt backfill require policy decisions; every differing runtime/SQL file needs target-branch review in a new coding session before a production release. See `LOCAL-RELEASE-STATUS-2026-10-15.md` for the full safety gate.
