# Supabase Storage and Database content review — 20 October 2026

## Scope and confidence

This is a **source and migration-schema inspection** of the restored release source. It is not a live Supabase audit: no production table, row, Storage object, bucket/provider setting, quota, backup, payment, or deployment was read or changed. Accordingly, this report confirms how this source release is designed to store content; it does not certify that a live project has applied the migrations or already migrated its legacy rows.

## Content placement reviewed

| Content | Intended Storage location | Database row/index |
| --- | --- | --- |
| Published material/note body | Private `kkcc-note-bodies`, UTF-8 text, maximum 8 MiB per object | `kkcc_materials.description` is cleared for Storage-backed saves; row keeps `body_storage_path`, SHA-256, and byte count. New Admin material saves write and verify the object before the DB update. Existing inline descriptions require the existing explicit Admin migration; they are not silently deleted. |
| Test question bodies (question, options, explanation) | Private `kkcc-test-bodies`, JSON, maximum 16 MiB per test batch | `kkcc_test_questions` rows keep question IDs, test IDs, scoring/ordering metadata, and object path/hash/byte count; body fields are blank in Storage-backed rows. Existing questions require the explicit migration endpoint. |
| Notes Series and Batch catalogues | Private `course-content` bucket, immutable `notes-catalog/{kind}/{id}/{sha256}.json` objects, maximum 20,000,000 bytes in the application | `kkcc_site_settings` / `kkcc_private_settings` values become short versioned pointers. Legacy JSON is copied and verified before an atomic pointer move; production CAS hashes the old value inside PostgreSQL, while local fixtures use a direct file-backed CAS. |
| Custom test-series catalogue | Private `kkcc-test-series-catalog`, immutable SHA-256 JSON objects, application limit 20,000,000 bytes | The `test_series_custom_catalog` settings value becomes a short pointer with bucket, path, hash, and byte count. Lazy legacy migration verifies bytes and does not overwrite a concurrent Admin edit. |
| AI question candidate full content and sources | Private `kkcc-ai-question-archive`, JSON, 256 KiB object cap; every read checks the SHA-256 and object/question IDs | New `ai_question_candidates` rows keep status, topic/exam metadata, duplicate key, correct index, timestamps, Storage key/provider, and hash; prompt/options/explanation/source URLs/source notes are empty/null. Existing inline or external records remain intact until the explicit bounded Admin migration uploads/verifies and compare-and-swaps each row. |
| Note practice responses | Private `kkcc-note-results` Storage objects; practice payloads are limited to 16 KiB in the application | Small references/summaries are stored for listing. The full question and response payload is not put in the Database. |
| Saved regular test/series result papers | Private `kkcc-result-papers`; application snapshot limit 2 MiB per attempt (bucket permits up to 16 MiB) | A compact `kkcc_attempt_papers` pointer/hash/byte receipt is stored. A separate cleanup receipt preserves the exact Storage path if an attempt is later deleted; it does not delete the object automatically. |
| Uploaded PDFs/media and thumbnails | Existing content upload path uses Supabase Storage when the configured provider is Supabase; it may use an already-configured S3-compatible provider for general media | Supabase uploads use short-lived upload tokens created server-side only after Admin authorization; small Database rows retain the compact file reference/metadata. Material `file_url` accepts at most 2,048 characters and only short HTTP(S), app-relative, secure-video, or durable `kkcc-file://` references. New saves reject `data:`/`blob:` file payloads. Thumbnails are separately bounded. General media provider configuration was not inspected live. |
| Coupon redemptions and Notes Series access grants | Not file content; these remain ordinary relational history/entitlement rows | `admin_hidden_at` only changes visibility in the Admin history list. It does not remove rows, alter coupon usage counts, revoke grants, or affect student-access checks. |

## Preserved Database fields and explicit caveats

- Regular `learning_attempts` rows still retain submitted answers, score, counters, and question references because the existing finalize RPC updates these atomically for timers and legacy clients. The current result-paper feature writes a verified Storage snapshot as a parallel copy. Removing/moving those relational fields requires a separate reviewed migration and an approved rollback/backup plan; this release does not do it.
- Existing note/test body rows and AI candidates can remain inline until their explicit Admin migration endpoints have run successfully. Existing external AI archive rows remain readable using their configured legacy provider until each record is migrated. This source review cannot tell how many such rows a live project has.
- Lazy catalogue migrations move legacy JSON on read, but only after the destination Storage object has been read back and hash-verified; a failed write, missing object, invalid pointer, or concurrent edit fails closed and retains the original Database value.
- General uploads may still use a previously selected external provider. Only the named note/test/catalogue/result/AI buckets above are specifically designed here as private Supabase Storage buckets. This report does not assert the settings in any deployed project.
- Database rows can still contain ordinary short text such as titles, descriptions/metadata, notes, hashes, compact URLs, statuses, prices, IDs, and timestamps. This review focuses on avoiding large bodies/blobs in Database fields, not eliminating useful metadata.

## 20 October follow-up — missing educational bucket recovery

The source now checks the private `course-content` bucket in Admin → Storage and can create it if missing. The upload target also provisions this canonical bucket when needed and returns a short-lived Storage upload token after the server verifies Admin access; the browser no longer depends on a direct, unauthenticated RLS upload policy. The additive `20261020150000_educational_storage_setup.sql` migration creates/repairs the private 45 MiB bucket, adds an admin-only policy boundary, and exposes a service-role-only readiness check. Admin Storage links to a downloadable SQL mirror and reports missing/private/policy status. This may correct a missing bucket after the matching application release is deployed, but it does not install SQL policies in the live project automatically and does not prove any live bucket exists. The migration and bucket-provisioning path passed disposable PGlite/source tests only.

## 20 October follow-up — Coupon Manager resilience

The Admin coupon list now treats the Notes Series and Test Series catalogues as optional reads. A missing `course-content` bucket can therefore produce an actionable Notes Series warning without taking coupon codes, redemption history, or unrelated coupon scopes offline. A failing Test Series catalogue is isolated in the same way. The Notes Series Builder keeps its requested specific item ID if the catalogue cannot load; the page does not silently convert that shortcut into a category-wide discount. Saving a series-scoped coupon stays disabled while that category's catalogue is unavailable, avoiding a misleading success/failure cycle. This is a source/UI resilience change, not a repair of live Storage; apply the documented SQL and independently verify the live bucket before creating or redeeming Notes Series coupons.

## Required release steps (not performed here)

1. Back up the target project and verify that it is the intended existing Supabase project.
2. Review the timestamped migrations and apply the additive `KKCC-Excellence-Hub-HISTORY-STORAGE.sql` (including `20261020150000_educational_storage_setup.sql`) or corresponding individual migrations only after confirming the expected tables/buckets and policy impact. For a new student-only project, use the updated `supabase/STUDENT_ONLY_SCHEMA.sql`; do not run that fresh-install entrypoint over an existing production project.
3. Deploy the matching server source with `SUPABASE_SERVICE_ROLE_KEY` kept server-only.
4. Use the existing Admin note/test Storage migration controls for legacy bodies. On the AI Question Engine page, inspect the inline/external counts and run the explicit bounded migration as needed. Verify the object/hash status and keep backups until counts and sample reads are independently checked.
5. Independently inspect live bucket privacy, object totals, remaining inline counts, RLS/function grants, backups, provider settings, and billing/quota in Supabase. None of these production checks is inferred from a passing local test.

## Local verification strategy

The release adds PGlite coverage for reversible history, Notes catalogue compare-and-swap, private AI Storage schema, and custom test-series pointer CAS, plus unit checks for verified archive objects and compact file references. These tests prove behavior against disposable local fixtures only; they are not production data or provider verification.
