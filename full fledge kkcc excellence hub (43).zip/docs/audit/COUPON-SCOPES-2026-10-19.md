# Coupon scopes and admin access controls — 19 October 2026 (V48)

## Delivered

- `/admin/coupons` can scope coupons to all paid items, Batches/Courses, individually paid Notes, Tests, Test Series, or Notes Series.
- Course scope can cover all published courses or one selected course/batch. Notes, Tests and both kinds of Series can cover the whole selected category or one selected item.
- The server verifies that item-specific scopes point to a published/active product, then checks category, course ID and item ID in validation, coin purchase, Razorpay purchase and coupon redemption paths. The trusted course redemption RPC independently rejects non-course coupons and preserves its historical idempotency.
- Coupon redemptions record `item_kind` and `item_id` for all product types. The legacy `course_id` remains populated for course redemptions and nullable for other products; old rows and old course-only writes remain compatible.
- Removing an unused coupon deletes it. If redemptions exist, or a legacy `used_count` is nonzero, the coupon is disabled instead. Existing redemption history is retained.
- The coupon page now embeds grant/revoke controls for course, test and Test Series access plus Notes and Notes Series access. The Notes panel includes paid Note purchase rows; revoking a purchase changes its status but keeps the record. Other independent active entitlements are not removed.
- Manual Notes Series grants omit `updated_at`, which is not a column of `series_access_grants`; only Note-grant writes send that table-specific timestamp.

## SQL and deployment

Migration: `supabase/migrations/20261019190000_coupon_scopes_and_controls.sql`.

Included in `supabase/STUDENT_ONLY_SCHEMA.sql`, `KKCC-Excellence-Hub-PRODUCTION-SQL.sql`, and its public mirror. Existing projects must apply the course-validity/manual-Notes migration first, then this additive migration, after backup/schema review. It does not issue grants or change any live student access by itself.

No live Supabase database, payment, catalogue or production deployment was accessed or changed in this work.

## Local verification

- Targeted PGlite course-validity, manual-Notes-access and coupon tests: **13/13 passed**.
- Full unit suite: **290/290 passed**.
- `npm run typecheck`: passed.
- `npm run build`: passed; the build reports the existing large-chunk advisory.
- Targeted ESLint on changed/new TypeScript and TSX files: passed.
- Repository quality, question-bank audit, PWA readiness and release-SQL mirror checks: passed.
- Repository-wide `npm run lint`: **802 errors and 20 warnings**. Targeted ESLint on changed files passes; unrelated files were not reformatted.
