# Working-app visual review (local fixture, 15 Oct 2026)

These are **real Chromium screenshots of the working KKCC app with local fixture data**, not static mockups or screenshots of production. They are not user-approved. The repository's current layout/routes remain in place; the optional **Review light layout** switch adds a *preview-only*, light/off-white and logo-teal colour proposal. Switching it off returns to the current app colours. No wholesale theme rollout has been made. The user's latest direction is to keep the rest of the app as is and retain the previously built Notes/Test colour and text-formatting tools.

| View | Phone | Desktop |
| --- | --- | --- |
| Student home, light sample | `review-student-home-phone.png` | `review-student-home-desktop.png` |
| Login | — | `review-login-desktop.png` |
| Study-material series/catalog | `review-student-notes-phone.png` | — |
| Notes text colours/highlight, working editor preview | `review-notes-colour-tools-phone.png`, `review-notes-coloured-text-phone.png` | — |
| Test series / empty series state | `review-student-tests-phone.png` | — |
| Fixture free practice paper and result | `review-test-paper-phone.png`, `review-test-result-phone.png` | — |
| Admin home | — | `review-admin-home-desktop.png` |
| Presentation Studio | `review-admin-studio-phone.png` | `review-admin-studio-desktop.png` |

The existing baseline snapshots (`student-*`, `admin-*`, `guest-login-desktop.png`) show the default colours without the review switch; most were recaptured after the Studio layout changes. Screenshots do not prove native Samsung/Gboard/iPhone keyboard behaviour, Safari, production payments, native Canva editing or desktop PowerPoint compatibility.

Working preview is the production-build local fixture on port **4600**; visit `/__fixture__/student-preview`, open **Preview tools**, switch roles and choose **Review light layout** if desired. Demo data is explicitly labelled. The app normally keeps the previous visual styling; the light sample is session-only and off by default. ZIP and cleaner endpoints return HTTP **409** and **403** respectively in this shared review mode. Do not download the older archive from this repository as a release; PR #2 reconciliation and full QA are pending.
