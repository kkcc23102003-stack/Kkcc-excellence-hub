-- READ-ONLY REVIEW QUERY; run only against a restored, access-controlled backup.
-- Requires the separately approved result-paper snapshot migration already installed.
-- Counts are not a proof of paper authenticity: Storage metadata is not blob bytes,
-- and old attempt IDs/order cannot prove the original text, answers or explanations.
-- No content reset, snapshot backfill, Storage deletion or retention decision here.
-- Run as a trusted database owner/service role; NEVER expose this query via the app.
WITH
attempt_inventory AS (
  SELECT
    count(*) AS attempts_total,
    count(*) FILTER (WHERE paper.attempt_id IS NULL) AS attempts_without_snapshot,
    count(*) FILTER (
      WHERE paper.attempt_id IS NULL AND attempt.status = 'submitted'
    ) AS submitted_without_snapshot,
    count(*) FILTER (
      WHERE paper.attempt_id IS NULL AND attempt.status <> 'submitted'
    ) AS open_without_snapshot,
    count(*) FILTER (
      WHERE paper.attempt_id IS NULL AND EXISTS (
        SELECT 1 FROM unnest(attempt.source_refs) AS ref(value)
        WHERE ref.value ~ '^__kkcc_meta__:.*:snapshot=v1$'
      )
    ) AS marked_attempts_without_snapshot
  FROM public.learning_attempts AS attempt
  LEFT JOIN public.kkcc_attempt_papers AS paper ON paper.attempt_id = attempt.id
),
active_references AS (
  SELECT
    count(*) AS active_snapshot_references,
    count(*) FILTER (
      WHERE NOT EXISTS (
        SELECT 1 FROM storage.objects AS obj
        WHERE obj.bucket_id = 'kkcc-result-papers' AND obj.name = paper.path
      )
    ) AS active_reference_without_object_row,
    count(*) FILTER (
      WHERE paper.sha256 !~ '^[0-9a-f]{64}$'
         OR paper.bytes NOT BETWEEN 1 AND 16777216
         OR paper.path !~ (
              '^' || paper.attempt_id::text ||
              '/[0-9a-f]{8}-[0-9a-f]{4}-[1-8][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}\.json$'
            )
    ) AS malformed_active_references
  FROM public.kkcc_attempt_papers AS paper
),
cleanup_receipts AS (
  SELECT
    count(*) AS queued_cleanup_receipts,
    count(*) FILTER (
      WHERE NOT EXISTS (
        SELECT 1 FROM storage.objects AS obj
        WHERE obj.bucket_id = 'kkcc-result-papers' AND obj.name = receipt.path
      )
    ) AS receipt_without_object_row,
    count(*) FILTER (
      WHERE EXISTS (
        SELECT 1 FROM public.kkcc_attempt_papers AS paper
        WHERE paper.path = receipt.path
      )
    ) AS receipt_path_still_active
  FROM public.kkcc_result_paper_cleanup AS receipt
),
bucket_inventory AS (
  SELECT
    count(*) AS result_paper_object_rows,
    count(*) FILTER (
      WHERE NOT EXISTS (
        SELECT 1 FROM public.kkcc_attempt_papers AS paper WHERE paper.path = obj.name
      ) AND NOT EXISTS (
        SELECT 1 FROM public.kkcc_result_paper_cleanup AS receipt WHERE receipt.path = obj.name
      )
    ) AS objects_without_reference_or_receipt,
    count(*) - count(DISTINCT obj.name) AS duplicate_object_names
  FROM storage.objects AS obj
  WHERE obj.bucket_id = 'kkcc-result-papers'
)
SELECT
  EXISTS (
    SELECT 1 FROM storage.buckets AS bucket
    WHERE bucket.id = 'kkcc-result-papers' AND bucket.public IS FALSE
  ) AS private_bucket_present,
  attempts.*,
  active.*,
  receipts.*,
  objects.*
FROM attempt_inventory AS attempts
CROSS JOIN active_references AS active
CROSS JOIN cleanup_receipts AS receipts
CROSS JOIN bucket_inventory AS objects;
