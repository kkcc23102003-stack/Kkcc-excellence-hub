# KKCC Document Studio — admin release

**Latest enhancement (15 October 2026):** In Simple mode, **Long text → editable PPT slides** accepts a full lesson (up to 60,000 characters); `#` headings are optional. Deterministic font-measured pagination creates native editable slides after the current slide, never replacing older work. It switches on a PowerPoint-style inline preview with a large current slide, a bounded thumbnail navigator, Previous/Next, and live heading/body editing on the same screen. Tapping editable heading/body text on that preview focuses its native-keyboard author field; decorative artwork remains an image, not text. The existing Present slides action gives a full-screen slideshow with an **Edit this slide** return action. It organises, **not AI-summarises**, the original words. On overflow (60 slides / 24 MB), the old deck and draft stay untouched. Save the project JSON, export editable PPTX, or export raster slide PDF. See Hindi steps: `../DOCUMENT-STUDIO-GUIDE-HINDI.md`.

Earlier in this update, Simple mode gained **Custom slide · add PDF page(s)** *in addition to* the separate Canva starting-design wizard. The chooser accepts a local PDF up to 25 MB/12 pages, then inserts selected pages after the current slide. PDF artwork is image-only; separately added headings/bodies are editable PowerPoint text shapes. Selecting existing slide text gives a visible B/I/U/colour toolbar with app-matched swatches, spectrum and custom HEX/HSV picker. Optional validated per-character runs round-trip in v1 project JSON, PPTX native text and PDF rendering; old plain-text v1 projects still load. Notes/Test author text is visual by default, with explicit source mode for Notes tables/formulas. `../TEMPLATES-AND-VIDEO-GUIDE-HINDI.md` describes earlier editable templates, ratios, deterministic pagination and lecture player. Verification in `audit/presentation-design/verification.json` and the original-release results below is historical; latest local run: **202/202 unit tests**, full check, **135 browser tests passed / 1 intentionally skipped / 0 failed** (fixture Chromium, **not** a real phone/PowerPoint desktop app or live backend).

## Where to find it
Admin → **Presentation & PDF Studio** (`/admin/document-studio`). It is also available through the admin command/search bar. The existing authenticated admin route verifies the admin role before opening the studio; ordinary student accounts are redirected away.

The studio contains three tabs, retaining their state while switching between them. Documents are processed in the browser. File contents are not uploaded to an external conversion service or stored in Supabase by these tools. Normal application login/settings requests still occur.

## Presentation Studio

### Custom Canva pamphlet → editable PPTX (new simple mode)
First card in Presentation Studio: upload one Canva **PDF Standard** (1–12 pages) or up to 12 PNG/JPG/WEBP images (25 MB combined, 12 MB per image), choose which page is the blank teaching template, optionally keep all originals at the front, paste lesson text with `#` headings, reserve header/footer space with two sliders, preview a generated slide, then download `.pptx` and a `.kkcc-presentation.json` backup. Original page artwork is fitted rather than cropped when ratios differ; a warning prompts margin review. The first page sets the deck ratio (supports portrait 3:4, 4:3, etc.). No files are uploaded to a conversion API. Long text is paginated automatically; size/slide limits show an actionable error without replacing the existing Studio project. The user can explicitly open the result in the detailed editor, which asks before replacing a dirty project. Phone users can download via the browser or use the native share sheet when file sharing is available.

Uploaded PDF/images become **replaceable flattened artwork image layers**, including any preprinted logo, name or footer; no OCR is performed. New titles/body and optionally separate brand name/footer are real editable PowerPoint text objects, and the separate KKCC logo is a replaceable image. Do not claim that pre-existing printed words inside uploaded imagery are individually editable, or that arbitrary Canva `.pptx` decks import. The exported PDF is still raster. Source artwork stays local to the current tab; export the JSON project for future editing. This wizard does not write to Supabase or require new SQL.

Verification for this enhancement: `tests/unit/custom-pamphlet.test.ts` (five cases on ratio, pagination, branding, immutability, hard limits), `tests/e2e/custom-pamphlet.spec.ts` (local-fixture PDF and image uploads, mobile width, generated PPTX native XML shapes, saved project unchanged until explicit editor action, unsupported PPTX rejection). This browser validation uses Chromium/fixture data, not a physical phone or native desktop PowerPoint; PNG/PDF import quality and font layout should be checked on the owner's device before publishing student materials.

Implemented:
- Title, lesson, quiz and blank slide templates; original KKCC branding.
- Add, duplicate, reorder and delete slides; up to 25-state undo/redo (approximate 32 MB image/text history budget).
- Editable text boxes, JPG/PNG pictures, rectangles and ellipses.
- Drag objects, edit their percentage position/size, change text size/bold/alignment/colour, background and shape fill; bring forward/send backward; delete objects.
- Speaker notes and presentation mode with Previous/Next, arrow/PageUp/PageDown keys, optional browser fullscreen and colour-inverted viewing.
- **Invert slide colours** modifies the current slide's background/text/shapes/pictures; branding stays unchanged. Undo restores the previous version. Text stays editable in PPTX.
- **Optimise pictures** reduces oversized pictures to smaller JPEG data where it is actually smaller. Transparency may become white and detail can decrease; confirmation is required.
- **Save editable project** downloads `.kkcc-presentation.json`; reopen it later or merge another studio project. Save projects before leaving. A route/refresh/close warning protects unsaved changes, but this is not cloud autosave.
- **Export PowerPoint** produces a ZIP-compressed, editable `.pptx` with slide objects and speaker notes.
- **Export slide PDF** creates image-based PDF pages, and can open the result immediately in KKCC Reader. This PDF does not contain searchable text. The editable source remains the project/PPTX.

Limits: 60 slides, 40 objects per slide, approximately 24 MB of image/text data per project; imported project file under 30 MB. Images: JPG/PNG, under 12 MB and 40 megapixels, resized to at most 1600 pixels on the longest edge. Objects must fit inside the slide; overflowing text is visibly clipped, so enlarge its box or reduce the font size before exporting. Local Noto Gurmukhi/Devanagari fonts support Punjabi/Hindi preview and raster export. PPTX font availability in the receiving presentation app can change layout; fonts are not embedded into PPTX.

**Not included:** importing arbitrary existing `.ppt`/`.pptx` decks, animated transitions, video/audio, SmartArt, complex charts, Office macros, DOCX/XLSX editing, collaborative/cloud editing, or full PowerPoint feature parity. Merge applies to studio project files, not arbitrary PPTX files.

## PDF Tools
| Tool | Working output / important behaviour |
|---|---|
| Merge | Multiple PDFs combined in chosen file order; Up/Down controls reorder inputs. |
| Extract / reorder | Enter `3,1-2` or a descending range such as `5-1`. Blank selects all pages. |
| Split | ZIP containing a separate PDF for each page. |
| Delete pages | Removes specified pages; deleting every page is rejected. |
| Reverse | Reverses the whole document's page order. |
| Rotate | Applies 90/180/270 degrees to selected pages. Duplicate page numbers rotate once. |
| Watermark | Draws a translucent text stamp on selected pages; 1–80 ASCII/English characters. |
| Optimise | Resaves without rasterising text/vector content; returns original bytes if the candidate is not smaller. |
| Compress scanned PDF | Renders pages as JPEG images at Small/Balanced/High settings. Shows actual input/output sizes; output may be larger for text-heavy PDFs. |
| Invert colours | Creates an image-based PDF with RGB colours inverted, including black/white inversion. |
| Images to PDF | JPG/PNG images fitted to A4 pages. |
| PDF to images | ZIP of PNG page images. |

Outputs are explicit downloads; PDFs can be opened in the built-in reader immediately. Original local files are never overwritten. Image-based operations require acknowledgement: searchable text, links, form fields and digital signatures do not survive rasterisation. Other page-editing operations may also lose interactive forms/bookmarks or invalidate signatures; keep originals. This is not a secure-redaction tool or an archival/PDF-A validator.

Limits: 40 MB per PDF; merge up to 20 PDFs / 120 MB / 500 pages. Structural operations: at most 500 pages. Split ZIP: 100 pages. Raster compress/invert: 100 pages. PDF-to-PNG: 50 pages. ZIP/image output is bounded to 120 MB for split/image conversion. Images-to-PDF: up to 50 images. Very large pages are capped at 12 million rendered pixels; work in smaller batches on mobile. Cancellation prevents publishing/downloading a partial result and completes the current processing step safely.

Protected PDFs can be read with their password; editing needs an unlocked copy obtained with the owner's permission. The tools do not bypass encryption. OCR, Word/Excel conversion, arbitrary PDF text editing, e-signatures, encryption creation and iLovePDF feature parity are **not** included.

## KKCC PDF Reader
Local PDF opening, page thumbnails (12-page groups), page selector, Previous/Next, zoom, rotation, colour-inverted view, text search (up to 100 matching pages), fullscreen where browser permissions allow, password opening, original download and print-current-page. Rendering and font/decoder resources are locally hosted; the reader does not run document scripts or open embedded PDF links.

Search requires embedded text; scanned images need OCR, not included here. Viewer invert/rotation do not change the original download. Print-current-page is an image of the rendered page using normal colours; exporting permanently inverted/rotated documents is done in PDF Tools. This release adds the reader to the **admin workspace**; existing student PDF/access flows are not replaced.

## Verification
- **154 unit tests passed**, including page-range validation, PDF merge/extract/delete/reverse/rotate/watermark, no-growth optimisation, slide/project schemas, Unicode, unique IDs, unsafe image rejection and colour inversion.
- **14 targeted browser E2E tests passed together**: six Document Studio workflows plus existing login/session, notes editing/language and series/access regressions. The six studio tests passed again after final unsaved-navigation protection and UI cleanup.
- Studio tests inspect downloaded PDF page counts/geometry/rotation, ZIP entries/PNG signatures, generated PPTX slide XML/Unicode and speaker notes, project reopening/merge, pictures, inversion, undo/redo, slide mode, mobile overflow, actual reader canvases/search/thumbnails, encrypted reading, protected editing rejection, invalid files, cancellation and navigation guard.
- Original and inverted PDF canvas pixels were checked; inversion output was opened in the app reader.
- TypeScript and production build passed. Lint: 0 errors, 12 existing warnings. Existing >500 KB build chunk warning remains. Studio widgets are lazy-loaded on the admin route.
- `npm audit --omit=dev`: 0 reported production dependency vulnerabilities at verification time. `image-size` is overridden to patched 2.0.4 for the PPTX dependency.
- Synthetic exports/screenshots: `docs/audit/document-studio/`. The password fixture in tests is a synthetic demo, not a private/customer document.
- Tests used Chromium and local fixture data. Native desktop PowerPoint/LibreOffice, Safari/Firefox, physical mobile devices/printers, every possible PDF, and maximum-size memory stress were not certified. Native `.pptx` rendering may vary by installed fonts.

## Deployment / SQL
No new SQL, no cleaner, no database reset. Existing accounts, access grants, payments, notes and test flows are preserved. Install with `npm ci`, build with `npm run build`; the new prebuild copies pinned PDF.js local CMap/font/decoder assets with their licences. The Node production server now serves `.mjs` workers and `.wasm` with correct MIME types. Noto fonts are bundled from their licensed Fontsource packages. Do not remove public/pdf-engine assets when deploying.

This coding session did not push, merge or deploy to GitHub/production. Delivery is the updated full ZIP and a download-only server.
