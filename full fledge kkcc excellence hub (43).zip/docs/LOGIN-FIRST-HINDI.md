# Login-first app flow

- Bina valid local Supabase session, app ke Home, Notes, Courses, Tests, Checkout, Dashboard, Admin aur unknown routes Login par redirect hote hain. Root route guard child loaders se pehle chalta hai.
- Root SSR disabled hai because existing Supabase session browser storage mein hai. Session resolve hone tak neutral loading screen hai; protected page ya login form ka flash avoid hota hai.
- Login aur active-session signup ke baad `/` Home khulta hai. Old `redirectTo`/non-recovery callback `next` ab initial destination override nahi karte.
- Logged-in user `/login`, `/signup`, `/forgot-password` par jaye to Home redirect hota hai. Uske baad normal app navigation available hai.
- Email confirmation required ho to account creation alone login nahi hai: user must confirm email and obtain a session.
- `/auth/callback` and `/reset-password` are deliberate exceptions, so verification/token exchange/recovery are not blocked. Recovery stays on Reset Password, not Home.
- Live auth-state gate hides old route content on sign-out; existing query cache clearing and role/payment authorization remain. This is an app navigation gate, not a replacement for API/RLS authorization or a database privacy migration.
- No new SQL, production account changes or production data deletion.

## Verification
133 unit tests passed; TypeScript and targeted ESLint passed. Six targeted browser tests passed: guest restrictions, login/session/back/logout across tabs/role checks, signup, email/recovery callbacks, multilingual notes and subject/chapter notes. Production-build fixture uses disposable local accounts, not live cloud credentials. Older browser tests that intentionally browse guest catalogues need signed-in fixtures under this new policy.

## Delivery
Changes are local. Closed coding session cannot push to GitHub; use a new coding session to review/apply the feature patch to latest main and deploy. `login-first-update.patch` is based on the current workspace immediately before this feature, including preceding notes/navigation updates; apply those first if absent. Do not overwrite unrelated newer main changes with a full workspace ZIP.
