# Subject → Chapter → Notes (additional view)

## Admin
Admin → Materials → **Subject → Chapter → Notes**.
1. Existing subject choose karein, ya New notes subject type → Continue to chapters.
2. Existing chapter choose karein, ya New notes chapter type → Continue to notes.
3. Add note in this chapter. A saved draft opens with subject/chapter prefilled.
4. Title/body, Hindi/Punjabi typing, diagrams, files, price/access and Published set karke Save changes.
5. Existing note name select karne se editor opens. Edit, Free/Paid, Publish/Unpublish and confirmed Delete remain available. Subject/Chapter fields edit karke individual note ko doosre group mein move kar sakte hain.

Empty subject/chapter names are draft navigation until a first note is saved. This feature does not persist empty folders or offer destructive bulk folder deletion/rename; groups derive from the actual note metadata. Deleting the last note removes that empty group from navigation. Unassigned old notes remain under Unassigned subject/chapter.

## Student
Study Material → **Subject → Chapter → Notes** → subject → chapter → note → existing Read Notes/checkout controls. Only published catalogue entries are used; paid/course content still uses the existing server authorization. Students get no add/edit/delete controls. Same chapter names under different subjects remain separate.

## Compatibility and verification
- **All notes — existing view** remains the default for both admin and student. Old search, cards, reader, print/PDF, thumbnails and access rules remain.
- Existing subject/chapter metadata is reused; note bodies still use the existing Supabase Storage save flow. **No new SQL required.** No cloud data was deleted or migrated.
- Dedicated browser tests pass for create/draft hiding/publish/student reading/edit/reload/paid gate/delete cancellation/deletion/mobile width, plus previous language typing feature.
- Use the language patch first, then navigation patch if applying outside this workspace. Each patch is feature-scoped to avoid overwriting unrelated work in newer main-branch code. Start a new coding session to apply/review/push to GitHub; this session is closed for remote operations.
