# KKCC performance audit and targeted refactor

## Scope and evidence
A static inventory scanned **358 TypeScript source files** for timers, listeners, object URLs, list rendering and broad projections. Hot paths were reviewed manually: public catalogues, learning/checkout, notes readers/admin editor, quiz and formal test timers, providers, protection/PWA lifecycles, and media components. This is not a claim that every component was runtime-profiled or that every device now sustains 60 FPS.

Audit evidence:
- `docs/audit/performance-refactor/source-inventory.json`
- `docs/audit/performance-refactor/catalog-measurement.json`
- `docs/audit/kkcc-future/constrained-device.json`

## Findings and implemented fixes
| Finding | Refactor |
|---|---|
| Entire quiz question UI updated every timer second | Countdown state moved into small leaf components. Only expiry updates the quiz parent; deadline-based timing catches up after backgrounding. |
| Formal test page recalculated questions on clock ticks | Isolated `AttemptClock`; parent receives only question-window changes/expiry. Question projection memoized. Existing server deadline, answer revision, scoring and submission handlers retained. |
| All cards mounted simultaneously | Accessible page controls bound public notes, dashboard notes, admin notes, course discovery/catalogue, batches and available tests to 24 items; discovery series to 12 per group; question palette to 100. All results remain reachable, filtering resets to page one, question numbers remain absolute. Existing enrolled shelves stay uncapped and near the top. |
| Notes catalogue hydrated every free body, resolved media and duplicated text in HTML data URLs | New metadata-only `listPublicMaterialCards` explicitly selects display columns. `getPublicMaterialBody` loads one published FREE note on request and rejects paid/course/unpublished records. Main library, dashboard library, public learning loader, global search and checkout use metadata. Existing protected paid-note handler remains authoritative. |
| Closed readers still analysed diagrams/rendered HTML | Analysis and body rendering are gated behind reader opening. Admin preview uses deferred text and memoized HTML so unrelated form controls don't regenerate the preview. |
| Every mounted paid-note card polled every 15 seconds | Closed cards no longer poll. Initial access lookup remains; explicit open rechecks access, open readers retain 15-second verification. Protected access data is not given the public catalogue's freshness policy. |
| Repeated public-loader requests | Shared QueryClient catalogue keys across Home/Courses/Classes/Learn/Notes; 60-second public metadata freshness. No global caching policy change for payment, auth or attempt loaders. Existing identity-change cache clearing preserved. |
| Website-content provider rebuilt context and rewrote localStorage | Normalization/context value memoized. Course-card memoization and stable enrolled-course sorting reduce unrelated rerenders. Search/filter work is deferred in primary catalogues. |
| Stats endpoint fetched educational content just to count rows | Fetches only IDs/status/course relationships/publication flags, not note bodies, video URLs or course syllabus. |
| Screenshot-guard timeout outlived component | Timer now retained, replaced and cleared during cleanup. Clock listeners/intervals clean up on unmount. Existing correctly cleaned PWA/install/canvas listeners preserved. |
| Printing allocated unreclaimed blob URLs | Print document is written to its own detached-opener tab; no retained object URL. Popup-blocked feedback added. |
| Slow catalogue loads appeared blank | Lightweight six-card skeletons for public catalogue routes; explicit note-body loading/error/retry feedback; PDFs lazy-mounted/loaded in the reader. |

## Measured local workload
A disposable fixture added 120 free notes with **1,949,400 bytes of raw body content**.
- Filtered grid mounted **24** note cards, not 120 (80% fewer mounted matching cards).
- Catalogue response was **163,216 bytes**, including other fixture notes, with none of the seeded body marker. Raw body bytes and serialized catalogue bytes are different measurements—not an exact before/after transfer benchmark.
- Last item remained reachable through filtering; page two showed 25–48.
- Body was fetched only after explicit open, and print output retained its text.
- Returning via client-side navigation while fresh made no new catalogue request.
- Exam clock advanced while the selected answer remained stable and submission succeeded.
- Existing 4x CPU / 150ms / 200KB/s Chromium simulation and 320–2560px checks passed again.

## Verification
- **138 unit tests passed**, including new bounded-grid, absolute-index and clock-format tests.
- **17 targeted browser tests passed together on the final implementation**: login/logout/roles, search cache, constrained-device mode, responsive themes, file-backed note migration/read/edit/free/paid gates, language input, notes navigation, large-list/payload/cache/print behavior, clock/answers, logo splash/day-night text, exam results.
- Earlier broad run: 83 passed, one test failed because it assumed guest checkout despite login-first. Its setup was corrected to authenticate, and it passed separately. That run exercised dozens of existing exam-bank learning flows and retention. It is not represented as a final full-suite run.
- An older note-storage test also assumed guest library access and exact punctuation stripped by the existing renderer; its assertions/setup were corrected without changing auth or renderer behavior. It now passes with free/paid checks intact.
- TypeScript passed. Full lint: **0 errors, 12 pre-existing Fast Refresh warnings**.
- Production build passed; existing chunk-size/plugin timing warnings remain.
- No live payment, production cloud Storage, SQL migration or production traffic benchmark was performed.

## Important behavior and remaining limits
- Catalogue search now searches metadata (title/subject/chapter), not every downloaded note body. Full text remains in the reader. A scalable server-side full-text index for Storage bodies is a separate project, not faked by downloading everything again.
- An unopened free PDF is resolved when its reader opens; the original PDF is unchanged. A first Print/PDF action on an unloaded card opens the reader; printing is enabled after the body arrives, avoiding blank output.
- Public catalogue freshness is up to 60 seconds; a full reload requests fresh data. Paid authorization is checked separately. Not all admin mutations invalidate every public route cache immediately.
- Pagination bounds the DOM, not the metadata dataset: catalogues still fetch all relevant metadata to preserve existing client-side filtering. Very large installations need server-side cursor pagination/search. Admin forms and enrolled shelves are not universally virtualized.
- Admin/course-specific endpoints that require complete editable records still return those records. The legacy `listPublicMaterials` API remains for compatibility; the main student entry points moved off it.
- User PDFs/uploads were not recompressed or altered. Existing lazy images, upload compression, dynamic exam-bank/template loading and reduced-motion/lite styles remain; no heavy animation dependency added.
- Very large single-note rendering, enormous saved-result reviews and large quiz-bank bundles may still be expensive. These should be profiled on the user's actual device/catalogue before further worker/code-splitting changes.
- Chromium emulation is not physical iOS/Safari/Firefox testing, a React Profiler trace, or a 60-FPS/zero-lag guarantee. Hosting, network and dataset size still matter.

## Delivery
No new SQL, schema or RLS changes; existing migrations are not rerun. No existing students/payments/attempts/content deleted. Local fixture records used by the workload test were removed in `finally`.

`kkcc-performance-refactor.patch` is incremental against the immediately preceding local revision. The ZIP includes the accumulated workspace, not a fresh remote-main export. This session is closed for GitHub operations: no push, PR or deployment was attempted. Review/integrate in a new coding session.
