-- Reversible admin-only list hiding. Never delete a coupon redemption or revoke
-- an access grant when an administrator removes it from a recent-history list.
BEGIN;

ALTER TABLE public.coupon_redemptions
  ADD COLUMN IF NOT EXISTS admin_hidden_at timestamptz;
ALTER TABLE public.series_access_grants
  ADD COLUMN IF NOT EXISTS admin_hidden_at timestamptz;

CREATE INDEX IF NOT EXISTS idx_coupon_redemptions_visible_created_at
  ON public.coupon_redemptions (created_at DESC)
  WHERE admin_hidden_at IS NULL;
CREATE INDEX IF NOT EXISTS idx_series_access_grants_visible_created_at
  ON public.series_access_grants (created_at DESC)
  WHERE admin_hidden_at IS NULL;

COMMENT ON COLUMN public.coupon_redemptions.admin_hidden_at IS
  'Admin-only reversible list hiding; preserves redemption history, usage count and granted access.';
COMMENT ON COLUMN public.series_access_grants.admin_hidden_at IS
  'Admin-only reversible list hiding; does not revoke or change the access grant.';

COMMIT;
