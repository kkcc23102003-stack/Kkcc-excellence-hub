-- Store the custom test-series catalogue as an immutable private JSON object.
-- The Database settings row becomes a short versioned Storage pointer.
BEGIN;

INSERT INTO storage.buckets (id, name, public, file_size_limit, allowed_mime_types)
VALUES (
  'kkcc-test-series-catalog',
  'kkcc-test-series-catalog',
  false,
  20971520,
  ARRAY['application/json']
)
ON CONFLICT (id) DO UPDATE
SET public = false,
    file_size_limit = 20971520,
    allowed_mime_types = ARRAY['application/json'];

DO $$
BEGIN
  IF EXISTS (
    SELECT 1 FROM storage.buckets
    WHERE id = 'kkcc-test-series-catalog' AND public
  ) THEN
    RAISE EXCEPTION 'kkcc-test-series-catalog must remain PRIVATE';
  END IF;
END $$;

DROP POLICY IF EXISTS kkcc_test_series_catalog_server_only ON storage.objects;
CREATE POLICY kkcc_test_series_catalog_server_only
  ON storage.objects AS RESTRICTIVE
  FOR ALL TO anon, authenticated
  USING (bucket_id <> 'kkcc-test-series-catalog')
  WITH CHECK (bucket_id <> 'kkcc-test-series-catalog');

-- Compare the old catalogue hash inside PostgreSQL instead of putting a large
-- legacy JSON value in a PostgREST filter URL. Only service_role may update this
-- one pointer row; a failed compare-and-swap leaves the old value untouched.
CREATE OR REPLACE FUNCTION public.move_test_series_catalog_pointer(
  p_old_md5 text,
  p_new_value text
) RETURNS boolean
LANGUAGE plpgsql SECURITY DEFINER SET search_path = public, pg_temp AS $$
DECLARE changed integer;
BEGIN
  IF auth.role() IS DISTINCT FROM 'service_role' THEN
    RAISE EXCEPTION 'Server only';
  END IF;
  IF p_old_md5 IS NULL OR p_old_md5 !~ '^[a-f0-9]{32}$'
     OR p_new_value IS NULL OR p_new_value NOT LIKE 'kkcc-storage-json:v1:%' THEN
    RAISE EXCEPTION 'Invalid test-series Storage pointer';
  END IF;
  UPDATE public.kkcc_site_settings
  SET value = p_new_value, updated_at = clock_timestamp()
  WHERE key = 'test_series_custom_catalog'
    AND md5(coalesce(value, '')) = p_old_md5;
  GET DIAGNOSTICS changed = ROW_COUNT;
  RETURN changed = 1;
END;
$$;
REVOKE ALL ON FUNCTION public.move_test_series_catalog_pointer(text, text) FROM PUBLIC, anon, authenticated;
GRANT EXECUTE ON FUNCTION public.move_test_series_catalog_pointer(text, text) TO service_role;

NOTIFY pgrst, 'reload schema';
COMMIT;
