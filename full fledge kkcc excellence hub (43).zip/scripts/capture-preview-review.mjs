// Local fixture only: actual production-build pages at phone/desktop widths.
// Usage: PORT=4600 PLAYWRIGHT_CHROMIUM_EXECUTABLE_PATH=/path/to/chromium node scripts/capture-preview-review.mjs
// Requires a running `npm run test:fixture` fixture; never contacts production.
import { chromium } from "@playwright/test";
import { mkdirSync, writeFileSync } from "node:fs";
import { resolve } from "node:path";

const base = `http://127.0.0.1:${process.env.PORT || "4600"}`;
const out = resolve("docs/audit/visual-gate");
mkdirSync(out, { recursive: true });
const browser = await chromium.launch({
  ...(process.env.PLAYWRIGHT_CHROMIUM_EXECUTABLE_PATH
    ? { executablePath: process.env.PLAYWRIGHT_CHROMIUM_EXECUTABLE_PATH }
    : {}),
  headless: true,
  args: ["--no-sandbox", "--disable-dev-shm-usage"],
});
const checks = [];
async function capture(page, path, name, viewport, scrollTo) {
  await page.setViewportSize(viewport);
  if (new URL(page.url()).pathname !== path) {
    await page.goto(base + path, { waitUntil: "domcontentloaded" });
  }
  await page.waitForFunction(
    () =>
      !document.querySelector('[data-testid="session-splash"]') &&
      document.body.innerText.length > 100,
    null,
    { timeout: 20_000 },
  );
  if (scrollTo) await page.getByRole("button", { name: scrollTo }).scrollIntoViewIfNeeded();
  await page.evaluate(() => document.fonts.ready);
  const state = await page.evaluate(() => ({
    width: innerWidth,
    scrollWidth: document.documentElement.scrollWidth,
    heading: document.querySelector("h1")?.textContent?.trim() || "",
  }));
  checks.push({ name, path, viewport, ...state });
  await page.screenshot({ path: resolve(out, `${name}.png`), animations: "disabled" });
}
async function signIn(page, email) {
  await page.goto(base + "/login");
  await page.getByLabel("Email", { exact: true }).fill(email);
  await page.getByLabel("Password", { exact: true }).fill("FixturePass123!");
  await page.getByRole("button", { name: /Sign in|Login|Log in/i }).click();
  await page.waitForURL((url) => !url.pathname.endsWith("/login"));
  await page.waitForFunction(
    () =>
      !document.querySelector('[data-testid="session-splash"]') && !!document.querySelector("h1"),
    null,
    { timeout: 20_000 },
  );
  await page.waitForTimeout(200); // Let the login redirect finish before capturing a second route.
}
try {
  const desktop = { width: 1440, height: 900 };
  const phone = { width: 390, height: 844 };
  const publicPage = await browser.newPage({ viewport: desktop });
  await capture(publicPage, "/login", "guest-login-desktop", desktop);
  await publicPage.close();
  const student = await browser.newPage({ viewport: phone });
  await signIn(student, "studenta@fixture.invalid");
  await capture(student, "/", "student-home-desktop", desktop);
  await capture(student, "/test-series", "student-tests-phone", phone);
  await capture(student, "/dashboard", "student-home-phone", phone);
  await capture(student, "/dashboard/materials", "student-notes-phone", phone);
  await student.close();
  const admin = await browser.newPage({ viewport: desktop });
  await signIn(admin, "admin@fixture.invalid");
  await capture(admin, "/admin", "admin-home-desktop", desktop);
  await capture(admin, "/admin/materials", "admin-materials-phone", phone);
  await capture(
    admin,
    "/admin/document-studio",
    "admin-studio-phone",
    phone,
    "Save editable project",
  );
  await capture(
    admin,
    "/admin/document-studio",
    "admin-studio-desktop",
    desktop,
    "Save editable project",
  );
  await admin.close();
  writeFileSync(resolve(out, "review-checks.json"), JSON.stringify(checks, null, 2) + "\n");
  console.log(JSON.stringify(checks, null, 2));
  if (checks.some((check) => check.scrollWidth > check.width + 2)) {
    console.error("Horizontal viewport overflow detected; inspect screenshots.");
    process.exitCode = 1;
  }
} finally {
  await browser.close();
}
