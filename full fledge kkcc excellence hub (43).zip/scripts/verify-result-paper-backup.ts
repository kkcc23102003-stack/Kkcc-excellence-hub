#!/usr/bin/env -S npx tsx
/**
 * Offline-only, read-only result-paper backup check. No SDK, network call,
 * deletion, exported student data, or write to the source tree.
 *
 * Usage: npx tsx scripts/verify-result-paper-backup.ts \
 *   --manifest /private/attempt-papers.ndjson \
 *   --bucket /private/kkcc-result-papers --expected 42
 *
 * An operator must independently compare --expected to a count from the SAME
 * consistent restored backup; this tool cannot prove export completeness or
 * authenticate historical papers that never had a snapshot.
 */
import { constants, createReadStream } from "node:fs";
import { lstat, open, realpath } from "node:fs/promises";
import { resolve, dirname, join, sep } from "node:path";
import { createInterface } from "node:readline";
import { fileURLToPath } from "node:url";
import {
  MAX_RESULT_PAPER_BYTES,
  assertPaperMatchesAttempt,
  openResultPaper,
  validateResultPaperReference,
  type ResultPaperReference,
} from "../src/lib/result-paper-store";

const REPOSITORY = resolve(dirname(fileURLToPath(import.meta.url)), "..");
const MAX_MANIFEST_LINE = 1_000_000;
const MANIFEST_KEYS = [
  "attempt_id",
  "bytes",
  "path",
  "question_count",
  "sha256",
  "source_refs",
].sort();

type ManifestRow = ResultPaperReference & {
  question_count: number;
  source_refs: string[];
};
export type OfflinePaperReport = {
  expected_records: number;
  manifest_rows: number;
  verified_rows: number;
  malformed_rows: number;
  duplicate_references: number;
  missing_files: number;
  unsafe_or_unreadable_files: number;
  oversized_files: number;
  corrupt_files: number;
  source_mismatches: number;
  manifest_count_matches: boolean;
  listed_files_verified: boolean;
};

function manifestRow(line: string): ManifestRow | null {
  if (line.length > MAX_MANIFEST_LINE) return null;
  try {
    const value: unknown = JSON.parse(line);
    if (!value || typeof value !== "object" || Array.isArray(value)) return null;
    const row = value as Record<string, unknown>;
    if (JSON.stringify(Object.keys(row).sort()) !== JSON.stringify(MANIFEST_KEYS)) return null;
    if (
      typeof row.attempt_id !== "string" ||
      typeof row.path !== "string" ||
      typeof row.sha256 !== "string" ||
      !Number.isSafeInteger(row.bytes) ||
      !Number.isSafeInteger(row.question_count) ||
      (row.question_count as number) < 1 ||
      !Array.isArray(row.source_refs) ||
      !row.source_refs.every((ref) => typeof ref === "string")
    )
      return null;
    const parsed = row as ManifestRow;
    validateResultPaperReference(parsed);
    return parsed;
  } catch {
    return null;
  }
}

/** Refuse private exports inside (or symlinked into) the source repository. */
async function externalInput(path: string, kind: "file" | "directory") {
  const direct = resolve(path);
  const info = await lstat(direct);
  if (info.isSymbolicLink() || (kind === "file" ? !info.isFile() : !info.isDirectory()))
    throw new Error("Private offline input must be a regular file/directory, not a symlink");
  const real = await realpath(direct);
  const root = await realpath(REPOSITORY);
  if (real === root || real.startsWith(`${root}${sep}`))
    throw new Error("Keep private offline exports outside the source repository");
  return real;
}

async function readPrivateObject(root: string, reference: ResultPaperReference) {
  // The validator above guarantees exactly UUID/UUID.json: no traversal, no
  // nested or arbitrary path. Check the intermediate directory as well as the
  // final object to avoid following symlinks into a different backup.
  const [folder, filename] = reference.path.split("/");
  if (!folder || !filename) throw new Error("Unsafe object path");
  const subdirectory = join(root, folder);
  const directory = await lstat(subdirectory);
  if (!directory.isDirectory() || directory.isSymbolicLink()) throw new Error("Unsafe directory");
  const file = join(subdirectory, filename);
  const info = await lstat(file);
  if (!info.isFile() || info.isSymbolicLink()) throw new Error("Unsafe object");
  if (info.size > MAX_RESULT_PAPER_BYTES) throw new RangeError("Oversized object");
  const handle = await open(file, constants.O_RDONLY | constants.O_NOFOLLOW);
  try {
    const actual = await handle.stat();
    if (!actual.isFile()) throw new Error("Unsafe object");
    if (actual.size > MAX_RESULT_PAPER_BYTES) throw new RangeError("Oversized object");
    return await handle.readFile();
  } finally {
    await handle.close();
  }
}

/** Counts only; no paths, IDs, answers, or exception contents are returned. */
export async function verifyOfflinePaperBackup(options: {
  manifest: string;
  bucket: string;
  expected: number;
}): Promise<OfflinePaperReport> {
  if (!Number.isSafeInteger(options.expected) || options.expected < 0)
    throw new Error("Provide a non-negative expected record count from the restored backup");
  const manifest = await externalInput(options.manifest, "file");
  const bucket = await externalInput(options.bucket, "directory");
  const report: OfflinePaperReport = {
    expected_records: options.expected,
    manifest_rows: 0,
    verified_rows: 0,
    malformed_rows: 0,
    duplicate_references: 0,
    missing_files: 0,
    unsafe_or_unreadable_files: 0,
    oversized_files: 0,
    corrupt_files: 0,
    source_mismatches: 0,
    manifest_count_matches: false,
    listed_files_verified: false,
  };
  const seenAttempts = new Set<string>();
  const seenPaths = new Set<string>();
  const input = createReadStream(manifest, { encoding: "utf8" });
  const lines = createInterface({ input, crlfDelay: Infinity });
  try {
    for await (const line of lines) {
      if (!line.trim()) continue;
      report.manifest_rows++;
      const row = manifestRow(line);
      if (!row) {
        report.malformed_rows++;
        continue;
      }
      if (seenAttempts.has(row.attempt_id) || seenPaths.has(row.path)) {
        report.duplicate_references++;
        continue;
      }
      seenAttempts.add(row.attempt_id);
      seenPaths.add(row.path);
      let bytes: Buffer;
      try {
        bytes = await readPrivateObject(bucket, row);
      } catch (error) {
        if ((error as NodeJS.ErrnoException).code === "ENOENT") report.missing_files++;
        else if (error instanceof RangeError) report.oversized_files++;
        else report.unsafe_or_unreadable_files++;
        continue;
      }
      try {
        const paper = openResultPaper(bytes, row);
        try {
          assertPaperMatchesAttempt(
            {
              id: row.attempt_id,
              question_count: row.question_count,
              source_refs: row.source_refs,
            },
            paper,
          );
          report.verified_rows++;
        } catch {
          report.source_mismatches++;
        }
      } catch {
        report.corrupt_files++;
      }
    }
  } finally {
    lines.close();
    input.destroy();
  }
  report.manifest_count_matches = report.manifest_rows === options.expected;
  report.listed_files_verified =
    report.manifest_rows > 0 &&
    report.manifest_count_matches &&
    report.verified_rows === report.manifest_rows;
  return report;
}

async function main(args: string[]) {
  if (
    args.length !== 6 ||
    args[0] !== "--manifest" ||
    args[2] !== "--bucket" ||
    args[4] !== "--expected"
  )
    throw new Error(
      "Usage: --manifest <external NDJSON> --bucket <external directory> --expected <count>",
    );
  const expected = Number(args[5]);
  if (!args[1] || !args[3] || !args[5] || !/^\d+$/.test(args[5]))
    throw new Error("Supply offline input paths and a non-negative integer expected count");
  const report = await verifyOfflinePaperBackup({ manifest: args[1], bucket: args[3], expected });
  console.log(
    JSON.stringify(
      {
        ...report,
        scope: "listed offline snapshots only; not historical backfill or release approval",
      },
      null,
      2,
    ),
  );
  if (!report.listed_files_verified) process.exitCode = 1;
}

if (process.argv[1] && fileURLToPath(import.meta.url) === resolve(process.argv[1]))
  void main(process.argv.slice(2)).catch(() => {
    console.error(
      "Offline verification did not complete. Check private inputs; no data was changed.",
    );
    process.exitCode = 2;
  });
