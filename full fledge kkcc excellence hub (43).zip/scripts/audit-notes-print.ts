// Run with: PLAYWRIGHT_CHROMIUM_EXECUTABLE_PATH=/path/to/chromium npx tsx scripts/audit-notes-print.ts
// Generates a synthetic multi-page PDF, not student/private content.
import { chromium } from "playwright";
import { mkdirSync } from "node:fs";
import { notesPrintDocument } from "../src/lib/notes-visuals";
const folder = "docs/audit/notes-office";
mkdirSync(folder, { recursive: true });
const text =
  Array.from(
    { length: 180 },
    (_, i) =>
      `Audit line ${String(i + 1).padStart(3, "0")}: This paragraph must stay below the repeated coaching header and above the footer.`,
  ).join("\n") +
  "\n:::table\nTerm\tDefinition\n" +
  Array.from(
    { length: 40 },
    (_, i) => `Table row ${i + 1}\tA preserved table cell on the printed page.`,
  ).join("\n") +
  '\n:::\n[mark]End of audit[/mark]\n:::visuals {"mode":"none"}\n:::';
const executablePath = process.env["PLAYWRIGHT_CHROMIUM_EXECUTABLE_PATH"];
const browser = await chromium.launch({
  ...(executablePath ? { executablePath } : {}),
  args: ["--no-sandbox", "--disable-dev-shm-usage"],
});
try {
  const page = await browser.newPage();
  await page.setContent(notesPrintDocument({ title: "Notes Print Layout Audit", text }));
  await page.evaluate(async () => {
    await document.fonts.ready;
    await Promise.all(Array.from(document.images).map((image) => image.decode()));
  });
  await page.pdf({
    path: `${folder}/print-layout.pdf`,
    preferCSSPageSize: true,
    printBackground: true,
    displayHeaderFooter: false,
  });
  console.log(
    `Generated ${folder}/print-layout.pdf. Validate with scripts/check-notes-print.py (requires PyMuPDF).`,
  );
} finally {
  await browser.close();
}
