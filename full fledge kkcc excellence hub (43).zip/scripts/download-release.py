"""Serve only release downloads, never the app, source tree or private configuration."""
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from urllib.parse import quote, unquote
import os
import shutil

ROOT = Path(__file__).resolve().parents[1]
ZIP = 'full fledge kkcc excellence hub.zip'
PAMPHLETS = 'KKCC editable reference pamphlets.zip'
FILES = {ZIP, PAMPHLETS, 'START-HERE-REFERENCE-UPDATE-HINDI.txt', 'DOCUMENT-STUDIO-GUIDE-HINDI.md', 'SQL-UPDATE-STATUS.txt', 'KKCC-Excellence-Hub-PRODUCTION-SQL.sql', 'KKCC-Excellence-Hub-HISTORY-STORAGE.sql', 'KKCC-Excellence-Hub-EDUCATIONAL-STORAGE.sql', 'KKCC-Excellence-Hub-SQL-CLEANER.sql'}

class DownloadHandler(BaseHTTPRequestHandler):
    def do_HEAD(self):
        self.serve(False)

    def do_GET(self):
        self.serve(True)

    def serve(self, body):
        path = unquote(self.path.split('?')[0]).lstrip('/')
        if not path:
            html = '''<!doctype html><html lang="en"><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>KKCC ZIP Download</title><style>body{margin:0;background:#f4f8f6;color:#173f30;font:17px system-ui;display:grid;min-height:100vh;place-items:center}main{box-sizing:border-box;width:min(590px,94%);background:white;border:1px solid #d9e4de;border-radius:20px;padding:32px}h1{font-size:28px}.download{display:block;margin:24px 0;background:#126a48;color:white;font-weight:700;text-align:center;text-decoration:none;padding:20px;border-radius:12px}p{line-height:1.6}small{overflow-wrap:anywhere}details a{display:block;padding:10px;color:#126a48}</style><main><h1>KKCC — ZIP downloads</h1><p><strong>New in the full app ZIP:</strong> Admin → Document Studio → Presentation Studio mein Canva PDF Standard / JPG / PNG design upload karein, teaching page choose karein, lesson text paste karein, preview dekhein aur editable-text PPTX phone par download karein. Top logo/name aur bottom footer artwork mein preserved; uploaded printed text picture rahega, naya lesson text editable. Full ZIP deploy karne ke baad feature app mein milega; yah page sirf downloads ke liye hai.</p><p>PowerPoint mein reference designs edit karne hain? Pehli ZIP extract karein, included fonts install karein, aur KKCC-reference-editable.pptx open karein.</p><a class="download" href="/pamphlets" download="KKCC editable reference pamphlets.zip">⬇ Download editable pamphlets</a><p><strong>Website mein change chahiye?</strong> Neeche wali ZIP mein website ka source code hai. Isko extract karke USI configured Vercel project mein deploy karein; ZIP file ko sirf upload karna site update nahi karta. ZIP download/deploy apne aap koi SQL ya cleaner nahi chalata; existing Supabase data untouched rehta hai. Is release mein optional additive history/Storage SQL hai—pehle backup aur schema review karein; sirf padhkar intended migration apply karein. Browser-only draft ka JSON backup pehle download karein; naye templates purani slides intact rakhte hain.</p><a class="download" href="/download" download="full fledge kkcc excellence hub.zip">⬇ Download full updated app ZIP</a><small>full fledge kkcc excellence hub.zip (Canva wizard + earlier editable reference designs)</small><p>Deploy ke baad: Admin → Document Studio → Presentation Studio → Load both reference templates (keep old slides). Do naye slides end mein add honge, purane unchanged. Project ko Save editable project se download karein.</p><p><a href="/DOCUMENT-STUDIO-GUIDE-HINDI.md">Canva custom pamphlet: step-by-step Hindi guide</a> · <a href="/START-HERE-REFERENCE-UPDATE-HINDI.txt">Same Vercel project safe update + purana data backup</a></p><p><strong>Download only — no app preview.</strong></p><p>Do not run the cleaner. For existing projects, apply the additive history/Storage migration only after backup and schema review; no migration ran automatically.</p><details><summary>SQL files / setup status</summary><a href="/SQL-UPDATE-STATUS.txt">SQL update status</a><a href="/KKCC-Excellence-Hub-HISTORY-STORAGE.sql">Additive history + Storage SQL</a><a href="/KKCC-Excellence-Hub-EDUCATIONAL-STORAGE.sql">Educational bucket and policy repair SQL</a><a href="/KKCC-Excellence-Hub-PRODUCTION-SQL.sql">Production SQL (fresh setup / reviewed cutover only)</a><a href="/KKCC-Excellence-Hub-SQL-CLEANER.sql">Existing Cleaner — do not run for this update</a></details></main></html>'''.encode()
            self.send_response(200)
            self.send_header('Content-Type', 'text/html; charset=utf-8')
            self.send_header('Content-Length', str(len(html)))
            self.send_header('Cache-Control', 'no-store')
            self.end_headers()
            if body:
                self.wfile.write(html)
            return
        name = ZIP if path == 'download' else PAMPHLETS if path == 'pamphlets' else path
        if name not in FILES or not (ROOT / name).is_file():
            self.send_error(404)
            return
        file = ROOT / name
        self.send_response(200)
        self.send_header('Content-Type', 'application/zip' if name.endswith('.zip') else 'application/octet-stream')
        self.send_header('Content-Disposition', "attachment; filename*=UTF-8''" + quote(name))
        self.send_header('Content-Length', str(file.stat().st_size))
        self.send_header('Cache-Control', 'no-store')
        self.send_header('X-Content-Type-Options', 'nosniff')
        self.end_headers()
        if body:
            try:
                with file.open('rb') as stream:
                    shutil.copyfileobj(stream, self.wfile)
            except (BrokenPipeError, ConnectionResetError):
                pass

if __name__ == '__main__':
    ThreadingHTTPServer(('0.0.0.0', int(os.environ.get('PORT', '3000'))), DownloadHandler).serve_forever()
