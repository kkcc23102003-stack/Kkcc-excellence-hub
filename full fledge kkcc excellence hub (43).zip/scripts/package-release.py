"""Create a review/source ZIP outside the repository without replacing the historical archive."""
from pathlib import Path
from tempfile import TemporaryDirectory
import hashlib
import json
import os
import re
import subprocess
import zipfile

ROOT = Path(__file__).resolve().parents[1]
# The repository-root ZIP is a historical backup, not this review deliverable.
OUTPUT = ROOT.parent / 'full fledge kkcc excellence hub.zip'
SKIP_DIRS = {'.git', '.cache', '.output', '.tanstack', '.vercel', '.nitro', '.venv', '__pycache__', 'node_modules', 'dist', 'build', 'test-results', 'playwright-report'}
SKIP_FILES = {'tests/fixtures/documents/protected-demo.pdf', 'ZIP-READ-FIRST-HINDI.txt'}  # superseded, damaged synthetic fixture; original local file retained
# These folders contain only generated before/after browser screenshots. None is a
# runtime asset, migration, unit-test fixture or source file. Keep them in the
# working tree; omit the redundant PNG evidence from the distributable source ZIP.
AUDIT_SCREENSHOT_DIRS = {
    'docs/audit/redesign',
    'docs/audit/kkcc-refined',
    'docs/audit/kkcc-professional',
    'docs/audit/kkcc-aesthetic',
    'docs/audit/kkcc-future',
    'docs/audit/visual-gate',
}
GITHUB_WEB_UPLOAD_LIMIT = 25_000_000
READ_FIRST = '''KKCC Excellence Hub — LOCAL SOURCE REVIEW ZIP V46 (19 October 2026)

LATEST STUDY MATERIAL / NOTES CATALOGUE FIX — REVIEW BEFORE DEPLOYING
The student Study Material Notes error was not verified against the live Supabase project. The app reads note cards from managed `kkcc_materials`; migration `20261019160000_managed_notes_free_preview.sql` adds/backfills its missing `is_free_preview` column (and handles projects without legacy `public.materials`). Apply only after backup/schema review. It is additive and does not rewrite note bodies, purchases, grants or unpublished rows.

Large Notes Series and Batch configuration now lives in private Supabase Storage `course-content/notes-catalog/{series|batch}/{UUID}/{sha256}.json`; database settings keep only compact pointers and the small course-to-series Batch index. Trusted server code uses `SUPABASE_SERVICE_ROLE_KEY`; browser roles are explicitly denied SELECT on catalogue paths. Migration `20261019170000_private_notes_catalog_storage.sql` keeps the bucket private and blocks browser-role SELECT on catalogue paths. Existing legacy JSON migrates lazily: upload first, verify by hash, then compare-and-swap the database pointer. A failed upload/CAS leaves the prior DB data authoritative. Old immutable objects are retained to avoid breaking in-flight readers. Existing per-note / Series / Batch purchases and access boundaries remain unchanged. See `docs/KKCC-NOTES-SERIES.md`.

LOCAL VERIFICATION ONLY: TypeScript and production build passed; focused Series/Batch/preview tests 17/17; real-handler local PGlite/Storage fixture `notes-batch-http` passed, including legacy-to-Storage CAS migration and pointer-only DB row. Full unit suite 275/280; five unrelated pre-existing failures remain (private-body/Storage SQL repeatability and note parser edge cases). The actual production Study Material page, live Supabase migration, remote storage, purchases and deployment were NOT verified. No live data changed. Keep `SUPABASE_SERVICE_ROLE_KEY` server-only.

OLDER RELEASE NOTES (historical; dates and test counts below describe earlier changes):
LATEST LOGO-COLOUR / GLOW CORRECTION: neeche Home, Courses, Learn, Notes,
Tests, Quiz ab 6 alag KKCC-logo-inspired, clearly readable colours aur halki
STATIC glow ke saath hain. Active aur keyboard-focus states alag dikhte hain;
320px phone se tablet tak dock fit hota hai. App ke screen-only headers, cards,
shared buttons mein bhi restrained teal/cyan/gold depth hai, bina notes ki
formatting, exam choices, payment ya flow badle.
Kit 2 Coins mein sirf QUESTION ka original colourful gradient NIGHT mode mein
WAPAS hai; DAY mode mein solid readable blue hai. ANSWER choices rainbow NAHIN.
Print ka actual PDF automatically grayscale, black faint centre KKCC logo aur
caption ke saath; student PDF colour mein dekhta hai, mode selector NAHIN.
Local verification: npm run check (0 lint errors / 22 existing warnings),
249/249 unit tests, 26/26 selected Chromium fixture tests, keyboard-focus
rerun 1/1, PWA/SQL source checks pass. Full browser suite, real phone/printer,
live payment/Supabase, SQL migration ya production deploy verify NAHIN hua.
Read docs/audit/LOGO-COLOUR-GLOW-2026-10-17.md.

EARLIER INTERACTIVE COLOUR / SOUND / DARK-FIRST UPDATE: pehli visit par Night
(dark) mode; agar Day choose kiya hai to agali visits par wahi saved rahega.
Phone: menu → Appearance → Day mode. Notes Series ke subject/chapter/topic
cards, exam/quiz choices aur relevant buttons ab filled KKCC colours mein hain;
hover, keyboard focus, disabled, selected aur destructive states alag hain.
Us PURANE pass mein Kit 2 Coins question Day/Night dono mein solid blue tha;
CURRENT release mein Night colourful question aur Day solid blue (upar dekhein).
Turant graded MCQ par original halki right/wrong Web Audio cues aur Sound off
control hai (mute device par remembered). Written/self-check, unsubmitted exam
answers aur timer expiry silent hain. Browser audio block kare to visible
result phir bhi kaam karega; sounds Testbook se copy NAHIN kiye gaye.
Notes, independently priced Batch, author formatting aur grayscale Print unchanged.
Local: 249/249 unit, 17 selected Chromium fixture cases, npm run check with
0 lint errors/22 existing warnings. Live phone/speaker/printer/payment/Supabase
verified NAHIN, production SQL ya deploy NAHIN kiya.
Read docs/audit/INTERACTIVE-COLOUR-SOUND-DARK-2026-10-17.md.

EARLIER VIDEO-BATCH ADDITION: Admin → Notes → paid Notes Series → Create video
Batch (draft Course), add URL/upload beside each note, then Course Admin mein
alag se Batch price/coin price set karke publish karein. Notes section ka
notes-only flow, note IDs, individual prices aur purchases unchanged hain.
Batch enrolment paid note purchase NAHIN hai; note purchase Batch video access
NAHIN hai. Subject → Chapter → optional Topic → Video ke baad Notes/Test,
5-second auto-test (choice na ho) aur unsaved unlimited Batch practice ke baad
10-second next-chapter video navigation hai. External hosts may block embed,
end-event ya autoplay; Finish video / Open on host / Play manually fallback.
Notes Series ka one-price bundle checkout abhi NAHIN: existing per-note price
hai, Batch price alag Course product ka. Price examples hard-coded NAHIN.
URLs private settings mein hain; private upload bucket configure karein, local
public /uploads fixture fallback ko paid-production privacy na samjhein.
No production SQL/deploy performed. Earlier Batch-only checks: 248/248 unit,
7/7 selected Chromium, 6/6 focused HTTP, full check 0 ESLint errors
(22 earlier fast-refresh warnings); not a live/real-device verification.
Detail and verification: docs/audit/NOTES-VIDEO-BATCH-2026-10-17.md.

Yeh existing Vercel project ke liye source/review ZIP hai, ONE-CLICK production
release NAHIN. Owner ne same Vercel + same Supabase project aur tested DB/private
Storage restore aur installed attempt RPCs bataye hain; live schema/remote main yahan
independently check nahin hua. Supabase bucket full hone par auto-provider-shift
is code mein prove/implement NAHIN hua. Pehle
`docs/EXISTING-VERCEL-STUDENT-PRESERVING-DEPLOY-HINDI.md` padhein.
Is ZIP ko GitHub par single file ki tarah upload karne se app update nahin hota:
reviewed source ko extract karke existing project's Preview se promote karein.
No node_modules, .git, private .env, runtime data, build output or old ZIP included.

17 Oct EARLIER STUDENT FLOW + STORAGE STATUS (latest colour changes upar hain;
purane date-waale sections neeche historical hain): Testbook se clarity inspiration li, exact design
NAHIN copy kiya. KKCC Discover → Syllabus → Lessons → Notes → Practice →
Results path ke saath tests, course cards, dashboard aur selected text labels
mein readable light/dark teal, blue, warm gold aur restrained rose hai.
Student test aur note practice mein question text dark blue, sabhi answer
options ek hi readable dark teal mein hain; latest update mein option cards
KKCC-tinted hain, rainbow NAHIN. Saved answer review mein bhi same KKCC colours. Author ki chuni hui
inline colours aur note formatting automatic overwrite NAHIN hoti. Shared
heading cue sirf screen par hai, print par NAHIN. Student PDF colour; Print
actual faint centre KKCC logo/caption ke saath grayscale. Local verification
neeche hai; live/device/printer check NAHIN hua.
Note editor mein kisi ek uploaded photo
ko Remove karke baaki text/photo/diagram safe rakhein; main Save changes dabayein.
Storage object khud delete NAHIN hota (dusre notes mein share ho sakta hai).
Signed-in student ka after-note submitted result AUR note ke andar har checked
MCQ/written practice response, Admin result saving ON ho to, proposed PRIVATE
kkcc-note-results bucket mein owner-only immutable JSON hota hai. Written
response self-check hai, automatic marks NAHIN. Regular/series ke NEW marked
submitted attempts ki verified private Storage copy existing kkcc-result-papers
bucket mein bhi banti hai; purane DB attempt/answers/score fields intact hain.
Yeh regular/series results ka Storage-ONLY migration ya old data backfill NAHIN.
Student auth, payment, enrolment, grants/access, operational attempt/timers DB
mein hi rahte hain. Note-result bucket SQL draft file
supabase/migrations/20261017120000_note_results_storage.sql production par
apply NAHIN hua; missing bucket/permissions par app save failure dikhata hai.
Earlier result-paper migration bhi live verified NAHIN. Bina backup, policy
review aur explicit approval SQL/deploy na karein. Local disposable fixture:
2/2 disposable Storage HTTP integration tests also passed in the preceding
flow/storage pass. Latest Q/A ink pass ran 24/24 focused Chromium browser
tests (see above), including authored text and printed PDF regression. Real backend,
physical device/printer, payment or production deploy verify NAHIN hua.
Read: docs/audit/STUDENT-FLOW-RESULT-STORAGE-2026-10-17.md.

17 Oct PRINT PHOTO correction: header logo tha, par centre ka halka logo
monochrome printed notes mein white note card ke PEECHE chhup gaya tha.
Print-only card ko transparent kiya; ab actual Chromium PDF ko image
mein rasterise karke har page par asli centre logo aur neeche ka text
visible verify hua, colour aur B&W dono mein (Background graphics OFF bhi).
Purani saved PDF ko dobara Print / Save as PDF se banayein. Real printer/phone
par physical test abhi nahin hua. Details:
docs/audit/NOTES-NEXT-TEST-COLOUR-PRINT-2026-10-17.md.

17 Oct latest correction (older 16 Oct PDF mode wording below superseded):
Student attached PDF COLOR mein padhe/download kare, unse colour/B&W chunne
ko NAHIN kaha jaata. App ka Print action alag actual grayscale PDF banata hai,
har page ke centre mein halka ASLI black KKCC K/book logo aur neeche
"KKCC Excellence Hub"; typed notes ki Print bhi automatically gray hai.
Admin note editor mein Tests-format MCQ paste → preview/edit → attach → main Save.
Student note ke END tak scroll kare to 5-second countdown ke baad wahi note
se linked EK next test khulta hai, series nahin. Submitted result Admin
saving ON par private note-result Storage mein jata hai; is test se separate
DB attempt row/localStorage nahin banta. Chhota note
poora screen par dikhe to 5-second countdown automatically shuru hota hai.
Attached PDF ho to uska last colour preview page dekhne aur note-end panel
tak aane ke baad hi auto-test shuru hota hai. Drawing save Blob upload se
CSP-safe; mobile formatting strip keyboard/navigation ke upar
rehti hai. Detail + limits: docs/audit/NOTES-NEXT-TEST-COLOUR-PRINT-2026-10-17.md.
Earlier 17 Oct print-specific local check (before the current Storage update): 237/237 units, npm run check (repo/questions, 0 ESLint
errors / 22 old warnings, TypeScript, production build), 28/28 selected
Chromium Notes/PDF/mobile fixture tests (including actual PDF pixel comparison). Full browser suite, actual Samsung,
live data/deployment verify NAHIN kiya. Archive ko source review se pehle
production mein seedha deploy na karein.

Sandbox ka primary URL ab DOWNLOAD SERVER hai, app preview nahi: us par
Download KKCC ZIP button se yahi source archive milegi. Included
scripts/serve-release-zip.mjs sirf local delivery wrapper hai; chalane par
uske liye deliverables/ mein generated ZIP hona chahiye. Yeh production
hosting ya app deployment server NAHIN hai.

16 Oct usability/safety update: official PW, Unacademy, Next Toppers aur
Testbook (user ka 'textbook' isi ko maana) se sirf focused workflow ideas liye.
Admin home ab Course → Notes → Slides → Test aur read-only follow-up queue
(doubts/enquiries/access) dikhata hai; compact searchable tools baaki controls
rakhte hain. Purane built-in series agar LIVE backend mein enabled hon to admin
home warning dega. Unlinked series ko Hide/Restore kar sakte hain; grant ya
saved attempt ho to Hide/visibility switch refuse karega, student data delete
nahin hoga. Notes ke saved drafts/edit/publish pehle; advanced organisation
niche optional. Slides ke detailed objects optional; advanced rich text bhi
selected-text colours/B/I/U safe rakhta hai. UI colours app ke existing palette
mein subtle hain. Read: docs/audit/COMPETITOR-ADMIN-NOTES-2026-10-16.md
Dangerous 'Empty All Series & Tests' aur Exam Bank ka per-chapter 'Clear All'
endpoints/buttons removed. Single-question Delete par historical-attempt warning
+ confirmation hai; bina exact-ID/dependency/backup review use na karein.
'Refresh admin data' ab sirf in-memory cache flush hai; started attempts,
browser drafts ya grants delete NAHIN hote. Public downloads ka one-click
cleaner/broken ZIP link hata diya. A standalone source ZIP is delivered here,
website par auto-served nahin. Real-live database ya students ko is update ne
touch NAHIN kiya.

16 Oct selected bulk cleanup: Admin home → 'Clean up old content in batches'
mein exact notes/tests/courses/series IDs search karke select karein (max 100),
preview blockers padhein aur CLEAN SELECTED confirm karein. Unused series ek
write mein sirf hide hoti hain (Restore available); sirf unpublished,
unlinked drafts delete ho sakte hain. Published sample notes ko title dekh
kar auto-delete NAHIN kiya: verified backup/ownership review ke baad editor
mein unpublish karke draft cleanup karein. Notes-series outline reference,
grants, payments, attempts aur failed reads action ko rokte hain. Application
checks non-atomic hain; partial success report ho sakti hai; private Storage
files delete nahi hote. Deploy se existing live rows par automatic operation
NAHIN chalega. Dekhein docs/audit/SELECTED-BULK-CLEANUP-2026-10-16.md.
Bulk-cleanup pass (PDF branding se pehle): 208/208 unit, full npm run check
(0 ESLint errors, 22 prior warnings, TypeScript, build), 8/8 selected-cleanup
+ single-delete + series fixture HTTP checks passed. Full isolated Chromium run mein 143 pass,
1 intentional skip aur 1 unrelated login-redirect navigation race fail thi;
login wait fix ke baad us test aur new cleanup flow ka targeted rerun 2/2
passed. Full suite ko is test fix ke baad dobara NAHIN chalaya. Yeh local
fixture verification hai, live backend/real device proof nahin.

16 Oct KKCC PDF branding v2: app ke PDF Tools/Reader, slide-PDF export,
split-PDF ZIP aur authorised study-material PDF download/print par KKCC ka
asli transparent K/book logo page ke CENTRE mein, aur bilkul neeche
"KKCC Excellence Hub" faint print hota hai — har page par. Original file
modify NAHIN karte. Typed notes ki Print/Save-as-PDF mein bhi centre logo +
caption har page par repeat, even jab Background graphics off ho. Header/footer
bhi repeat; free inline note ka fallback bhi branded hai. Paid
PDF access click par dobara check hota hai. Signed PDF ka derivative signature
invalid kar sakta hai. Badi (>40 MB / 500 pages), encrypted, damaged ya CORS
blocked external PDF ka branded copy fail karega, silently unbranded download
NAHIN hoga. External site ke apne direct downloads app control NAHIN karta;
agar browser viewer PDF auto-download karta hai, branded copy ko khol kar
print karein. See docs/audit/PDF-BRANDING-2026-10-16.md. Final local checks:
211/211 unit, build/lint/TypeScript passed; 12/12 combined Document Studio +
material/print Chromium, 4/4 bulk HTTP on disposable fixture. 150-test
Chromium sweep ka 900-second tool timeout last Test Builder tests par laga;
terminal full-pass status NAHIN mila, baaki late browser files ka 15/15
alag se pass hua. Centre-logo correction ke BAAD 211/211 unit, full
check (0 lint errors, 22 old warnings), aur targeted PDF/Document Studio
Chromium 12/12 pass hue. Notes Print → Save as PDF ka multiple-page test
Background graphics OFF par har page ke centre mein 224px KKCC image aur
just neeche caption check karta hai; PDF reader current-page Print ka
actual PDF bhi centre image aur caption ke saath verify kiya. Isliye full-suite-green ya production/phone
testing ka claim NAHIN hai.

16 Oct Notes preview-formatting correction: plain bullets, colon labels aur
inferred diagram headings ab apne aap coloured strip/yellow highlight NAHIN
bante. Auto-Generate Notes Outline apni teen headings ko explicitly ## mark
karta hai. Admin → Study material → note edit → Preview note mein line tap
karke topic strip add/remove karein; pehle se peele highlight par tap karke
Remove selected highlight, ya line ke shabd select karke Highlight selected
text/Clear highlights on line karein. Shabd nahin mitenge; Save changes
zaroor dabayein. Yehi saved markup authorised student reader/Print PDF mein
show hoga; preview-only editing handles un pages mein nahin jaate. Complex
fence/image/table text ka exact source-line match na mile to galat line edit
karne ki bajay source editor use karne ko bolega. Local verification aur
limitations: docs/audit/NOTES-PREVIEW-FORMATTING-2026-10-16.md.

16 Oct custom-page/practice/colour output update: Admin → Study material →
New note/Edit → select words and tap Text/Marker swatch; Preview note mein
exact line/word par highlight ya strip add/remove karein, phir Save changes.
Draw / handwrite mein A4/A5/Letter/custom mm paper, blank/ruled/grid/dotted,
page photos/template, pen/marker, Add/Duplicate/Reorder/Delete, touch controls,
JPG backup aur custom-size multi-page KKCC PDF hai. Sare pages draft mein add
karne ke BAAD main Save changes dabayein; uploaded JPEG ink flat hai, vector
layers/Samsung cloud sync nahin. Private Storage configuration zaroori hai.
Chapter/topic practice note ke andar author-written MCQ/self-check aur explanation
ke saath hai; paid/course access gate same hai. Student unlimited retry kare;
signed-in checked response Admin saving ON par private Storage mein save hota hai,
DB attempt row ya browser localStorage mein NAHIN. Written answer self-check hai.
Colour PDF mein saved highlight aur actual centre K/book logo; B&W download
ke actual pixels gray hain aur centre artwork asli logo ka black version hai.
Printed notes mein bhi black centre logo, grayscale paper, neutral highlight;
opaque handwritten page ke upar faint logo print hota hai. Local 235/235 units,
repo/question/lint/type/build check (0 errors, 22 existing warnings) aur 22/22
Notes/PDF + 10/10 Studio/language scoped Chromium fixture tests pass hue.
Yeh physical Samsung, live Supabase ya full browser-suite proof NAHIN. Details:
docs/audit/NOTES-CUSTOM-PAGES-PRACTICE-PRINT-2026-10-16.md.

16 Oct follow-up — custom page aur selected-text rang aur aasaan:
Admin → Study material → New note/Edit mein ab **Custom page** direct button
hai. Yeh 180 × 240 mm blank custom sheet ke saath page-size, orientation,
pattern, background aur colour settings KHULI hui dikhata hai. Size/paper
chun kar settings fold karein, phir pen/marker se likhein; Add page par naya
page current paper choices leta hai, alag page par apni setting bhi badal
sakte hain. Purana Draw / handwrite A4 se pehle ki tarah khulta hai. Canvas
mein Save pages into notes ke BAAD main note ka Save changes bhi dabayein.
Note ke keyboard ke upar existing word/phrase select karke **A Text** ya
**▰ Highlight** mode tap karein, phir colour ka bada swatch; sirf ek palette
saamne hoti hai. Hint selection ready batata hai. Clear text colour aur Clear
highlight shabd bina mitaaye rang hatate hain. Bina selection tap par note
badalta NAHIN; advanced source quick palette hidden visuals metadata ko
colour nahin karega. Full colour mixer/preview controls ab bhi hain. Local
verification: 235/235 units, full check (0 errors, 22 warnings) aur 35/35
scoped Chromium Notes/PDF/Studio/language fixture tests pass. Samsung parity,
real phone, live Supabase ya poore browser-suite ka claim NAHIN. Details:
docs/audit/NOTES-CUSTOM-PAGES-PRACTICE-PRINT-2026-10-16.md.

Naya Simple Long text → editable PPT slides: 60,000 characters tak paste/type karein;
optional # headings ke bina bhi text automatically naye editable slides par banta hai.
Current slide ke baad ADD hota hai, purane slides replace nahin; thumbnail preview,
Previous/Next aur bade preview par heading/body tap karke native-keyboard editing.
Full-screen Present slides se Edit this slide par wapas aa sakte hain. 60-slide/24 MB
limit paar ho to bina text kaate project unchanged rehta hai. Yeh AI summary
NAHIN hai; PPTX native editable text hai, Save JSON zaroor karein.
Simple custom PDF slide ADD (25 MB/12-page source limit): PDF artwork image-only,
alag add kiya text project/PPTX mein editable rehta hai. Notes, Test author aur
Simple slide ke selected text par visual B/I/U, swatches, spectrum/custom HEX
colours; native IME retained. Old project/markup compatible.
Earlier usability pass (bulk/PDF changes se pehle): 207/207 unit tests; full `npm run check`
(repo inventory, question audit, lint 0 errors / 22 warnings, TypeScript,
production build), PWA + release SQL checks; 5/5 content/series HTTP checks;
full isolated fixture Chromium suite 143 passed, 1 intentionally skipped,
0 failed, 0 flaky. Initial full run found a Notes quick-draft focus race;
fixed it and reran full suite. Extracted source ZIP ke `npm ci` +
`VERCEL=1 npm run build` bina credentials/SQL ke pass hue. Local fixture
checks production proof nahin hain.
Chromium temporary npm-only test binary tha; ZIP mein bundled nahin. Physical
Samsung/Gboard/iPhone, live backend, payment ya real PowerPoint app testing
NAHIN hua.

IMPORTANT: Draft result-paper SQL (supabase/migrations/20261015120000_result_paper_snapshots.sql)
LIVE Supabase par apply NAHIN hua. Bina verified backup, RLS/privacy review aur explicit
approval ke isko ya kisi CLEANER/content-reset SQL ko run na karein. Historical
attempts automatically backfilled/proven nahin hain. Saved answers/result ke liye
versioned student-only SQL RPC chahiye; missing/old RPC par app fail-closed rahega.
Jab draft snapshot schema ho, nayi saved attempts original paper ke bina resume
nahin hongi; old unsnapshotted attempts alag provenance review maangti hain.
Live SQL pehle se installed/approved hai, yeh assume NAHIN kiya gaya. Test History
cleanup private JSON Storage objects ko delete NAHIN karti; restricted cleanup
receipts sirf reference rakhte hain. Included read-only inventory aur offline file verifier sirf restored
backup ke liye hain, live par chalaye nahin gaye. Storage retention/deletion
workflow alag approve karein.
Students ki auth ID, profiles, roles, grants, payments, enrolments, saved results
YA private Storage ko delete/replace NAHIN kiya gaya. Source seed mein courses,
notes, tests pehle se khaali hain; built-in sample notes ka public fallback aur
sample-import button band hai. Fresh interactive preview bhi empty shuru hota hai.
Existing Supabase/project ke old/sample rows ya includeBuiltIn series setting
is ZIP/redeploy se delete/disable NAHIN hote. Unke liye backup + exact-ID
student-dependency review ke baad alag approval chahiye. Dekhein:
docs/audit/SAMPLE-CONTENT-SAFETY-2026-10-15.md
No automatic SQL migration/cleaner follows extracting, building or redeploying.
BUT missing versioned RPCs ho to saved answers/results fail-closed rahenge;
isliye bina schema + current-main review is ZIP ko direct production mein deploy na karein.
PR #2/main ke differing files ki full reconciliation aur live/real-device QA pending hai.
Detailed status: docs/audit/LOCAL-RELEASE-STATUS-2026-10-15.md
'''


def allowed(name):
    path = Path(name)
    if any(part in SKIP_DIRS for part in path.parts) or name in SKIP_FILES:
        return False
    if path.suffix.lower() in {'.zip', '.patch', '.pem', '.key', '.pyc', '.ndjson', '.dump', '.backup', '.sqlite', '.db'} or '.runtime.json' in name:
        return False
    if path.suffix.lower() == '.png' and str(path.parent) in AUDIT_SCREENSHOT_DIRS:
        return False
    if path.name.startswith('.env') and path.name != '.env.example':
        return False
    if path.name in {'release-checksum.txt', 'credentials', '.netrc'}:
        return False
    return True


if __name__ == '__main__':
    # Refuse even a future change to the output path that might overwrite a
    # repository file (especially the tracked historical ZIP).
    assert not OUTPUT.resolve().is_relative_to(ROOT.resolve()), 'Review archive must stay outside repository'
    # Source-config guard only: the ZIP must not trigger a database migration,
    # sample reset or import during npm/Vercel installation or build. This
    # cannot attest to the live backend, third-party lifecycle scripts or
    # future administrator actions; those remain separate release gates.
    package = json.loads((ROOT / 'package.json').read_text())
    vercel = json.loads((ROOT / 'vercel.json').read_text())
    automatic = {name: command for name, command in package.get('scripts', {}).items()
                 if name in {'preinstall', 'install', 'postinstall', 'prepare', 'prebuild', 'build', 'postbuild'}}
    automatic.update({name: vercel.get(name, '') for name in ('buildCommand', 'installCommand')})
    forbidden = re.compile(r'\b(?:psql|supabase\s+db|migrat(?:e|ion)|cleaner|content[-:]reset|content:import|prisma\s+db|drizzle[- ]kit)\b', re.I)
    for stage, command in automatic.items():
        assert not forbidden.search(command), f'Automatic database-changing stage must be reviewed: {stage}'
    names = subprocess.check_output(['git', 'ls-files', '--cached', '--others', '--exclude-standard', '-z'], cwd=ROOT).decode().split('\0')
    included = sorted({name for name in names if name and allowed(name) and (ROOT / name).is_file() and not (ROOT / name).is_symlink()})
    # Atomically replace the prior review copy only after verifying the new one;
    # a failed ZIP build must never damage either archive.
    with TemporaryDirectory(dir=OUTPUT.parent, prefix='.kkcc-review-') as tmp:
        candidate = Path(tmp) / OUTPUT.name
        with zipfile.ZipFile(candidate, 'w', compression=zipfile.ZIP_DEFLATED, compresslevel=9) as archive:
            archive.writestr('ZIP-READ-FIRST-HINDI.txt', READ_FIRST)
            # Keep screenshot output folders so E2E can still write into them when the ZIP is extracted.
            for folder in sorted(AUDIT_SCREENSHOT_DIRS):
                archive.writestr(folder + '/', b'')
            for name in included:
                archive.write(ROOT / name, name)
        with zipfile.ZipFile(candidate) as archive:
            assert archive.testzip() is None, 'Archive integrity failure'
            assert archive.namelist()[0] == 'ZIP-READ-FIRST-HINDI.txt'
            for name in included:
                assert archive.read(name) == (ROOT / name).read_bytes(), f'Source differs: {name}'
            assert candidate.stat().st_size < GITHUB_WEB_UPLOAD_LIMIT, 'Archive exceeds the 25 MB web-upload limit.'
            for required in [
                'package.json', 'package-lock.json', 'vercel.json',
                'src/lib/analytics.functions.ts', 'src/lib/admin.functions.ts',
                'src/lib/admin-content-deletion.server.ts',
                'src/lib/admin-bulk-cleanup.server.ts',
                'src/components/kkcc/admin-bulk-cleanup.tsx',
                'src/lib/project-content.server.ts',
                'docs/audit/SELECTED-BULK-CLEANUP-2026-10-16.md',
                'tests/unit/admin-bulk-cleanup.test.ts',
                'tests/integration/admin-bulk-cleanup-http.test.ts',
                'src/lib/pdf-brand.ts',
                'src/lib/pdf-studio.ts',
                'src/lib/presentation-export.ts',
                'src/lib/notes-print-logo.ts',
                'src/lib/notes-print-logo-compact.ts',
                'public/kkcc-watermark.png',
                'src/lib/notes-print-watermark-logo.ts',
                'src/lib/notes-visuals/index.ts',
                'src/lib/notes-visuals/analyze.ts',
                'src/lib/note-preview-format.ts',
                'src/components/kkcc/note-preview-editor.tsx',
                'tests/unit/note-preview-format.test.ts',
                'tests/e2e/notes-preview-format.spec.ts',
                'docs/audit/NOTES-PREVIEW-FORMATTING-2026-10-16.md',
                'docs/audit/NOTES-CUSTOM-PAGES-PRACTICE-PRINT-2026-10-16.md',
                'src/lib/note-page.ts',
                'src/lib/note-practice.ts',
                'src/lib/note-follow-up-test.ts',
                'src/lib/author-quick-colours.ts',
                'src/lib/notes-print-watermark-black-logo.ts',
                'src/components/kkcc/notes-canvas-editor.tsx',
                'src/components/kkcc/note-practice-editor.tsx',
                'src/components/kkcc/note-practice-quiz.tsx',
                'src/components/kkcc/note-follow-up-editor.tsx',
                'src/components/kkcc/note-follow-up-reader.tsx',
                'src/components/kkcc/author-keyboard-strip.tsx',
                'tests/unit/note-page.test.ts',
                'tests/unit/note-practice.test.ts',
                'tests/unit/note-follow-up-test.test.ts',
                'tests/e2e/note-practice-pages.spec.ts',
                'tests/e2e/note-follow-up.spec.ts',
                'tests/e2e/notes-drawing-keyboard.spec.ts',
                'docs/audit/NOTES-NEXT-TEST-COLOUR-PRINT-2026-10-17.md',
                'tests/e2e/note-quick-colour.spec.ts',
                'src/lib/content.functions.ts',
                'src/components/kkcc/branded-pdf-preview.tsx',
                'src/components/kkcc/pdf-studio-tools.tsx',
                'src/components/kkcc/pdf-studio-reader.tsx',
                'src/components/kkcc/material-access-button.tsx',
                'tests/unit/pdf-brand.test.ts',
                'tests/e2e/pdf-brand-materials.spec.ts',
                'tests/e2e/document-studio.spec.ts',
                'docs/audit/PDF-BRANDING-2026-10-16.md',
                'scripts/serve-release-zip.mjs',
                'src/routes/_authenticated/admin.index.tsx',
                'src/routes/_authenticated/admin.materials.tsx',
                'src/routes/_authenticated/admin.exam-bank.tsx',
                'src/components/kkcc/admin-command-bar.tsx',
                'src/components/kkcc/presentation-studio.tsx',
                'docs/audit/COMPETITOR-ADMIN-NOTES-2026-10-16.md',
                'docs/audit/SAMPLE-CONTENT-SAFETY-2026-10-15.md',
                'docs/audit/browser-results.json',
                'tests/e2e/admin-solo-workspace.spec.ts',
                'tests/integration/admin-content-delete-http.test.ts',
                'tests/integration/admin-series-hide-http.test.ts',
                'tests/unit/admin-content-deletion.test.ts',
                'tests/unit/exam-bank-safety.test.ts',
                'tests/e2e/presentation-existing-rich-text.spec.ts',
                'src/lib/presentation-design.ts', 'src/components/kkcc/presentation-design-panel.tsx',
                'src/lib/custom-pamphlet.ts', 'src/lib/custom-pamphlet-browser.ts',
                'src/lib/author-inline.ts', 'src/lib/presentation-rich.ts',
                'src/components/kkcc/visual-inline-editor.tsx',
                'src/components/kkcc/custom-pamphlet-wizard.tsx',
                'tests/unit/visual-author-slides.test.ts',
                'tests/e2e/presentation-custom-slide-visual.spec.ts',
                'tests/e2e/presentation-long-text-preview.spec.ts',
                'tests/unit/presentation-design.test.ts',
                'tests/unit/custom-pamphlet.test.ts', 'tests/e2e/custom-pamphlet.spec.ts',
                'DOCUMENT-STUDIO-GUIDE-HINDI.md',
                'public/templates/kkcc-reference-v2/project.json',
                'public/templates/kkcc-reference-v2/reference-editable.pptx',
                'public/templates/kkcc-reference-v2/teaching.png',
                'public/templates/kkcc-reference-v2/cover.png',
                'public/secure-video.html', 'START-HERE-REFERENCE-UPDATE-HINDI.txt',
                'TEMPLATES-AND-VIDEO-GUIDE-HINDI.md',
                'tests/fixtures/documents/protected-reader.pdf', 'SQL-UPDATE-STATUS.txt',
                'docs/audit/LOCAL-RELEASE-STATUS-2026-10-15.md',
                'docs/EXISTING-VERCEL-STUDENT-PRESERVING-DEPLOY-HINDI.md',
                'docs/audit/CACHED-MAIN-LOCAL-INVENTORY-2026-10-15.md',
                'docs/audit/RESULT-PAPER-READINESS-2026-10-15.md',
                'docs/audit/RESULT-PAPER-READINESS-READ-ONLY.sql',
                'docs/audit/RESULT-PAPER-OFFLINE-MANIFEST-READ-ONLY.sql',
                'tests/unit/result-paper-readiness.test.ts',
                'tests/unit/result-paper-backup.test.ts',
                'tests/unit/series-paper-access.test.ts',
                'src/lib/attempt-rpc.ts', 'src/lib/test-attempts.functions.ts',
                'src/lib/result-paper-store.ts', 'src/lib/result-paper.server.ts',
                'tests/unit/attempt-rpc.test.ts', 'tests/unit/result-paper.test.ts',
                'tests/unit/result-paper-readiness.test.ts',
                'tests/integration/fixture-rpc.ts',
                'tests/fixtures/dev-server.ts',
                'tests/integration/attempt-replay-http.test.ts',
                'tests/integration/attempt-rpc-missing-http.test.ts',
                'tests/integration/attempt-paper-write-failure-http.test.ts',
                'scripts/verify-result-paper-backup.ts',
                'supabase/migrations/20261015120000_result_paper_snapshots.sql',
                'supabase/migrations/20261017120000_note_results_storage.sql',
                'docs/audit/STUDENT-FLOW-RESULT-STORAGE-2026-10-17.md',
                'src/components/kkcc/student-journey.tsx',
                'src/components/kkcc/global-search.tsx',
                'src/styles.css',
                'tests/e2e/kkcc-study-colours.spec.ts',
                'tests/e2e/test-paper-style.spec.ts',
                'src/lib/learning-result-store.ts',
                'src/lib/note-result-store.ts',
                'src/lib/note-practice-result-store.ts',
                'src/lib/note-result.server.ts',
                'src/lib/note-results.functions.ts',
                'tests/unit/learning-result-store.test.ts',
                'tests/unit/note-result-store.test.ts',
                'tests/unit/note-practice-result-store.test.ts',
                'tests/integration/learning-result-storage.test.ts',
                'tests/integration/note-result-storage.test.ts',
                'tests/e2e/student-learning-path.spec.ts',
                'tests/e2e/notes-photo-remove.spec.ts',
                'tests/e2e/result-paper-preservation.spec.ts',
                'src/lib/notes-batch.ts',
                'src/lib/notes-batch.functions.ts',
                'src/components/kkcc/batch-video-manager.tsx',
                'src/components/kkcc/batch-course-flow.tsx',
                'tests/unit/notes-batch.test.ts',
                'tests/integration/notes-batch-http.test.ts',
                'tests/e2e/notes-batch.spec.ts',
                'docs/audit/NOTES-VIDEO-BATCH-2026-10-17.md',
                'docs/audit/INTERACTIVE-COLOUR-SOUND-DARK-2026-10-17.md',
                'docs/audit/INTERACTIVE-BROWSER-RESULTS-2026-10-17.txt',
                'docs/audit/LOGO-COLOUR-GLOW-2026-10-17.md',
                'tests/e2e/logo-glow.spec.ts',
                'src/routes/games.tsx',
                'src/components/ui/button.tsx',
                'src/components/kkcc/bottom-nav.tsx',
                'src/lib/quiz-feedback-sound.ts',
                'src/hooks/use-quiz-feedback-sound.ts',
                'tests/unit/quiz-feedback-sound.test.ts',
                'tests/e2e/interactive-feedback.spec.ts',
            ]:
                assert required in archive.namelist(), required
            assert not any(name.startswith('.git/') or name.startswith('node_modules/') or name.startswith('dist/') for name in archive.namelist())
            assert '.env' not in archive.namelist()
            assert not any(name.startswith('data/') and '.runtime.json' in name for name in archive.namelist())
        result = {'file': OUTPUT.name, 'files': len(included), 'bytes': candidate.stat().st_size, 'sha256': hashlib.sha256(candidate.read_bytes()).hexdigest()}
        os.replace(candidate, OUTPUT)
    print(json.dumps(result, indent=2))
