"""Create a review/source ZIP outside the repository without replacing the historical archive."""
from pathlib import Path
from tempfile import TemporaryDirectory
import hashlib
import json
import os
import re
import subprocess
import zipfile

ROOT = Path(__file__).resolve().parents[1]
# The repository-root ZIP is a historical backup, not this review deliverable.
OUTPUT = ROOT.parent / 'full fledge kkcc excellence hub.zip'
SKIP_DIRS = {'.git', '.cache', '.output', '.tanstack', '.vercel', '.nitro', '.venv', '__pycache__', 'node_modules', 'dist', 'build', 'test-results', 'playwright-report'}
SKIP_FILES = {'tests/fixtures/documents/protected-demo.pdf', 'ZIP-READ-FIRST-HINDI.txt'}  # superseded, damaged synthetic fixture; original local file retained
# These folders contain only generated before/after browser screenshots. None is a
# runtime asset, migration, unit-test fixture or source file. Keep them in the
# working tree; omit the redundant PNG evidence from the distributable source ZIP.
AUDIT_SCREENSHOT_DIRS = {
    'docs/audit/redesign',
    'docs/audit/kkcc-refined',
    'docs/audit/kkcc-professional',
    'docs/audit/kkcc-aesthetic',
    'docs/audit/kkcc-future',
    'docs/audit/visual-gate',
}
GITHUB_WEB_UPLOAD_LIMIT = 25_000_000
READ_FIRST = (ROOT / 'ZIP-READ-FIRST-HINDI.txt').read_text()


def allowed(name):
    path = Path(name)
    if any(part in SKIP_DIRS for part in path.parts) or name in SKIP_FILES:
        return False
    if path.suffix.lower() in {'.zip', '.patch', '.pem', '.key', '.pyc', '.ndjson', '.dump', '.backup', '.sqlite', '.db'} or '.runtime.json' in name:
        return False
    if path.suffix.lower() == '.png' and str(path.parent) in AUDIT_SCREENSHOT_DIRS:
        return False
    if path.name.startswith('.env') and path.name != '.env.example':
        return False
    if path.name in {'release-checksum.txt', 'credentials', '.netrc'}:
        return False
    return True


if __name__ == '__main__':
    # Refuse even a future change to the output path that might overwrite a
    # repository file (especially the tracked historical ZIP).
    assert not OUTPUT.resolve().is_relative_to(ROOT.resolve()), 'Review archive must stay outside repository'
    # Source-config guard only: the ZIP must not trigger a database migration,
    # sample reset or import during npm/Vercel installation or build. This
    # cannot attest to the live backend, third-party lifecycle scripts or
    # future administrator actions; those remain separate release gates.
    package = json.loads((ROOT / 'package.json').read_text())
    vercel = json.loads((ROOT / 'vercel.json').read_text())
    automatic = {name: command for name, command in package.get('scripts', {}).items()
                 if name in {'preinstall', 'install', 'postinstall', 'prepare', 'prebuild', 'build', 'postbuild'}}
    automatic.update({name: vercel.get(name, '') for name in ('buildCommand', 'installCommand')})
    forbidden = re.compile(r'\b(?:psql|supabase\s+db|migrat(?:e|ion)|cleaner|content[-:]reset|content:import|prisma\s+db|drizzle[- ]kit)\b', re.I)
    for stage, command in automatic.items():
        assert not forbidden.search(command), f'Automatic database-changing stage must be reviewed: {stage}'
    names = subprocess.check_output(['git', 'ls-files', '--cached', '--others', '--exclude-standard', '-z'], cwd=ROOT).decode().split('\0')
    included = sorted({name for name in names if name and allowed(name) and (ROOT / name).is_file() and not (ROOT / name).is_symlink()})
    # Atomically replace the prior review copy only after verifying the new one;
    # a failed ZIP build must never damage either archive.
    with TemporaryDirectory(dir=OUTPUT.parent, prefix='.kkcc-review-') as tmp:
        candidate = Path(tmp) / OUTPUT.name
        with zipfile.ZipFile(candidate, 'w', compression=zipfile.ZIP_DEFLATED, compresslevel=9) as archive:
            archive.writestr('ZIP-READ-FIRST-HINDI.txt', READ_FIRST)
            # Keep screenshot output folders so E2E can still write into them when the ZIP is extracted.
            for folder in sorted(AUDIT_SCREENSHOT_DIRS):
                archive.writestr(folder + '/', b'')
            for name in included:
                archive.write(ROOT / name, name)
        with zipfile.ZipFile(candidate) as archive:
            assert archive.testzip() is None, 'Archive integrity failure'
            assert archive.namelist()[0] == 'ZIP-READ-FIRST-HINDI.txt'
            for name in included:
                assert archive.read(name) == (ROOT / name).read_bytes(), f'Source differs: {name}'
            assert candidate.stat().st_size < GITHUB_WEB_UPLOAD_LIMIT, 'Archive exceeds the 25 MB web-upload limit.'
            for required in [
                'package.json', 'package-lock.json', 'vercel.json',
                'src/lib/analytics.functions.ts', 'src/lib/admin.functions.ts',
                'src/lib/admin-content-deletion.server.ts',
                'src/lib/admin-bulk-cleanup.server.ts',
                'src/components/kkcc/admin-bulk-cleanup.tsx',
                'src/lib/project-content.server.ts',
                'docs/audit/SELECTED-BULK-CLEANUP-2026-10-16.md',
                'tests/unit/admin-bulk-cleanup.test.ts',
                'tests/integration/admin-bulk-cleanup-http.test.ts',
                'src/lib/pdf-brand.ts',
                'src/lib/pdf-studio.ts',
                'src/lib/presentation-export.ts',
                'src/lib/notes-print-logo.ts',
                'src/lib/notes-print-logo-compact.ts',
                'public/kkcc-watermark.png',
                'src/lib/notes-print-watermark-logo.ts',
                'src/lib/notes-visuals/index.ts',
                'src/lib/notes-visuals/analyze.ts',
                'src/lib/note-preview-format.ts',
                'src/components/kkcc/note-preview-editor.tsx',
                'tests/unit/note-preview-format.test.ts',
                'tests/e2e/notes-preview-format.spec.ts',
                'docs/audit/NOTES-PREVIEW-FORMATTING-2026-10-16.md',
                'docs/audit/NOTES-CUSTOM-PAGES-PRACTICE-PRINT-2026-10-16.md',
                'src/lib/note-page.ts',
                'src/lib/note-practice.ts',
                'src/lib/note-follow-up-test.ts',
                'src/lib/author-quick-colours.ts',
                'src/lib/notes-print-watermark-black-logo.ts',
                'src/components/kkcc/notes-canvas-editor.tsx',
                'src/components/kkcc/note-practice-editor.tsx',
                'src/components/kkcc/note-practice-quiz.tsx',
                'src/components/kkcc/note-follow-up-editor.tsx',
                'src/components/kkcc/note-follow-up-reader.tsx',
                'src/components/kkcc/author-keyboard-strip.tsx',
                'tests/unit/note-page.test.ts',
                'tests/unit/note-practice.test.ts',
                'tests/unit/note-follow-up-test.test.ts',
                'tests/e2e/note-practice-pages.spec.ts',
                'tests/e2e/note-follow-up.spec.ts',
                'tests/e2e/notes-drawing-keyboard.spec.ts',
                'docs/audit/NOTES-NEXT-TEST-COLOUR-PRINT-2026-10-17.md',
                'tests/e2e/note-quick-colour.spec.ts',
                'src/lib/content.functions.ts',
                'src/components/kkcc/branded-pdf-preview.tsx',
                'src/components/kkcc/pdf-studio-tools.tsx',
                'src/components/kkcc/pdf-studio-reader.tsx',
                'src/components/kkcc/material-access-button.tsx',
                'tests/unit/pdf-brand.test.ts',
                'tests/e2e/pdf-brand-materials.spec.ts',
                'tests/e2e/document-studio.spec.ts',
                'docs/audit/PDF-BRANDING-2026-10-16.md',
                'scripts/serve-release-zip.mjs',
                'src/routes/_authenticated/admin.index.tsx',
                'src/routes/_authenticated/admin.materials.tsx',
                'src/routes/_authenticated/admin.exam-bank.tsx',
                'src/components/kkcc/admin-command-bar.tsx',
                'src/components/kkcc/presentation-studio.tsx',
                'src/lib/content-library.ts',
                'src/lib/content-library.batch.ts',
                'src/lib/content-library.snapshot.ts',
                'src/lib/content-library.functions.ts',
                'src/lib/coupon-series-recovery.ts',
                'src/routes/checkout.tsx',
                'tests/unit/coupon-series-recovery.test.ts',
                'tests/unit/notes-global-pricing.test.ts',
                'src/routes/_authenticated/admin.library.tsx',
                'src/routes/_authenticated/admin.owner.tsx',
                'src/routeTree.gen.ts',
                'tests/unit/content-library.test.ts',
                'tests/unit/content-library-batch.test.ts',
                'tests/unit/content-library-snapshot.test.ts',
                'docs/audit/COMPETITOR-ADMIN-NOTES-2026-10-16.md',
                'docs/audit/SAMPLE-CONTENT-SAFETY-2026-10-15.md',
                'docs/audit/browser-results.json',
                'tests/e2e/admin-solo-workspace.spec.ts',
                'tests/integration/admin-content-delete-http.test.ts',
                'tests/integration/admin-series-hide-http.test.ts',
                'tests/unit/admin-content-deletion.test.ts',
                'tests/unit/exam-bank-safety.test.ts',
                'tests/e2e/presentation-existing-rich-text.spec.ts',
                'src/lib/presentation-design.ts', 'src/components/kkcc/presentation-design-panel.tsx',
                'src/lib/custom-pamphlet.ts', 'src/lib/custom-pamphlet-browser.ts',
                'src/lib/author-inline.ts', 'src/lib/presentation-rich.ts',
                'src/components/kkcc/visual-inline-editor.tsx',
                'src/components/kkcc/custom-pamphlet-wizard.tsx',
                'tests/unit/visual-author-slides.test.ts',
                'tests/e2e/presentation-custom-slide-visual.spec.ts',
                'tests/e2e/presentation-long-text-preview.spec.ts',
                'tests/unit/presentation-design.test.ts',
                'tests/unit/custom-pamphlet.test.ts', 'tests/e2e/custom-pamphlet.spec.ts',
                'DOCUMENT-STUDIO-GUIDE-HINDI.md',
                'public/templates/kkcc-reference-v2/project.json',
                'public/templates/kkcc-reference-v2/reference-editable.pptx',
                'public/templates/kkcc-reference-v2/teaching.png',
                'public/templates/kkcc-reference-v2/cover.png',
                'public/secure-video.html', 'START-HERE-REFERENCE-UPDATE-HINDI.txt',
                'TEMPLATES-AND-VIDEO-GUIDE-HINDI.md',
                'tests/fixtures/documents/protected-reader.pdf', 'SQL-UPDATE-STATUS.txt',
                'docs/audit/LOCAL-RELEASE-STATUS-2026-10-15.md',
                'docs/EXISTING-VERCEL-STUDENT-PRESERVING-DEPLOY-HINDI.md',
                'docs/audit/CACHED-MAIN-LOCAL-INVENTORY-2026-10-15.md',
                'docs/audit/RESULT-PAPER-READINESS-2026-10-15.md',
                'docs/audit/RESULT-PAPER-READINESS-READ-ONLY.sql',
                'docs/audit/RESULT-PAPER-OFFLINE-MANIFEST-READ-ONLY.sql',
                'tests/unit/result-paper-readiness.test.ts',
                'tests/unit/result-paper-backup.test.ts',
                'tests/unit/series-paper-access.test.ts',
                'src/lib/attempt-rpc.ts', 'src/lib/test-attempts.functions.ts',
                'src/lib/result-paper-store.ts', 'src/lib/result-paper.server.ts',
                'tests/unit/attempt-rpc.test.ts', 'tests/unit/result-paper.test.ts',
                'tests/unit/result-paper-readiness.test.ts',
                'tests/integration/fixture-rpc.ts',
                'tests/fixtures/dev-server.ts',
                'tests/integration/attempt-replay-http.test.ts',
                'tests/integration/attempt-rpc-missing-http.test.ts',
                'tests/integration/attempt-paper-write-failure-http.test.ts',
                'scripts/verify-result-paper-backup.ts',
                'supabase/migrations/20261015120000_result_paper_snapshots.sql',
                'supabase/migrations/20261017120000_note_results_storage.sql',
                'docs/audit/STUDENT-FLOW-RESULT-STORAGE-2026-10-17.md',
                'src/components/kkcc/student-journey.tsx',
                'src/components/kkcc/global-search.tsx',
                'src/styles.css',
                'tests/e2e/kkcc-study-colours.spec.ts',
                'tests/e2e/test-paper-style.spec.ts',
                'src/lib/learning-result-store.ts',
                'src/lib/note-result-store.ts',
                'src/lib/note-practice-result-store.ts',
                'src/lib/note-result.server.ts',
                'src/lib/note-results.functions.ts',
                'tests/unit/learning-result-store.test.ts',
                'tests/unit/note-result-store.test.ts',
                'tests/unit/note-practice-result-store.test.ts',
                'tests/integration/learning-result-storage.test.ts',
                'tests/integration/note-result-storage.test.ts',
                'tests/e2e/student-learning-path.spec.ts',
                'tests/e2e/notes-photo-remove.spec.ts',
                'tests/e2e/result-paper-preservation.spec.ts',
                'src/lib/notes-batch.ts',
                'src/lib/notes-batch.functions.ts',
                'src/components/kkcc/batch-video-manager.tsx',
                'src/components/kkcc/batch-course-flow.tsx',
                'tests/unit/notes-batch.test.ts',
                'tests/integration/notes-batch-http.test.ts',
                'tests/e2e/notes-batch.spec.ts',
                'docs/audit/NOTES-VIDEO-BATCH-2026-10-17.md',
                'docs/audit/INTERACTIVE-COLOUR-SOUND-DARK-2026-10-17.md',
                'docs/audit/INTERACTIVE-BROWSER-RESULTS-2026-10-17.txt',
                'docs/audit/LOGO-COLOUR-GLOW-2026-10-17.md',
                'tests/e2e/logo-glow.spec.ts',
                'src/routes/games.tsx',
                'src/components/ui/button.tsx',
                'src/components/kkcc/bottom-nav.tsx',
                'src/lib/quiz-feedback-sound.ts',
                'src/hooks/use-quiz-feedback-sound.ts',
                'tests/unit/quiz-feedback-sound.test.ts',
                'tests/e2e/interactive-feedback.spec.ts',
                'supabase/migrations/20261019190000_coupon_scopes_and_controls.sql',
                'src/lib/coupon-scope.ts',
                'src/lib/coupons.functions.ts',
                'src/routes/_authenticated/admin.coupons.tsx',
                'src/lib/admin-notes-access.functions.ts',
                'src/components/kkcc/admin-notes-access-panel.tsx',
                'tests/unit/coupon-scopes.test.ts',
                'tests/unit/manual-notes-access.test.ts',
                'docs/audit/COUPON-SCOPES-2026-10-19.md',
                'src/lib/custom-series-catalog-storage.ts',
                'src/lib/custom-series-catalog-storage.server.ts',
                'src/lib/learning.server.ts',
                'src/lib/learning-access.ts',
                'src/lib/student-validity.functions.ts',
                'tests/unit/course-validity.test.ts',
                'src/lib/ai-question-archive-store.ts',
                'src/lib/ai-question-archive.server.ts',
                'src/lib/ai-question-archive.ts',
                'src/lib/ai-question-research.server.ts',
                'src/lib/material-file-reference.ts',
                'src/lib/notes-catalog-storage.server.ts',
                'src/components/kkcc/admin-notes-access-panel.tsx',
                'src/routes/_authenticated/admin.coupons.tsx',
                'src/routes/_authenticated/admin.ai-question-engine.tsx',
                'supabase/migrations/20261020100000_admin_history_hiding.sql',
                'supabase/migrations/20261020110000_custom_test_series_catalog_storage.sql',
                'supabase/migrations/20261020120000_ai_archive_supabase_storage.sql',
                'supabase/migrations/20261020130000_notes_catalog_pointer_cas.sql',
                'supabase/migrations/20261020150000_educational_storage_setup.sql',
                'src/lib/educational-storage.config.ts',
                'src/lib/educational-storage.server.ts',
                'src/lib/educational-storage.functions.ts',
                'src/lib/admin-daily-queue.ts',
                'src/lib/storage-upload.functions.ts',
                'src/lib/storage.ts',
                'src/lib/project-content.server.ts',
                'src/integrations/supabase/db.ts',
                'scripts/download-release.py',
                'scripts/serve-release-zip.mjs',
                'scripts/sync-release-sql.mjs',
                'README.md',
                'RELEASE_VERIFICATION.md',
                'docs/DEPLOYMENT_STUDENT_ONLY.md',
                'docs/audit/STORAGE-REVIEW-2026-10-20.md',
                'ZIP-READ-FIRST-HINDI.txt',
                'src/routes/_authenticated/admin.storage.tsx',
                'src/routes/_authenticated/admin.index.tsx',
                'src/components/kkcc/notes-series-editor.tsx',
                'src/routes/_authenticated/admin.coupons.tsx',
                'src/lib/optional-admin-catalog.ts',
                'tests/unit/optional-admin-catalog.test.ts',
                'tests/unit/educational-storage-setup.test.ts',
                'tests/unit/admin-daily-queue.test.ts',
                'KKCC-Excellence-Hub-EDUCATIONAL-STORAGE.sql',
                'public/KKCC-Excellence-Hub-EDUCATIONAL-STORAGE.sql',
                'KKCC-Excellence-Hub-ADMIN-HISTORY-HIDING.sql',
                'public/KKCC-Excellence-Hub-ADMIN-HISTORY-HIDING.sql',
                'KKCC-Excellence-Hub-TEST-SERIES-STORAGE.sql',
                'public/KKCC-Excellence-Hub-TEST-SERIES-STORAGE.sql',
                'supabase/migrations/20261001020000_kkcc_external_question_archive.sql',
                'KKCC-Excellence-Hub-HISTORY-STORAGE.sql',
                'public/KKCC-Excellence-Hub-HISTORY-STORAGE.sql',
                'supabase/STUDENT_ONLY_SCHEMA.sql',
                'KKCC-Excellence-Hub-PRODUCTION-SQL.sql',
                'tests/unit/admin-history-hiding.test.ts',
                'tests/unit/ai-question-archive-storage.test.ts',
                'tests/unit/custom-series-catalog-storage.test.ts',
                'tests/unit/notes-catalog-storage-cas.test.ts',
                'tests/unit/material-file-reference.test.ts',
                'docs/audit/STORAGE-REVIEW-2026-10-20.md',
                'src/lib/student-access-notification.ts',
                'src/lib/notifications.server.ts',
                'src/lib/admin-users.functions.ts',
                'src/lib/enrollments.functions.ts',
                'src/lib/test-access.functions.ts',
                'src/lib/offline-access.functions.ts',
                'src/lib/admin-access-recovery.functions.ts',
                'src/routes/_authenticated/admin.notifications.tsx',
                'src/routes/_authenticated/admin.courses.$id.tsx',
                'tests/unit/automatic-access-notifications.test.ts',
                'tests/e2e/note-editor-caret.spec.ts',
                'supabase/migrations/20261020210000_automatic_access_notifications.sql',
                'KKCC-Excellence-Hub-AUTOMATIC-ACCESS-NOTIFICATIONS.sql',
                'public/KKCC-Excellence-Hub-AUTOMATIC-ACCESS-NOTIFICATIONS.sql',
                'SQL-UPDATE-STATUS.txt',
            ]:
                assert required in archive.namelist(), required
            assert not any(name.startswith('.git/') or name.startswith('node_modules/') or name.startswith('dist/') for name in archive.namelist())
            assert '.env' not in archive.namelist()
            assert not any(name.startswith('data/') and '.runtime.json' in name for name in archive.namelist())
        result = {'file': OUTPUT.name, 'files': len(included), 'bytes': candidate.stat().st_size, 'sha256': hashlib.sha256(candidate.read_bytes()).hexdigest()}
        os.replace(candidate, OUTPUT)
    print(json.dumps(result, indent=2))
