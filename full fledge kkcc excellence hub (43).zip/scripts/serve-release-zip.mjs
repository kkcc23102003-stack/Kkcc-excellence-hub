// Disposable download server for the reviewed source ZIP, not the production app.
// Start with: PORT=4600 node scripts/serve-release-zip.mjs
import { createServer } from "node:http";
import { createReadStream, statSync } from "node:fs";
import { resolve } from "node:path";

const filename = "full fledge kkcc excellence hub.zip";
const zipPath = resolve(process.cwd(), "deliverables", filename);
const port = Number(process.env.PORT || 4600);
if (!Number.isInteger(port) || port < 1 || port > 65535) throw new Error("Invalid PORT");

function zipSize() {
  const size = statSync(zipPath).size;
  if (!size || size >= 25_000_000) throw new Error("Review ZIP missing or over 25 MB");
  return size;
}
zipSize();

const commonHeaders = {
  "Cache-Control": "no-store",
  "X-Content-Type-Options": "nosniff",
  "Referrer-Policy": "no-referrer",
};

createServer((request, response) => {
  const pathname = new URL(request.url || "/", "http://localhost").pathname;
  if (request.method !== "GET" && request.method !== "HEAD") {
    response.writeHead(405, { ...commonHeaders, Allow: "GET, HEAD" }).end();
    return;
  }
  if (pathname === "/health") {
    const body = JSON.stringify({ ready: true, bytes: zipSize() });
    response.writeHead(200, {
      ...commonHeaders,
      "Content-Type": "application/json; charset=utf-8",
      "Content-Length": Buffer.byteLength(body),
    });
    response.end(request.method === "HEAD" ? undefined : body);
    return;
  }
  if (pathname === "/download" || pathname === `/${encodeURIComponent(filename)}`) {
    response.writeHead(200, {
      ...commonHeaders,
      "Content-Type": "application/zip",
      "Content-Length": zipSize(),
      "Content-Disposition": `attachment; filename="${filename}"`,
    });
    if (request.method === "HEAD") response.end();
    else
      createReadStream(zipPath)
        .on("error", () => response.destroy())
        .pipe(response);
    return;
  }
  if (pathname === "/") {
    const size = (zipSize() / 1_000_000).toFixed(2);
    const body = `<!doctype html><html lang="en"><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>KKCC Excellence Hub v53 — ZIP download</title><style>body{min-height:100vh;margin:0;display:grid;place-items:center;background:linear-gradient(140deg,#f4fbf7,#e8f5ef 62%,#f8f5e8);color:#173835;font:16px/1.6 system-ui,sans-serif}main{box-sizing:border-box;width:min(100% - 32px,700px);padding:36px;border:1px solid #b7d9ca;border-radius:22px;background:#fff;box-shadow:0 18px 48px #17383518}h1{margin:0 0 12px;line-height:1.2;font-size:clamp(1.7rem,5vw,2.3rem)}p{color:#45605b}a{display:inline-block;padding:13px 21px;border-radius:10px;background:#087e83;color:#fff;font-weight:750;text-decoration:none}a:hover,a:focus-visible{background:#075f63}small{display:block;margin-top:16px;color:#45605b}</style><main><h1>KKCC Excellence Hub — v53 source ZIP</h1><p>Missing private kkcc-test-series-catalog Storage no longer blocks Database-backed Batch/course, individual test or Notes access checks. Legacy inline custom-series data can be read without changing its Database row while the private bucket is not provisioned. A Storage-pointer series still needs its private object restored.</p><p>The ZIP includes separate Test Series catalogue Storage SQL. The Test Series bucket is not the course-content bucket. Review and back up first; no migration runs automatically. V52 coupon history fallback and separate Notes bundle pricing remain included.</p><p>Source archive ready (${size} MB). This ZIP does not change live pricing, apply migrations or deploy the app.</p><a href="/download" download="${filename}">Download KKCC ZIP v53</a><small>${filename}<br>This review/source archive does not deploy the app, modify student data, or run a database migration.</small></main></html>`;
    response.writeHead(200, {
      ...commonHeaders,
      "Content-Type": "text/html; charset=utf-8",
      "Content-Length": Buffer.byteLength(body),
      "Content-Security-Policy": "default-src 'none'; style-src 'unsafe-inline'",
    });
    response.end(request.method === "HEAD" ? undefined : body);
    return;
  }
  response.writeHead(404, { ...commonHeaders, "Content-Type": "text/plain" }).end("Not found");
}).listen(port, "0.0.0.0", () => {
  console.log(`KKCC ZIP download server listening on 0.0.0.0:${port} (${zipSize()} bytes)`);
});
