"""Optional local PDF geometry audit. Requires PyMuPDF; never processes live note data."""
import json
from pathlib import Path
import pymupdf

folder = Path('docs/audit/notes-office')
pdf = pymupdf.open(folder / 'print-layout.pdf')
results, all_text = [], ''
for index, page in enumerate(pdf):
    all_text += page.get_text()
    headers = [rect for rect in page.search_for('Kusum Kartik Coaching Centre') if rect.y0 < 105]
    footers = [rect for rect in page.search_for('KKCC Excellence Hub') if rect.y0 > 105]
    assert headers and footers, f'Missing branding on page {index + 1}'
    logos = [rect for image in page.get_images() for rect in page.get_image_rects(image[0]) if rect.y0 < 105]
    assert logos, f'Missing painted logo on page {index + 1}'
    lines = [line for block in page.get_text('dict')['blocks'] if 'lines' in block for line in block['lines']
             if any('Audit line' in span['text'] or 'Table row' in span['text'] for span in line['spans'])]
    for line in lines:
        assert line['bbox'][1] > headers[0].y1 + 8, f'Header overlap on page {index + 1}'
        assert line['bbox'][3] < footers[-1].y0 - 8, f'Footer overlap on page {index + 1}'
    results.append({'page': index + 1, 'logo': True, 'header_bottom': round(headers[0].y1, 2),
                    'footer_top': round(footers[-1].y0, 2), 'checked_content_lines': len(lines)})
for index in range(180):
    assert f'Audit line {index + 1:03d}' in all_text, f'Missing paragraph {index + 1}'
for index in range(40):
    assert f'Table row {index + 1}' in all_text, f'Missing table row {index + 1}'
assert 'End of audit' in all_text
(folder / 'print-layout-check.json').write_text(json.dumps({'pages': len(pdf), 'paragraphs_preserved': 180,
    'table_rows_preserved': 40, 'checks': results}, indent=2))
pdf[0].get_pixmap().save(folder / 'print-page-1.png')
print(f'PASS: {len(pdf)} pages; logo/header/footer on every page; all 180 paragraphs and 40 rows preserved; checked text clear of branding.')
