# KKCC — Editable Templates aur Lecture Player update

> **14 October v2 reference designs (non-destructive update):** Updated source ko apne existing Vercel project mein deploy karne ke baad **Admin → Document Studio → Presentation Studio → Your photo-reference templates · v2 → Load both reference templates (keep old slides)** dabayein. Dono slides current project ke END par append hongi; existing slides/title/brand nahi mitenge, repeat click duplicates nahi banata. Current project browser-tab-only hai—deployment se pehle aur edits ke baad **Save editable project** JSON download karein. Alag 5:4 JSON aur fully editable native PPTX bhi isi panel se download hoti hain. Uploaded JPGs backgrounds nahi hain. Sirf ZIP upload/download karne se live site update nahi hoti; Vercel source/backup/env steps [START-HERE-REFERENCE-UPDATE-HINDI.txt](START-HERE-REFERENCE-UPDATE-HINDI.txt) mein hain. Is feature ke liye koi SQL/cleaner nahi.

## Presentation kahan milegi?
**Admin → Presentation & PDF Studio → Presentation Studio**.

1. **Editable templates, ratios & text-to-slides** panel kholein.
2. Coaching/app name, Series, Subject aur Teacher badlein. Linked template labels update honge. Logo ko object selector mein choose karke **Replace selected image / logo** use karein.
3. Canvas ratio choose karein: **16:9, 9:16, 1:1, 4:5, 3:4, 4:3**, ya custom pixels.
4. Galaxy neon, White classroom, Teal studio, Warm peach ya Royal violet choose karein. Teaching page, Series cover ya Thumbnail choose karke **Add designed slide** dabayein.
5. Har text, logo, shape, line aur decoration alag editable object hai. References ki JPGs background ke taur par use nahi ki gayi hain. Tiny decoration ko select karne ke liye **Select any template object** dropdown use karein.

## Text paste karke slides
**Ab Simple mode mein:** **Long text → editable PPT slides** mein bina `#` ke bhi poora text type/paste karein, style chunein aur **Generate slides & preview** dabayein. Naye pages current slide ke baad judte hain; purane slides nahin mitate. Slide thumbnails/Previous/Next se preview karein aur wahi heading/main text live edit karein. Project JSON save karke editable PPTX export karein; full-screen ke liye **Present slides**. Details: `DOCUMENT-STUDIO-GUIDE-HINDI.md`.

**Purane Advanced panel mein:** `# Chapter heading` likhein, neeche lesson paragraphs/bullets paste karein. Agle chapter ke liye naya `# Heading`. Advanced ka **Generate slides from text** current slides *replace* karega; confirmation aati hai. Pehle project save karna best hai. Undo bhi available hai.

Yeh deterministic layout/pagination hai—external AI se content likhna ya summarise karna nahi. Logo/header ke neeche aur footer ke upar content area reserved rehta hai. Lamba text extra slides par continue hota hai. Unicode Punjabi/Hindi/English supported hain.

- Maximum 60,000 input characters aur 60 slides. Limit exceed hone par generation reject hoti hai; chupke se content truncate nahi hota.
- Ratio change generated body ko repaginate karta hai. Manually edited text ki readability, positions aur font size export se pehle review karein. **Fit text in box** helper bhi hai.
- Custom canvas: 320–2560px per edge, maximum 4 megapixels, ratio 1:3 se 3:1.
- New theme selection existing slides ko automatically recolour nahi karti; selected theme agle designed/generated slides par lagti hai.

## Save / download
- **Save editable project**: JSON download; app mein dobara open/merge kar sakte hain. Purane version-1 projects compatible hain. Different-ratio project merge current canvas ke hisaab se refit hota hai.
- **Export PowerPoint**: native editable PPTX text/shapes/images. Desktop PowerPoint mein fonts installed na hone par appearance badal sakti hai. Fonts embedded nahi hain; Great Vibes display font aur suitable Hindi/Punjabi fonts use karein.
- **Export slide PDF**: selected ratio ke image-based PDF pages; searchable text nahi.
- **Export PNG / JPG thumbnail**: current selected slide, exact selected pixel size.
- Browser/local processing hai. Automatic cloud save/upload nahi hota. Project file save karke rakhein. Koi heavy PPT/PDF body database mein nahi jaati.

## Lecture player improvements
Admin course lecture mein valid YouTube watch, short, live, embed, youtu.be link ya 11-character video ID use karein. Lookalike domains aur malformed IDs reject hote hain. Video public/unlisted aur embedding-enabled hona chahiye.

Student ko **Play lecture** button milta hai. Native YouTube quality/speed/captions/fullscreen controls retained hain. Mobile inline playback supported hai; browser autoplay policy ke kaaran YouTube ka play button dobara tap karna pad sakta hai.

- Iframe tap/blur par video dhakne wala old protection overlay removed.
- Referrer policy corrected; missing-referrer error 153 ka app-side cause addressed.
- Slow connection/buffering, offline aur API playback errors par message/Retry milta hai.
- **Basic player** YouTube control API blocked hone par standard embed use karta hai; yeh YouTube/network restrictions bypass nahi karta.
- YouTube token encoding/watermark DRM ya screenshot protection nahi hain. Existing app course-access checks retained hain.

## Performance aur verification
- Static editable designs, no heavy animation; route widgets lazy-loaded.
- Unchanged slide previews memoised; history up to 25 states, approximate 32MB image/text history budget.
- Images preserve proportions; raster export processes slides sequentially and releases canvas buffers.
- Mobile horizontal overflow fixed; 360px, 390px and 768px viewport checks included.
- **Latest reference add-safe update: 164 unit tests PASS; 9 targeted Document/Presentation browser flows PASS** (including old-slide preservation, failed fetch and duplicate click). Broader prior-release evidence: 37 targeted browser flows + 2 feature evidence checks; these predate the add-safe update and were not all rerun now.
- TypeScript, standard build and local Vercel-mode build PASS; lint 0 errors / 12 existing warnings. Prior production dependency audit reported 0 vulnerabilities; not rerun for this update.
- Old Notes formatting/language/series, PDF tools/reader, login/access, Easy/Advanced tests, 1001-question publication, retention, storage and thumbnails included in targeted coverage. This is not every test/exam in the repository.

YouTube browser tests use controlled stubs: real YouTube delivery, physical Android/iPhone, Safari/Firefox, maximum-size memory stress, and native Office rendering were not certified. Har device/network par zero lag guarantee nahi hai.

## SQL / deployment
**Koi NEW SQL nahi. Cleaner dobara NA chalayein.** Existing accounts/payments/access aur production data par koi cleanup nahi kiya gaya.

Extract ZIP, follow existing configuration guide, then `npm ci` and `npm run build`. PDF engine assets build ke saath locally sync hote hain. GitHub push/merge/production deployment is session mein nahi hua.
