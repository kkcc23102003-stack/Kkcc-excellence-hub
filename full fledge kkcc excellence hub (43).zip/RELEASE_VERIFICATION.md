# KKCC Excellence Hub — release verification

> **19 October local coupon-scope + admin access update (v48):** The coupon page now separates All paid products, Batches/Courses, individual paid Notes, Tests, Test Series and Notes Series, with an optional specific item for each product category (one course/batch, Note, Test or Series). Server-side validation, wallet/Razorpay purchase and redemption enforce the saved kind/item scope; the course RPC checks it independently. Generic redemption history now records type + item ID. Unused codes can be deleted; used codes are deactivated so their history and granted access are retained. Course/test/series and Notes/Notes Series grant/revoke panels are embedded on the coupon page; paid Note purchases can be revoked without deleting history. Manual Notes Series grant payloads do not send `updated_at`, which is not present on `series_access_grants`. Migration `supabase/migrations/20261019190000_coupon_scopes_and_controls.sql` is included in fresh-install and production SQL bundles/mirror. Targeted PGlite course-validity/manual-Notes/coupon tests **13/13**, full unit suite **290/290**, TypeScript, production build, repo/question/PWA/release-SQL checks, and targeted changed-file ESLint passed. Full `npm run lint` reports **802 errors and 20 warnings**; targeted changed-file ESLint passes and unrelated files were not reformatted. Build has the existing large-chunk advisory. **No live database migration, payment test, or production deployment was performed.**

> **Previous 19 October Notes catalogue/schema work (v46/v45; historical verification):** The Study Material Notes error was not verified against the live Supabase project. Managed-table migration `20261019160000_managed_notes_free_preview.sql` and private-catalogue migration `20261019170000_private_notes_catalog_storage.sql` are local source changes. Earlier test counts in the v45/v46 sections below are superseded by v48's final 290/290 run. Applying SQL and verifying a real Study Material page remain deployment steps, not live changes made here.

> **19 October local Notes catalogue schema hotfix (v45):** Root cause traced to `projectContent` mapping `materials` to `kkcc_materials` while the free-preview migration added `is_free_preview` only to legacy `public.materials`; the published-card Supabase select therefore requested a missing column and failed the entire Paid Notes Series fetch. Adds an additive managed-table migration with deterministic free-preview backfill/index and schema-cache reload, plus catalogue loading/empty/error/Retry diagnostics and PGlite migration coverage. `npm run typecheck`, targeted ESLint, production build, release-SQL mirror check (14 files), and new schema/state tests (3/3) passed. Full suite 275/280 passed; five unrelated SQL-mirror/note-parser tests remain failing. Notes Series Playwright was attempted but Chromium is not installed. **Real Supabase-backed page verification remains blocked**: this workspace has no Supabase URL/public key/service-role environment and the migration has not been applied. Do not claim the live catalogue is fixed until the migration is applied and the real Study Material page is rechecked. See `ZIP-READ-FIRST-HINDI.txt`.

> **19 October local purchase/access + payment-recovery update (v44):** Adds distinct individually purchasable notes, Notes Series, and Batch entitlements; subject-first free notes; separate pricing/coupons; and payment-ID claims for callback/recovery idempotency. Razorpay recovery fetches payment and order server-to-server, and coin-pack retries are idempotent. Admin payment history is served through a server-function boundary. Earlier typecheck, targeted ESLint, Razorpay recovery tests (10/10), focused purchase/access/coupon tests (64/64), release-SQL mirror check (14 files), and production build passed. Earlier unit-test counts are historical for v44; see v45 for current results. No live prices, database migration, payment, or production deployment were changed.

> **17 October local logo-colour/glow correction (historical):** Six legible, individually coloured and softly glowing dock tabs; restrained screen-only header, card and shared-button accents; colourful Kit 2 Coins **questions in Night**, solid blue questions in Day, and unchanged single-colour answer options. Notes, access and grayscale printed PDFs remain intact. `npm run check` (0 errors/22 existing lint warnings), **249/249 unit tests**, **26/26 selected Chromium fixture checks** and a further **1/1 keyboard-focus check** passed. PWA, release-SQL source verification and diff checks passed. This is a source ZIP, not a deployment or live SQL approval. [Scope and limits](docs/audit/LOGO-COLOUR-GLOW-2026-10-17.md).

> **Earlier 17 October local colour/sound/dark-first update:** KKCC-filled buttons and clickable Notes Series subject/chapter/topic cards, solid branded Kit 2 Coins question ink, original short right/wrong sounds with a persistent mute choice, and Night mode on first visit with a saved Day choice. Student Notes/Batch purchases, author formatting and print rules are preserved. Local verification: **249/249 unit tests**, `npm run check` with 0 ESLint errors/22 pre-existing warnings, and a **single final 17/17 selected Chromium fixture run** passed, including note practice, Batch, Notes and grayscale PDF regressions. This is a downloadable source-review ZIP, **not** a deployed site or approved SQL migration. [Scope, controls and limitations](docs/audit/INTERACTIVE-COLOUR-SOUND-DARK-2026-10-17.md).

> **Earlier 17 October local video-Batch update:** The Notes section keeps its existing individual-note purchase flow; a separate draft Course reuses the same notes and has its own admin-set price/videos. Batch practice results are not saved, while standalone note saving remains unchanged. Private video mapping uses existing private settings. Public syllabus is metadata-only; no live data/SQL/deployment has been changed. Browser and HTTP fixture evidence, upload/source limits, and setup steps: [Notes + video Batch audit](docs/audit/NOTES-VIDEO-BATCH-2026-10-17.md). The ZIP is a review source archive, not a one-click production release. Earlier status sections below are historical.

> **Historical status (15 October 2026): RELEASE WITHHELD.** See
> [`docs/audit/LOCAL-RELEASE-STATUS-2026-10-15.md`](docs/audit/LOCAL-RELEASE-STATUS-2026-10-15.md)
> for that earlier state and the unresolved PR #2 reconciliation blocker. It is not a current
> verification of `main`. Port 4600 is now a ZIP download page, **not** an app preview;
> this review source is not an authorization to deploy or apply live SQL.

## Earlier local verification — 14 October 2026 (historical)

- Canva custom pamphlet wizard: PDF Standard / PNG/JPG/WEBP upload in the admin Document Studio, choose teaching page, keep original pages, reserve header/footer, paginate new editable text, preview and download PPTX plus editable JSON backup. PDF/image artwork is a replaceable **flattened** image, not automatically editable Canva text. Direct Canva PPTX import is unsupported.
- `npm test`: **169/169 unit tests passed**. Targeted Chromium/local-fixture browser run: **11/11 passed** (two Canva import flows plus existing PDF Studio, slide-design and reference-template regressions), including 360-pixel phone width and native PPTX XML text shapes. `tsc --noEmit`: PASS. Lint: 0 errors, 12 pre-existing fast-refresh warnings. Production build: PASS, existing large-chunk warning. Repository quality: PASS.
- No database migration, cleaner, Supabase reset, GitHub push/merge, or production deployment for this frontend addition. Port 3000 serves ZIP downloads only, not the app preview. To update a live site, deploy the full source ZIP into the **same configured Vercel project**, retaining the existing Supabase settings and a rollback/backup.
- Not certified on physical Android/iPhone devices, Safari/Firefox, native desktop PowerPoint, or the user's live Vercel/Supabase. The older baseline below predates this verification; its incomplete-test note is historical, not the current state.

## Earlier baseline — historical only

- Repository quality check: PASS (405 source files inspected)
- PWA readiness check: PASS
- TypeScript/TSX transpilation: PASS (279 files, 0 transpile diagnostics)
- package.json uses @tanstack/react-start 1.168.60
- Vercel framework is explicitly configured as `tanstack-start`
- Notes/study-material layouts were hardened for narrow mobile screens: no horizontal page overflow, horizontally scrollable filter chips, stacked resource cards/actions, and min-width containment.
- ETT Paper A and ETT Paper B are configured as free.
- Public legacy SQL download artifacts are removed.

## Not claimed as live verification

- Full npm install/build/lint/unit/E2E browser run was not completed here because dependency installation could not finish within the available network/runtime window.
- Live Supabase production cutover was not performed.
- Live Razorpay payments were not enabled or tested.

The source is prepared for the next real dependency install and deployment verification.
