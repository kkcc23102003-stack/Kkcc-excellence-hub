-- KKCC Excellence Hub: additive history hiding and private Storage updates.
-- Back up first. Apply to the same Supabase project after its current base schema.
-- Does not delete redemptions, grants, tests, notes, attempts, or Storage objects.

-- BEGIN MIGRATION: 20261020100000_admin_history_hiding.sql
-- Reversible admin-only list hiding. Never delete a coupon redemption or revoke
-- an access grant when an administrator removes it from a recent-history list.
BEGIN;

ALTER TABLE public.coupon_redemptions
  ADD COLUMN IF NOT EXISTS admin_hidden_at timestamptz;
ALTER TABLE public.series_access_grants
  ADD COLUMN IF NOT EXISTS admin_hidden_at timestamptz;

CREATE INDEX IF NOT EXISTS idx_coupon_redemptions_visible_created_at
  ON public.coupon_redemptions (created_at DESC)
  WHERE admin_hidden_at IS NULL;
CREATE INDEX IF NOT EXISTS idx_series_access_grants_visible_created_at
  ON public.series_access_grants (created_at DESC)
  WHERE admin_hidden_at IS NULL;

COMMENT ON COLUMN public.coupon_redemptions.admin_hidden_at IS
  'Admin-only reversible list hiding; preserves redemption history, usage count and granted access.';
COMMENT ON COLUMN public.series_access_grants.admin_hidden_at IS
  'Admin-only reversible list hiding; does not revoke or change the access grant.';

COMMIT;

-- END MIGRATION: 20261020100000_admin_history_hiding.sql

-- BEGIN MIGRATION: 20261020110000_custom_test_series_catalog_storage.sql
-- Store the custom test-series catalogue as an immutable private JSON object.
-- The Database settings row becomes a short versioned Storage pointer.
BEGIN;

INSERT INTO storage.buckets (id, name, public, file_size_limit, allowed_mime_types)
VALUES (
  'kkcc-test-series-catalog',
  'kkcc-test-series-catalog',
  false,
  20971520,
  ARRAY['application/json']
)
ON CONFLICT (id) DO UPDATE
SET public = false,
    file_size_limit = 20971520,
    allowed_mime_types = ARRAY['application/json'];

DO $$
BEGIN
  IF EXISTS (
    SELECT 1 FROM storage.buckets
    WHERE id = 'kkcc-test-series-catalog' AND public
  ) THEN
    RAISE EXCEPTION 'kkcc-test-series-catalog must remain PRIVATE';
  END IF;
END $$;

DROP POLICY IF EXISTS kkcc_test_series_catalog_server_only ON storage.objects;
CREATE POLICY kkcc_test_series_catalog_server_only
  ON storage.objects AS RESTRICTIVE
  FOR ALL TO anon, authenticated
  USING (bucket_id <> 'kkcc-test-series-catalog')
  WITH CHECK (bucket_id <> 'kkcc-test-series-catalog');

-- Compare the old catalogue hash inside PostgreSQL instead of putting a large
-- legacy JSON value in a PostgREST filter URL. Only service_role may update this
-- one pointer row; a failed compare-and-swap leaves the old value untouched.
CREATE OR REPLACE FUNCTION public.move_test_series_catalog_pointer(
  p_old_md5 text,
  p_new_value text
) RETURNS boolean
LANGUAGE plpgsql SECURITY DEFINER SET search_path = public, pg_temp AS $$
DECLARE changed integer;
BEGIN
  IF auth.role() IS DISTINCT FROM 'service_role' THEN
    RAISE EXCEPTION 'Server only';
  END IF;
  IF p_old_md5 IS NULL OR p_old_md5 !~ '^[a-f0-9]{32}$'
     OR p_new_value IS NULL OR p_new_value NOT LIKE 'kkcc-storage-json:v1:%' THEN
    RAISE EXCEPTION 'Invalid test-series Storage pointer';
  END IF;
  UPDATE public.kkcc_site_settings
  SET value = p_new_value, updated_at = clock_timestamp()
  WHERE key = 'test_series_custom_catalog'
    AND md5(coalesce(value, '')) = p_old_md5;
  GET DIAGNOSTICS changed = ROW_COUNT;
  RETURN changed = 1;
END;
$$;
REVOKE ALL ON FUNCTION public.move_test_series_catalog_pointer(text, text) FROM PUBLIC, anon, authenticated;
GRANT EXECUTE ON FUNCTION public.move_test_series_catalog_pointer(text, text) TO service_role;

NOTIFY pgrst, 'reload schema';
COMMIT;

-- END MIGRATION: 20261020110000_custom_test_series_catalog_storage.sql

-- BEGIN MIGRATION: 20261020120000_ai_archive_supabase_storage.sql
-- New AI question payloads use a private, bounded Supabase Storage bucket.
-- Database rows retain compact routing/review metadata and a verified hash.
BEGIN;

INSERT INTO storage.buckets (id, name, public, file_size_limit, allowed_mime_types)
VALUES (
  'kkcc-ai-question-archive',
  'kkcc-ai-question-archive',
  false,
  262144,
  ARRAY['application/json']
)
ON CONFLICT (id) DO UPDATE
SET public = false,
    file_size_limit = 262144,
    allowed_mime_types = ARRAY['application/json'];

DO $$
BEGIN
  IF EXISTS (
    SELECT 1 FROM storage.buckets
    WHERE id = 'kkcc-ai-question-archive' AND public
  ) THEN
    RAISE EXCEPTION 'kkcc-ai-question-archive must remain PRIVATE';
  END IF;

  IF to_regclass('public.ai_question_candidates') IS NOT NULL THEN
    ALTER TABLE public.ai_question_candidates
      ADD COLUMN IF NOT EXISTS archive_key text,
      ADD COLUMN IF NOT EXISTS content_hash text,
      ADD COLUMN IF NOT EXISTS archive_provider text;

    ALTER TABLE public.ai_question_candidates ALTER COLUMN prompt DROP NOT NULL;
    ALTER TABLE public.ai_question_candidates ALTER COLUMN options DROP NOT NULL;
    ALTER TABLE public.ai_question_candidates ALTER COLUMN explanation DROP NOT NULL;

    CREATE INDEX IF NOT EXISTS idx_ai_candidates_archive_key
      ON public.ai_question_candidates(archive_key);

    COMMENT ON TABLE public.ai_question_candidates IS
      'AI question candidate metadata only. New complete question payloads use the private kkcc-ai-question-archive Storage bucket; inline columns are retained only while legacy records are migrated.';
    COMMENT ON COLUMN public.ai_question_candidates.content_hash IS
      'SHA-256 of the complete UTF-8 JSON question payload in the private AI archive bucket.';
  END IF;
END $$;

DROP POLICY IF EXISTS kkcc_ai_question_archive_server_only ON storage.objects;
CREATE POLICY kkcc_ai_question_archive_server_only
  ON storage.objects AS RESTRICTIVE
  FOR ALL TO anon, authenticated
  USING (bucket_id <> 'kkcc-ai-question-archive')
  WITH CHECK (bucket_id <> 'kkcc-ai-question-archive');

NOTIFY pgrst, 'reload schema';
COMMIT;

-- END MIGRATION: 20261020120000_ai_archive_supabase_storage.sql

-- BEGIN MIGRATION: 20261020130000_notes_catalog_pointer_cas.sql
-- Atomically replace a potentially large legacy Notes catalogue value without
-- placing it in a PostgREST filter URL. Only the service role can call this.
BEGIN;

CREATE OR REPLACE FUNCTION public.move_notes_catalog_pointer(
  p_table text,
  p_key text,
  p_old_md5 text,
  p_new_value text
) RETURNS boolean
LANGUAGE plpgsql SECURITY DEFINER SET search_path = public, pg_temp AS $$
DECLARE changed integer;
BEGIN
  IF auth.role() IS DISTINCT FROM 'service_role' THEN
    RAISE EXCEPTION 'Server only';
  END IF;
  IF p_table NOT IN ('site_settings', 'private_settings')
     OR p_key !~ '^notes_(series|batch)_v1:[0-9a-f-]{36}$'
     OR p_old_md5 IS NULL OR p_old_md5 !~ '^[a-f0-9]{32}$'
     OR p_new_value IS NULL OR p_new_value NOT LIKE 'kkcc-storage-json:v1:%' THEN
    RAISE EXCEPTION 'Invalid Notes catalogue Storage pointer request';
  END IF;

  IF p_table = 'site_settings' THEN
    UPDATE public.kkcc_site_settings
    SET value = p_new_value, updated_at = clock_timestamp()
    WHERE key = p_key AND md5(coalesce(value, '')) = p_old_md5;
  ELSE
    UPDATE public.kkcc_private_settings
    SET value = p_new_value, updated_at = clock_timestamp()
    WHERE key = p_key AND md5(coalesce(value, '')) = p_old_md5;
  END IF;
  GET DIAGNOSTICS changed = ROW_COUNT;
  RETURN changed = 1;
END;
$$;

REVOKE ALL ON FUNCTION public.move_notes_catalog_pointer(text, text, text, text)
  FROM PUBLIC, anon, authenticated;
GRANT EXECUTE ON FUNCTION public.move_notes_catalog_pointer(text, text, text, text)
  TO service_role;
NOTIFY pgrst, 'reload schema';
COMMIT;

-- END MIGRATION: 20261020130000_notes_catalog_pointer_cas.sql



-- KKCC-educational-storage-setup: 20261020150000_educational_storage_setup.sql
-- Repair the private educational-file bucket used by course/material uploads.
-- Safe to re-run. Never opens this bucket to public/student roles.
BEGIN;

INSERT INTO storage.buckets (id, name, public, file_size_limit)
VALUES ('course-content', 'course-content', false, 47185920)
ON CONFLICT (id) DO UPDATE
SET name = 'course-content',
    public = false,
    file_size_limit = GREATEST(COALESCE(storage.buckets.file_size_limit, 0), EXCLUDED.file_size_limit);

-- Even if older permissive policies exist, a restrictive boundary keeps the
-- educational bucket admin-only for browser sessions. Student file delivery
-- uses short-lived URLs created after server-side access checks.
DROP POLICY IF EXISTS "KKCC educational bucket admin boundary" ON storage.objects;
CREATE POLICY "KKCC educational bucket admin boundary"
  ON storage.objects AS RESTRICTIVE
  FOR ALL TO anon, authenticated
  USING (bucket_id <> 'course-content' OR public.has_role(auth.uid(), 'admin'))
  WITH CHECK (bucket_id <> 'course-content' OR public.has_role(auth.uid(), 'admin'));

DROP POLICY IF EXISTS "Admins read course content" ON storage.objects;
CREATE POLICY "Admins read course content"
  ON storage.objects FOR SELECT TO authenticated
  USING (bucket_id = 'course-content' AND public.has_role(auth.uid(), 'admin'));

DROP POLICY IF EXISTS "Admins upload course content" ON storage.objects;
CREATE POLICY "Admins upload course content"
  ON storage.objects FOR INSERT TO authenticated
  WITH CHECK (bucket_id = 'course-content' AND public.has_role(auth.uid(), 'admin'));

DROP POLICY IF EXISTS "Admins update course content" ON storage.objects;
CREATE POLICY "Admins update course content"
  ON storage.objects FOR UPDATE TO authenticated
  USING (bucket_id = 'course-content' AND public.has_role(auth.uid(), 'admin'))
  WITH CHECK (bucket_id = 'course-content' AND public.has_role(auth.uid(), 'admin'));

DROP POLICY IF EXISTS "Admins delete course content" ON storage.objects;
CREATE POLICY "Admins delete course content"
  ON storage.objects FOR DELETE TO authenticated
  USING (bucket_id = 'course-content' AND public.has_role(auth.uid(), 'admin'));

CREATE OR REPLACE FUNCTION public.kkcc_educational_storage_setup_status()
RETURNS jsonb
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public, storage, pg_temp AS $$
DECLARE
  bucket_exists boolean;
  bucket_private boolean;
  upload_policy boolean;
  read_policy boolean;
  update_policy boolean;
  delete_policy boolean;
  boundary_policy boolean;
  upload_limit bigint;
BEGIN
  IF auth.role() IS DISTINCT FROM 'service_role' THEN
    RAISE EXCEPTION 'Server only';
  END IF;

  SELECT EXISTS (SELECT 1 FROM storage.buckets WHERE id = 'course-content')
    INTO bucket_exists;
  SELECT COALESCE((SELECT NOT public FROM storage.buckets WHERE id = 'course-content'), false),
         COALESCE((SELECT file_size_limit FROM storage.buckets WHERE id = 'course-content'), 0)
    INTO bucket_private, upload_limit;
  SELECT EXISTS (SELECT 1 FROM pg_policies WHERE schemaname = 'storage' AND tablename = 'objects' AND policyname = 'Admins upload course content'),
         EXISTS (SELECT 1 FROM pg_policies WHERE schemaname = 'storage' AND tablename = 'objects' AND policyname = 'Admins read course content'),
         EXISTS (SELECT 1 FROM pg_policies WHERE schemaname = 'storage' AND tablename = 'objects' AND policyname = 'Admins update course content'),
         EXISTS (SELECT 1 FROM pg_policies WHERE schemaname = 'storage' AND tablename = 'objects' AND policyname = 'Admins delete course content'),
         EXISTS (SELECT 1 FROM pg_policies WHERE schemaname = 'storage' AND tablename = 'objects' AND policyname = 'KKCC educational bucket admin boundary')
    INTO upload_policy, read_policy, update_policy, delete_policy, boundary_policy;

  RETURN jsonb_build_object(
    'bucket_exists', bucket_exists,
    'bucket_private', bucket_private,
    'file_size_limit', upload_limit,
    'upload_policy', upload_policy,
    'read_policy', read_policy,
    'update_policy', update_policy,
    'delete_policy', delete_policy,
    'boundary_policy', boundary_policy,
    'ready', bucket_exists AND bucket_private AND upload_limit >= 47185920
      AND upload_policy AND read_policy AND update_policy AND delete_policy AND boundary_policy
  );
END;
$$;
REVOKE ALL ON FUNCTION public.kkcc_educational_storage_setup_status() FROM PUBLIC, anon, authenticated;
GRANT EXECUTE ON FUNCTION public.kkcc_educational_storage_setup_status() TO service_role;

NOTIFY pgrst, 'reload schema';
COMMIT;
