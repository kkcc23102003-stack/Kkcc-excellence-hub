-- KKCC Excellence Hub: additive history hiding and private Storage updates.
-- Back up first. Apply to the same Supabase project after its current base schema.
-- Does not delete redemptions, grants, tests, notes, attempts, or Storage objects.

-- BEGIN MIGRATION: 20261020100000_admin_history_hiding.sql
-- Reversible admin-only list hiding. Never delete a coupon redemption or revoke
-- an access grant when an administrator removes it from a recent-history list.
BEGIN;

ALTER TABLE public.coupon_redemptions
  ADD COLUMN IF NOT EXISTS admin_hidden_at timestamptz;
ALTER TABLE public.series_access_grants
  ADD COLUMN IF NOT EXISTS admin_hidden_at timestamptz;

CREATE INDEX IF NOT EXISTS idx_coupon_redemptions_visible_created_at
  ON public.coupon_redemptions (created_at DESC)
  WHERE admin_hidden_at IS NULL;
CREATE INDEX IF NOT EXISTS idx_series_access_grants_visible_created_at
  ON public.series_access_grants (created_at DESC)
  WHERE admin_hidden_at IS NULL;

COMMENT ON COLUMN public.coupon_redemptions.admin_hidden_at IS
  'Admin-only reversible list hiding; preserves redemption history, usage count and granted access.';
COMMENT ON COLUMN public.series_access_grants.admin_hidden_at IS
  'Admin-only reversible list hiding; does not revoke or change the access grant.';

COMMIT;

-- END MIGRATION: 20261020100000_admin_history_hiding.sql

-- BEGIN MIGRATION: 20261020110000_custom_test_series_catalog_storage.sql
-- Store the custom test-series catalogue as an immutable private JSON object.
-- The Database settings row becomes a short versioned Storage pointer.
BEGIN;

INSERT INTO storage.buckets (id, name, public, file_size_limit, allowed_mime_types)
VALUES (
  'kkcc-test-series-catalog',
  'kkcc-test-series-catalog',
  false,
  20971520,
  ARRAY['application/json']
)
ON CONFLICT (id) DO UPDATE
SET public = false,
    file_size_limit = 20971520,
    allowed_mime_types = ARRAY['application/json'];

DO $$
BEGIN
  IF EXISTS (
    SELECT 1 FROM storage.buckets
    WHERE id = 'kkcc-test-series-catalog' AND public
  ) THEN
    RAISE EXCEPTION 'kkcc-test-series-catalog must remain PRIVATE';
  END IF;
END $$;

DROP POLICY IF EXISTS kkcc_test_series_catalog_server_only ON storage.objects;
CREATE POLICY kkcc_test_series_catalog_server_only
  ON storage.objects AS RESTRICTIVE
  FOR ALL TO anon, authenticated
  USING (bucket_id <> 'kkcc-test-series-catalog')
  WITH CHECK (bucket_id <> 'kkcc-test-series-catalog');

-- Compare the old catalogue hash inside PostgreSQL instead of putting a large
-- legacy JSON value in a PostgREST filter URL. Only service_role may update this
-- one pointer row; a failed compare-and-swap leaves the old value untouched.
CREATE OR REPLACE FUNCTION public.move_test_series_catalog_pointer(
  p_old_md5 text,
  p_new_value text
) RETURNS boolean
LANGUAGE plpgsql SECURITY DEFINER SET search_path = public, pg_temp AS $$
DECLARE changed integer;
BEGIN
  IF auth.role() IS DISTINCT FROM 'service_role' THEN
    RAISE EXCEPTION 'Server only';
  END IF;
  IF p_old_md5 IS NULL OR p_old_md5 !~ '^[a-f0-9]{32}$'
     OR p_new_value IS NULL OR p_new_value NOT LIKE 'kkcc-storage-json:v1:%' THEN
    RAISE EXCEPTION 'Invalid test-series Storage pointer';
  END IF;
  UPDATE public.kkcc_site_settings
  SET value = p_new_value, updated_at = clock_timestamp()
  WHERE key = 'test_series_custom_catalog'
    AND md5(coalesce(value, '')) = p_old_md5;
  GET DIAGNOSTICS changed = ROW_COUNT;
  RETURN changed = 1;
END;
$$;
REVOKE ALL ON FUNCTION public.move_test_series_catalog_pointer(text, text) FROM PUBLIC, anon, authenticated;
GRANT EXECUTE ON FUNCTION public.move_test_series_catalog_pointer(text, text) TO service_role;

NOTIFY pgrst, 'reload schema';
COMMIT;

-- END MIGRATION: 20261020110000_custom_test_series_catalog_storage.sql

-- BEGIN MIGRATION: 20261020120000_ai_archive_supabase_storage.sql
-- New AI question payloads use a private, bounded Supabase Storage bucket.
-- Database rows retain compact routing/review metadata and a verified hash.
BEGIN;

INSERT INTO storage.buckets (id, name, public, file_size_limit, allowed_mime_types)
VALUES (
  'kkcc-ai-question-archive',
  'kkcc-ai-question-archive',
  false,
  262144,
  ARRAY['application/json']
)
ON CONFLICT (id) DO UPDATE
SET public = false,
    file_size_limit = 262144,
    allowed_mime_types = ARRAY['application/json'];

DO $$
BEGIN
  IF EXISTS (
    SELECT 1 FROM storage.buckets
    WHERE id = 'kkcc-ai-question-archive' AND public
  ) THEN
    RAISE EXCEPTION 'kkcc-ai-question-archive must remain PRIVATE';
  END IF;

  IF to_regclass('public.ai_question_candidates') IS NOT NULL THEN
    ALTER TABLE public.ai_question_candidates
      ADD COLUMN IF NOT EXISTS archive_key text,
      ADD COLUMN IF NOT EXISTS content_hash text,
      ADD COLUMN IF NOT EXISTS archive_provider text;

    ALTER TABLE public.ai_question_candidates ALTER COLUMN prompt DROP NOT NULL;
    ALTER TABLE public.ai_question_candidates ALTER COLUMN options DROP NOT NULL;
    ALTER TABLE public.ai_question_candidates ALTER COLUMN explanation DROP NOT NULL;

    CREATE INDEX IF NOT EXISTS idx_ai_candidates_archive_key
      ON public.ai_question_candidates(archive_key);

    COMMENT ON TABLE public.ai_question_candidates IS
      'AI question candidate metadata only. New complete question payloads use the private kkcc-ai-question-archive Storage bucket; inline columns are retained only while legacy records are migrated.';
    COMMENT ON COLUMN public.ai_question_candidates.content_hash IS
      'SHA-256 of the complete UTF-8 JSON question payload in the private AI archive bucket.';
  END IF;
END $$;

DROP POLICY IF EXISTS kkcc_ai_question_archive_server_only ON storage.objects;
CREATE POLICY kkcc_ai_question_archive_server_only
  ON storage.objects AS RESTRICTIVE
  FOR ALL TO anon, authenticated
  USING (bucket_id <> 'kkcc-ai-question-archive')
  WITH CHECK (bucket_id <> 'kkcc-ai-question-archive');

NOTIFY pgrst, 'reload schema';
COMMIT;

-- END MIGRATION: 20261020120000_ai_archive_supabase_storage.sql

-- BEGIN MIGRATION: 20261020130000_notes_catalog_pointer_cas.sql
-- Atomically replace a potentially large legacy Notes catalogue value without
-- placing it in a PostgREST filter URL. Only the service role can call this.
BEGIN;

CREATE OR REPLACE FUNCTION public.move_notes_catalog_pointer(
  p_table text,
  p_key text,
  p_old_md5 text,
  p_new_value text
) RETURNS boolean
LANGUAGE plpgsql SECURITY DEFINER SET search_path = public, pg_temp AS $$
DECLARE changed integer;
BEGIN
  IF auth.role() IS DISTINCT FROM 'service_role' THEN
    RAISE EXCEPTION 'Server only';
  END IF;
  IF p_table NOT IN ('site_settings', 'private_settings')
     OR p_key !~ '^notes_(series|batch)_v1:[0-9a-f-]{36}$'
     OR p_old_md5 IS NULL OR p_old_md5 !~ '^[a-f0-9]{32}$'
     OR p_new_value IS NULL OR p_new_value NOT LIKE 'kkcc-storage-json:v1:%' THEN
    RAISE EXCEPTION 'Invalid Notes catalogue Storage pointer request';
  END IF;

  IF p_table = 'site_settings' THEN
    UPDATE public.kkcc_site_settings
    SET value = p_new_value, updated_at = clock_timestamp()
    WHERE key = p_key AND md5(coalesce(value, '')) = p_old_md5;
  ELSE
    UPDATE public.kkcc_private_settings
    SET value = p_new_value, updated_at = clock_timestamp()
    WHERE key = p_key AND md5(coalesce(value, '')) = p_old_md5;
  END IF;
  GET DIAGNOSTICS changed = ROW_COUNT;
  RETURN changed = 1;
END;
$$;

REVOKE ALL ON FUNCTION public.move_notes_catalog_pointer(text, text, text, text)
  FROM PUBLIC, anon, authenticated;
GRANT EXECUTE ON FUNCTION public.move_notes_catalog_pointer(text, text, text, text)
  TO service_role;
NOTIFY pgrst, 'reload schema';
COMMIT;

-- END MIGRATION: 20261020130000_notes_catalog_pointer_cas.sql

