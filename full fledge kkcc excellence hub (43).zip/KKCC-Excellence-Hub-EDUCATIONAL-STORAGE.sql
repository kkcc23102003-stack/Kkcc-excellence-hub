-- Repair the private educational-file bucket used by course/material uploads.
-- Safe to re-run. Never opens this bucket to public/student roles.
BEGIN;

INSERT INTO storage.buckets (id, name, public, file_size_limit)
VALUES ('course-content', 'course-content', false, 47185920)
ON CONFLICT (id) DO UPDATE
SET name = 'course-content',
    public = false,
    file_size_limit = GREATEST(COALESCE(storage.buckets.file_size_limit, 0), EXCLUDED.file_size_limit);

-- Even if older permissive policies exist, a restrictive boundary keeps the
-- educational bucket admin-only for browser sessions. Student file delivery
-- uses short-lived URLs created after server-side access checks.
DROP POLICY IF EXISTS "KKCC educational bucket admin boundary" ON storage.objects;
CREATE POLICY "KKCC educational bucket admin boundary"
  ON storage.objects AS RESTRICTIVE
  FOR ALL TO anon, authenticated
  USING (bucket_id <> 'course-content' OR public.has_role(auth.uid(), 'admin'))
  WITH CHECK (bucket_id <> 'course-content' OR public.has_role(auth.uid(), 'admin'));

DROP POLICY IF EXISTS "Admins read course content" ON storage.objects;
CREATE POLICY "Admins read course content"
  ON storage.objects FOR SELECT TO authenticated
  USING (bucket_id = 'course-content' AND public.has_role(auth.uid(), 'admin'));

DROP POLICY IF EXISTS "Admins upload course content" ON storage.objects;
CREATE POLICY "Admins upload course content"
  ON storage.objects FOR INSERT TO authenticated
  WITH CHECK (bucket_id = 'course-content' AND public.has_role(auth.uid(), 'admin'));

DROP POLICY IF EXISTS "Admins update course content" ON storage.objects;
CREATE POLICY "Admins update course content"
  ON storage.objects FOR UPDATE TO authenticated
  USING (bucket_id = 'course-content' AND public.has_role(auth.uid(), 'admin'))
  WITH CHECK (bucket_id = 'course-content' AND public.has_role(auth.uid(), 'admin'));

DROP POLICY IF EXISTS "Admins delete course content" ON storage.objects;
CREATE POLICY "Admins delete course content"
  ON storage.objects FOR DELETE TO authenticated
  USING (bucket_id = 'course-content' AND public.has_role(auth.uid(), 'admin'));

CREATE OR REPLACE FUNCTION public.kkcc_educational_storage_setup_status()
RETURNS jsonb
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public, storage, pg_temp AS $$
DECLARE
  bucket_exists boolean;
  bucket_private boolean;
  upload_policy boolean;
  read_policy boolean;
  update_policy boolean;
  delete_policy boolean;
  boundary_policy boolean;
  upload_limit bigint;
BEGIN
  IF auth.role() IS DISTINCT FROM 'service_role' THEN
    RAISE EXCEPTION 'Server only';
  END IF;

  SELECT EXISTS (SELECT 1 FROM storage.buckets WHERE id = 'course-content')
    INTO bucket_exists;
  SELECT COALESCE((SELECT NOT public FROM storage.buckets WHERE id = 'course-content'), false),
         COALESCE((SELECT file_size_limit FROM storage.buckets WHERE id = 'course-content'), 0)
    INTO bucket_private, upload_limit;
  SELECT EXISTS (SELECT 1 FROM pg_policies WHERE schemaname = 'storage' AND tablename = 'objects' AND policyname = 'Admins upload course content'),
         EXISTS (SELECT 1 FROM pg_policies WHERE schemaname = 'storage' AND tablename = 'objects' AND policyname = 'Admins read course content'),
         EXISTS (SELECT 1 FROM pg_policies WHERE schemaname = 'storage' AND tablename = 'objects' AND policyname = 'Admins update course content'),
         EXISTS (SELECT 1 FROM pg_policies WHERE schemaname = 'storage' AND tablename = 'objects' AND policyname = 'Admins delete course content'),
         EXISTS (SELECT 1 FROM pg_policies WHERE schemaname = 'storage' AND tablename = 'objects' AND policyname = 'KKCC educational bucket admin boundary')
    INTO upload_policy, read_policy, update_policy, delete_policy, boundary_policy;

  RETURN jsonb_build_object(
    'bucket_exists', bucket_exists,
    'bucket_private', bucket_private,
    'file_size_limit', upload_limit,
    'upload_policy', upload_policy,
    'read_policy', read_policy,
    'update_policy', update_policy,
    'delete_policy', delete_policy,
    'boundary_policy', boundary_policy,
    'ready', bucket_exists AND bucket_private AND upload_limit >= 47185920
      AND upload_policy AND read_policy AND update_policy AND delete_policy AND boundary_policy
  );
END;
$$;
REVOKE ALL ON FUNCTION public.kkcc_educational_storage_setup_status() FROM PUBLIC, anon, authenticated;
GRANT EXECUTE ON FUNCTION public.kkcc_educational_storage_setup_status() TO service_role;

NOTIFY pgrst, 'reload schema';
COMMIT;
