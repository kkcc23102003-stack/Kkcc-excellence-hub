/* Original editable reconstruction, not a screenshot background. */
const fs = require("fs");
const path = require("path");
const { createRequire } = require("module");
const tools = process.env.KKCC_DESIGN_TOOLKIT
  ? createRequire(path.join(process.env.KKCC_DESIGN_TOOLKIT, "package.json"))
  : require;
const PptxGenJS = tools("pptxgenjs");
const { Resvg } = tools("@resvg/resvg-js");
const root = __dirname,
  W = 1280,
  H = 1024;
const logo = fs.readFileSync(path.join(root, "assets/logo.png")).toString("base64");
const fontFiles = ["great-vibes", "anton"].map((n) => path.join(root, "fonts", n + ".ttf"));
const esc = (s) => s.replaceAll("&", "&amp;").replaceAll("<", "&lt;").replaceAll('"', "&quot;");
let seed = 23102003;
const rand = () => {
  seed = (Math.imul(seed, 1664525) + 1013904223) >>> 0;
  return seed / 4294967296;
};
const galaxy = [];
function ellipse(x, y, w, h, fill, opacity, rotate = 0) {
  galaxy.push({ type: "ellipse", x, y, w, h, fill, opacity, rotate });
}
// Hundreds of separately editable glow ellipses and stars, with a lower-left nebula.
for (const [cx, cy, rx, ry, col, alpha, rot] of [
  [236, 681, 206, 264, "006cac", 0.025, -30],
  [224, 663, 130, 184, "048bdb", 0.035, -30],
  [217, 651, 82, 124, "40d3ef", 0.07, -30],
  [435, 802, 132, 252, "0076ac", 0.035, 21],
  [437, 783, 59, 170, "08b9d6", 0.035, 21],
  [680, 600, 440, 390, "003b75", 0.009, 0],
]) {
  for (let i = 0; i < 64; i++) {
    const k = 1 - i / 72;
    ellipse(cx - rx * k, cy - ry * k, rx * 2 * k, ry * 2 * k, col, (alpha * 24) / 64, rot);
  }
}
for (let i = 0; i < 1150; i++) {
  const x = 24 + rand() * 1230,
    y = 12 + rand() * 990,
    large = rand() > 0.945;
  const r = large ? 2 + rand() * 2.2 : 0.45 + rand() * 1.15;
  const bright = (0.2 + rand() * 0.65) * (x < 850 ? 1 : 0.65);
  if (large) {
    for (let j = 4; j > 0; j--)
      ellipse(x - r * j, y - r * j, r * j * 2, r * j * 2, "49caff", 0.035);
  }
  ellipse(x - r, y - r, r * 2, r * 2, large ? "bcf5ff" : "56bbec", bright);
  if (large) {
    galaxy.push({
      type: "rect",
      x: x - 0.4,
      y: y - r * 2.5,
      w: 0.8,
      h: r * 5,
      fill: "a0eaff",
      opacity: 0.4,
    });
    galaxy.push({
      type: "rect",
      x: x - r * 2.5,
      y: y - 0.4,
      w: r * 5,
      h: 0.8,
      fill: "a0eaff",
      opacity: 0.4,
    });
  }
}
function line(y) {
  return Array.from({ length: 100 }, (_, i) => ({
    type: "rect",
    x: (i * W) / 100,
    y,
    w: W / 100 + 0.2,
    h: 2.8,
    fill: [
      Math.round(10 + (245 * i) / 99),
      Math.round(228 + (16 * i) / 99),
      Math.round(239 - (181 * i) / 99),
    ]
      .map((n) => n.toString(16).padStart(2, "0"))
      .join(""),
    opacity: 1,
  }));
}
function text(value, x, y, w, h, size, font = "Great Vibes", glow = true, align = "center") {
  return {
    type: "text",
    text: value,
    x,
    y,
    w,
    h,
    size,
    font,
    glow,
    italic: font === "Anton",
    align,
    fill: glow ? "13ef79" : "e6dfea",
    opacity: 1,
  };
}
const logoNode = { type: "image", x: 1170, y: 10, w: 101, h: 101 };
const teaching = [
  ...galaxy,
  { type: "rect", x: 0, y: 0, w: W, h: 122, fill: "040e13", opacity: 1 },
  { type: "rect", x: 0, y: 907, w: W, h: 117, fill: "060d17", opacity: 1 },
  ...line(123),
  ...line(904),
  logoNode,
  text("K.K.2.3.1.0", 44, 923, 350, 59, 62),
  text("KARTIK", 117, 974, 201, 49, 54, "Anton", false),
  text("Brahmastra...", 926, 918, 333, 62, 64),
  text("ACCOUNTANCY", 945, 975, 318, 47, 47, "Anton", false),
];
const cover = [
  ...galaxy,
  logoNode,
  text("Brahmastra...", 49, 91, 1180, 206, 201),
  text("PSTET-2025", 169, 305, 975, 205, 221, "Anton", false),
  text("K.K.2.3.1.0", 92, 684, 1118, 205, 194),
  text("KARTIK", 401, 878, 497, 142, 147, "Anton", false),
];
const css = `@font-face{font-family:'Great Vibes';src:url(data:font/ttf;base64,${fs.readFileSync(fontFiles[0]).toString("base64")})}@font-face{font-family:Anton;src:url(data:font/ttf;base64,${fs.readFileSync(fontFiles[1]).toString("base64")})}`;
function nodeSvg(n) {
  if (n.type === "image")
    return `<image x="${n.x}" y="${n.y}" width="${n.w}" height="${n.h}" href="data:image/png;base64,${logo}"/>`;
  if (n.type === "text") {
    const x = n.align === "center" ? n.x + n.w / 2 : n.x;
    const baseline = n.y + n.size * (n.font === "Anton" ? 0.91 : 0.82);
    return `<text data-editable="true" x="${x}" y="${baseline}" text-anchor="${n.align === "center" ? "middle" : "start"}" font-family="${n.font}" font-size="${n.size}" font-style="normal" ${n.italic ? `transform="translate(${baseline * Math.tan(Math.PI / 18)} 0) skewX(-10)"` : ""} fill="#${n.fill}" ${n.glow ? 'filter="url(#neon)"' : ""}>${esc(n.text)}</text>`;
  }
  const rot = n.rotate ? ` transform="rotate(${n.rotate},${n.x + n.w / 2},${n.y + n.h / 2})"` : "";
  return n.type === "ellipse"
    ? `<ellipse cx="${n.x + n.w / 2}" cy="${n.y + n.h / 2}" rx="${n.w / 2}" ry="${n.h / 2}" fill="#${n.fill}" opacity="${n.opacity}"${rot}/>`
    : `<rect x="${n.x}" y="${n.y}" width="${n.w}" height="${n.h}" fill="#${n.fill}" opacity="${n.opacity}"/>`;
}
function svg(nodes) {
  return `<svg xmlns="http://www.w3.org/2000/svg" width="1280" height="1024" viewBox="0 0 1280 1024"><defs><style>${css}</style><filter id="neon" x="-30%" y="-60%" width="160%" height="220%"><feGaussianBlur stdDeviation="4" result="blur"/><feMerge><feMergeNode in="blur"/><feMergeNode in="blur"/><feMergeNode in="SourceGraphic"/></feMerge></filter></defs><rect width="1280" height="1024" fill="#020b17"/>${nodes.map(nodeSvg).join("")}</svg>`;
}
const render = (s) =>
  new Resvg(s, { font: { fontFiles, loadSystemFonts: false } }).render().asPng();
for (const [name, nodes] of [
  ["01-teaching-slide", teaching],
  ["02-cover-pstet", cover],
]) {
  const s = svg(nodes);
  fs.writeFileSync(path.join(root, name + ".svg"), s);
  fs.writeFileSync(path.join(root, name + ".png"), render(s));
}
fs.writeFileSync(path.join(root, "assets/galaxy-original.png"), render(svg(galaxy)));
const pptx = new PptxGenJS();
pptx.defineLayout({ name: "REFERENCE", width: W / 96, height: H / 96 });
pptx.layout = "REFERENCE";
pptx.author = "Kusum Kartik Coaching Centre";
pptx.title = "Brahmastra — editable reference reconstruction";
pptx.subject = "Original starfield shapes, native editable text and separate replaceable KKCC logo";
for (const [i, nodes] of [teaching, cover].entries()) {
  const slide = pptx.addSlide();
  slide.background = { color: "020b17" };
  for (const [j, n] of nodes.entries()) {
    const g = { x: n.x / 96, y: n.y / 96, w: n.w / 96, h: n.h / 96 };
    if (n.type === "text")
      slide.addText(n.text, {
        ...g,
        y: Math.max(0, n.y - n.size * (n.font === "Anton" ? 0.1 : 0.22)) / 96,
        h:
          Math.min(
            H - Math.max(0, n.y - n.size * (n.font === "Anton" ? 0.1 : 0.22)),
            n.size * 1.5,
          ) / 96,
        fontFace: n.font,
        fontSize: n.size * 0.75,
        color: n.fill,
        italic: n.italic,
        align: n.align,
        margin: 0,
        breakLine: false,
        wrap: false,
        valign: "top",
        transparency: 0,
        ...(n.glow ? { glow: { color: "00ef70", opacity: 0.75, size: 7 } } : {}),
        objectName: `Editable text: ${n.text}`,
      });
    else if (n.type === "image")
      slide.addImage({
        ...g,
        data: "data:image/png;base64," + logo,
        objectName: "Replaceable original KKCC logo",
      });
    else
      slide.addShape(n.type === "ellipse" ? pptx.ShapeType.ellipse : pptx.ShapeType.rect, {
        ...g,
        rotate: n.rotate || 0,
        line: { transparency: 100 },
        fill: { color: n.fill, transparency: 100 * (1 - n.opacity) },
        objectName: `${n.type === "ellipse" ? "Star / nebula" : "Band / spectrum"} ${j + 1}`,
      });
  }
  slide.addNotes(
    i === 0
      ? "Blank teaching area intentionally retained. All stars, nebula layers, spectrum segments and footer text are editable. Use Selection Pane to select small shapes."
      : "Text intentionally matches the supplied reference, including PSTET-2025. Edit to any exam/year. Install the bundled OFL fonts before editing.",
  );
}
(async () => {
  await pptx.writeFile({
    fileName: path.join(root, "KKCC-reference-editable.pptx"),
    compression: true,
  });
  fs.writeFileSync(
    path.join(root, "layout-source.json"),
    JSON.stringify({ width: W, height: H, slides: [teaching, cover] }, null, 2),
  );
  console.log(`Created two editable slides: ${teaching.length} / ${cover.length} objects.`);
})();

// Compact app project: text/logo/bands stay editable; the 1,800-object starfield is one
// independently generated background layer to respect the app's 40-object limit.
const { randomUUID } = require("crypto");
const bg =
  "data:image/png;base64," +
  fs.readFileSync(path.join(root, "assets/galaxy-original.png")).toString("base64");
const strip = render(
  `<svg xmlns="http://www.w3.org/2000/svg" width="1280" height="4">${line(0).map(nodeSvg).join("")}</svg>`,
);
fs.writeFileSync(path.join(root, "assets/spectrum-line.png"), strip);
const base = (type, x, y, w, h) => ({
  id: randomUUID(),
  type,
  x: (x / W) * 100,
  y: (y / H) * 100,
  w: (w / W) * 100,
  h: (h / H) * 100,
  text: "",
  image: "",
  colour: "#ffffff",
  fill: "#020b17",
  fontSize: 20,
  bold: false,
  align: "center",
});
const decks = [teaching, cover].map((nodes, i) => {
  const objects = [{ ...base("image", 0, 0, W, H), image: bg, role: "decoration" }];
  if (i === 0) {
    for (const [y, h] of [
      [0, 122],
      [907, 117],
    ])
      objects.push({
        ...base("rectangle", 0, y, W, h),
        fill: y ? "#060d17" : "#040e13",
        role: "decoration",
      });
    for (const y of [123, 904])
      objects.push({
        ...base("image", 0, y, W, 3),
        image: "data:image/png;base64," + strip.toString("base64"),
        role: "decoration",
      });
  }
  objects.push({
    ...base("image", logoNode.x, logoNode.y, logoNode.w, logoNode.h),
    image: "data:image/png;base64," + logo,
    slot: "logo",
    role: "brand",
  });
  for (const n of nodes.filter((n) => n.type === "text")) {
    const y = Math.max(0, n.y - n.size * (n.font === "Anton" ? 0.1 : 0.22)),
      x = Math.max(0, n.x - 18),
      w = Math.min(W - x, n.w + 36),
      h = Math.min(H - y, n.size * 1.5);
    objects.push({
      ...base("text", x, y, w, h),
      text: n.text,
      fontSize: Math.min(n.size / 2, h / 2 / 1.3),
      font: n.font === "Anton" ? "condensed" : "display",
      italic: n.italic,
      glow: n.glow,
      colour: "#" + n.fill,
      role: "content",
      slot:
        n.text === "Brahmastra..."
          ? "series"
          : n.text === "KARTIK"
            ? "teacher"
            : n.text.startsWith("K.K.")
              ? "appName"
              : "subject",
    });
  }
  return {
    id: randomUUID(),
    background: "#020b17",
    design: "galaxy",
    purpose: i ? "cover" : "lesson",
    notes:
      "Reference reconstruction. Galaxy is a compact replaceable image in the app project; every star is a native shape in the separately supplied PPTX.",
    elements: objects,
  };
});
fs.writeFileSync(
  path.join(root, "KKCC-reference.kkcc-presentation.json"),
  JSON.stringify(
    {
      version: 1,
      title: "Brahmastra reference designs",
      size: { width: 640, height: 512 },
      brand: {
        appName: "K.K.2.3.1.0",
        series: "Brahmastra...",
        teacher: "KARTIK",
        subject: "PSTET-2025",
      },
      slides: decks,
    },
    null,
    2,
  ),
);
