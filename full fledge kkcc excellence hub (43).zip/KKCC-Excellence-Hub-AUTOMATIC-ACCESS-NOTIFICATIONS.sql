-- Add a nullable idempotency key for generated in-app notifications.
-- Existing manually authored notifications remain unchanged; generated events can
-- use a stable key so a retried write cannot create a duplicate inbox item.
ALTER TABLE public.notifications
  ADD COLUMN IF NOT EXISTS event_key text;

-- Mark one already-sent launch notice per course URL so a later
-- unpublish/republish does not announce the same batch a second time.
WITH legacy_batch_events AS (
  SELECT
    n.id,
    n.action_url,
    row_number() OVER (PARTITION BY n.action_url ORDER BY n.created_at, n.id) AS occurrence
  FROM public.notifications AS n
  WHERE n.type = 'batch'
    AND n.audience = 'students'
    AND n.action_url LIKE '/courses/%'
    AND n.event_key IS NULL
)
UPDATE public.notifications AS n
SET event_key = 'batch-launch:' || legacy_batch_events.action_url
FROM legacy_batch_events
WHERE n.id = legacy_batch_events.id
  AND legacy_batch_events.occurrence = 1;

CREATE UNIQUE INDEX IF NOT EXISTS notifications_event_key_unique
  ON public.notifications (event_key)
  WHERE event_key IS NOT NULL;
