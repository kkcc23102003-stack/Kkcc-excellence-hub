-- Safe, audited restoration/renewal of existing student access.
-- This migration adds only an admin audit table and a guarded RPC. It does not
-- alter existing students, prices, purchases, coupon redemptions or grants.
BEGIN;

CREATE TABLE IF NOT EXISTS public.admin_access_recovery_events (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  -- Keep the event if a student account is later removed; this is a durable audit record.
  user_id uuid NOT NULL,
  admin_id uuid REFERENCES auth.users(id) ON DELETE SET NULL,
  record_kind text NOT NULL CHECK (record_kind IN ('course','test','series','notes_series','note','note_purchase')),
  record_id uuid NOT NULL,
  product_id text NOT NULL,
  action text NOT NULL CHECK (action IN ('restored','renewed','regranted')),
  reason text NOT NULL CHECK (length(btrim(reason)) BETWEEN 4 AND 500),
  before_state jsonb NOT NULL,
  after_state jsonb NOT NULL,
  created_at timestamptz NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS admin_access_recovery_events_student_idx
  ON public.admin_access_recovery_events(user_id, created_at DESC);
CREATE INDEX IF NOT EXISTS admin_access_recovery_events_admin_idx
  ON public.admin_access_recovery_events(admin_id, created_at DESC);

ALTER TABLE public.admin_access_recovery_events ENABLE ROW LEVEL SECURITY;
REVOKE ALL ON public.admin_access_recovery_events FROM PUBLIC, anon, authenticated, service_role;
GRANT SELECT ON public.admin_access_recovery_events TO authenticated;
GRANT SELECT, INSERT ON public.admin_access_recovery_events TO service_role;
DROP POLICY IF EXISTS admin_access_recovery_events_admin_read ON public.admin_access_recovery_events;
CREATE POLICY admin_access_recovery_events_admin_read
  ON public.admin_access_recovery_events
  FOR SELECT TO authenticated
  USING (public.has_role(auth.uid(), 'admin'));

CREATE OR REPLACE FUNCTION public.reject_admin_access_recovery_event_mutation()
RETURNS trigger
LANGUAGE plpgsql
SET search_path = public
AS $$
BEGIN
  RAISE EXCEPTION 'Access recovery audit events are immutable';
END;
$$;
REVOKE ALL ON FUNCTION public.reject_admin_access_recovery_event_mutation() FROM PUBLIC;
DROP TRIGGER IF EXISTS admin_access_recovery_events_immutable ON public.admin_access_recovery_events;
CREATE TRIGGER admin_access_recovery_events_immutable
  BEFORE UPDATE OR DELETE ON public.admin_access_recovery_events
  FOR EACH ROW EXECUTE FUNCTION public.reject_admin_access_recovery_event_mutation();

CREATE OR REPLACE FUNCTION public.admin_recover_access(
  p_user_id uuid,
  p_kind text,
  p_record_id uuid,
  p_validity_mode text,
  p_valid_days integer,
  p_reason text
) RETURNS jsonb
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  v_now timestamptz := now();
  v_expiry timestamptz;
  v_old_expiry timestamptz;
  v_previous_state text;
  v_action text;
  v_product_id text;
  v_before jsonb;
  v_after jsonb;
  v_previous_grant jsonb;
  v_note text;
  v_entry text;
  v_revoked_at timestamptz;
  v_source text;
  v_event_id uuid;
  v_grant_id uuid;
  v_has_other_unrevoked boolean;
BEGIN
  IF auth.uid() IS NULL OR NOT public.has_role(auth.uid(), 'admin')
     OR public.is_user_blocked(auth.uid()) THEN
    RAISE EXCEPTION 'Forbidden — admin access required';
  END IF;
  IF NOT EXISTS (SELECT 1 FROM public.profiles WHERE id = p_user_id) THEN
    RAISE EXCEPTION 'Student profile not found';
  END IF;
  IF public.is_user_blocked(p_user_id) THEN
    RAISE EXCEPTION 'Student account is blocked; unblock it separately before restoring access';
  END IF;
  IF p_kind IS NULL OR p_kind NOT IN ('course','test','series','notes_series','note','note_purchase') THEN
    RAISE EXCEPTION 'Unsupported access type';
  END IF;
  IF p_validity_mode IS NULL OR p_validity_mode NOT IN ('keep','days','lifetime') THEN
    RAISE EXCEPTION 'Choose an access validity';
  END IF;
  IF p_validity_mode = 'days' AND (p_valid_days IS NULL OR p_valid_days NOT BETWEEN 1 AND 3650) THEN
    RAISE EXCEPTION 'Renewal must be between 1 and 3650 days';
  END IF;
  IF length(btrim(COALESCE(p_reason, ''))) NOT BETWEEN 4 AND 500 THEN
    RAISE EXCEPTION 'Enter a reason between 4 and 500 characters';
  END IF;

  PERFORM pg_advisory_xact_lock(hashtext(p_user_id::text || ':' || p_kind || ':' || p_record_id::text));

  IF p_kind = 'course' THEN
    SELECT to_jsonb(e), e.course_id::text, e.status, e.expires_at, e.admin_note, e.source
      INTO v_before, v_product_id, v_previous_state, v_old_expiry, v_note, v_source
      FROM public.course_enrollments e
      WHERE e.id = p_record_id AND e.user_id = p_user_id
      FOR UPDATE;
    IF NOT FOUND THEN RAISE EXCEPTION 'Course access record not found'; END IF;
    IF v_previous_state = 'revoked' THEN
      v_previous_state := 'revoked';
    ELSIF v_previous_state = 'expired' OR (v_old_expiry IS NOT NULL AND v_old_expiry <= v_now) THEN
      v_previous_state := 'expired';
    ELSE
      RAISE EXCEPTION 'This course access is already active';
    END IF;

  ELSIF p_kind = 'test' THEN
    SELECT to_jsonb(g), g.test_id::text, g.expires_at, g.revoked_at, g.note
      INTO v_before, v_product_id, v_old_expiry, v_revoked_at, v_note
      FROM public.test_access_grants g
      WHERE g.id = p_record_id AND g.user_id = p_user_id
      FOR UPDATE;
    IF NOT FOUND THEN RAISE EXCEPTION 'Test access record not found'; END IF;
    IF v_revoked_at IS NOT NULL THEN
      v_previous_state := 'revoked';
      SELECT EXISTS (
        SELECT 1 FROM public.test_access_grants g
        WHERE g.user_id = p_user_id AND g.test_id::text = v_product_id
          AND g.revoked_at IS NULL AND g.id <> p_record_id
      ) INTO v_has_other_unrevoked;
      IF v_has_other_unrevoked THEN RAISE EXCEPTION 'Another current test grant exists; renew that record instead'; END IF;
    ELSIF v_old_expiry IS NOT NULL AND v_old_expiry <= v_now THEN
      v_previous_state := 'expired';
    ELSE
      RAISE EXCEPTION 'This test access is already active';
    END IF;

  ELSIF p_kind IN ('series','notes_series') THEN
    SELECT to_jsonb(g), g.series_id, g.expires_at, g.revoked_at, g.note
      INTO v_before, v_product_id, v_old_expiry, v_revoked_at, v_note
      FROM public.series_access_grants g
      WHERE g.id = p_record_id AND g.user_id = p_user_id
      FOR UPDATE;
    IF NOT FOUND THEN RAISE EXCEPTION 'Series access record not found'; END IF;
    IF (p_kind = 'notes_series' AND v_product_id NOT LIKE 'notes-series:%')
       OR (p_kind = 'series' AND v_product_id LIKE 'notes-series:%') THEN
      RAISE EXCEPTION 'Access record does not match the selected series type';
    END IF;
    IF v_revoked_at IS NOT NULL THEN
      v_previous_state := 'revoked';
      SELECT EXISTS (
        SELECT 1 FROM public.series_access_grants g
        WHERE g.user_id = p_user_id AND g.series_id = v_product_id
          AND g.revoked_at IS NULL AND g.id <> p_record_id
      ) INTO v_has_other_unrevoked;
      IF v_has_other_unrevoked THEN RAISE EXCEPTION 'Another current series grant exists; renew that record instead'; END IF;
    ELSIF v_old_expiry IS NOT NULL AND v_old_expiry <= v_now THEN
      v_previous_state := 'expired';
    ELSE
      RAISE EXCEPTION 'This series access is already active';
    END IF;

  ELSIF p_kind = 'note' THEN
    SELECT to_jsonb(g), g.material_id::text, g.expires_at, g.revoked_at, g.note
      INTO v_before, v_product_id, v_old_expiry, v_revoked_at, v_note
      FROM public.material_access_grants g
      WHERE g.id = p_record_id AND g.user_id = p_user_id
      FOR UPDATE;
    IF NOT FOUND THEN RAISE EXCEPTION 'Note access record not found'; END IF;
    IF v_revoked_at IS NOT NULL THEN
      v_previous_state := 'revoked';
      SELECT EXISTS (
        SELECT 1 FROM public.material_access_grants g
        WHERE g.user_id = p_user_id AND g.material_id::text = v_product_id
          AND g.revoked_at IS NULL AND g.id <> p_record_id
      ) INTO v_has_other_unrevoked;
      IF v_has_other_unrevoked THEN RAISE EXCEPTION 'Another current note grant exists; renew that record instead'; END IF;
    ELSIF v_old_expiry IS NOT NULL AND v_old_expiry <= v_now THEN
      v_previous_state := 'expired';
    ELSE
      RAISE EXCEPTION 'This note access is already active';
    END IF;

  ELSE
    -- A revoked paid purchase remains historical. Regranting creates/renews a
    -- separate access grant; it never changes the purchase or coin ledger.
    SELECT to_jsonb(p), p.material_id::text
      INTO v_before, v_product_id
      FROM public.material_purchases p
      WHERE p.id = p_record_id AND p.user_id = p_user_id
      FOR UPDATE;
    IF NOT FOUND THEN RAISE EXCEPTION 'Paid Note purchase record not found'; END IF;
    IF (v_before->>'status') <> 'revoked' THEN
      RAISE EXCEPTION 'Only a revoked paid Note purchase can be regranted here';
    END IF;
    v_previous_state := 'revoked';
    SELECT to_jsonb(g), g.id, g.expires_at, g.note
      INTO v_previous_grant, v_grant_id, v_old_expiry, v_note
      FROM public.material_access_grants g
      WHERE g.user_id = p_user_id AND g.material_id::text = v_product_id
        AND g.revoked_at IS NULL
      FOR UPDATE;
    IF FOUND THEN
      IF v_old_expiry IS NULL OR v_old_expiry > v_now THEN
        RAISE EXCEPTION 'An active Note access grant already exists';
      END IF;
      v_previous_state := 'expired';
    ELSE
      v_after := NULL;
      v_old_expiry := NULL;
    END IF;
  END IF;

  IF p_validity_mode = 'keep' THEN
    IF v_old_expiry IS NOT NULL AND v_old_expiry <= v_now THEN
      RAISE EXCEPTION 'This access has expired; choose a renewal period instead';
    END IF;
    v_expiry := v_old_expiry;
  ELSIF p_validity_mode = 'days' THEN
    v_expiry := v_now + make_interval(days => p_valid_days);
  ELSE
    v_expiry := NULL;
  END IF;

  v_action := CASE
    WHEN p_kind = 'note_purchase' THEN 'regranted'
    WHEN v_previous_state = 'expired' THEN 'renewed'
    ELSE 'restored'
  END;
  v_entry := format(
    '[Access %s %s by %s] Previous state: %s; previous expiry: %s; reason: %s',
    v_action, v_now, auth.uid(), v_previous_state, COALESCE(v_old_expiry::text, 'lifetime'), btrim(p_reason)
  );

  IF p_kind = 'course' THEN
    UPDATE public.course_enrollments
      SET status = 'active', expires_at = v_expiry,
          admin_note = concat_ws(E'\n', NULLIF(btrim(v_note), ''), v_entry),
          updated_at = v_now
      WHERE id = p_record_id AND user_id = p_user_id
      RETURNING to_jsonb(course_enrollments) INTO v_after;
    IF v_source = 'offline' THEN
      UPDATE public.offline_access_grants
        SET status = 'activated', activated_user_id = p_user_id, expires_at = v_expiry,
            admin_note = concat_ws(E'\n', NULLIF(btrim(admin_note), ''), v_entry), updated_at = v_now
        WHERE course_id = v_product_id::uuid
          AND activated_user_id = p_user_id AND status = 'revoked';
    END IF;
  ELSIF p_kind = 'test' THEN
    UPDATE public.test_access_grants
      SET revoked_at = NULL, expires_at = v_expiry,
          note = concat_ws(E'\n', NULLIF(btrim(v_note), ''), v_entry)
      WHERE id = p_record_id AND user_id = p_user_id
      RETURNING to_jsonb(test_access_grants) INTO v_after;
  ELSIF p_kind IN ('series','notes_series') THEN
    UPDATE public.series_access_grants
      SET revoked_at = NULL, expires_at = v_expiry,
          note = concat_ws(E'\n', NULLIF(btrim(v_note), ''), v_entry)
      WHERE id = p_record_id AND user_id = p_user_id
      RETURNING to_jsonb(series_access_grants) INTO v_after;
  ELSIF p_kind = 'note' THEN
    UPDATE public.material_access_grants
      SET revoked_at = NULL, expires_at = v_expiry,
          note = concat_ws(E'\n', NULLIF(btrim(v_note), ''), v_entry), updated_at = v_now
      WHERE id = p_record_id AND user_id = p_user_id
      RETURNING to_jsonb(material_access_grants) INTO v_after;
  ELSE
    IF v_grant_id IS NOT NULL THEN
      UPDATE public.material_access_grants
        SET expires_at = v_expiry,
            note = concat_ws(E'\n', NULLIF(btrim(v_note), ''), v_entry), updated_at = v_now
        WHERE id = v_grant_id AND user_id = p_user_id
        RETURNING to_jsonb(material_access_grants) INTO v_after;
    ELSE
      INSERT INTO public.material_access_grants(
        user_id, material_id, granted_by, method, amount_inr, note, expires_at, revoked_at, updated_at
      ) VALUES (
        p_user_id, v_product_id::uuid, auth.uid(), 'admin_recovery', 0, v_entry, v_expiry, NULL, v_now
      ) RETURNING id, to_jsonb(material_access_grants) INTO v_grant_id, v_after;
    END IF;
  END IF;

  INSERT INTO public.admin_access_recovery_events(
    user_id, admin_id, record_kind, record_id, product_id, action, reason, before_state, after_state, created_at
  ) VALUES (
    p_user_id, auth.uid(), p_kind, p_record_id, v_product_id, v_action, btrim(p_reason),
    CASE WHEN p_kind = 'note_purchase' THEN jsonb_build_object('purchase', v_before, 'previous_access_grant', v_previous_grant) ELSE v_before END,
    v_after, v_now
  ) RETURNING id INTO v_event_id;

  RETURN jsonb_build_object(
    'ok', true,
    'event_id', v_event_id,
    'action', v_action,
    'record_kind', p_kind,
    'product_id', v_product_id,
    'expires_at', v_expiry
  );
END;
$$;

REVOKE ALL ON FUNCTION public.admin_recover_access(uuid,text,uuid,text,integer,text) FROM PUBLIC;
GRANT EXECUTE ON FUNCTION public.admin_recover_access(uuid,text,uuid,text,integer,text) TO authenticated;

COMMIT;
