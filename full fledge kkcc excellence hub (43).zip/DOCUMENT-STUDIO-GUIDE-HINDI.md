Latest update guide: **TEMPLATES-AND-VIDEO-GUIDE-HINDI.md** — editable templates, canvas ratios, automatic slides aur improved lecture player.

# PPT aur PDF ka kaam app ke andar

## Naya: apne Canva pamphlet se editable PowerPoint (phone par bhi)
1. Canva mein **cover + khaali teaching slide** banayein. Upar apna naam/logo aur neeche footer wahi rakhein, beech mein lesson ke liye jagah khaali chhodein. Canva → **Share → Download → PDF Standard** (saare pages), ya JPG/PNG images download karein. Direct Canva `.pptx` upload aur printed text ka OCR is tool mein nahi hai.
2. Deploy ke baad Admin → **Document Studio → Presentation Studio** kholein. Sabse upar **Custom pamphlet → editable PPT** mein Canva PDF ya images upload karein (12 pages/25 MB tak). Preview mein **khaali teaching page** select karein. Agar cover/design pages bhi chahiye to **Keep all original Canva pages first** ON rakhein. Alag page ratios bina crop kiye first-page canvas mein fit honge; warning aaye to preview dekhein.
3. PowerPoint ka naam/topic aur lesson text paste karein. `# Chapter` likhne par naya section slide banta hai; lamba text automatically naye pages par jaata hai. **Keep top/bottom branding clear** sliders se naam/logo/footer ki jagah bachayein. Printed Canva branding hai to **NO name/logo/footer** checkbox OFF rakhein. Agar blank design hai to ON karke alag replaceable KKCC logo aur editable naam/footer likhein. Dark/light text aur optional reading panel available hain.
4. **Make my editable PowerPoint** dabayein. Slide preview dekhkar **Download editable PPTX** se phone par save karein (Android Files/Downloads; iPhone Share → Save to Files agar supported, warna browser Downloads/Share). PPTX ko PowerPoint ya compatible editor mein kholein. **Save editable project JSON** bhi download karein, taaki baad mein isi Studio mein reopen kar saken. **Edit these slides in Studio** optional hai; current detailed project ko badalne se pehle confirmation aayega. Purane projects ko pehle JSON ke roop mein backup karein.

**Sachchi editability:** Canva ka uploaded artwork PDF/image se **replaceable picture layer** banta hai; usmein pehle se printed letters alag-alag edit nahi honge. KKCC mein ab jo text/name/footer add hua hai wo PPTX mein **native editable text objects** hain. Logo alag replaceable image hai. Blank Canva teaching page use karein taaki purane printed words naye text par na aayein. Har page ka ratio/visual density alag ho sakta hai; generation se pehle preview check karein. 60-slide/24-MB limit par content chupchaap delete nahi hota—error dikhega, text aur upload tab mein bache rahenge; lesson split karein. Ye **browser-local** kaam hai, cloud autosave nahi. Yeh frontend change hai: iske liye **SQL/cleaner bilkul nahi chalana**.

## Naya: lamba text likhein → app khud editable PPT slides banaye, phir preview/edit karein

1. Admin → **Document Studio → Presentation Studio → Simple** kholein. **Presentation name** likhein. **Long text → editable PPT slides** mein apna poora lesson type ya paste karein (60,000 characters tak). `# Topic` se naya section start kar sakte hain, **lekin `#` likhna zaroori nahin**—bina heading ke bhi lamba text agle slides mein automatically baant diya jaata hai. Yeh aapke words ko AI se badal/summarise nahin karta.
2. Chahein to **Slide style** mein app ki existing White classroom/Teal/other design choose karein. **Generate slides & preview** dabayein. Naye slides current slide *ke baad* judte hain; pehle ke slides, images aur edited text replace nahin hote. Limit 60 slides / 24 MB; zyada text ko alag project mein baantein. Error aane par original deck aur typed draft wahi rehte hain.
3. Slides banne ke baad **Preview all slides** automatically ON ho jata hai. Bada slide preview, **thumbnails** aur **Previous/Next** se slide-by-slide dekhein. Bade preview par heading/body ko tap karein: usi slide ka native-keyboard text editor focus hoga, jahan likhte hi preview badalta hai. Selected words par B/I/U/colour bhi laga sakte hain; Advanced mode mein shapes, image layers, speaker notes aur positioning milti hai. **Present slides** full-screen slideshow hai; usmein **Edit this slide** dabakar current slide ke editor par laut sakte hain. Uploaded PDF/Canva artwork par printed words alag text ki tarah edit nahin hote.
4. Review ke baad **Save editable project** (`.kkcc-presentation.json`) rakhein, **Export PowerPoint** se native editable text wali `.pptx` lein, ya **Export slide PDF** se image-based PDF. Browser tab close karne par unsaved drafts chale jaate hain; yeh cloud autosave nahin hai. Native phone keyboard replace nahin hota; physical device aur PowerPoint app mein layout check karna zaroori hai.

## Naya: chalti presentation mein custom PDF slide jodein — purane slides na mitayein

1. Admin → **Document Studio → Presentation Studio → Simple** mein **Custom slide · add PDF page(s)** kholein. **Choose custom slide PDF** se 25 MB / 12 pages tak ki PDF chunein. File browser mein hi render hoti hai; is workflow mein cloud upload nahin hota.
2. Page field mein `2` ya `1,3-4` likhein; **Add selected PDF page(s)** ya **Add all PDF pages** dabayein. Chune huye pages *current slide ke baad* jod diye jaate hain. Maujooda slide IDs, text aur images bilkul waise hi rehte hain; Undo bhi available hai. 60-slide / 24-MB project limit paar ho to error aayega aur existing deck unchanged rahega.
3. PDF artwork image-only hoga—printed words ke alag PowerPoint text objects nahi banenge. Imported page par **Add editable heading** / **Add editable main text** se naya text alag native PPTX shapes banega. Existing heading/main text mein words select karein; keyboard ke upar **B / I / U / Colours** toolbar se selected text ko visibly format karein. Swatches, spectrum, HEX aur sliders milte hain; edit field mein `[b]` / `[color]` tokens nahin dikhte. PPTX mein yeh coloured text editable rahega; exported slide PDF image hai. **Save editable project** JSON rakhein, taaki pages aur text styles baad mein reopen hon.

Notes aur Test-question author fields bhi ab default visual formatting dikhate hain; inka purana safe markup storage bina database migration ke same rehta hai. Notes ke complex tables, diagrams/formulas aur raw editing ke liye **Advanced note source** button hai. Native Samsung/Gboard/iPhone keyboard ki jagah custom IME nahin lagaya gaya; physical devices par final Preview QA zaroor karein.

## Kahan milega?
Admin panel → **Presentation & PDF Studio**.
Sirf admin access wale accounts isse open kar sakte hain.

## PPT banana
1. Presentation name likhein.
2. Lesson/Title/Quiz/Blank template se slide add karein.
3. Slide par text/image/shape click karein. Side controls se text, colour, font size, position aur size badlein; drag bhi kar sakte hain.
4. Image add karne ke liye JPG/PNG choose karein. Optimise pictures se badi images chhoti ki ja sakti hain.
5. **Invert slide colours** current slide ke colours badlega; Undo available hai.
6. **Save editable project** zaroor karein. Yeh `.kkcc-presentation.json` download karta hai, jise baad mein isi app mein open/edit/merge kar sakte hain. Cloud autosave nahi hai.
7. PowerPoint file ke liye **Export PowerPoint**; PDF ke liye **Export slide PDF**; class mein dikhane ke liye **Present slides**.

Purani arbitrary `.pptx` files ko import/edit/merge karna is version mein nahi hai. App ke apne saved projects merge hote hain. Exported PPTX editable hai; PDF slides images hoti hain.

## PDFs
PDF Tools tab mein tool choose karke file(s) select karein, phir **Process PDF**.
- Merge mein file order Up/Down buttons se badlein.
- Pages `3,1-2` likhne ka matlab page 3, phir 1, phir 2.
- Split se har page ki PDF ek ZIP mein milegi.
- Rotate, delete, reverse, watermark aur size optimisation available hain.
- **Invert colours** black/white aur doosre colours ulte karke nayi PDF banata hai.
- Image compression/invert mein text aur forms images ban jaate hain. Confirmation padhkar hi continue karein. Har PDF chhoti hone ki guarantee nahi hai; result ka size dikhaya jata hai.
- JPG/PNG → PDF aur PDF → PNG ZIP conversion bhi available hai.
- Output download karein ya **Open result in reader** se app mein dekhein.

## PDF Reader
File choose karein; page thumbnails, page number, search, zoom, rotate/invert view aur fullscreen se padhein. Protected file ka correct password dal kar read kar sakte hain. Search scanned pictures mein kaam nahi karta; OCR abhi nahi hai. Print current page aur original download available hain.

**Files kisi outside conversion service ko upload nahi hoti. Original files unchanged rehti hain.** Browser tab close karne se unsaved workspace chala jata hai, isliye project/output download karke rakhein. Signed/form PDFs ki original copy hamesha rakhein.

## Update
Naya SQL run nahi karna. Cleaner bhi nahi chalana. Existing notes, students, accounts, purchases aur access unchanged hain.
Detailed limits, supported features aur test evidence: `docs/KKCC-DOCUMENT-STUDIO.md`.
