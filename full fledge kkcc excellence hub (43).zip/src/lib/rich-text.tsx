/**
 * Rich inline formatting for Notes / Tests — one implementation everywhere.
 *
 * Admins type into a plain textarea, but can wrap text in a tiny whitelist of
 * inline tags using the editor toolbar (B / I / U, colour swatches, Punjabi +
 * Hindi character keys):
 *
 *   <b>bold</b>  <i>italic</i>  <u>underline</u>
 *   <span style="color:#1d4ed8">coloured text</span>
 *
 * Everything else stays literal text. The parser recognises ONLY these exact
 * tags with their exact attributes and only the fixed colour palette below, so
 * a student-facing render can never inject markup: React nodes are used on the
 * test/result screens and `richInlineToHtml` escapes every text fragment for
 * the notes reader / print pipeline. Tags may nest (e.g. bold inside a colour).
 */
import type { ReactNode } from "react";

export type RichColor = { hex: string; name: string };

/** Fixed safe palette — the only colours the parser accepts. */
export const RICH_COLORS: readonly RichColor[] = [
  { hex: "#0f172a", name: "Ink" },
  { hex: "#1d4ed8", name: "Blue" },
  { hex: "#b91c1c", name: "Red" },
  { hex: "#047857", name: "Green" },
  { hex: "#7c3aed", name: "Violet" },
  { hex: "#c2410c", name: "Orange" },
  { hex: "#0e7490", name: "Teal" },
  { hex: "#be185d", name: "Pink" },
] as const;

const SAFE_COLORS = new Set(RICH_COLORS.map((c) => c.hex));

/** Gurmukhi keys (Punjabi) — vowels, vowel-signs, special, consonants. */
export const GURMUKHI_KEYS: readonly (readonly string[])[] = [
  ["ਅ", "ਆ", "ਇ", "ਈ", "ਉ", "ਊ", "ਏ", "ਐ", "ਓ", "ਔ", "ਾ", "ਿ", "ੀ", "ੁ", "ੂ", "ੇ", "ੈ", "ੋ", "ੌ"],
  ["ੰ", "ੱ", "ਂ", "਼", "ਃ", "ੳ", "ੲ", "ਖ਼", "ਗ਼", "ਜ਼", "ਫ਼", "ਲ਼", "ੜ"],
  ["ਕ", "ਖ", "ਗ", "ਘ", "ਙ", "ਚ", "ਛ", "ਜ", "ਝ", "ਞ"],
  ["ਟ", "ਠ", "ਡ", "ਢ", "ਣ", "ਤ", "ਥ", "ਦ", "ਧ", "ਨ"],
  ["ਪ", "ਫ", "ਬ", "ਭ", "ਮ", "ਯ", "ਰ", "ਲ", "ਵ", "ਸ", "ਹ"],
] as const;

/** Devanagari keys (Hindi) — vowels, vowel-signs, special, consonants. */
export const DEVANAGARI_KEYS: readonly (readonly string[])[] = [
  [
    "अ",
    "आ",
    "इ",
    "ई",
    "उ",
    "ऊ",
    "ऋ",
    "ए",
    "ऐ",
    "ओ",
    "औ",
    "ा",
    "ि",
    "ी",
    "ु",
    "ू",
    "ृ",
    "े",
    "ै",
    "ो",
    "ौ",
  ],
  ["ं", "ँ", "़", "ः", "ॐ", "क्ष", "त्र", "ज्ञ", "श्र"],
  ["क", "ख", "ग", "घ", "ङ", "च", "छ", "ज", "झ", "ञ"],
  ["ट", "ठ", "ड", "ढ", "ण", "त", "थ", "द", "ध", "न"],
  ["प", "फ", "ब", "भ", "म", "य", "र", "ल", "व", "श", "ष", "स", "ह"],
] as const;

export type RichNode =
  | { type: "text"; value: string }
  | { type: "bold"; children: RichNode[] }
  | { type: "italic"; children: RichNode[] }
  | { type: "underline"; children: RichNode[] }
  | { type: "color"; color: string; children: RichNode[] };

/**
 * Strict token matcher. Only <b|u|i>…</same> and
 * <span style="color:#hex">…</span> match; anything else is plain text.
 * Built fresh per parse — recursion must not share a global regex cursor.
 */
const RICH_TOKEN_SOURCE =
  '<(b|i|u)>([\\s\\S]*?)</\\1>|<span style="color:(#[0-9a-fA-F]{6})">([\\s\\S]*?)</span>';

const MAX_DEPTH = 8;

function toNode(
  tag: string | undefined,
  color: string | undefined,
  inner: string,
  depth: number,
): RichNode | null {
  if (color !== undefined) {
    const normalised = color.toLowerCase();
    if (!SAFE_COLORS.has(normalised)) return null;
    return { type: "color", color: normalised, children: parseRichInline(inner, depth + 1) };
  }
  if (tag === "b") return { type: "bold", children: parseRichInline(inner, depth + 1) };
  if (tag === "i") return { type: "italic", children: parseRichInline(inner, depth + 1) };
  if (tag === "u") return { type: "underline", children: parseRichInline(inner, depth + 1) };
  return null;
}

/**
 * Split text into text / bold / italic / underline / colour nodes. Unmatched
 * angle brackets stay literal text — the renderers escape them.
 */
export function parseRichInline(text: string, depth = 0): RichNode[] {
  const source = text ?? "";
  if (!source) return [];
  // Too-deep nesting: strip anything tag-like so it renders as literal text.
  if (depth > MAX_DEPTH) {
    return [{ type: "text", value: source.replace(/<[^>]*>/g, "") }];
  }

  const nodes: RichNode[] = [];
  let cursor = 0;
  const token = new RegExp(RICH_TOKEN_SOURCE, "g");
  let match: RegExpExecArray | null;
  while ((match = token.exec(source)) !== null) {
    // Safety: never loop on a zero-length match.
    if (match[0].length === 0) {
      token.lastIndex += 1;
      continue;
    }
    if (match.index > cursor) {
      nodes.push({ type: "text", value: source.slice(cursor, match.index) });
    }
    const node = toNode(match[1], match[3], match[2] ?? match[4] ?? "", depth);
    if (node) {
      nodes.push(node);
    } else {
      // Colour outside the palette — keep the raw text literal.
      nodes.push({ type: "text", value: match[0] });
    }
    cursor = match.index + match[0].length;
  }
  if (cursor < source.length) {
    nodes.push({ type: "text", value: source.slice(cursor) });
  }
  return nodes;
}

/** Escape a text fragment the same way the notes pipeline does. */
export function escapeRichText(value: string): string {
  return value
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;")
    .replace(/'/g, "&#39;");
}

/**
 * Safe HTML for the notes reader / print document. Only <strong>/<em>/<u>/
 * <span style="color:…"> from the whitelist are emitted; every text fragment
 * is escaped first.
 */
export function richInlineToHtml(text: string): string {
  return parseRichInline(text)
    .map((node) => richNodeToHtml(node))
    .join("");
}

function richNodeToHtml(node: RichNode): string {
  switch (node.type) {
    case "text":
      return escapeRichText(node.value);
    case "bold":
      return `<strong>${node.children.map(richNodeToHtml).join("")}</strong>`;
    case "italic":
      return `<em>${node.children.map(richNodeToHtml).join("")}</em>`;
    case "underline":
      return `<u>${node.children.map(richNodeToHtml).join("")}</u>`;
    case "color":
      return `<span style="color:${node.color}">${node.children.map(richNodeToHtml).join("")}</span>`;
  }
}

/**
 * React render for student test / result screens. Plain strings become normal
 * React text nodes (auto-escaped) — no dangerouslySetInnerHTML anywhere.
 */
export function RichText({ text, className }: { text: string; className?: string }) {
  return (
    <span className={className}>
      {parseRichInline(text).map((node, i) => richNodeElement(node, i))}
    </span>
  );
}

function richNodeElement(node: RichNode, key: number): ReactNode {
  switch (node.type) {
    case "text":
      return node.value;
    case "bold":
      return (
        <strong key={key}>{node.children.map((child, i) => richNodeElement(child, i))}</strong>
      );
    case "italic":
      return <em key={key}>{node.children.map((child, i) => richNodeElement(child, i))}</em>;
    case "underline":
      return <u key={key}>{node.children.map((child, i) => richNodeElement(child, i))}</u>;
    case "color":
      return (
        <span key={key} style={{ color: node.color }}>
          {node.children.map((child, i) => richNodeElement(child, i))}
        </span>
      );
  }
}

/* ------------------------------------------------------- editor helpers */

const WRAPPERS: Record<"bold" | "italic" | "underline", { open: string; close: string }> = {
  bold: { open: "<b>", close: "</b>" },
  italic: { open: "<i>", close: "</i>" },
  underline: { open: "<u>", close: "</u>" },
};

export function colorWrapOpen(hex: string): string {
  return `<span style="color:${hex}">`;
}

export const RICH_CLOSE = "</span>";

/** Wrap the textarea selection in open/close (or insert empty tags). */
export function applyRichWrap(
  value: string,
  selectionStart: number,
  selectionEnd: number,
  open: string,
  close: string,
): { value: string; selectionStart: number; selectionEnd: number } {
  const selected = value.slice(selectionStart, selectionEnd);
  const next = value.slice(0, selectionStart) + open + selected + close + value.slice(selectionEnd);
  return {
    value: next,
    selectionStart: selectionStart + open.length,
    selectionEnd: selectionStart + open.length + selected.length,
  };
}

/** Wrap the selection as bold / italic / underline. */
export function applyRichStyle(
  value: string,
  selectionStart: number,
  selectionEnd: number,
  style: "bold" | "italic" | "underline",
): { value: string; selectionStart: number; selectionEnd: number } {
  const { open, close } = WRAPPERS[style];
  return applyRichWrap(value, selectionStart, selectionEnd, open, close);
}

/** Wrap the selection in a palette colour span. */
export function applyRichColor(
  value: string,
  selectionStart: number,
  selectionEnd: number,
  hex: string,
): { value: string; selectionStart: number; selectionEnd: number } {
  return applyRichWrap(value, selectionStart, selectionEnd, colorWrapOpen(hex), RICH_CLOSE);
}

/** Insert a Punjabi / Hindi character at the caret. */
export function applyRichInsert(
  value: string,
  selectionStart: number,
  selectionEnd: number,
  char: string,
): { value: string; selectionStart: number; selectionEnd: number } {
  const next = value.slice(0, selectionStart) + char + value.slice(selectionEnd);
  const caret = selectionStart + char.length;
  return { value: next, selectionStart: caret, selectionEnd: caret };
}
