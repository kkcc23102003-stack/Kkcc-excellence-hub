export function isAuthCompletionRoute(pathname: string): boolean {
  return ["/auth/callback", "/reset-password"].includes(pathname.replace(/\/+$/, ""));
}

/** Recovery and email verification must still work before a user has a session. */
export function appAccessRedirect(pathname: string, signedIn: boolean): "/" | "/login" | null {
  const path = pathname.replace(/\/+$/, "") || "/";
  if (isAuthCompletionRoute(path)) return null;
  const guestPage = ["/login", "/signup", "/forgot-password"].includes(path);
  if (signedIn) return guestPage ? "/" : null;
  return guestPage ? null : "/login";
}
