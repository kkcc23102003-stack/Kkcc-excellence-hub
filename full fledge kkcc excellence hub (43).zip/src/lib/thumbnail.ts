import { z } from "zod";
export const thumbnailUrlSchema = z
  .string()
  .trim()
  .max(4000)
  .refine(
    (value) =>
      !value ||
      /^https?:\/\//i.test(value) ||
      /^\/(?!\/)/.test(value) ||
      value.startsWith("kkcc-file://"),
    "Use an http(s) image URL or a KKCC upload.",
  )
  .nullable()
  .optional();
export const thumbnailFields = {
  thumbnail_url: thumbnailUrlSchema,
  thumbnail_text: z.string().trim().max(200).nullable().optional(),
};
export type ThumbnailValue = {
  thumbnail_url?: string | null;
  thumbnail_text?: string | null;
};

/**
 * Turn Google Drive share links into an image endpoint. A Drive "view" page is HTML,
 * not an <img> source; the thumbnail endpoint can render a file shared as
 * "Anyone with the link". Other local, uploaded and ordinary image URLs are unchanged.
 */
export function thumbnailImageUrl(
  value: string | null | undefined,
): string | null {
  const raw = value?.trim();
  if (!raw) return null;

  try {
    const url = new URL(raw);
    const host = url.hostname.toLowerCase();
    if (host !== "drive.google.com" && host !== "www.drive.google.com")
      return raw;

    const pathId = url.pathname.match(/\/(?:file\/d|d)\/([^/?#]+)/i)?.[1];
    const id = pathId || url.searchParams.get("id");
    if (!id) return raw;

    const image = new URL("https://drive.google.com/thumbnail");
    image.searchParams.set("id", id);
    const resourceKey = url.searchParams.get("resourcekey");
    if (resourceKey) image.searchParams.set("resourcekey", resourceKey);
    image.searchParams.set("sz", "w1200");
    return image.toString();
  } catch {
    // Relative app URLs (for example /logo.png) and internal KKCC refs are valid.
    return raw;
  }
}
