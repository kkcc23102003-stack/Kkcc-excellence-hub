import { Buffer } from "node:buffer";
import { createHash } from "node:crypto";
import { z } from "zod";

export const AI_QUESTION_ARCHIVE_BUCKET = "kkcc-ai-question-archive";
export const MAX_AI_QUESTION_ARCHIVE_BYTES = 256 * 1024;

const archivedQuestionSchema = z.object({
  id: z.string().uuid(),
  prompt: z.string().min(25).max(3000),
  options: z.array(z.string().min(1).max(700)).length(4),
  correct_index: z.number().int().min(0).max(3),
  explanation: z.string().min(40).max(3000),
  exam: z.string().min(1).max(80),
  subject: z.string().min(1).max(80),
  topic: z.string().min(1).max(160),
  difficulty: z.enum(["Easy", "Moderate", "Difficult"]),
  quality_score: z.number().int().min(0).max(100),
  source_urls: z.array(z.string().url().max(2048)).max(20),
  source_notes: z.string().max(3000),
  created_at: z.string().datetime(),
});

export type ArchivedAIQuestion = z.infer<typeof archivedQuestionSchema>;

export function aiQuestionArchiveKey(id: string) {
  const canonical = z.string().uuid().parse(id).toLowerCase();
  return `kkcc-question-bank/v1/${canonical.slice(0, 2)}/${canonical}.json`;
}

const hash = (bytes: Uint8Array) => createHash("sha256").update(bytes).digest("hex");

export function encodeArchivedAIQuestion(input: ArchivedAIQuestion) {
  const question = archivedQuestionSchema.parse(input);
  const key = aiQuestionArchiveKey(question.id);
  const bytes = Buffer.from(JSON.stringify(question), "utf8");
  if (bytes.byteLength > MAX_AI_QUESTION_ARCHIVE_BYTES)
    throw new Error("AI question payload exceeds the private Storage object limit.");
  return { key, bytes, content_hash: hash(bytes) };
}

export function decodeArchivedAIQuestion(
  key: string,
  bytes: Uint8Array,
  expectedHash?: string | null,
): ArchivedAIQuestion {
  if (!/^kkcc-question-bank\/v1\/[0-9a-f]{2}\/[0-9a-f-]{36}\.json$/i.test(key))
    throw new Error("AI archive object path is invalid.");
  const id = key
    .split("/")
    .at(-1)
    ?.replace(/\.json$/i, "");
  if (!id || aiQuestionArchiveKey(id) !== key.toLowerCase())
    throw new Error("AI archive object path is invalid.");
  if (bytes.byteLength > MAX_AI_QUESTION_ARCHIVE_BYTES)
    throw new Error("AI archive object exceeds the 256 KB limit.");
  const actualHash = hash(bytes);
  if (expectedHash && actualHash !== expectedHash)
    throw new Error("AI archive content integrity check failed.");
  let raw: unknown;
  try {
    raw = JSON.parse(Buffer.from(bytes).toString("utf8"));
  } catch {
    throw new Error("AI archive object is not valid JSON.");
  }
  const question = archivedQuestionSchema.parse(raw);
  if (question.id.toLowerCase() !== id.toLowerCase())
    throw new Error("AI archive object ID does not match its Storage path.");
  return question;
}
