import { NOTES_PRINT_LOGO } from "../notes-print-logo";
import { KKCC_CENTRE_WATERMARK_LOGO } from "../notes-print-watermark-logo";
import { KKCC_CENTRE_WATERMARK_BLACK_LOGO } from "../notes-print-watermark-black-logo";
import type { PdfColourMode } from "../pdf-brand";
import { officeInline, officeStyles, prepareOfficeText } from "../notes-office";
/**
 * Notes rendering pipeline — one implementation used everywhere.
 *
 * The admin types plain text. This module turns it into:
 *   - clean headings / bullets / paragraphs,
 *   - auto-generated diagrams and charts (see ./analyze + ./render),
 *   - a printable document that carries the KKCC watermark on every page.
 *
 * Reader and printer share the same authored note/visuals, not the same colours:
 * the reader shows colour, while the separate print document defaults to
 * grayscale with the genuine faint centre logo on every printed sheet.
 */
import { analyzeNotes, type TextBlock, type VisualSpec } from "./analyze";
import { escapeHtml, visualSvg, wrapText } from "./render";
import { looksLikeFormula, renderFormulaLine, renderMath } from "./math";

export { analyzeNotes } from "./analyze";
export { escapeHtml, visualSvg } from "./render";
export { looksLikeFormula, renderFormulaLine, renderMath } from "./math";
export type { TextBlock, VisualSpec } from "./analyze";

export const KKCC_BRAND_PRIMARY = "KKCC Excellence Hub";
export const KKCC_BRAND_SECONDARY = "Kusum Kartik Coaching Centre";

/** Shown on both the screen reader and every printed page. */
export const KKCC_BRANDS = [KKCC_BRAND_PRIMARY, KKCC_BRAND_SECONDARY] as const;

/**
 * The watermark repeats on every printed page. Rows alternate between the two
 * brand names so both "KKCC Excellence Hub" and "Kusum Kartik Coaching Centre"
 * appear across the whole sheet.
 */
export function watermarkHtml(): string {
  const cells: string[] = [];
  for (let index = 0; index < 24; index += 1) {
    const brand = KKCC_BRANDS[index % KKCC_BRANDS.length]!;
    cells.push(`<span>${escapeHtml(brand)}</span>`);
  }
  return `<div class="kkcc-print-watermark" aria-hidden="true">${cells.join("")}</div>`;
}

/**
 * One line of the admin's text. A line that is a formula (or a bullet that
 * carries one, e.g. "E = mc^2") is typeset; everything else is escaped text, so
 * the author can never inject markup.
 */
function inlineText(text: string): string {
  if (looksLikeFormula(text)) return renderFormulaLine(text);
  // A colon is ordinary text, never an instruction to highlight what precedes
  // it. Only explicit [mark]/[highlight=…] from the author may paint yellow.
  return officeInline(text);
}

function isFormula(block: TextBlock): boolean {
  return block.type === "formula" || looksLikeFormula(block.text);
}

function noteLineAttrs(block: TextBlock, editable: boolean): string {
  return editable ? ` data-note-line="${block.sourceLine}" tabindex="0"` : "";
}

function textBlockHtml(block: TextBlock, editable: boolean): string {
  const attrs = noteLineAttrs(block, editable);
  switch (block.type) {
    case "heading":
      return `<h2 class="kkcc-note-h2"${attrs}>${officeInline(block.text)}</h2>`;
    case "subheading":
      return `<h3 class="kkcc-note-h3"${attrs}>${officeInline(block.text)}</h3>`;
    case "formula":
      return `<div class="kkcc-math-block" role="math"${attrs}>${renderFormulaLine(block.text)}</div>`;
    default:
      return `<p class="kkcc-note-p"${attrs}>${inlineText(block.text)}</p>`;
  }
}

function listItemHtml(block: TextBlock, editable: boolean): string {
  const number = block.type === "numbered" && block.ordinal ? ` value="${block.ordinal}"` : "";
  return `<li class="kkcc-note-li"${number}${noteLineAttrs(block, editable)}>${inlineText(block.text)}</li>`;
}

function visualHtml(spec: VisualSpec, print = false): string {
  if (spec.kind === "image") {
    // A photo carries its own caption inside the figure.
    return `<figure class="kkcc-visual kkcc-visual-image kkcc-note-figure">${visualSvg(spec, { print })}</figure>`;
  }
  return `<figure class="kkcc-visual kkcc-visual-${spec.kind}">${visualSvg(spec)}<figcaption>${escapeHtml(spec.title)}</figcaption></figure>`;
}

export type NotesRenderOptions = {
  /** Font size of the note body in px (the reader's A- / A+ buttons). */
  fontScale?: number;
  /** Admin-only source-line handles; NEVER included in student/print output. */
  editable?: boolean;
  /** A print-only logo over opaque handwritten page images. */
  print?: boolean;
  /** Student-only launchers placed after the author's exact source line. */
  practiceAfterLines?: ReadonlyMap<
    number,
    readonly { index: number; topic: string; count: number }[]
  >;
  practiceAtEnd?: readonly { index: number; topic: string; count: number }[];
};

/**
 * Body HTML for a note: text with the generated diagrams placed exactly where
 * the content supports them.
 */
export function renderNotesBody(text: string, options: NotesRenderOptions = {}): string {
  const fontScale = options.fontScale ?? 15;
  const office = prepareOfficeText(text ?? "");
  const { blocks, visuals } = analyzeNotes(office.text);
  const byBlock = new Map<number, VisualSpec[]>();
  for (const visual of visuals) {
    const list = byBlock.get(visual.afterBlock) ?? [];
    list.push(visual.spec);
    byBlock.set(visual.afterBlock, list);
  }

  const html: string[] = [];
  let listType: "ul" | "ol" | null = null;
  const closeList = () => {
    if (!listType) return;
    html.push(`</${listType}>`);
    listType = null;
  };
  const pushVisuals = (index: number) => {
    const specs = byBlock.get(index);
    if (!specs?.length) return;
    // A figure never sits inside a list: close it, draw, and reopen after.
    closeList();
    for (const spec of specs) html.push(visualHtml(spec, options.print));
  };
  const pushPractice = (
    entries: readonly { index: number; topic: string; count: number }[] | undefined,
  ) => {
    if (!entries?.length) return;
    closeList();
    for (const entry of entries) {
      html.push(
        `<button type="button" class="kkcc-note-practice-link" data-note-practice-group="${entry.index}" aria-label="Practice ${escapeHtml(entry.topic)}: ${entry.count} questions">Practice ${escapeHtml(entry.topic)} · ${entry.count} question${entry.count === 1 ? "" : "s"} →</button>`,
      );
    }
  };

  pushVisuals(-1);
  blocks.forEach((block, index) => {
    const formatted = office.blocks.get(block.text);
    if (formatted) {
      closeList();
      html.push(
        options.editable
          ? `<div class="kkcc-preview-formatted-line"${noteLineAttrs(block, true)}>${formatted}</div>`
          : formatted,
      );
      pushVisuals(index);
      pushPractice(options.practiceAfterLines?.get(block.sourceLine));
      return;
    }
    if (block.type === "bullet" || block.type === "numbered") {
      const wanted = block.type === "bullet" ? "ul" : "ol";
      if (listType !== wanted) {
        closeList();
        html.push(`<${wanted} class="kkcc-note-list">`);
        listType = wanted;
      }
      html.push(listItemHtml(block, !!options.editable));
    } else {
      closeList();
      html.push(textBlockHtml(block, !!options.editable));
    }
    pushVisuals(index);
    pushPractice(options.practiceAfterLines?.get(block.sourceLine));
  });
  closeList();
  // Photos/settings pinned to "after the last paragraph" land here.
  pushVisuals(Number.MAX_SAFE_INTEGER);
  pushPractice(options.practiceAtEnd);

  const rendered = html.join("\n");
  // Never reveal the internal JSON metadata when the only content is practice.
  return `<style>${officeStyles}</style><div class="kkcc-note-body" style="font-size:${Math.max(10, Math.min(40, Number(fontScale) || 15))}px">${rendered || '<p class="kkcc-note-p">No note text yet.</p>'}</div>`;
}

/* --------------------------------------------------------- print document */

export function notesPrintStyles(): string {
  return `
:root{color-scheme:light}
*{box-sizing:border-box}
html,body{margin:0;padding:0}
/* The print window does not load src/styles.css. Keep its Latin typography and
   add the same local Punjabi/Hindi glyph subsets used by the in-app reader. */
@font-face{font-family:"KKCC Noto Gurmukhi";src:url("/fonts/indic/noto-sans-gurmukhi-400.woff2") format("woff2");font-weight:400 600;font-style:normal;font-display:swap;unicode-range:U+0A00-0A7F}
@font-face{font-family:"KKCC Noto Gurmukhi";src:url("/fonts/indic/noto-sans-gurmukhi-700.woff2") format("woff2");font-weight:700 900;font-style:normal;font-display:swap;unicode-range:U+0A00-0A7F}
@font-face{font-family:"KKCC Noto Devanagari";src:url("/fonts/indic/noto-sans-devanagari-400.woff2") format("woff2");font-weight:400 600;font-style:normal;font-display:swap;unicode-range:U+0900-097F,U+1CD0-1CFF,U+A8E0-A8FF}
@font-face{font-family:"KKCC Noto Devanagari";src:url("/fonts/indic/noto-sans-devanagari-700.woff2") format("woff2");font-weight:700 900;font-style:normal;font-display:swap;unicode-range:U+0900-097F,U+1CD0-1CFF,U+A8E0-A8FF}
body{background:#f1f5f9;color:#0f172a;font-family:Segoe UI,"KKCC Noto Gurmukhi","KKCC Noto Devanagari",system-ui,-apple-system,"Noto Sans",sans-serif;line-height:1.7;-webkit-print-color-adjust:exact;print-color-adjust:exact}
.kkcc-print-shell{max-width:820px;margin:0 auto;padding:16px}
.kkcc-print-toolbar{position:sticky;top:0;z-index:5;display:flex;flex-wrap:wrap;gap:10px;padding:10px 0 14px}
.kkcc-btn{display:inline-flex;align-items:center;gap:8px;padding:10px 18px;border-radius:999px;background:#4f46e5;color:#fff;font-weight:700;font-size:14px;border:0;cursor:pointer}
.kkcc-btn.ghost{background:#fff;color:#4f46e5;border:1px solid #c7d2fe}
.kkcc-note-card{background:#fff;border:1px solid #e2e8f0;border-radius:18px;padding:clamp(16px,4vw,30px);box-shadow:0 8px 30px rgba(15,23,42,.06)}
.kkcc-note-kicker{font-size:11.5px;font-weight:800;letter-spacing:.08em;text-transform:uppercase;color:#4f46e5}
.kkcc-note-title{margin:6px 0 2px;font-size:clamp(19px,4.6vw,27px);line-height:1.28;font-weight:900}
.kkcc-note-meta{margin:0 0 14px;font-size:12px;font-weight:700;color:#64748b}
.kkcc-note-h2{margin:20px 0 8px;font-size:17px;font-weight:900;color:#1e1b4b;border-left:4px solid #4f46e5;padding-left:10px}
.kkcc-note-h3{margin:14px 0 6px;font-size:15px;font-weight:800;color:#0f172a}
.kkcc-note-p{margin:8px 0}
.kkcc-note-list{margin:8px 0 8px 20px;padding:0}
.kkcc-note-li{margin:5px 0;padding-left:2px}
.kkcc-visual{margin:16px 0;padding:10px;border:1px solid #e2e8f0;border-radius:16px;background:#fff;break-inside:avoid;page-break-inside:avoid}
.kkcc-visual svg{width:100%;height:auto;display:block}
/* Formulas: plain text in, printed formula out. Serif stacks exist everywhere. */
.kkcc-math-block{margin:12px 0;padding:10px 14px;border:1px solid #c7d2fe;border-radius:14px;background:#eef2ff;font-family:"Cambria Math",Cambria,Georgia,"Times New Roman",serif;font-size:1.06em;line-height:1.9;text-align:center;overflow-x:auto;break-inside:avoid;page-break-inside:avoid}
.kkcc-math-frac{display:inline-flex;flex-direction:column;align-items:center;vertical-align:middle;margin:0 3px;line-height:1.15}
.kkcc-math-num{padding:0 5px 1px;border-bottom:1.4px solid currentColor}
.kkcc-math-den{padding:1px 5px 0}
.kkcc-math-sqrt{display:inline-flex;align-items:stretch;margin:0 2px}
.kkcc-math-radical{font-size:1.18em;line-height:1}
.kkcc-math-radicand{border-top:1.4px solid currentColor;padding:2px 4px 0;margin-top:3px}
.kkcc-math-sup,.kkcc-math-sub{font-size:.72em}
.kkcc-math-text{font-style:italic}
/* Photos the admin adds (handwritten pages, replaced diagrams). */
.kkcc-visual-image{background:#fff}
.kkcc-note-image{text-align:center}
.kkcc-note-image img{max-width:100%;height:auto;display:block;margin:0 auto;border-radius:12px}
.kkcc-custom-page-art{position:relative}
.kkcc-custom-page-mark{display:none}
.kkcc-note-image-caption{margin:6px 0 0;font-size:11px;font-weight:700;letter-spacing:.04em;text-transform:uppercase;color:#64748b}
.kkcc-visual figcaption{margin-top:6px;text-align:center;font-size:11px;font-weight:700;letter-spacing:.04em;text-transform:uppercase;color:#64748b}
.kkcc-note-h2{background:#eef8f5;color:#145344;border-color:#0d9488;padding:8px 12px;border-radius:0 8px 8px 0}
.kkcc-print-brandbar{display:flex;align-items:center;justify-content:center;position:relative;min-height:64px;padding:12px 65px;background:#fff;font-weight:800;text-align:center;color:#145344}
.kkcc-print-brandbar img{position:absolute;left:12px;width:44px;height:44px;object-fit:contain}
.kkcc-print-watermark{display:none}
.kkcc-centre-watermark{display:none}
.kkcc-print-footer{display:none}
/* B&W is a separate print document: no teal pixels, coloured highlights, SVGs or photos. */
body.kkcc-print-mono{background:#fff;color:#111}
body.kkcc-print-mono .kkcc-note-card,body.kkcc-print-mono .kkcc-visual{background:#fff;border-color:#777;box-shadow:none}
body.kkcc-print-mono .kkcc-note-kicker,body.kkcc-print-mono .kkcc-note-title,body.kkcc-print-mono .kkcc-note-meta,body.kkcc-print-mono .kkcc-note-h2,body.kkcc-print-mono .kkcc-note-h3,body.kkcc-print-mono .kkcc-note-body,body.kkcc-print-mono .kkcc-note-body [style*="color"],body.kkcc-print-mono .kkcc-print-brandbar,body.kkcc-print-mono .kkcc-print-footer{color:#111!important}
body.kkcc-print-mono .kkcc-note-body mark,body.kkcc-print-mono .kkcc-note-body [style*="background"],body.kkcc-print-mono .kkcc-office-callout,body.kkcc-print-mono .kkcc-math-block,body.kkcc-print-mono .kkcc-note-h2{background:#e4e4e4!important;border-color:#555!important}
body.kkcc-print-mono .kkcc-office-table th,body.kkcc-print-mono .kkcc-office-table tr:nth-child(even) td{color:#111!important;background:#ededed!important}
body.kkcc-print-mono .kkcc-note-body [class^="kkcc-ink-"],body.kkcc-print-mono .kkcc-note-body [class*=" kkcc-ink-"]{color:#111!important}
body.kkcc-print-mono .kkcc-visual svg,body.kkcc-print-mono .kkcc-note-image img,body.kkcc-print-mono .kkcc-print-brandbar img{filter:grayscale(1)}
body.kkcc-print-mono .kkcc-centre-watermark span{color:rgba(0,0,0,.23)}
@media print{
  @page{size:A4;margin:16mm 13mm 16mm}
  body{background:#fff}
  .kkcc-print-toolbar{display:none!important}
  .kkcc-print-shell{max-width:100%;padding:0}
  /* The monochrome screen rule is more specific than .kkcc-note-card alone.
     Override it here too: otherwise its opaque white card hides the fixed
     centre logo on the rasterized PDF, despite the image being embedded. */
  .kkcc-note-card,body.kkcc-print-mono .kkcc-note-card{background:transparent;border:0;border-radius:0;box-shadow:none;padding:0}
  /* A fixed decorative mark repeats on every printed sheet UNDER the note text.
     The real logo has a transparent background, so even with Background graphics
     turned off it remains light and does not obscure words. */
  .kkcc-centre-watermark{display:flex;position:fixed;left:50%;top:50%;transform:translate(-50%,-50%);width:64mm;flex-direction:column;align-items:center;justify-content:center;z-index:0;pointer-events:none}
  .kkcc-centre-watermark img{display:block;width:60mm;height:60mm;object-fit:contain;opacity:.19}
  .kkcc-centre-watermark span{display:block;margin-top:1mm;white-space:nowrap;font-size:12px;line-height:1.3;font-weight:800;letter-spacing:.04em;color:rgba(6,105,108,.22)}
  /* Table headers/footers reserve margins on EVERY page; the content stays on top. */
  .kkcc-print-watermark{display:none!important}
  .kkcc-print-pages{position:relative;z-index:1;width:100%;border-collapse:collapse;table-layout:fixed}
  .kkcc-print-pages > thead{display:table-header-group;break-inside:avoid}
  .kkcc-print-pages > tfoot{display:table-footer-group;break-inside:avoid}
  .kkcc-print-pages > thead > tr > td{padding:0 0 7mm}
  .kkcc-print-pages > tbody > tr > td{padding:0;vertical-align:top}
  .kkcc-print-pages > tfoot > tr > td{padding:6mm 0 0}
  .kkcc-print-footer{display:flex;justify-content:space-between;align-items:center;min-height:8mm;border-top:1px solid #d1ddd8;font-size:8px;color:#52645a;gap:5mm}
  .kkcc-print-brandbar{position:relative;height:19mm;min-height:0;padding:0 16mm;background:white;border-bottom:1px solid #b9cfc5;font-size:13px;line-height:1.3}
  body.kkcc-print-mono .kkcc-print-footer{border-top-color:#777}
  body.kkcc-print-mono .kkcc-print-brandbar{border-bottom-color:#777}
  .kkcc-print-brandbar img{left:0;width:14mm;height:14mm}
  /* Reserved header watermark repeats on each printed sheet, never over note text. */
  .kkcc-print-brandbar::after{content:"KKCC";position:absolute;right:0;bottom:1mm;transform:rotate(-12deg);font-size:9px;letter-spacing:.06em;opacity:.17;pointer-events:none}
  .kkcc-visual svg{max-height:210mm}
  .kkcc-note-image img{max-height:210mm;object-fit:contain}
  /* An opaque custom-page photo would hide the fixed page watermark. Put the
     faint real logo ABOVE this one image, keeping the rest of the page below text. */
  .kkcc-custom-page-art{display:inline-block;max-width:100%;vertical-align:top}
  .kkcc-custom-page-mark{display:flex;position:absolute;left:50%;top:52%;transform:translate(-50%,-50%);width:50mm;flex-direction:column;align-items:center;pointer-events:none}
  .kkcc-custom-page-mark img{width:42mm;height:42mm;object-fit:contain;opacity:.18}
  .kkcc-custom-page-mark .kkcc-custom-mark-black{display:none}
  .kkcc-custom-page-mark span{color:rgba(6,105,108,.24);font-size:11px;font-weight:800;white-space:nowrap}
  body.kkcc-print-mono .kkcc-custom-page-mark .kkcc-custom-mark-colour{display:none}
  body.kkcc-print-mono .kkcc-custom-page-mark .kkcc-custom-mark-black{display:block}
  body.kkcc-print-mono .kkcc-custom-page-mark span{color:rgba(0,0,0,.24)}
  .kkcc-note-body{position:relative;z-index:2}
  .kkcc-note-h2,.kkcc-note-h3{break-after:avoid;page-break-after:avoid}
  .kkcc-note-p,.kkcc-note-li{orphans:3;widows:3}
}
`;
}

/**
 * Full printable document for a note. Used by the reader's Print button, the
 * "Print / Save as PDF" window and the inline note that has no PDF file.
 */
export function notesPrintDocument(input: {
  title: string;
  subject?: string | null | undefined;
  chapter?: string | null | undefined;
  materialType?: string | null | undefined;
  text: string;
  fontScale?: number;
  /** Defaults to ink-only B&W print; explicit colour remains for internal previews. */
  mode?: PdfColourMode;
  /** Compact embedded KKCC artwork for small public inline URLs; default is print-quality. */
  logoSrc?: string;
}): string {
  const monochrome = input.mode !== "colour";
  const meta = [input.subject, input.chapter, input.materialType].filter(Boolean).join(" · ");
  const body = renderNotesBody(input.text, { fontScale: input.fontScale ?? 16, print: true });
  const title = input.title || "KKCC Study Note";
  return `<!doctype html><html lang="en"><head><meta charset="utf-8"/><meta name="viewport" content="width=device-width,initial-scale=1.0,maximum-scale=5.0,viewport-fit=cover"/><title>${escapeHtml(title)} — ${KKCC_BRAND_PRIMARY}</title><style>${notesPrintStyles()}</style></head><body class="${monochrome ? "kkcc-print-mono" : "kkcc-print-colour"}">
<div class="kkcc-print-shell">
  <div class="kkcc-print-toolbar">
    <button class="kkcc-btn" type="button" onclick="Promise.all([document.fonts.ready,...Array.from(document.images).map(i=>i.decode().catch(()=>{}))]).then(()=>window.print())">Print / Save as PDF</button>
    <button class="kkcc-btn ghost" type="button" onclick="window.close()">Close</button><p>${monochrome ? "Black & white print document: colours and highlights render as neutral gray; the centre logo uses black ink." : "Colour print document: highlights and artwork retain their colours. Enable Background graphics to keep highlight colours."} Use A4, default margins, and turn off browser Headers and footers.</p>
  </div>
  <div class="kkcc-centre-watermark" aria-hidden="true"><img src="${monochrome ? KKCC_CENTRE_WATERMARK_BLACK_LOGO : KKCC_CENTRE_WATERMARK_LOGO}" alt=""/><span>${escapeHtml(KKCC_BRAND_PRIMARY)}</span></div>
  <table class="kkcc-print-pages" role="presentation" style="width:100%"><thead><tr><td>
    <div class="kkcc-print-brandbar"><img src="${escapeHtml(input.logoSrc ?? NOTES_PRINT_LOGO)}" alt="KKCC logo"/><span>${escapeHtml(KKCC_BRAND_SECONDARY)}</span></div>
  </td></tr></thead><tbody><tr><td><article class="kkcc-note-card">
    <div class="kkcc-note-kicker">${escapeHtml(KKCC_BRAND_PRIMARY)}</div>
    <h1 class="kkcc-note-title">${escapeHtml(title)}</h1>
    <p class="kkcc-note-meta">${escapeHtml(meta || KKCC_BRAND_SECONDARY)}</p>
    ${body}
  </article></td></tr></tbody><tfoot><tr><td><div class="kkcc-print-footer"><span>${escapeHtml(KKCC_BRAND_PRIMARY)}</span><span>${escapeHtml(KKCC_BRAND_SECONDARY)}</span></div></td></tr></tfoot></table>
</div>
</body></html>`;
}

/** Short brand line used inside lists and cards. */
export function brandLine(): string {
  return `${KKCC_BRAND_PRIMARY} · ${KKCC_BRAND_SECONDARY}`;
}

/** Human summary such as "3 diagrams · 2 charts" for the admin preview. */
export function describeVisuals(specs: VisualSpec[]): string {
  if (!specs.length) return "No visuals detected";
  const diagrams = specs.filter((spec) => spec.kind !== "chart").length;
  const charts = specs.filter((spec) => spec.kind === "chart").length;
  const parts: string[] = [];
  if (diagrams) parts.push(`${diagrams} diagram${diagrams > 1 ? "s" : ""}`);
  if (charts) parts.push(`${charts} chart${charts > 1 ? "s" : ""}`);
  return parts.join(" · ");
}

/** Labels for the admin preview chips. */
export const VISUAL_KIND_LABELS: Record<VisualSpec["kind"], string> = {
  image: "Photo",
  flow: "Flow diagram",
  cycle: "Cycle diagram",
  tree: "Classification tree",
  compare: "Comparison",
  timeline: "Timeline",
  chart: "Chart",
};

export { wrapText };
