import type { PDFDocumentProxy } from "pdfjs-dist";
// PDF.js modern build assumes Map.getOrInsertComputed (not present in Chrome 141,
// older Android WebViews, or current iOS Safari). Legacy bundles polyfill it in
// BOTH the main thread and the worker, keeping local PDF tools functional.
import workerUrl from "pdfjs-dist/legacy/build/pdf.worker.min.mjs?url";
import { PDFDocument } from "pdf-lib";

export async function openBrowserPdf(bytes: Uint8Array, password = "") {
  const pdfjs = await import("pdfjs-dist/legacy/build/pdf.mjs");
  pdfjs.GlobalWorkerOptions.workerSrc = workerUrl;
  const task = pdfjs.getDocument({
    data: bytes.slice(),
    password,
    cMapUrl: "/pdf-engine/cmaps/",
    cMapPacked: true,
    standardFontDataUrl: "/pdf-engine/standard_fonts/",
    wasmUrl: "/pdf-engine/wasm/",
  });
  try {
    return await task.promise;
  } catch (error) {
    await task.destroy();
    throw error;
  }
}
export async function renderPdfPage(
  pdf: PDFDocumentProxy,
  number: number,
  scale = 1,
  rotation = 0,
) {
  const page = await pdf.getPage(number);
  let viewport = page.getViewport({ scale, rotation: (page.rotate + rotation) % 360 });
  if (viewport.width * viewport.height > 12_000_000)
    viewport = page.getViewport({
      scale: scale * Math.sqrt(12_000_000 / (viewport.width * viewport.height)),
      rotation: (page.rotate + rotation) % 360,
    });
  const canvas = document.createElement("canvas");
  canvas.width = Math.ceil(viewport.width);
  canvas.height = Math.ceil(viewport.height);
  await page.render({
    canvas,
    canvasContext: canvas.getContext("2d")!,
    viewport,
    background: "#ffffff",
  }).promise;
  return { canvas, viewport };
}
export function grayscaleCanvasPixels(canvas: HTMLCanvasElement): void {
  const ctx = canvas.getContext("2d");
  if (!ctx) throw new Error("Black & white export needs a 2D canvas.");
  const pixels = ctx.getImageData(0, 0, canvas.width, canvas.height);
  for (let i = 0; i < pixels.data.length; i += 4) {
    const gray = Math.round(
      pixels.data[i]! * 0.2126 + pixels.data[i + 1]! * 0.7152 + pixels.data[i + 2]! * 0.0722,
    );
    pixels.data[i] = pixels.data[i + 1] = pixels.data[i + 2] = gray;
  }
  ctx.putImageData(pixels, 0, 0);
}

export async function rasterPdf(
  bytes: Uint8Array,
  options: {
    invert: boolean;
    /** Make the actual exported image pixels grayscale, not just the on-screen preview. */
    grayscale?: boolean;
    scale: number;
    quality: number;
    progress: (page: number, total: number) => void;
    cancelled: () => boolean;
  },
) {
  const source = await openBrowserPdf(bytes);
  const out = await PDFDocument.create();
  try {
    if (source.numPages > 100)
      throw new Error(
        "Image-based PDF export is limited to 100 pages. Extract a smaller range first.",
      );
    let outputImageBytes = 0;
    for (let number = 1; number <= source.numPages; number++) {
      if (options.cancelled()) throw new Error("Cancelled. Original file is unchanged.");
      options.progress(number, source.numPages);
      const { canvas } = await renderPdfPage(source, number, options.scale);
      if (options.grayscale) grayscaleCanvasPixels(canvas);
      else if (options.invert) {
        const ctx = canvas.getContext("2d")!,
          pixels = ctx.getImageData(0, 0, canvas.width, canvas.height);
        for (let i = 0; i < pixels.data.length; i += 4) {
          pixels.data[i] = 255 - pixels.data[i]!;
          pixels.data[i + 1] = 255 - pixels.data[i + 1]!;
          pixels.data[i + 2] = 255 - pixels.data[i + 2]!;
        }
        ctx.putImageData(pixels, 0, 0);
      }
      const jpg = canvas.toDataURL("image/jpeg", options.quality);
      outputImageBytes += (jpg.length - jpg.indexOf(",") - 1) * 0.75;
      if (outputImageBytes > 120 * 1024 * 1024)
        throw new Error("Image-based PDF exceeds 120 MB. Export a smaller page range first.");
      const image = await out.embedJpg(jpg);
      const original = await source.getPage(number),
        size = original.getViewport({ scale: 1 });
      out
        .addPage([size.width, size.height])
        .drawImage(image, { x: 0, y: 0, width: size.width, height: size.height });
      canvas.width = 0;
      canvas.height = 0;
      await new Promise((resolve) => setTimeout(resolve, 0));
    }
    return out.save();
  } finally {
    await source.loadingTask.destroy();
  }
}
export async function prepareStudioImage(file: File): Promise<string> {
  if (!["image/jpeg", "image/png"].includes(file.type))
    throw new Error("Choose a JPG or PNG image.");
  if (file.size > 12 * 1024 * 1024) throw new Error("Image must be under 12 MB.");
  const bitmap = await createImageBitmap(file);
  try {
    if (bitmap.width * bitmap.height > 40_000_000)
      throw new Error("Image resolution too large. Resize below 40 megapixels.");
    const scale = Math.min(1, 1600 / Math.max(bitmap.width, bitmap.height));
    const canvas = document.createElement("canvas");
    canvas.width = Math.max(1, Math.round(bitmap.width * scale));
    canvas.height = Math.max(1, Math.round(bitmap.height * scale));
    canvas.getContext("2d")!.drawImage(bitmap, 0, 0, canvas.width, canvas.height);
    const data = canvas.toDataURL(file.type, 0.82);
    canvas.width = 0;
    canvas.height = 0;
    if (data.length > 4_000_000) throw new Error("Image is too detailed. Resize it and try again.");
    return data;
  } finally {
    bitmap.close();
  }
}

export async function pdfImagesZip(
  bytes: Uint8Array,
  progress: (n: number, total: number) => void,
  cancelled: () => boolean,
) {
  const source = await openBrowserPdf(bytes);
  const { default: JSZip } = await import("jszip");
  const zip = new JSZip();
  let size = 0;
  try {
    if (source.numPages > 50)
      throw new Error("PDF-to-images is limited to 50 pages; extract a smaller range first.");
    for (let n = 1; n <= source.numPages; n++) {
      if (cancelled()) throw new Error("Cancelled.");
      progress(n, source.numPages);
      const { canvas } = await renderPdfPage(source, n, 1.5);
      const blob = await new Promise<Blob>((resolve, reject) =>
        canvas.toBlob(
          (b) => (b ? resolve(b) : reject(new Error("Image encoding failed"))),
          "image/png",
        ),
      );
      size += blob.size;
      if (size > 120 * 1024 * 1024)
        throw new Error("Image output exceeds 120 MB. Work with fewer pages.");
      zip.file(`page-${String(n).padStart(3, "0")}.png`, await blob.arrayBuffer());
      canvas.width = 0;
      canvas.height = 0;
    }
    return await zip.generateAsync({ type: "uint8array" });
  } finally {
    await source.loadingTask.destroy();
  }
}
