export type AdminDailyQueue = {
  openDoubts: number | null;
  newEnquiries: number | null;
  pendingOfflineGrants: number | null;
  builtInSeriesVisible: boolean | null;
};

type QueueCountResult = { count: number | null; error: unknown | null };

/** Return null on a failed source; never turn a missing table into a fake zero. */
export async function safeAdminQueueCount(
  query: () => PromiseLike<QueueCountResult>,
): Promise<number | null> {
  try {
    const result = await query();
    return result.error ? null : (result.count ?? 0);
  } catch {
    return null;
  }
}

export function hasUnavailableAdminQueueCounts(queue: AdminDailyQueue | null | undefined) {
  return (
    !queue ||
    queue.openDoubts === null ||
    queue.newEnquiries === null ||
    queue.pendingOfflineGrants === null
  );
}
