import { createServerFn } from "@tanstack/react-start";
import { z } from "zod";
import { requireSupabaseAuth } from "@/integrations/supabase/auth-middleware";
import { noteFollowUpVersion } from "./note-follow-up-test";
import { notePracticeVersion } from "./note-practice";
import { parseVisualDirectives } from "./notes-visuals/directives";
import { materialForStudent } from "./material-access.server";
import { projectContent } from "./project-content.server";
import { unwrap } from "./learning.server";
import { requireSavedTestMode } from "./test-retention.server";

const attemptId = z.object({ id: z.string().uuid() });

export const saveNoteFollowUpResult = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .validator((input: unknown) =>
    z
      .object({
        material_id: z.string().uuid(),
        attempt_id: z.string().uuid(),
        test_version: z.string().regex(/^[0-9a-f]{8}$/),
        answers: z.array(z.number().int().min(0).max(3).nullable()).min(1).max(40),
      })
      .parse(input),
  )
  .handler(async ({ context, data }) => {
    // The privacy toggle is authoritative; don't create saved results when it is OFF.
    await requireSavedTestMode(context.supabase);
    // Recheck publication, purchase/enrolment and the actual saved note body on
    // every submission. Never grade an answer key or a note ID sent by the client.
    const access = await materialForStudent(context, data.material_id);
    const test = parseVisualDirectives(access.description).directives.followUpTest;
    if (!test || noteFollowUpVersion(test) !== data.test_version)
      throw new Error("This note's test changed. Reopen the note and start a new attempt.");
    const material = unwrap(
      await projectContent.from("materials").select("title").eq("id", data.material_id).single(),
    );
    const { storeNoteResult } = await import("./note-result.server");
    return storeNoteResult({
      id: data.attempt_id,
      userId: context.userId,
      materialId: data.material_id,
      materialTitle: material.title,
      test,
      answers: data.answers,
    });
  });

export const listMyNoteFollowUpResults = createServerFn({ method: "GET" })
  .middleware([requireSupabaseAuth])
  .handler(async ({ context }) => {
    const { listMyNoteResults } = await import("./note-result.server");
    return listMyNoteResults(context.userId);
  });

export const getMyNoteFollowUpResult = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .validator((input: unknown) => attemptId.parse(input))
  .handler(async ({ context, data }) => {
    const { findMyNoteResult } = await import("./note-result.server");
    return findMyNoteResult(context.userId, data.id);
  });

export const saveNotePracticeResult = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .validator((input: unknown) =>
    z
      .object({
        material_id: z.string().uuid(),
        attempt_id: z.string().uuid(),
        question_id: z.string().regex(/^[a-zA-Z0-9_-]{1,64}$/),
        question_version: z.string().regex(/^[a-f0-9]{8}$/),
        response: z.union([z.number().int().min(0).max(3), z.string().trim().min(1).max(1000)]),
      })
      .parse(input),
  )
  .handler(async ({ context, data }) => {
    await requireSavedTestMode(context.supabase);
    const access = await materialForStudent(context, data.material_id);
    const question = parseVisualDirectives(access.description).directives.practice.find(
      (item) => item.id === data.question_id,
    );
    if (!question || notePracticeVersion(question) !== data.question_version)
      throw new Error("This note's practice question changed. Reopen the note and try again.");
    const material = unwrap(
      await projectContent.from("materials").select("title").eq("id", data.material_id).single(),
    );
    const { storePracticeResult } = await import("./note-result.server");
    return storePracticeResult({
      id: data.attempt_id,
      userId: context.userId,
      materialId: data.material_id,
      materialTitle: material.title,
      question,
      response: data.response,
    });
  });

export const listMyNotePracticeResults = createServerFn({ method: "GET" })
  .middleware([requireSupabaseAuth])
  .handler(async ({ context }) => {
    const { listMyPracticeResults } = await import("./note-result.server");
    return listMyPracticeResults(context.userId);
  });

export const getMyNotePracticeResult = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .validator((input: unknown) => attemptId.parse(input))
  .handler(async ({ context, data }) => {
    const { findMyPracticeResult } = await import("./note-result.server");
    return findMyPracticeResult(context.userId, data.id);
  });
