import { z } from "zod";
import type { CourseRow } from "@/integrations/supabase/db";
import { projectContent } from "./project-content.server";

const SETTINGS_KEY = "notes_batch_pricing_v1";
const COURSE_INDEX_PREFIX = "notes_batch_course_v1:";
export const notesBatchPricingSchema = z
  .object({
    mode: z.enum(["shared", "per_batch"]).default("per_batch"),
    priceInr: z.number().int().min(0).max(1_000_000).default(0),
    priceCoins: z.number().int().min(0).max(1_000_000).default(0),
  })
  .superRefine((pricing, ctx) => {
    if (pricing.mode === "shared" && pricing.priceInr <= 0 && pricing.priceCoins <= 0)
      ctx.addIssue({ code: "custom", message: "Set a shared INR or 23KAAT price above zero." });
  });
export type NotesBatchPricing = z.infer<typeof notesBatchPricingSchema>;

export async function getNotesBatchPricing(): Promise<NotesBatchPricing> {
  const { data, error } = await projectContent
    .from("private_settings")
    .select("value")
    .eq("key", SETTINGS_KEY)
    .maybeSingle();
  if (error) throw new Error(error.message);
  return data
    ? notesBatchPricingSchema.parse(JSON.parse(data.value))
    : notesBatchPricingSchema.parse({});
}

export type BatchPricedCourse<T extends CourseRow = CourseRow> = T & {
  coin_price_is_explicit?: true;
  is_notes_batch?: true;
  batch_price_configured?: boolean;
};

export async function applySharedBatchPriceToCourse<T extends CourseRow>(
  course: T,
): Promise<BatchPricedCourse<T>> {
  const pricing = await getNotesBatchPricing();
  const { data: index, error } = await projectContent
    .from("private_settings")
    .select("value")
    .eq("key", COURSE_INDEX_PREFIX + course.id)
    .maybeSingle();
  if (error) throw new Error(error.message);
  if (!index) return course;
  const price = pricing.mode === "shared" ? pricing.priceInr : course.price;
  const coinPrice = pricing.mode === "shared" ? pricing.priceCoins : course.coin_price;
  return {
    ...course,
    price,
    coin_price: coinPrice,
    coin_price_is_explicit: true,
    is_notes_batch: true,
    batch_price_configured: price > 0 || coinPrice > 0,
  };
}

export async function applySharedBatchPriceToCourses<T extends CourseRow>(
  courses: T[],
): Promise<BatchPricedCourse<T>[]> {
  if (!courses.length) return courses;
  const pricing = await getNotesBatchPricing();
  const { data: indexes, error } = await projectContent
    .from("private_settings")
    .select("key")
    .in(
      "key",
      courses.map((course) => COURSE_INDEX_PREFIX + course.id),
    );
  if (error) throw new Error(error.message);
  const batchIds = new Set((indexes ?? []).map((row) => row.key.slice(COURSE_INDEX_PREFIX.length)));
  return courses.map((course) => {
    if (!batchIds.has(course.id)) return course;
    const price = pricing.mode === "shared" ? pricing.priceInr : course.price;
    const coinPrice = pricing.mode === "shared" ? pricing.priceCoins : course.coin_price;
    return {
      ...course,
      price,
      coin_price: coinPrice,
      coin_price_is_explicit: true,
      is_notes_batch: true,
      batch_price_configured: price > 0 || coinPrice > 0,
    };
  });
}
