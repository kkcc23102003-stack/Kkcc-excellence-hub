import { z } from "zod";
import { thumbnailFields } from "./thumbnail";
import { materialAccessMode } from "./material-access-mode";

const name = z.string().trim().min(1).max(200);
const noteIds = z.array(z.string().uuid()).max(50000).default([]);
const topic = z.object({ id: z.string().uuid(), name, noteIds });
const chapter = z.object({
  id: z.string().uuid(),
  name,
  noteIds,
  topics: z.array(topic).max(5000).default([]),
});
const subject = z.object({
  id: z.string().uuid(),
  name,
  chapters: z.array(chapter).max(5000).default([]),
});
export const notesSeriesSchema = z
  .object({
    id: z.string().uuid(),
    name,
    ...thumbnailFields,
    kind: z.enum(["paid", "sample"]),
    /** Standalone full-series checkout prices. Zero means Admin has not configured it yet. */
    priceInr: z.number().int().min(0).max(1_000_000).default(0),
    priceCoins: z.number().int().min(0).max(1_000_000).default(0),
    published: z.boolean(),
    revision: z.number().int().min(0),
    subjects: z.array(subject).max(5000).default([]),
  })
  .superRefine((series, ctx) => {
    const ids = new Set<string>();
    const notes = new Set<string>();
    const checkNames = (rows: { id: string; name: string }[]) => {
      const names = new Set<string>();
      for (const row of rows) {
        const normalized = row.name.normalize("NFC").toLocaleLowerCase();
        if (ids.has(row.id) || names.has(normalized))
          ctx.addIssue({
            code: "custom",
            message: "Use unique names within each list and unique node IDs.",
          });
        ids.add(row.id);
        names.add(normalized);
      }
    };
    const checkNotes = (values: string[]) => {
      for (const id of values) {
        if (notes.has(id))
          ctx.addIssue({ code: "custom", message: "A note can appear only once within a series." });
        notes.add(id);
      }
    };
    checkNames(series.subjects);
    for (const sub of series.subjects) {
      checkNames(sub.chapters);
      for (const chap of sub.chapters) {
        checkNotes(chap.noteIds);
        checkNames(chap.topics);
        for (const item of chap.topics) checkNotes(item.noteIds);
      }
    }
    if (JSON.stringify(series).length > 20_000_000)
      ctx.addIssue({
        code: "custom",
        message: "This series exceeds the 20 MB Storage catalogue limit. Split it into two series.",
      });
  });
export type NotesSeries = z.infer<typeof notesSeriesSchema>;
export const NOTES_SERIES_ACCESS_PREFIX = "notes-series:";
export const notesSeriesAccessKey = (id: string) => `${NOTES_SERIES_ACCESS_PREFIX}${id}`;
export type NotesSubject = NotesSeries["subjects"][number];
export type NotesChapter = NotesSubject["chapters"][number];
export type NotesTopic = NotesChapter["topics"][number];
export function seriesNoteIds(series: NotesSeries): string[] {
  return series.subjects.flatMap((sub) =>
    sub.chapters.flatMap((chap) => [
      ...chap.noteIds,
      ...chap.topics.flatMap((item) => item.noteIds),
    ]),
  );
}

/** First published note in each subject is the free preview for paid series. */
export function seriesFirstNoteIds(
  series: NotesSeries,
  availableIds?: ReadonlySet<string>,
): string[] {
  return series.subjects.flatMap((subject) => {
    for (const chapter of subject.chapters) {
      const ordered = [...chapter.noteIds, ...chapter.topics.flatMap((topic) => topic.noteIds)];
      const first = ordered.find((id) => !availableIds || availableIds.has(id));
      if (first) return [first];
    }
    return [];
  });
}
export type SeriesMaterial = {
  id: string;
  title: string;
  subject?: string | null;
  chapter?: string | null;
  access_type?: string | null;
  price?: number | null;
  coin_price?: number | null;
  course_id?: string | null;
};
export const isSampleNote = (note: SeriesMaterial) => materialAccessMode(note) === "free";

/** Visibility is organisation only, never an access grant. Draft assignments do not leak into fallback. */
export function buildNotesLibrary(
  series: NotesSeries[],
  materials: SeriesMaterial[],
  kind: "paid" | "sample",
) {
  const eligible = materials.filter((note) => isSampleNote(note) === (kind === "sample"));
  const eligibleIds = new Set(eligible.map((note) => note.id));
  const assigned = new Set(series.flatMap(seriesNoteIds));
  const visible = series
    .filter((item) => item.published && item.kind === kind)
    .map((item) => ({
      ...item,
      subjects: item.subjects
        .map((sub) => ({
          ...sub,
          chapters: sub.chapters
            .map((chap) => ({
              ...chap,
              noteIds: chap.noteIds.filter((id) => eligibleIds.has(id)),
              topics: chap.topics
                .map((t) => ({ ...t, noteIds: t.noteIds.filter((id) => eligibleIds.has(id)) }))
                .filter((t) => t.noteIds.length),
            }))
            .filter((chap) => chap.noteIds.length || chap.topics.length),
        }))
        .filter((sub) => sub.chapters.length),
    }))
    .filter((item) => item.subjects.length);
  const remaining = eligible.filter((note) => !assigned.has(note.id));
  if (remaining.length) {
    const subjects: NotesSubject[] = [];
    for (const note of remaining) {
      const subjectName = note.subject?.trim() || "General studies";
      const chapterName = note.chapter?.trim() || "General notes";
      let sub = subjects.find((item) => item.name === subjectName);
      if (!sub) {
        sub = { id: `legacy-subject-${subjects.length}`, name: subjectName, chapters: [] };
        subjects.push(sub);
      }
      let chap = sub.chapters.find((item) => item.name === chapterName);
      if (!chap) {
        chap = {
          id: `${sub.id}-chapter-${sub.chapters.length}`,
          name: chapterName,
          noteIds: [],
          topics: [],
        };
        sub.chapters.push(chap);
      }
      chap.noteIds.push(note.id);
    }
    visible.push({
      id: `${kind}-unassigned`,
      name: kind === "sample" ? "Free notes" : "Other paid notes",
      kind,
      revision: 0,
      priceInr: 0,
      priceCoins: 0,
      published: true,
      subjects,
      thumbnail_url: null,
      thumbnail_text: null,
    });
  }
  return visible;
}
