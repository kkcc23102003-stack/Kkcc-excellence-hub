import { escapeHtml } from "./notes-visuals/render";
import { richInlineToHtml } from "./rich-text";
import { looksLikeFormula, renderFormulaLine } from "./notes-visuals/math";
import { authorContrast, normaliseAuthorColour } from "./author-colours";

/** Format each selected line independently, leaving diagram/table fences intact. */
export function formatNoteSelection(text: string, tag: string): string {
  const close = tag.split("=")[0];
  let fenced = false;
  return (text || "Text")
    .split("\n")
    .map((line) => {
      if (line.trim().startsWith(":::")) {
        fenced = line.trim() !== ":::";
        return line;
      }
      if (fenced || !line.trim()) return line;
      const match = line.match(/^(\s*(?:#{1,4}|[-*•]|\d+[.)])\s+)?(.*)$/)!;
      const prefix = match[1] ?? "",
        body = match[2]!;
      const openTag = `[${tag}]`,
        closeTag = `[/${close}]`;
      return (
        prefix +
        (body.startsWith(openTag) && body.endsWith(closeTag)
          ? body.slice(openTag.length, -closeTag.length)
          : `${openTag}${body}${closeTag}`)
      );
    })
    .join("\n");
}

/** Portable bracket formatting plus safe reading of the older PR #2 inline markup. */
export function officeInline(text: string, depth = 0): string {
  if (depth > 12) return escapeHtml(text);
  const pattern =
    /\[(b|i|u|mark|sup|sub|color|highlight|size|align|box)(?:=([^\]\n]+))?\]([\s\S]*?)\[\/\1\]/g;
  let result = "",
    end = 0;
  for (const match of text.matchAll(pattern)) {
    result += plain(text.slice(end, match.index));
    const kind = match[1]!,
      value = match[2] ?? "",
      body = officeInline(match[3]!, depth + 1);
    const tags: Record<string, string> = {
      b: "strong",
      i: "em",
      u: "u",
      mark: "mark",
      sup: "sup",
      sub: "sub",
    };
    const tag = tags[kind];
    if (tag) result += `<${tag}>${body}</${tag}>`;
    else if (kind === "color" && /^(teal|blue|purple|red|green)$/.test(value))
      result += `<span class="kkcc-ink-${value}">${body}</span>`;
    else if (kind === "color" && normaliseAuthorColour(value))
      result += `<span style="color:${normaliseAuthorColour(value)}">${body}</span>`;
    else if (kind === "highlight" && normaliseAuthorColour(value)) {
      const colour = normaliseAuthorColour(value)!;
      const ink =
        authorContrast("#172b36", colour) >= authorContrast("#ffffff", colour)
          ? "#172b36"
          : "#ffffff";
      result += `<mark style="background-color:${colour};color:${ink}">${body}</mark>`;
    } else if (kind === "size" && /^(12|14|16|18|20|24|28|32)$/.test(value))
      result += `<span style="font-size:${value}px">${body}</span>`;
    else if (kind === "align" && /^(left|center|right|justify)$/.test(value))
      result += `<span style="display:block;text-align:${value}">${body}</span>`;
    else if (kind === "box") result += `<span class="kkcc-office-callout">${body}</span>`;
    else result += escapeHtml(match[0]);
    end = match.index! + match[0].length;
  }
  return result + plain(text.slice(end));
}
function plain(text: string) {
  // Previously authored Notes and Tests use <b>/<i>/<u> and a fixed-palette
  // <span style="color:…">. The legacy parser only emits those safe tags and
  // escapes everything else; new bracket HEX/highlight markup still works.
  return looksLikeFormula(text) ? renderFormulaLine(text) : richInlineToHtml(text);
}

/**
 * Keep authored formatting/tables away from diagram inference without moving
 * lines: the preview editor must be able to map a rendered line back to the
 * EXACT source line, even when a table or bracket formatting comes before it.
 */
export function prepareOfficeText(source: string) {
  let prefix = "kkccofficeblock";
  while (source.includes(prefix)) prefix += "x";
  const blocks = new Map<string, string>();
  const hold = (html: string) => {
    const key = `${prefix}${blocks.size}`;
    blocks.set(key, html);
    return key;
  };
  const lines = (source ?? "").replace(/\r\n?/g, "\n").split("\n");
  const prepared: string[] = [];
  let fenced = false;
  for (let i = 0; i < lines.length; i++) {
    const line = lines[i]!;
    if (!fenced && /^\s*:::table\s*$/.test(line)) {
      const end = lines.findIndex((entry, position) => position > i && /^\s*:::\s*$/.test(entry));
      if (end > i) {
        const rows = lines.slice(i + 1, end).map((row) => row.split("\t"));
        // Invalid tables remain readable as their original source, never truncated.
        if (rows.length && rows.length <= 100 && rows.every((row) => row.length <= 12)) {
          const header = rows[0]!
            .map((cell) => `<th scope="col">${officeInline(cell)}</th>`)
            .join("");
          const rest = rows
            .slice(1)
            .map(
              (row) => `<tr>${row.map((cell) => `<td>${officeInline(cell)}</td>`).join("")}</tr>`,
            )
            .join("");
          prepared.push(
            hold(
              `<table class="kkcc-office-table"><thead><tr>${header}</tr></thead><tbody>${rest}</tbody></table>`,
            ),
          );
          for (let n = i + 1; n <= end; n++) prepared.push("");
          i = end;
          continue;
        }
      }
    }
    if (line.trim().startsWith(":::")) {
      fenced = line.trim() !== ":::";
      prepared.push(line);
      continue;
    }
    if (fenced || !/\[(b|i|u|mark|sup|sub|color|highlight|size|align|box)(?:=|\])/.test(line)) {
      prepared.push(line);
      continue;
    }
    const heading = line.match(/^#{1,4}\s+(.*)$/);
    prepared.push(
      hold(
        heading
          ? `<h2 class="kkcc-note-h2">${officeInline(heading[1]!)}</h2>`
          : `<p class="kkcc-note-p">${officeInline(line)}</p>`,
      ),
    );
  }
  return { text: prepared.join("\n"), blocks };
}

export const officeStyles = `
.kkcc-note-reader .kkcc-note-h2{background:#eef8f5;color:#145344;padding:8px 12px;border-left:4px solid #0d9488;border-radius:0 8px 8px 0}
.kkcc-note-body strong{font-weight:800;color:inherit}
.kkcc-note-body mark{background:#fff0a6;color:#332800;padding:1px 3px;border-radius:3px;box-decoration-break:clone}
.kkcc-ink-teal{color:#0f766e}.kkcc-ink-blue{color:#1d4ed8}.kkcc-ink-purple{color:#7e22ce}.kkcc-ink-red{color:#b91c1c}.kkcc-ink-green{color:#166534}
.dark .kkcc-note-body .kkcc-ink-teal{color:#5eead4}.dark .kkcc-note-body .kkcc-ink-blue{color:#93c5fd}.dark .kkcc-note-body .kkcc-ink-purple{color:#d8b4fe}.dark .kkcc-note-body .kkcc-ink-red{color:#fca5a5}.dark .kkcc-note-body .kkcc-ink-green{color:#86efac}
.kkcc-office-callout{display:block;border-left:4px solid #0d9488;background:#effcf8;color:#134e4a;padding:12px 16px;border-radius:8px;margin:10px 0}
.kkcc-office-table{border-collapse:collapse;width:100%;table-layout:fixed;margin:16px 0;font-size:.92em}
.kkcc-office-table th,.kkcc-office-table td{border:1px solid #b9cbd1;padding:8px;text-align:left;overflow-wrap:anywhere;vertical-align:top}
.kkcc-office-table th{background:#e0f2ef;color:#134e4a;font-weight:800}.kkcc-office-table tr:nth-child(even) td{background:#f4f8fb;color:#172b36}
.kkcc-office-table thead{display:table-header-group}.kkcc-office-table tr{break-inside:avoid}
.kkcc-note-body{overflow-wrap:anywhere}
.kkcc-note-practice-link{display:block;width:100%;margin:14px 0;padding:12px 16px;border:1px solid #a5d6ca;border-radius:12px;background:#eef8f5;color:#145344;text-align:left;font:inherit;font-weight:800;cursor:pointer}
.kkcc-note-practice-link:hover,.kkcc-note-practice-link:focus-visible{outline:2px solid #0d9488;outline-offset:2px;background:#dbf3ec}
`;
