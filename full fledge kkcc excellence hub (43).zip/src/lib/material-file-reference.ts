import { decodeSecureVideoToken } from "./video";

export const MAX_MATERIAL_FILE_REFERENCE_CHARS = 2048;

/** Material rows keep a short URL or a durable Storage pointer, never a file data blob. */
export function isCompactMaterialFileReference(value: string | null | undefined): boolean {
  if (value == null || value.trim() === "") return true;
  const reference = value.trim();
  if (
    reference.length > MAX_MATERIAL_FILE_REFERENCE_CHARS ||
    Array.from(reference).some((character) => {
      const code = character.charCodeAt(0);
      return code < 32 || code === 127;
    })
  )
    return false;
  if (reference.startsWith("data:") || reference.startsWith("blob:")) return false;
  if (reference.startsWith("kkccv1.")) return Boolean(decodeSecureVideoToken(reference));
  if (reference.startsWith("kkcc-file://")) {
    const encoded = reference.slice("kkcc-file://".length);
    const slash = encoded.indexOf("/");
    if (slash < 1 || slash === encoded.length - 1) return false;
    try {
      const bucket = decodeURIComponent(encoded.slice(0, slash));
      const path = decodeURIComponent(encoded.slice(slash + 1));
      return (
        /^[a-z0-9][a-z0-9-]{0,62}$/i.test(bucket) &&
        path.length <= 1800 &&
        path.split("/").every((segment) => segment && segment !== "." && segment !== "..")
      );
    } catch {
      return false;
    }
  }
  if (reference.startsWith("/")) return !reference.startsWith("//");
  try {
    const url = new URL(reference);
    return (
      (url.protocol === "https:" || url.protocol === "http:") &&
      Boolean(url.hostname) &&
      !url.username &&
      !url.password
    );
  } catch {
    return false;
  }
}
