import {
  buildFallbackExplanation,
  isNumberedQuestionHeading,
  parseBulkMcqText,
} from "./test-bulk-parse";
import {
  parseNotePracticeQuestion,
  type NotePracticeQuestion,
} from "./note-practice";

/** Authored next test lives with its note; student answers/scores never live here. */
export type NoteFollowUpTest = {
  title: string;
  questions: NotePracticeQuestion[];
};
export const MAX_NOTE_FOLLOW_UP_QUESTIONS = 200;

/** Lightweight revision token, not an authorization secret. The server checks it against the current note. */
export function noteFollowUpVersion(test: NoteFollowUpTest): string {
  const text = JSON.stringify(test);
  let hash = 2166136261;
  for (let index = 0; index < text.length; index++)
    hash = Math.imul(hash ^ text.charCodeAt(index), 16777619) >>> 0;
  return hash.toString(16).padStart(8, "0");
}

/** Fail closed on malformed metadata rather than showing partial or wrong answers. */
export function parseNoteFollowUpTest(input: unknown): NoteFollowUpTest | null {
  if (!input || typeof input !== "object" || Array.isArray(input)) return null;
  const value = input as Record<string, unknown>;
  const title = value["title"];
  const raw = value["questions"];
  if (
    typeof title !== "string" ||
    !title.trim() ||
    title.length > 100 ||
    !Array.isArray(raw) ||
    raw.length < 1 ||
    raw.length > MAX_NOTE_FOLLOW_UP_QUESTIONS
  )
    return null;
  const seen = new Set<string>();
  const questions: NotePracticeQuestion[] = [];
  for (const item of raw) {
    const question = parseNotePracticeQuestion(item);
    if (
      !question ||
      !question.options.length ||
      question.afterLine !== -1 ||
      question.afterText !== "" ||
      seen.has(question.id)
    )
      return null;
    seen.add(question.id);
    questions.push({ ...question, topic: title.trim() });
  }
  return { title: title.trim(), questions };
}

/** Same MCQ parser as Admin → Tests; nothing is persisted until the note is saved. */
export function prepareNoteFollowUpPaste(
  text: string,
  title: string,
  makeId: () => string,
): { test: NoteFollowUpTest | null; error: string } {
  const name = title.trim();
  if (!name || name.length > 100)
    return { test: null, error: "Test title 1–100 characters rakhein." };
  const parsed = parseBulkMcqText(text);
  if (!parsed.length)
    return {
      test: null,
      error:
        "MCQ paste mein question, 2–4 options aur Answer/उत्तर zaroor likhein.",
    };
  if (parsed.length > MAX_NOTE_FOLLOW_UP_QUESTIONS)
    return {
      test: null,
      error: `Ek note test mein maximum ${MAX_NOTE_FOLLOW_UP_QUESTIONS} questions rakhein.`,
    };
  const labelled = text
    .replace(/\r/g, "")
    .split("\n")
    .filter((line) => isNumberedQuestionHeading(line)).length;
  if (labelled > parsed.length)
    return {
      test: null,
      error: `${labelled - parsed.length} numbered question parse nahi hue. Options aur Answer/उत्तर line theek karke phir Preview karein.`,
    };
  const questions: NotePracticeQuestion[] = parsed.map((item) => ({
    id: makeId(),
    topic: name,
    question: item.question_text,
    options: item.options,
    correctIndex: item.correct_index,
    answer: "",
    explanation:
      item.explanation.trim() || buildFallbackExplanation(item, name),
    afterLine: -1,
    afterText: "",
  }));
  const test = parseNoteFollowUpTest({ title: name, questions });
  return test
    ? { test, error: "" }
    : {
        test: null,
        error:
          "Ek question limit se bada ya invalid hai. Question/option/Explanation chhote karke Preview karein.",
      };
}

export function scoreNoteFollowUp(
  questions: readonly NotePracticeQuestion[],
  answers: readonly (number | null)[],
): number {
  return questions.reduce(
    (score, question, index) =>
      score + (answers[index] === question.correctIndex ? 1 : 0),
    0,
  );
}
