import { materialAccessMode } from "./material-access-mode";
import { readNoteBody } from "./note-body.server";
import { isFreeCourse } from "@/lib/cms";
import { notesPrintDocument } from "@/lib/notes-visuals";
import type { StudentContext } from "@/lib/learning.server";
import { readStudentAccess, unwrap } from "@/lib/learning.server";
import { projectContent } from "@/lib/project-content.server";
import {
  hasNotesSeriesGrantForMaterial,
  isFreeNotesSeriesPreview,
} from "@/lib/notes-series-purchase.server";
import { resolveContentUrl, resolveNoteImages } from "@/lib/content-storage.server";
import { applySharedBatchPriceToCourse } from "@/lib/notes-batch-pricing.server";

function buildInlineNoteDataUrl(material: {
  title?: string | null;
  subject?: string | null;
  chapter?: string | null;
  material_type?: string | null;
  description?: string | null;
}) {
  // Same builder the reader and the print button use: text goes in, headings,
  // diagrams/charts and the KKCC watermark on every page come out.
  const html = notesPrintDocument({
    title: material.title || "KKCC Study Note",
    subject: material.subject,
    chapter: material.chapter,
    materialType: material.material_type,
    text: material.description ?? "",
  });
  return `data:text/html;charset=utf-8,${encodeURIComponent(html)}`;
}

export async function materialForStudent(context: StudentContext, id: string) {
  const material = unwrap(
    await projectContent
      .from("materials")
      .select("*")
      .eq("id", id)
      .eq("is_published", true)
      .maybeSingle(),
  );
  if (!material) throw new Error("Material not found.");
  const access = await readStudentAccess(context);
  const mode = materialAccessMode(material);
  const isFreeSeriesPreview = await isFreeNotesSeriesPreview(material.id);
  const hasSeriesPurchase = await hasNotesSeriesGrantForMaterial(
    access.notes_series_grants,
    material.id,
  );
  const hasManualNoteGrant = access.material_grants.some(
    (grant) => grant.material_id === material.id,
  );
  let allowed =
    access.is_admin ||
    mode === "free" ||
    material.is_free_preview ||
    isFreeSeriesPreview ||
    hasSeriesPurchase ||
    hasManualNoteGrant;
  if (!allowed && mode === "paid") {
    allowed = Boolean(
      unwrap(
        await context.supabase
          .from("material_purchases")
          .select("id")
          .eq("user_id", context.userId)
          .eq("material_id", id)
          .eq("status", "active")
          .maybeSingle(),
      ),
    );
  }
  if (!allowed && mode === "paid" && material.course_id) {
    const course = unwrap(
      await projectContent
        .from("courses")
        .select("*")
        .eq("id", material.course_id)
        .eq("status", "published")
        .maybeSingle(),
    );
    const pricedCourse = course ? await applySharedBatchPriceToCourse(course) : null;
    allowed = Boolean(
      pricedCourse && (isFreeCourse(pricedCourse) || access.course_ids.includes(pricedCourse.id)),
    );
  }
  if (!allowed && mode === "course") {
    if (!material.course_id) {
      allowed = true;
    } else {
      const course = unwrap(
        await projectContent
          .from("courses")
          .select("*")
          .eq("id", material.course_id)
          .eq("status", "published")
          .maybeSingle(),
      );
      const pricedCourse = course ? await applySharedBatchPriceToCourse(course) : null;
      allowed = Boolean(
        pricedCourse && (isFreeCourse(pricedCourse) || access.course_ids.includes(pricedCourse.id)),
      );
    }
  }
  if (!allowed)
    throw new Error(mode === "paid" ? "MATERIAL_ACCESS_REQUIRED" : "COURSE_ACCESS_REQUIRED");
  const description = await resolveNoteImages(await readNoteBody(material));
  const resolvedUrl = await resolveContentUrl(material.file_url);
  const file_url =
    resolvedUrl && resolvedUrl !== "#"
      ? resolvedUrl
      : buildInlineNoteDataUrl({ ...material, description });
  return { ok: true, material_id: material.id, file_url, description };
}
