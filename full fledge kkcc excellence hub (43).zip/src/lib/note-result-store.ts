import { createHash } from "node:crypto";
import {
  parseNoteFollowUpTest,
  scoreNoteFollowUp,
  type NoteFollowUpTest,
} from "./note-follow-up-test";

/** Private, immutable result payload. The database remains the source of truth for identity/access. */
export type NoteResult = {
  version: 1;
  id: string;
  user_id: string;
  material_id: string;
  material_title: string;
  submitted_at: string;
  test_sha256: string;
  test: NoteFollowUpTest;
  answers: (number | null)[];
  score: number;
  total: number;
  attempted: number;
};
export type NoteResultSummary = Pick<
  NoteResult,
  "id" | "material_id" | "material_title" | "submitted_at" | "score" | "total" | "attempted"
> & { test_title: string };

export const NOTE_RESULT_BUCKET = "kkcc-note-results";
export const MAX_NOTE_RESULT_BYTES = 256 * 1024;
const uuid = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i;
export function resultPath(userId: string, attemptId: string) {
  if (!uuid.test(userId) || !uuid.test(attemptId))
    throw new Error("Invalid result owner or attempt ID.");
  return `${userId}/${attemptId}.json`;
}

export function makeNoteResult(input: {
  id: string;
  userId: string;
  materialId: string;
  materialTitle: string;
  test: NoteFollowUpTest;
  answers: (number | null)[];
  submittedAt?: string;
}): NoteResult {
  resultPath(input.userId, input.id);
  if (!uuid.test(input.materialId)) throw new Error("Invalid note ID.");
  const test = parseNoteFollowUpTest(input.test);
  if (!test || test.questions.length !== input.answers.length)
    throw new Error("This test or its answer count changed. Reopen the note and try again.");
  if (
    input.answers.some(
      (answer, index) =>
        answer !== null &&
        (!Number.isInteger(answer) ||
          answer < 0 ||
          answer >= test.questions[index]!.options.length),
    )
  )
    throw new Error("Invalid answer option.");
  const result: NoteResult = {
    version: 1,
    id: input.id,
    user_id: input.userId,
    material_id: input.materialId,
    material_title: input.materialTitle.slice(0, 200),
    submitted_at: input.submittedAt ?? new Date().toISOString(),
    test_sha256: createHash("sha256").update(JSON.stringify(test)).digest("hex"),
    test,
    answers: input.answers,
    score: scoreNoteFollowUp(test.questions, input.answers),
    total: test.questions.length,
    attempted: input.answers.filter((answer) => answer !== null).length,
  };
  if (Buffer.byteLength(JSON.stringify(result)) > MAX_NOTE_RESULT_BYTES)
    throw new Error("Test result exceeds the private Storage size limit.");
  return result;
}

/** Verify every saved byte on read. Never trust a Storage path supplied by a client. */
export function readNoteResult(bytes: Uint8Array, userId: string, attemptId: string): NoteResult {
  if (bytes.byteLength > MAX_NOTE_RESULT_BYTES) throw new Error("Saved result is too large.");
  let raw: unknown;
  try {
    raw = JSON.parse(Buffer.from(bytes).toString("utf8"));
  } catch {
    throw new Error("Saved result is not valid JSON.");
  }
  if (!raw || typeof raw !== "object" || Array.isArray(raw))
    throw new Error("Saved result is invalid.");
  const value = raw as Record<string, unknown>;
  if (
    value["version"] !== 1 ||
    value["id"] !== attemptId ||
    value["user_id"] !== userId ||
    typeof value["material_id"] !== "string" ||
    typeof value["material_title"] !== "string" ||
    value["material_title"].length > 200 ||
    typeof value["submitted_at"] !== "string" ||
    !Number.isFinite(Date.parse(value["submitted_at"])) ||
    typeof value["test_sha256"] !== "string" ||
    !Array.isArray(value["answers"]) ||
    value["answers"].length > 40
  )
    throw new Error("Saved result does not match its owner or schema.");
  const result = makeNoteResult({
    id: attemptId,
    userId,
    materialId: value["material_id"],
    materialTitle: value["material_title"],
    test: value["test"] as NoteFollowUpTest,
    answers: value["answers"] as (number | null)[],
    submittedAt: value["submitted_at"],
  });
  if (
    value["test_sha256"] !== result.test_sha256 ||
    value["score"] !== result.score ||
    value["total"] !== result.total ||
    value["attempted"] !== result.attempted
  )
    throw new Error("Saved result failed integrity verification.");
  return result;
}

export function resultSummary(result: NoteResult): NoteResultSummary {
  return {
    id: result.id,
    material_id: result.material_id,
    material_title: result.material_title,
    submitted_at: result.submitted_at,
    score: result.score,
    total: result.total,
    attempted: result.attempted,
    test_title: result.test.title,
  };
}
