import { z } from "zod";
import type { NotesSeries } from "./notes-series";

/** Video links belong to the batch, NOT to the public notes-series object. */
export const notesBatchSchema = z.object({
  seriesId: z.string().uuid(),
  courseId: z.string().uuid(),
  revision: z.number().int().min(0),
  videos: z.record(z.string().uuid(), z.string().max(4000)).default({}),
});
export type NotesBatch = z.infer<typeof notesBatchSchema>;

export type BatchLesson = {
  noteId: string;
  title: string;
  subject: string;
  subjectId: string;
  chapter: string;
  chapterId: string;
  topic: string | null;
  topicId: string | null;
  hasVideo: boolean;
};
export type BatchOutline = {
  courseId: string;
  seriesId: string;
  seriesName: string;
  lessons: BatchLesson[];
};

/** Public outline has names and availability only; neither media refs nor paid note bodies. */
export function batchOutline(
  series: NotesSeries,
  batch: NotesBatch,
  notes: readonly { id: string; title: string; is_published: boolean }[],
): BatchOutline {
  const available = new Map(
    notes.filter((note) => note.is_published).map((note) => [note.id, note]),
  );
  const lessons: BatchLesson[] = [];
  for (const subject of series.subjects) {
    for (const chapter of subject.chapters) {
      const addNotes = (ids: string[], topic: string | null, topicId: string | null) => {
        for (const noteId of ids) {
          const note = available.get(noteId);
          if (note)
            lessons.push({
              noteId,
              title: note.title,
              subject: subject.name,
              subjectId: subject.id,
              chapter: chapter.name,
              chapterId: chapter.id,
              topic,
              topicId,
              hasVideo: Boolean(batch.videos[noteId]),
            });
        }
      };
      addNotes(chapter.noteIds, null, null);
      for (const topic of chapter.topics) addNotes(topic.noteIds, topic.name, topic.id);
    }
  }
  return { courseId: batch.courseId, seriesId: series.id, seriesName: series.name, lessons };
}

/** Results lead to the next *chapter's* video, not another topic within this chapter. */
export function nextChapterVideo(lessons: readonly BatchLesson[], noteId: string) {
  const index = lessons.findIndex((lesson) => lesson.noteId === noteId);
  if (index < 0) return null;
  const current = lessons[index]!;
  return (
    lessons
      .slice(index + 1)
      .find((lesson) => lesson.chapterId !== current.chapterId && lesson.hasVideo) ?? null
  );
}
