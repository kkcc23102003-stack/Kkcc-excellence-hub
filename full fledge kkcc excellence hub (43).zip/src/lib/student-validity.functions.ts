import { createServerFn } from "@tanstack/react-start";
import { requireSupabaseAuth } from "@/integrations/supabase/auth-middleware";
import type {
  CourseEnrollmentRow,
  MaterialAccessGrantRow,
  MaterialPurchaseRow,
  SeriesAccessGrantRow,
  TestAccessGrantRow,
} from "@/integrations/supabase/db";
import { getAccessValidity, type StudentLearningAccessItem } from "./access-validity";
import { projectContent } from "./project-content.server";
import { getNotesSeriesById, NOTES_SERIES_GRANT_PREFIX } from "./notes-series-purchase.server";
import { readCustomSeriesCatalog } from "./learning.server";
import { getEffectiveLearningSeries } from "./test-series-catalog";

function accessItem(
  input: Omit<StudentLearningAccessItem, "validity_state" | "days_left"> & {
    status?: string | null;
  },
) {
  const validity = getAccessValidity({
    ...(input.status === undefined ? {} : { status: input.status }),
    expires_at: input.expires_at,
    revoked_at: input.revoked_at,
  });
  const { status: _status, ...item } = input;
  return { ...item, ...validity } satisfies StudentLearningAccessItem;
}

export const getMyLearningValidity = createServerFn({ method: "GET" })
  .middleware([requireSupabaseAuth])
  .handler(async ({ context }): Promise<StudentLearningAccessItem[]> => {
    const [enrollmentsResult, testsResult, seriesResult, materialsGrantResult, purchasesResult] =
      await Promise.all([
        context.supabase
          .from("course_enrollments")
          .select("*")
          .eq("user_id", context.userId)
          .order("created_at", { ascending: false }),
        context.supabase
          .from("test_access_grants")
          .select("*")
          .eq("user_id", context.userId)
          .order("created_at", { ascending: false }),
        context.supabase
          .from("series_access_grants")
          .select("*")
          .eq("user_id", context.userId)
          .order("created_at", { ascending: false }),
        context.supabase
          .from("material_access_grants")
          .select("*")
          .eq("user_id", context.userId)
          .order("created_at", { ascending: false }),
        context.supabase
          .from("material_purchases")
          .select("*")
          .eq("user_id", context.userId)
          .order("created_at", { ascending: false }),
      ]);
    for (const result of [
      enrollmentsResult,
      testsResult,
      seriesResult,
      materialsGrantResult,
      purchasesResult,
    ]) {
      if (result.error) throw new Error(result.error.message);
    }

    const enrollments = (enrollmentsResult.data ?? []) as CourseEnrollmentRow[];
    const testGrants = (testsResult.data ?? []) as TestAccessGrantRow[];
    const seriesGrants = (seriesResult.data ?? []) as SeriesAccessGrantRow[];
    const manualNoteGrants = (materialsGrantResult.data ?? []) as MaterialAccessGrantRow[];
    const materialPurchases = (purchasesResult.data ?? []) as MaterialPurchaseRow[];

    const courseIds = [...new Set(enrollments.map((grant) => grant.course_id))];
    const testIds = [...new Set(testGrants.map((grant) => grant.test_id))];
    const regularSeriesIds = [
      ...new Set(
        seriesGrants
          .filter((grant) => !grant.series_id.startsWith(NOTES_SERIES_GRANT_PREFIX))
          .map((grant) => grant.series_id),
      ),
    ];
    const noteSeriesIds = [
      ...new Set(
        seriesGrants
          .filter((grant) => grant.series_id.startsWith(NOTES_SERIES_GRANT_PREFIX))
          .map((grant) => grant.series_id.slice(NOTES_SERIES_GRANT_PREFIX.length)),
      ),
    ];
    const materialIds = [
      ...new Set([
        ...manualNoteGrants.map((grant) => grant.material_id),
        ...materialPurchases.map((purchase) => purchase.material_id),
      ]),
    ];

    const [coursesResult, testsContentResult, materialsResult, overridesResult, customSeries] =
      await Promise.all([
        courseIds.length
          ? projectContent
              .from("courses")
              .select("id,title,class_level,subject,faculty,slug")
              .in("id", courseIds)
          : Promise.resolve({ data: [], error: null }),
        testIds.length
          ? projectContent
              .from("tests")
              .select("id,title,subject,syllabus_chapter,course_id,series_name")
              .in("id", testIds)
          : Promise.resolve({ data: [], error: null }),
        materialIds.length
          ? projectContent
              .from("materials")
              .select("id,title,subject,chapter")
              .in("id", materialIds)
          : Promise.resolve({ data: [], error: null }),
        regularSeriesIds.length
          ? projectContent
              .from("test_series_overrides")
              .select("series_id,name")
              .in("series_id", regularSeriesIds)
          : Promise.resolve({ data: [], error: null }),
        readCustomSeriesCatalog(),
      ]);
    for (const result of [coursesResult, testsContentResult, materialsResult, overridesResult]) {
      if (result.error) throw new Error(result.error.message);
    }

    const courses = new Map((coursesResult.data ?? []).map((course) => [course.id, course]));
    const tests = new Map((testsContentResult.data ?? []).map((test) => [test.id, test]));
    const materials = new Map(
      (materialsResult.data ?? []).map((material) => [material.id, material]),
    );
    const seriesById = new Map(
      getEffectiveLearningSeries(customSeries).map((series) => [series.id, series]),
    );
    const seriesOverrides = new Map(
      (overridesResult.data ?? []).map((row) => [row.series_id, row.name]),
    );
    const notesSeries = await Promise.all(
      noteSeriesIds.map(async (id) => {
        try {
          return [id, await getNotesSeriesById(id)] as const;
        } catch {
          return [id, null] as const;
        }
      }),
    );
    const notesSeriesById = new Map(notesSeries);

    const items: StudentLearningAccessItem[] = enrollments.map((grant) => {
      const course = courses.get(grant.course_id);
      const title = course?.title || "Batch / course";
      const subtitle =
        [course?.class_level, course?.subject, course?.faculty].filter(Boolean).join(" · ") ||
        grant.course_id;
      return accessItem({
        id: `batch:${grant.id}`,
        kind: "batch",
        item_id: grant.course_id,
        ...(course?.slug ? { course_slug: course.slug } : {}),
        title,
        subtitle,
        source: grant.payment_method || grant.source,
        note: grant.admin_note,
        granted_at: grant.created_at,
        expires_at: grant.expires_at,
        revoked_at: grant.status === "revoked" ? grant.updated_at : null,
        status: grant.status,
      });
    });

    for (const grant of seriesGrants) {
      if (grant.series_id.startsWith(NOTES_SERIES_GRANT_PREFIX)) {
        const id = grant.series_id.slice(NOTES_SERIES_GRANT_PREFIX.length);
        const series = notesSeriesById.get(id);
        items.push(
          accessItem({
            id: `notes-series:${grant.id}`,
            kind: "notes-series",
            item_id: id,
            title: series?.name || "Notes Series",
            subtitle: "Complete Notes Series access",
            source: grant.method,
            note: grant.note,
            granted_at: grant.created_at,
            expires_at: grant.expires_at,
            revoked_at: grant.revoked_at,
          }),
        );
      } else {
        const series = seriesById.get(grant.series_id);
        items.push(
          accessItem({
            id: `test-series:${grant.id}`,
            kind: "test-series",
            item_id: grant.series_id,
            title: seriesOverrides.get(grant.series_id) || series?.name || "Test Series",
            subtitle: "Test Series access",
            source: grant.method,
            note: grant.note,
            granted_at: grant.created_at,
            expires_at: grant.expires_at,
            revoked_at: grant.revoked_at,
          }),
        );
      }
    }

    for (const grant of testGrants) {
      const test = tests.get(grant.test_id);
      items.push(
        accessItem({
          id: `test:${grant.id}`,
          kind: "test",
          item_id: grant.test_id,
          title: test?.title || "Individual test",
          subtitle:
            [test?.subject, test?.syllabus_chapter].filter(Boolean).join(" · ") || grant.test_id,
          source: grant.method,
          note: grant.note,
          granted_at: grant.created_at,
          expires_at: grant.expires_at,
          revoked_at: grant.revoked_at,
        }),
      );
    }

    // If a learner owns a note outright, show that lifetime entitlement rather
    // than a duplicate overlapping manual row for the same material.
    const activePurchases = new Set(
      materialPurchases
        .filter((purchase) => purchase.status === "active")
        .map((purchase) => purchase.material_id),
    );
    for (const purchase of materialPurchases) {
      const material = materials.get(purchase.material_id);
      items.push(
        accessItem({
          id: `note-purchase:${purchase.id}`,
          kind: "note",
          item_id: purchase.material_id,
          title: material?.title || "Study note",
          subtitle:
            [material?.subject, material?.chapter].filter(Boolean).join(" · ") ||
            purchase.material_id,
          source: "Purchase",
          note: "",
          granted_at: purchase.created_at,
          expires_at: null,
          revoked_at: purchase.status === "active" ? null : purchase.updated_at,
          status: purchase.status === "active" ? "active" : "revoked",
        }),
      );
    }
    for (const grant of manualNoteGrants) {
      if (activePurchases.has(grant.material_id) && !grant.revoked_at) continue;
      const material = materials.get(grant.material_id);
      items.push(
        accessItem({
          id: `note-grant:${grant.id}`,
          kind: "note",
          item_id: grant.material_id,
          title: material?.title || "Study note",
          subtitle:
            [material?.subject, material?.chapter].filter(Boolean).join(" · ") || grant.material_id,
          source: grant.method,
          note: grant.note,
          granted_at: grant.created_at,
          expires_at: grant.expires_at,
          revoked_at: grant.revoked_at,
        }),
      );
    }

    return items.sort((a, b) => Date.parse(b.granted_at) - Date.parse(a.granted_at));
  });
