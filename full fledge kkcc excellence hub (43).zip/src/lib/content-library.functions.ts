import { randomUUID } from "node:crypto";
import { createServerFn } from "@tanstack/react-start";
import { z } from "zod";
import type { CourseRow, MaterialRow, TestQuestionRow, TestRow } from "@/integrations/supabase/db";
import { requireSupabaseAuth } from "@/integrations/supabase/auth-middleware";
import { assertAdmin, unwrap } from "@/lib/learning.server";
import {
  getChapterQuestionCount,
  getEffectiveLearningSeries,
  makeCustomChapterKey,
  seriesPlan,
  type CustomChapterConfig,
  type PaidTestSeries,
} from "@/lib/test-series-catalog";
import { canonicalSeriesId, seriesAliases } from "@/lib/learning-access";
import { snapshotSeriesChapter, type SnapshotQuestion } from "@/lib/content-library.snapshot";
import { projectContent } from "@/lib/project-content.server";
import { materialAccessMode } from "@/lib/material-access-mode";
import { readNoteBody, storeNoteBody } from "@/lib/note-body.server";
import { notesBatchSchema, type NotesBatch } from "@/lib/notes-batch";
import { validateVideoUrl } from "@/lib/video";
import {
  notesSeriesSchema,
  seriesNoteIds,
  type NotesSeries,
  type SeriesMaterial,
} from "@/lib/notes-series";
import {
  readNotesCatalogSetting,
  writeNotesCatalogObject,
} from "@/lib/notes-catalog-storage.server";
import { readCustomSeriesCatalog } from "@/lib/learning.server";
import { writeStoredCustomSeriesCatalog } from "@/lib/custom-series-catalog-storage.server";
import {
  addNotesToSeries,
  supportsSharedLink,
  type LibrarySourceKind,
  type LibraryTargetKind,
  type ReuseMode,
} from "@/lib/content-library";
import { copyBatchVideoSettings } from "@/lib/content-library.batch";

const NOTES_SERIES_PREFIX = "notes_series_v1:";
const NOTES_BATCH_PREFIX = "notes_batch_v1:";
const NOTES_BATCH_COURSE_INDEX_PREFIX = "notes_batch_course_v1:";
const uuidInput = z.string().uuid();

type NotesSeriesRecord = { series: NotesSeries; storedValue: string };
type CourseSummary = Pick<CourseRow, "id" | "title" | "status">;
async function notesSeriesById(id: string): Promise<NotesSeriesRecord | null> {
  const key = NOTES_SERIES_PREFIX + id;
  const row = unwrap(
    await projectContent.from("site_settings").select("value").eq("key", key).maybeSingle(),
  );
  if (!row) return null;
  const stored = await readNotesCatalogSetting<NotesSeries>({
    table: "site_settings",
    key,
    kind: "series",
    id,
    value: row.value,
  });
  return { series: notesSeriesSchema.parse(stored.data), storedValue: stored.storedValue };
}

async function notesBatchRecordBySeries(id: string) {
  const key = NOTES_BATCH_PREFIX + id;
  const row = unwrap(
    await projectContent.from("private_settings").select("value").eq("key", key).maybeSingle(),
  );
  if (!row) return null;
  const stored = await readNotesCatalogSetting<NotesBatch>({
    table: "private_settings",
    key,
    kind: "batch",
    id,
    value: row.value,
  });
  return { batch: notesBatchSchema.parse(stored.data), storedValue: stored.storedValue };
}

async function notesBatchBySeries(id: string): Promise<NotesBatch | null> {
  return (await notesBatchRecordBySeries(id))?.batch ?? null;
}

async function saveNotesSeries(current: NotesSeriesRecord, nextSeries: NotesSeries) {
  const key = NOTES_SERIES_PREFIX + current.series.id;
  const next = notesSeriesSchema.parse({ ...nextSeries, revision: current.series.revision + 1 });
  const value = await writeNotesCatalogObject("series", next.id, next);
  const saved = await projectContent
    .from("site_settings")
    .update({ value, updated_at: new Date().toISOString() })
    .eq("key", key)
    .eq("value", current.storedValue)
    .select("key")
    .limit(1);
  if (saved.error) throw new Error(saved.error.message);
  if (!saved.data?.length)
    throw new Error("This Notes Series changed while adding content. Reload and retry.");
  return next;
}

function validateNoteFitsSeries(series: NotesSeries, material: SeriesMaterial) {
  const free = materialAccessMode(material) === "free";
  if (free !== (series.kind === "sample"))
    throw new Error(
      "This note’s access type does not match the destination Series. Free-note series accept free notes; paid series accept paid/course notes.",
    );
}

async function cloneMaterial(
  source: MaterialRow,
  targetCourseId: string | null,
): Promise<MaterialRow> {
  const id = randomUUID();
  const text = await readNoteBody(source);
  const body = await storeNoteBody(id, text);
  const mode = materialAccessMode(source);
  const toCourse = targetCourseId !== null;
  const payload = {
    ...source,
    id,
    course_id: targetCourseId,
    lecture_id: null,
    description: "",
    ...body,
    // Copies are reviewable drafts. A Course copy uses the destination Course’s access;
    // a Series copy remains individually paid/free according to its destination type.
    access_type: toCourse ? "course" : mode === "free" ? "free" : "paid",
    // A copy transfers content only, never a note-level price/payment product.
    price: 0,
    coin_price: 0,
    is_free_preview: false,
    is_published: false,
    sort_order: 0,
    created_at: new Date().toISOString(),
    updated_at: new Date().toISOString(),
  };
  const inserted = await projectContent
    .from("materials")
    .insert(payload as never)
    .select("*")
    .single();
  if (inserted.error)
    throw new Error(
      `Could not create a draft copy of “${source.title}”: ${inserted.error.message}`,
    );
  return inserted.data as MaterialRow;
}

async function cloneMaterialsIntoCourse(materials: MaterialRow[], courseId: string) {
  const copies: MaterialRow[] = [];
  for (let offset = 0; offset < materials.length; offset += 8) {
    const batch = await Promise.allSettled(
      materials.slice(offset, offset + 8).map((material) => cloneMaterial(material, courseId)),
    );
    copies.push(
      ...batch.flatMap((result) => (result.status === "fulfilled" ? [result.value] : [])),
    );
    const failure = batch.find(
      (result): result is PromiseRejectedResult => result.status === "rejected",
    );
    if (failure)
      throw new Error(
        `Copy stopped. ${copies.length} unpublished Note drafts were created in the destination Course; they stay unpublished for review. ${failure.reason instanceof Error ? failure.reason.message : String(failure.reason)}`,
      );
  }
  return copies;
}

async function removeUnpublishedTestDrafts(ids: string[]) {
  const cleanup = await projectContent.from("tests").delete().in("id", ids);
  return !cleanup.error;
}

async function copyTestToCourse(source: TestRow, courseId: string): Promise<TestRow> {
  const sourceQuestions = unwrap(
    await projectContent
      .from("test_questions")
      .select("*")
      .eq("test_id", source.id)
      .order("sort_order"),
  ) as TestQuestionRow[];
  let questions: SnapshotQuestion[];
  if (source.question_source === "manual") {
    questions = sourceQuestions.map((question) => ({
      question_text: question.question_text,
      subject: question.subject || source.syllabus_subject || source.subject,
      options: [...question.options],
      correct_index: question.correct_index,
      marks: question.marks,
      negative_marks: question.negative_marks,
      explanation: question.explanation,
    }));
  } else {
    const subject = source.syllabus_subject || source.generation_subject || source.subject;
    const chapter =
      source.syllabus_chapter ||
      (source.generation_topic !== "Mixed" ? source.generation_topic : "");
    if (!subject.trim() || !chapter.trim())
      throw new Error(
        "This generated Test needs a specific subject/chapter. Copy its Test Series instead.",
      );
    if (sourceQuestions.length > 1000)
      throw new Error("This Test has too many supplemental questions to snapshot safely.");
    const catalog = await readCustomSeriesCatalog();
    const overrides = unwrap(
      await projectContent.from("test_series_overrides").select("series_id,name"),
    );
    const seriesId =
      canonicalSeriesId(source.series_name, seriesAliases(overrides, catalog)) ?? undefined;
    const questionCount = Math.min(
      200,
      Math.max(
        1,
        source.generation_count || getChapterQuestionCount(seriesId, subject, chapter, catalog),
      ),
    );
    questions = snapshotSeriesChapter({
      catalog,
      ...(seriesId ? { seriesId } : {}),
      exam: source.generation_exam || source.exam_track || "All Exams",
      subject,
      chapter,
      count: questionCount,
      difficulty: source.generation_difficulty,
      marks: source.generation_marks ?? 1,
      negativeMarks: source.generation_negative_marks ?? 0,
      manualQuestions: sourceQuestions,
    });
  }
  if (!questions.length)
    throw new Error("No readable questions are available; no Test copy was created.");
  if (questions.length > 1000)
    throw new Error("This Test contains more than 1,000 questions and cannot be copied safely.");

  const id = randomUUID();
  const currentTests = unwrap(
    await projectContent.from("tests").select("id,sort_order").eq("course_id", courseId),
  );
  const nextSort = currentTests.reduce((max, row) => Math.max(max, row.sort_order), -1) + 1;
  const now = new Date().toISOString();
  const { id: _id, created_at: _created, updated_at: _updated, ...fields } = source;
  const inserted = await projectContent
    .from("tests")
    .insert({
      ...fields,
      id,
      course_id: courseId,
      lecture_id: null,
      // Snapshot questions into a new Course product. No source series grant or price follows it.
      series_name: "",
      is_paid: true,
      price_inr: 0,
      price_coins: 0,
      question_source: "manual",
      generation_count: 0,
      questions_count: questions.length,
      total_marks: questions.reduce((sum, question) => sum + question.marks, 0),
      is_published: false,
      sort_order: nextSort,
      created_at: now,
      updated_at: now,
    } as never)
    .select("*")
    .single();
  if (inserted.error)
    throw new Error(
      `Could not create a draft copy of “${source.title}”: ${inserted.error.message}`,
    );

  const questionRows = questions.map((question, index) => ({
    ...question,
    id: randomUUID(),
    test_id: id,
    sort_order: index,
    created_at: now,
    updated_at: now,
  }));
  const copied = await projectContent.from("test_questions").insert(questionRows as never);
  if (copied.error) {
    const removed = await removeUnpublishedTestDrafts([id]);
    throw new Error(
      `Test-question copy failed; ${removed ? "the unpublished draft was removed" : "the unpublished draft could not be removed and remains unassigned"}. ${copied.error.message}`,
    );
  }
  return inserted.data as TestRow;
}

async function materialsByIds(ids: string[]): Promise<MaterialRow[]> {
  const uniqueIds = [...new Set(ids)];
  if (!uniqueIds.length) return [];
  const rows: MaterialRow[] = [];
  for (let offset = 0; offset < uniqueIds.length; offset += 250) {
    rows.push(
      ...(unwrap(
        await projectContent
          .from("materials")
          .select("*")
          .in("id", uniqueIds.slice(offset, offset + 250)),
      ) as MaterialRow[]),
    );
  }
  const found = new Set(rows.map((row) => row.id));
  if (found.size !== uniqueIds.length)
    throw new Error("Some source Notes are missing. Nothing was linked.");
  return rows;
}

async function seriesMaterials(series: NotesSeries) {
  return materialsByIds(seriesNoteIds(series));
}

async function notesForSource(kind: LibrarySourceKind, id: string): Promise<MaterialRow[]> {
  if (kind === "material") {
    const row = unwrap(
      await projectContent
        .from("materials")
        .select("*")
        .eq("id", uuidInput.parse(id))
        .maybeSingle(),
    );
    if (!row) throw new Error("Source Note was not found.");
    return [row as MaterialRow];
  }
  if (kind === "course") {
    const course = unwrap(
      await projectContent.from("courses").select("id").eq("id", uuidInput.parse(id)).maybeSingle(),
    );
    if (!course) throw new Error("Source Course was not found.");
    return unwrap(
      await projectContent.from("materials").select("*").eq("course_id", id).order("sort_order"),
    ) as MaterialRow[];
  }
  if (kind === "notes_series" || kind === "batch") {
    const seriesId = uuidInput.parse(id);
    if (kind === "batch" && !(await notesBatchBySeries(seriesId)))
      throw new Error("Source Batch was not found.");
    const record = await notesSeriesById(seriesId);
    if (!record) throw new Error("Source Notes Series was not found.");
    return seriesMaterials(record.series);
  }
  throw new Error("This source type does not contain reusable Notes.");
}

async function targetSeriesId(kind: LibraryTargetKind, id: string): Promise<string> {
  if (kind === "notes_series") {
    const seriesId = uuidInput.parse(id);
    if (!(await notesSeriesById(seriesId)))
      throw new Error("Destination Notes Series was not found.");
    return seriesId;
  }
  if (kind === "batch") {
    const seriesId = uuidInput.parse(id);
    if (!(await notesBatchBySeries(seriesId))) throw new Error("Destination Batch was not found.");
    if (!(await notesSeriesById(seriesId))) throw new Error("The Batch’s Notes Series is missing.");
    return seriesId;
  }
  throw new Error("Destination is not a Notes Series or Batch.");
}

async function copyBatchVideos(input: {
  sourceSeriesId: string;
  targetSeriesId: string;
  sourceToTargetIds: { sourceId: string; targetId: string }[];
}) {
  try {
    const [sourceRecord, targetRecord] = await Promise.all([
      notesBatchRecordBySeries(input.sourceSeriesId),
      notesBatchRecordBySeries(input.targetSeriesId),
    ]);
    if (!sourceRecord || !targetRecord)
      return {
        addedCount: 0,
        warning:
          "Notes are present in the destination, but Batch settings were unavailable; no videos were copied.",
      };

    return await copyBatchVideoSettings({
      sourceVideos: sourceRecord.batch.videos,
      destinationVideos: targetRecord.batch.videos,
      mappings: input.sourceToTargetIds,
      validateUrl: validateVideoUrl,
      save: async (videos) => {
        const next = notesBatchSchema.parse({
          ...targetRecord.batch,
          revision: targetRecord.batch.revision + 1,
          videos,
        });
        const pointer = await writeNotesCatalogObject("batch", input.targetSeriesId, next);
        const saved = await projectContent
          .from("private_settings")
          .update({ value: pointer, updated_at: new Date().toISOString() })
          .eq("key", NOTES_BATCH_PREFIX + input.targetSeriesId)
          .eq("value", targetRecord.storedValue)
          .select("key")
          .limit(1);
        if (saved.error) throw new Error(saved.error.message);
        return Boolean(saved.data?.length);
      },
    });
  } catch (error) {
    return {
      addedCount: 0,
      warning: `Notes are present in the destination, but Batch videos could not be checked or saved: ${error instanceof Error ? error.message : String(error)}`,
    };
  }
}

async function addMaterialsToSeries(input: {
  materials: MaterialRow[];
  seriesId: string;
  mode: ReuseMode;
}) {
  const current = await notesSeriesById(input.seriesId);
  if (!current) throw new Error("Destination Notes Series was not found.");
  for (const material of input.materials) validateNoteFitsSeries(current.series, material);
  const existing = new Set(seriesNoteIds(current.series));
  const fresh = input.materials.filter((material) => !existing.has(material.id));
  if (!fresh.length)
    return {
      addedCount: 0,
      mode: input.mode,
      draftCount: 0,
      sourceToTargetIds: [] as { sourceId: string; targetId: string }[],
    };

  // A true link preserves the original Material ID; edits to its body/title are shared.
  // Copy mode creates unpublished independent Material rows before changing the outline.
  const targetMaterials: MaterialRow[] = [];
  if (input.mode === "link") targetMaterials.push(...fresh);
  else {
    for (let offset = 0; offset < fresh.length; offset += 8) {
      const batch = await Promise.allSettled(
        fresh.slice(offset, offset + 8).map((material) => cloneMaterial(material, null)),
      );
      targetMaterials.push(
        ...batch.flatMap((result) => (result.status === "fulfilled" ? [result.value] : [])),
      );
      const failure = batch.find(
        (result): result is PromiseRejectedResult => result.status === "rejected",
      );
      if (failure) {
        throw new Error(
          `Copy stopped before updating the Series. ${targetMaterials.length} independent Note drafts were created and remain unpublished; review them before retrying. ${failure.reason instanceof Error ? failure.reason.message : String(failure.reason)}`,
        );
      }
    }
  }
  const added = addNotesToSeries(current.series, targetMaterials);
  try {
    await saveNotesSeries(current, added.series);
  } catch (error) {
    if (input.mode === "copy")
      throw new Error(
        `Notes Series was not updated. ${targetMaterials.length} independent Note drafts were created and remain unpublished. ${error instanceof Error ? error.message : String(error)}`,
      );
    throw error;
  }
  return {
    addedCount: added.addedIds.length,
    mode: input.mode,
    draftCount: input.mode === "copy" ? targetMaterials.length : 0,
    sourceToTargetIds: fresh.map((source, index) => ({
      sourceId: source.id,
      targetId: targetMaterials[index]!.id,
    })),
  };
}

async function targetCourseId(kind: LibraryTargetKind, id: string): Promise<string> {
  const courseId =
    kind === "batch"
      ? (await notesBatchBySeries(uuidInput.parse(id)))?.courseId
      : kind === "course"
        ? uuidInput.parse(id)
        : null;
  if (!courseId) throw new Error("Destination Course/Batch was not found.");
  const course = unwrap(
    await projectContent.from("courses").select("id").eq("id", courseId).maybeSingle(),
  );
  if (!course) throw new Error("Destination Course no longer exists.");
  return courseId;
}

async function listNotesSeriesRows(): Promise<NotesSeries[]> {
  const rows = unwrap(
    await projectContent
      .from("site_settings")
      .select("key,value")
      .ilike("key", `${NOTES_SERIES_PREFIX}%`),
  );
  return Promise.all(
    rows
      .filter((row) => row.key.startsWith(NOTES_SERIES_PREFIX))
      .map(async (row) => {
        const id = row.key.slice(NOTES_SERIES_PREFIX.length);
        const stored = await readNotesCatalogSetting<NotesSeries>({
          table: "site_settings",
          key: row.key,
          kind: "series",
          id,
          value: row.value,
        });
        return notesSeriesSchema.parse(stored.data);
      }),
  );
}

async function listBatchRows(
  courseMap: Map<string, CourseSummary>,
  seriesMap: Map<string, NotesSeries>,
) {
  const rows = unwrap(
    await projectContent
      .from("private_settings")
      .select("key,value")
      .ilike("key", `${NOTES_BATCH_PREFIX}%`),
  );
  return Promise.all(
    rows
      .filter((row) => row.key.startsWith(NOTES_BATCH_PREFIX))
      .map(async (row) => {
        const seriesId = row.key.slice(NOTES_BATCH_PREFIX.length);
        const stored = await readNotesCatalogSetting<NotesBatch>({
          table: "private_settings",
          key: row.key,
          kind: "batch",
          id: seriesId,
          value: row.value,
        });
        const batch = notesBatchSchema.parse(stored.data);
        const course = courseMap.get(batch.courseId);
        const series = seriesMap.get(seriesId);
        if (!course || !series) return null;
        return {
          id: seriesId,
          seriesId,
          courseId: course.id,
          name: `${course.title} · Batch`,
          courseTitle: course.title,
          seriesName: series.name,
          noteCount: seriesNoteIds(series).length,
          draft: course.status !== "published",
          videoCount: Object.keys(batch.videos).length,
        };
      }),
  ).then((items) => items.filter((item): item is NonNullable<typeof item> => Boolean(item)));
}

export const listAdminContentLibrary = createServerFn({ method: "GET" })
  .middleware([requireSupabaseAuth])
  .handler(async ({ context }) => {
    await assertAdmin(context);
    const [coursesResult, materialsResult, testsResult] = await Promise.all([
      projectContent
        .from("courses")
        .select("id,title,slug,status,subject,class_level,sort_order")
        .order("sort_order"),
      projectContent
        .from("materials")
        .select(
          "id,title,subject,chapter,course_id,is_published,access_type,material_type,sort_order",
        )
        .order("sort_order"),
      projectContent
        .from("tests")
        .select(
          "id,title,subject,course_id,series_name,is_published,question_source,syllabus_subject,syllabus_chapter,sort_order",
        )
        .order("sort_order"),
    ]);
    const courses = unwrap(coursesResult) as Pick<
      CourseRow,
      "id" | "title" | "slug" | "status" | "subject" | "class_level" | "sort_order"
    >[];
    const materials = unwrap(materialsResult) as Pick<
      MaterialRow,
      | "id"
      | "title"
      | "subject"
      | "chapter"
      | "course_id"
      | "is_published"
      | "access_type"
      | "material_type"
      | "sort_order"
    >[];
    const tests = unwrap(testsResult) as Pick<
      TestRow,
      | "id"
      | "title"
      | "subject"
      | "course_id"
      | "series_name"
      | "is_published"
      | "question_source"
      | "syllabus_subject"
      | "syllabus_chapter"
      | "sort_order"
    >[];
    const courseMap = new Map<string, CourseSummary>(courses.map((course) => [course.id, course]));
    const warnings: string[] = [];
    let notesSeries: {
      id: string;
      name: string;
      kind: string;
      published: boolean;
      noteCount: number;
    }[] = [];
    let batches: Awaited<ReturnType<typeof listBatchRows>> = [];
    let testSeries: Pick<
      PaidTestSeries,
      "id" | "name" | "examTrack" | "group" | "priceInr" | "priceCoins"
    >[] = [];

    const optional = await Promise.allSettled([listNotesSeriesRows(), readCustomSeriesCatalog()]);
    const seriesResult = optional[0];
    const catalogueResult = optional[1];
    const seriesData = seriesResult.status === "fulfilled" ? seriesResult.value : [];
    if (seriesResult.status === "rejected")
      warnings.push(`Notes Series/Batch catalogue unavailable: ${String(seriesResult.reason)}`);
    const seriesMap = new Map(seriesData.map((series) => [series.id, series]));
    notesSeries = seriesData.map((series) => ({
      id: series.id,
      name: series.name,
      kind: series.kind,
      published: series.published,
      noteCount: seriesNoteIds(series).length,
    }));
    const batchesResult = await Promise.allSettled([listBatchRows(courseMap, seriesMap)]);
    if (batchesResult[0]?.status === "fulfilled") batches = batchesResult[0].value;
    else warnings.push(`Batch catalogue unavailable: ${String(batchesResult[0]?.reason)}`);

    if (catalogueResult.status === "fulfilled") {
      testSeries = getEffectiveLearningSeries(catalogueResult.value).map(
        ({ id, name, examTrack, group, priceInr, priceCoins }) => ({
          id,
          name,
          examTrack,
          group,
          priceInr,
          priceCoins,
        }),
      );
    } else {
      warnings.push(`Test Series catalogue unavailable: ${String(catalogueResult.reason)}`);
    }
    return { courses, materials, tests, notesSeries, batches, testSeries, warnings };
  });

const reuseSchema = z.object({
  source_kind: z.enum(["material", "test", "course", "notes_series", "test_series", "batch"]),
  source_id: z.string().trim().min(1).max(200),
  target_kind: z.enum(["course", "notes_series", "test_series", "batch"]),
  target_id: z.string().trim().min(1).max(200),
  mode: z.enum(["link", "copy"]),
  subject: z.string().trim().max(160).optional(),
  chapter: z.string().trim().max(240).optional(),
  test_series_mode: z.enum(["custom_only", "custom_plus_bank"]).optional(),
});

async function importTestQuestionsToSeries(input: {
  test: TestRow;
  seriesId: string;
  subject: string;
  chapter: string;
  mode: "custom_only" | "custom_plus_bank";
}) {
  if (input.test.question_source !== "manual")
    throw new Error(
      "Only a manual test with real saved questions can be copied into a Test Series.",
    );
  const questions = unwrap(
    await projectContent
      .from("test_questions")
      .select("*")
      .eq("test_id", input.test.id)
      .order("sort_order"),
  ) as TestQuestionRow[];
  if (!questions.length) throw new Error("This manual test has no readable questions to copy.");
  const catalog = await readCustomSeriesCatalog();
  const available = getEffectiveLearningSeries(catalog).some(
    (series) => series.id === input.seriesId,
  );
  if (!available) throw new Error("Destination Test Series is not in the current catalogue.");
  const key = makeCustomChapterKey(input.seriesId, input.subject, input.chapter);
  const map = { ...(catalog.customQuestionsByChapter ?? {}) };
  const existing: CustomChapterConfig = map[key] ?? { mode: input.mode, questions: [] };
  const known = new Set(existing.questions.map((question) => question.id));
  const imported = questions
    .filter((question) => !known.has(`library-${input.test.id}-${question.id}`))
    .map((question) => ({
      id: `library-${input.test.id}-${question.id}`,
      question_text: question.question_text,
      options: question.options,
      correct_index: question.correct_index,
      explanation: question.explanation,
      difficulty: "Moderate" as const,
      marks: question.marks,
      negative_marks: question.negative_marks,
      source: "manual" as const,
    }));
  if (!imported.length) return { addedCount: 0, mode: "copy" as const, draftCount: 0 };
  map[key] = { ...existing, mode: input.mode, questions: [...existing.questions, ...imported] };
  await writeStoredCustomSeriesCatalog({ ...catalog, customQuestionsByChapter: map });
  return { addedCount: imported.length, mode: "copy" as const, draftCount: 0 };
}

async function copyTestSeriesSettings(sourceId: string, targetId: string) {
  if (sourceId === targetId) throw new Error("Choose a different destination Test Series.");
  const catalog = await readCustomSeriesCatalog();
  const allSeries = getEffectiveLearningSeries(catalog);
  const source = allSeries.find((series) => series.id === sourceId);
  const target = allSeries.find((series) => series.id === targetId);
  if (!source || !target) throw new Error("Source or destination Test Series is unavailable.");

  // Append syllabus coverage to the destination. Never replace its existing outline.
  const syllabusBySeriesId = { ...(catalog.syllabusBySeriesId ?? {}) };
  const targetPlan = structuredClone(syllabusBySeriesId[targetId] ?? seriesPlan(target));
  const sourcePlan = seriesPlan(source);
  let addedChapters = 0;
  for (const sourceSubject of sourcePlan) {
    let targetSubject = targetPlan.find(
      (item) =>
        item.subject.trim().toLocaleLowerCase() ===
        sourceSubject.subject.trim().toLocaleLowerCase(),
    );
    if (!targetSubject) {
      targetSubject = { subject: sourceSubject.subject, chapters: [] };
      targetPlan.push(targetSubject);
    }
    const knownChapters = new Set(
      targetSubject.chapters.map((chapter) => chapter.trim().toLocaleLowerCase()),
    );
    for (const chapter of sourceSubject.chapters) {
      const key = chapter.trim().toLocaleLowerCase();
      if (!knownChapters.has(key)) {
        targetSubject.chapters.push(chapter);
        knownChapters.add(key);
        addedChapters += 1;
      }
    }
  }
  syllabusBySeriesId[targetId] = targetPlan;

  const customQuestionsByChapter = { ...(catalog.customQuestionsByChapter ?? {}) };
  const sourcePrefix = `${sourceId.trim().toLowerCase()}::`;
  const targetPrefix = `${targetId.trim().toLowerCase()}::`;
  let addedQuestions = 0;
  for (const [key, config] of Object.entries(catalog.customQuestionsByChapter ?? {})) {
    if (!key.startsWith(sourcePrefix)) continue;
    const targetKey = `${targetPrefix}${key.slice(sourcePrefix.length)}`;
    const existing = customQuestionsByChapter[targetKey];
    const known = new Set((existing?.questions ?? []).map((question) => question.id));
    const questions = [...(existing?.questions ?? [])];
    for (const question of config.questions) {
      if (!known.has(question.id)) {
        questions.push(structuredClone(question));
        known.add(question.id);
        addedQuestions += 1;
      }
    }
    customQuestionsByChapter[targetKey] = {
      ...(existing ?? config),
      mode: existing?.mode ?? config.mode,
      ...(existing?.questionCount !== undefined
        ? { questionCount: existing.questionCount }
        : config.questionCount !== undefined
          ? { questionCount: config.questionCount }
          : {}),
      questions,
    };
  }
  const questionsPerSeriesId = { ...(catalog.questionsPerSeriesId ?? {}) };
  if (questionsPerSeriesId[targetId] === undefined && questionsPerSeriesId[sourceId] !== undefined)
    questionsPerSeriesId[targetId] = questionsPerSeriesId[sourceId]!;

  await writeStoredCustomSeriesCatalog({
    ...catalog,
    syllabusBySeriesId,
    questionsPerSeriesId,
    customQuestionsByChapter,
  });
  // Price, access grants, history and product identity stay with each series.
  return { addedCount: addedChapters + addedQuestions, mode: "copy" as const, draftCount: 0 };
}

async function copyTestSeriesToCourse(sourceId: string, courseId: string) {
  const catalog = await readCustomSeriesCatalog();
  const series = getEffectiveLearningSeries(catalog).find((item) => item.id === sourceId);
  if (!series) throw new Error("Source Test Series is unavailable.");
  const course = unwrap(
    await projectContent.from("courses").select("id").eq("id", courseId).maybeSingle(),
  );
  if (!course) throw new Error("Destination Course was not found.");
  const plan = seriesPlan(series);
  const candidates = plan.flatMap((subject) =>
    subject.chapters.map((chapter) => ({ subject: subject.subject, chapter })),
  );
  if (!candidates.length || candidates.length > 500)
    throw new Error(
      "The Test Series has no usable chapters or exceeds the safe 500-test import limit.",
    );
  const current = unwrap(
    await projectContent.from("tests").select("id,sort_order").eq("course_id", courseId),
  );
  const startSort = current.reduce((max, row) => Math.max(max, row.sort_order), -1) + 1;
  const now = new Date().toISOString();
  const questionsPerTest = candidates.map(({ subject, chapter }) =>
    snapshotSeriesChapter({
      catalog,
      seriesId: sourceId,
      exam: series.examTrack,
      subject,
      chapter,
      count: getChapterQuestionCount(sourceId, subject, chapter, catalog),
    }),
  );
  const totalQuestions = questionsPerTest.reduce((sum, questions) => sum + questions.length, 0);
  if (totalQuestions > 25000)
    throw new Error(
      "This Test Series exceeds the safe 25,000-question copy limit. Copy a smaller Series first.",
    );
  const emptyIndex = questionsPerTest.findIndex((questions) => !questions.length);
  if (emptyIndex >= 0) {
    const missing = candidates[emptyIndex]!;
    throw new Error(
      `No copyable questions are configured for ${missing.subject} · ${missing.chapter}; no Test drafts were created.`,
    );
  }
  const testRows = candidates.map(({ subject, chapter }, index) => {
    const questions = questionsPerTest[index]!;
    const id = randomUUID();
    return {
      id,
      course_id: courseId,
      lecture_id: null,
      title: `${series.name} · ${subject} · ${chapter}`.slice(0, 200),
      instructions:
        "Draft copied from an existing Test Series. Review Course access and set a destination-specific price before publishing.",
      subject,
      duration_minutes: 60,
      question_timer_seconds: 0,
      timer_mode: "test" as const,
      questions_count: questions.length,
      total_marks: questions.reduce((sum, question) => sum + question.marks, 0),
      is_published: false,
      sort_order: startSort + index,
      exam_track: series.examTrack,
      level: "Mixed" as const,
      // Snapshot copies have no source Series ID, so its grants cannot unlock this Course copy.
      series_name: "",
      is_paid: true,
      price_inr: 0,
      price_coins: 0,
      question_source: "manual" as const,
      generation_exam: series.examTrack,
      generation_subject: subject,
      generation_topic: chapter,
      generation_difficulty: "Mixed" as const,
      generation_count: 0,
      syllabus_subject: subject,
      syllabus_chapter: chapter,
      syllabus_topic: "",
      created_at: now,
      updated_at: now,
    };
  });
  const inserted = await projectContent.from("tests").insert(testRows as never);
  if (inserted.error)
    throw new Error(`No Test Series drafts were saved: ${inserted.error.message}`);
  const questionRows = questionsPerTest.flatMap((questions, testIndex) => {
    const testId = testRows[testIndex]!.id;
    return questions.map((question, questionIndex) => ({
      ...question,
      id: randomUUID(),
      test_id: testId,
      sort_order: questionIndex,
      created_at: now,
      updated_at: now,
    }));
  });
  const copied = await projectContent.from("test_questions").insert(questionRows as never);
  if (copied.error) {
    const removed = await removeUnpublishedTestDrafts(testRows.map((row) => row.id));
    throw new Error(
      `Test-question copy failed; ${removed ? "unpublished Test drafts were removed" : "unpublished Test drafts could not be removed and remain without their copied questions"}. ${copied.error.message}`,
    );
  }
  return { addedCount: testRows.length, mode: "copy" as const, draftCount: testRows.length };
}

export const reuseAdminLibraryContent = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .validator((input: unknown) => reuseSchema.parse(input))
  .handler(async ({ context, data }) => {
    await assertAdmin(context);
    const sourceKind = data.source_kind as LibrarySourceKind;
    const targetKind = data.target_kind as LibraryTargetKind;
    const mode = data.mode as ReuseMode;
    if (mode === "link" && !supportsSharedLink(sourceKind, targetKind))
      throw new Error(
        "A live shared link is only available for Notes included in a Notes Series/Batch. Use Copy for other destinations.",
      );

    if (targetKind === "test_series") {
      if (sourceKind === "test") {
        const test = unwrap(
          await projectContent
            .from("tests")
            .select("*")
            .eq("id", uuidInput.parse(data.source_id))
            .maybeSingle(),
        );
        if (!test) throw new Error("Source Test was not found.");
        const subject = data.subject || test.syllabus_subject || test.subject;
        const chapter = data.chapter || test.syllabus_chapter || test.generation_topic;
        if (!subject?.trim() || !chapter?.trim() || chapter === "Mixed")
          throw new Error(
            "Set a real subject and chapter before copying this Test into a Test Series.",
          );
        return importTestQuestionsToSeries({
          test: test as TestRow,
          seriesId: data.target_id,
          subject: subject.trim(),
          chapter: chapter.trim(),
          mode: data.test_series_mode ?? "custom_plus_bank",
        });
      }
      if (sourceKind === "test_series")
        return copyTestSeriesSettings(data.source_id, data.target_id);
      throw new Error(
        "For Test Series, choose a manual Test or another Test Series as the source.",
      );
    }

    const isNotesDestination = targetKind === "notes_series" || targetKind === "batch";

    if (isNotesDestination) {
      if (
        (sourceKind === "notes_series" || sourceKind === "batch") &&
        data.source_id === data.target_id
      )
        throw new Error("Choose a different destination Notes Series/Batch.");
      const seriesId = await targetSeriesId(targetKind, data.target_id);
      const destinationCourseId =
        targetKind === "batch" ? await targetCourseId(targetKind, data.target_id) : null;
      if (sourceKind === "batch" && targetKind === "batch" && data.source_id === data.target_id)
        throw new Error("Choose a different destination Batch.");
      const materials = await notesForSource(sourceKind, data.source_id);
      const result = await addMaterialsToSeries({ materials, seriesId, mode });
      let batchVideos: Awaited<ReturnType<typeof copyBatchVideos>> = { addedCount: 0 };
      if (sourceKind === "batch" && targetKind === "batch") {
        const sourceToTargetIds =
          mode === "link"
            ? materials.map((material) => ({ sourceId: material.id, targetId: material.id }))
            : result.sourceToTargetIds;
        batchVideos = await copyBatchVideos({
          sourceSeriesId: data.source_id,
          targetSeriesId: seriesId,
          sourceToTargetIds,
        });
      }
      const { sourceToTargetIds: _idMap, ...publicResult } = result;
      return {
        ...publicResult,
        addedVideos: batchVideos.addedCount,
        ...(batchVideos.warning ? { videoWarning: batchVideos.warning } : {}),
        targetCourseId: destinationCourseId,
      };
    }

    const courseId = await targetCourseId(targetKind, data.target_id);

    if (sourceKind === "material") {
      const source = unwrap(
        await projectContent
          .from("materials")
          .select("*")
          .eq("id", uuidInput.parse(data.source_id))
          .maybeSingle(),
      );
      if (!source) throw new Error("Source Note was not found.");
      const cloned = await cloneMaterial(source as MaterialRow, courseId);
      return { addedCount: 1, mode: "copy" as const, draftCount: 1, createdId: cloned.id };
    }
    if (sourceKind === "test") {
      const source = unwrap(
        await projectContent
          .from("tests")
          .select("*")
          .eq("id", uuidInput.parse(data.source_id))
          .maybeSingle(),
      );
      if (!source) throw new Error("Source Test was not found.");
      const cloned = await copyTestToCourse(source as TestRow, courseId);
      return { addedCount: 1, mode: "copy" as const, draftCount: 1, createdId: cloned.id };
    }
    if (sourceKind === "notes_series" || sourceKind === "batch") {
      const materials = await notesForSource(sourceKind, data.source_id);
      if (materials.length > 500)
        throw new Error(
          "This source contains more than 500 Notes. Add smaller subject/chapter groups to keep the operation safe.",
        );
      const copies = await cloneMaterialsIntoCourse(materials, courseId);
      return { addedCount: copies.length, mode: "copy" as const, draftCount: copies.length };
    }
    if (sourceKind === "test_series") return copyTestSeriesToCourse(data.source_id, courseId);
    throw new Error("Choose a Note, Test, Notes Series, Batch or Test Series as the source.");
  });
