import { LEGACY_INKS, normaliseAuthorColour } from "./author-colours";

/** Inline formatting is data, never authored HTML/CSS. Offsets use JS UTF-16 string indices. */
export type AuthorRun = {
  text: string;
  bold?: boolean | undefined;
  italic?: boolean | undefined;
  underline?: boolean | undefined;
  color?: string | undefined;
  highlight?: string | undefined;
};
type Style = Omit<AuthorRun, "text">;
type StyleKey = keyof Style;
const STYLE_KEYS: StyleKey[] = ["highlight", "color", "bold", "italic", "underline"];

export function plainAuthorRuns(runs: readonly AuthorRun[]) {
  return runs.map((run) => run.text).join("");
}
function sameStyle(a: AuthorRun, b: AuthorRun) {
  return STYLE_KEYS.every((key) => a[key] === b[key]);
}
export function normaliseAuthorRuns(runs: readonly AuthorRun[]): AuthorRun[] {
  const result: AuthorRun[] = [];
  for (const { text, ...style } of runs) {
    if (!text) continue;
    const run: AuthorRun = { text, ...style };
    const previous = result[result.length - 1];
    if (previous && sameStyle(previous, run)) previous.text += text;
    else result.push(run);
  }
  return result;
}

/**
 * Read the existing portable Notes/Test syntax and PR #2's limited safe HTML.
 * An unbalanced/invalid expression remains literal (never silently deletes data).
 */
export function parseAuthorRuns(source: string): AuthorRun[] {
  const tokens =
    /\[(\/?)(b|i|u|mark|color|highlight)(?:=([^\]\n]+))?\]|<(\/?)(b|i|u)>|<span style="color:(#[0-9a-fA-F]{6})">|<\/span>/gi;
  const result: AuthorRun[] = [];
  const stack: { tag: string; style: Style }[] = [];
  let style: Style = {};
  let end = 0;
  const push = (text: string) => {
    if (text) result.push({ text, ...style });
  };
  for (const match of source.matchAll(tokens)) {
    push(source.slice(end, match.index));
    const raw = match[0];
    const legacy = !!match[5];
    const tag = match[2]?.toLowerCase() ?? (legacy ? match[5]!.toLowerCase() : "span");
    const closing = (legacy ? match[4] : match[1]) === "/" || raw === "</span>";
    if (closing) {
      if (stack.at(-1)?.tag !== tag) return source ? [{ text: source }] : [];
      style = stack.pop()!.style;
    } else {
      const value = match[3] ?? match[6];
      const color = value ? normaliseAuthorColour(value) : null;
      if ((tag === "color" || tag === "highlight" || tag === "span") && !color)
        return [{ text: source }];
      // Older HTML supported a fixed palette only; don't turn arbitrary HTML into formatting.
      if (tag === "span" && !Object.values(LEGACY_INKS).includes(color!)) return [{ text: source }];
      stack.push({ tag, style });
      style = {
        ...style,
        ...(tag === "b" ? { bold: true } : {}),
        ...(tag === "i" ? { italic: true } : {}),
        ...(tag === "u" ? { underline: true } : {}),
        ...(tag === "mark" ? { highlight: "#fff0a6" } : {}),
        ...(tag === "color" || tag === "span" ? { color: color! } : {}),
        ...(tag === "highlight" ? { highlight: color! } : {}),
      };
    }
    end = match.index! + raw.length;
  }
  if (stack.length) return source ? [{ text: source }] : [];
  push(source.slice(end));
  return normaliseAuthorRuns(result);
}

/** Keep every line independently balanced: the Notes reader formats per line. */
export function serializeAuthorRuns(runs: readonly AuthorRun[]): string {
  const lines: AuthorRun[][] = [[]];
  for (const run of normaliseAuthorRuns(runs)) {
    const parts = run.text.split("\n");
    for (const [index, text] of parts.entries()) {
      if (index) lines.push([]);
      if (text) lines[lines.length - 1]!.push({ ...run, text });
    }
  }
  const open = (key: StyleKey, value: boolean | string) =>
    `[${key === "bold" ? "b" : key === "italic" ? "i" : key === "underline" ? "u" : key}${typeof value === "string" ? `=${value}` : ""}]`;
  const close = (key: StyleKey) =>
    `[/${key === "bold" ? "b" : key === "italic" ? "i" : key === "underline" ? "u" : key}]`;
  return lines
    .map((line) => {
      let result = "";
      let active: StyleKey[] = [];
      let previous: Style = {};
      for (const run of line) {
        const desired = STYLE_KEYS.filter((key) => run[key]);
        let common = 0;
        while (
          common < active.length &&
          active[common] === desired[common] &&
          previous[active[common]!] === run[active[common]!]
        )
          common++;
        for (const key of active.slice(common).reverse()) result += close(key);
        for (const key of desired.slice(common)) result += open(key, run[key]!);
        result += run.text;
        active = desired;
        previous = run;
      }
      for (const key of active.reverse()) result += close(key);
      return result;
    })
    .join("\n");
}

export function formatAuthorRuns(
  input: readonly AuthorRun[],
  start: number,
  end: number,
  key: StyleKey,
  value?: boolean | string,
): AuthorRun[] {
  const runs = normaliseAuthorRuns(input);
  const length = plainAuthorRuns(runs).length;
  start = Math.max(0, Math.min(length, Math.trunc(start)));
  end = Math.max(start, Math.min(length, Math.trunc(end)));
  if (start === end) return runs;
  const colour = typeof value === "string" ? normaliseAuthorColour(value) : null;
  if (typeof value === "string" && !colour) return runs;
  // B/I/U toggle off only when the entire selected text already has that style.
  let allStyled = key === "bold" || key === "italic" || key === "underline";
  let position = 0;
  for (const run of runs) {
    const overlap = position < end && position + run.text.length > start;
    if (overlap && !run[key]) allStyled = false;
    position += run.text.length;
  }
  const next: AuthorRun[] = [];
  position = 0;
  for (const run of runs) {
    const left = Math.max(0, Math.min(run.text.length, start - position));
    const right = Math.max(left, Math.min(run.text.length, end - position));
    if (left) next.push({ ...run, text: run.text.slice(0, left) });
    if (right > left) {
      const middle = { ...run, text: run.text.slice(left, right) };
      if (value === undefined || allStyled) delete middle[key];
      else if (key === "color" || key === "highlight") {
        if (colour) middle[key] = colour;
      } else middle[key] = true;
      next.push(middle);
    }
    if (right < run.text.length) next.push({ ...run, text: run.text.slice(right) });
    position += run.text.length;
  }
  return normaliseAuthorRuns(next);
}

/**
 * Only the app's valid, trailing :::visuals metadata is hidden from the normal
 * writing field. Keep its exact bytes while the author edits the visible text;
 * malformed, inline or mixed source directives must not be silently rewritten.
 */
export function splitEditableNoteBody(value: string): { text: string; suffix: string } | null {
  const match = /(?:\r?\n){0,2}:::visuals[ \t]+(\{[^\r\n]*\})[ \t]*\r?\n:::[ \t]*(?:\r?\n)?$/i.exec(
    value,
  );
  if (!match) return null;
  try {
    const settings: unknown = JSON.parse(match[1]!);
    if (!settings || typeof settings !== "object" || Array.isArray(settings)) return null;
  } catch {
    return null;
  }
  const text = value.slice(0, match.index);
  if (needsNoteSource(text)) return null;
  return { text, suffix: value.slice(match.index) };
}

/** The advanced note builder's tables, math and layout directives retain their source editor. */
export function needsNoteSource(value: string) {
  return /:::|\[(?:size|align|box|sup|sub)(?:=|\])|\\(?:frac|sqrt|begin)\b|<span\b(?! style="color:#[0-9a-fA-F]{6}">)/i.test(
    value,
  );
}
