import type { NotesSeries, SeriesMaterial } from "./notes-series";
import { seriesNoteIds } from "./notes-series";

export type LibrarySourceKind =
  "material" | "test" | "course" | "notes_series" | "test_series" | "batch";
export type LibraryTargetKind = "course" | "notes_series" | "test_series" | "batch";
export type ReuseMode = "link" | "copy";

/** Only native note-ID membership is a true shared link; other transfers are snapshots. */
export function supportsSharedLink(source: LibrarySourceKind, target: LibraryTargetKind) {
  return (
    (target === "notes_series" || target === "batch") &&
    (source === "material" ||
      source === "course" ||
      source === "notes_series" ||
      source === "batch")
  );
}

export function addNotesToSeries(
  series: NotesSeries,
  notes: readonly SeriesMaterial[],
  makeId: () => string = () => globalThis.crypto.randomUUID(),
): { series: NotesSeries; addedIds: string[] } {
  const next = structuredClone(series);
  const included = new Set(seriesNoteIds(next));
  const addedIds: string[] = [];

  for (const note of notes) {
    if (included.has(note.id)) continue;
    const subjectName = note.subject?.trim() || "General studies";
    const chapterName = note.chapter?.trim() || "General notes";
    let subject = next.subjects.find(
      (item) =>
        item.name.normalize("NFC").toLocaleLowerCase() ===
        subjectName.normalize("NFC").toLocaleLowerCase(),
    );
    if (!subject) {
      subject = { id: makeId(), name: subjectName, chapters: [] };
      next.subjects.push(subject);
    }
    let chapter = subject.chapters.find(
      (item) =>
        item.name.normalize("NFC").toLocaleLowerCase() ===
        chapterName.normalize("NFC").toLocaleLowerCase(),
    );
    if (!chapter) {
      chapter = { id: makeId(), name: chapterName, noteIds: [], topics: [] };
      subject.chapters.push(chapter);
    }
    chapter.noteIds.push(note.id);
    included.add(note.id);
    addedIds.push(note.id);
  }

  return { series: next, addedIds };
}
