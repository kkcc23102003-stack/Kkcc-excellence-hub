export type AccessValidityState = "lifetime" | "active" | "expiring" | "expired" | "revoked";

export type StudentLearningAccessItem = {
  id: string;
  kind: "batch" | "test-series" | "notes-series" | "test" | "note";
  item_id: string;
  course_slug?: string;
  title: string;
  subtitle: string;
  source: string;
  note: string;
  granted_at: string;
  expires_at: string | null;
  revoked_at: string | null;
  validity_state: AccessValidityState;
  days_left: number | null;
};

export function getAccessValidity(
  grant: {
    status?: string | null;
    revoked_at?: string | null;
    expires_at?: string | null;
  },
  now = Date.now(),
): Pick<StudentLearningAccessItem, "validity_state" | "days_left"> {
  if (grant.revoked_at || grant.status === "revoked")
    return { validity_state: "revoked", days_left: null };
  if (grant.status === "expired") return { validity_state: "expired", days_left: 0 };
  if (!grant.expires_at) return { validity_state: "lifetime", days_left: null };

  const expiry = Date.parse(grant.expires_at);
  if (!Number.isFinite(expiry) || expiry <= now) return { validity_state: "expired", days_left: 0 };
  const daysLeft = Math.max(0, Math.ceil((expiry - now) / 86_400_000));
  return {
    validity_state: daysLeft <= 7 ? "expiring" : "active",
    days_left: daysLeft,
  };
}
