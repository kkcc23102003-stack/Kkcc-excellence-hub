export type OptionalAdminCatalog<T> = {
  items: T[];
  error: string | null;
};

/** Keep a failed, nonessential product catalogue from blocking the Admin workflow. */
export async function readOptionalAdminCatalog<T>(
  read: () => Promise<T[]>,
): Promise<OptionalAdminCatalog<T>> {
  try {
    return { items: await read(), error: null };
  } catch (error) {
    return {
      items: [],
      error:
        error instanceof Error && error.message.trim()
          ? error.message
          : "Product catalogue is temporarily unavailable.",
    };
  }
}
