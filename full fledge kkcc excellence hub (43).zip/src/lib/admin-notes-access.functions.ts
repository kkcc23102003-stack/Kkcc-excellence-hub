import { createServerFn } from "@tanstack/react-start";
import { z } from "zod";
import { requireSupabaseAuth } from "@/integrations/supabase/auth-middleware";
import type {
  MaterialAccessGrantRow,
  MaterialPurchaseRow,
  SeriesAccessGrantRow,
} from "@/integrations/supabase/db";
import { materialAccessMode } from "./material-access-mode";
import { getAccessValidity } from "./access-validity";
import { findStudent, assertAdmin, unwrap } from "./learning.server";
import { projectContent } from "./project-content.server";
import { readAdminNotesSeriesCatalog } from "./notes-series-catalog.server";
import { NOTES_SERIES_ACCESS_PREFIX, notesSeriesAccessKey } from "./notes-series";
import { isCurrentGrant } from "./learning-access";
import { sendStudentAccessNotification } from "@/lib/notifications.server";

const searchSchema = z.object({ query: z.string().trim().max(120).optional().default("") });
const grantSchema = z.object({
  email: z.string().trim().email().max(200),
  kind: z.enum(["note", "series"]),
  item_id: z.string().uuid(),
  expires_at: z.string().datetime().nullable().optional(),
  note: z.string().trim().max(500).default(""),
});
const revokeSchema = z.object({
  id: z.string().uuid(),
  kind: z.enum(["note", "series", "purchase"]),
});
const notesSeriesHistoryVisibilitySchema = z.object({
  id: z.string().uuid(),
  hidden: z.boolean(),
});

type NotesGrantListItem = {
  id: string;
  kind: "note" | "series" | "purchase";
  item_id: string;
  user_id: string;
  student_name: string;
  student_email: string;
  title: string;
  subject: string;
  chapter: string;
  method: string;
  note: string;
  expires_at: string | null;
  revoked_at: string | null;
  admin_hidden_at: string | null;
  created_at: string;
  state: "active" | "expired" | "revoked";
};

function statusOf(grant: {
  expires_at: string | null;
  revoked_at: string | null;
}): NotesGrantListItem["state"] {
  const state = getAccessValidity(grant).validity_state;
  if (state === "expired") return "expired";
  if (state === "revoked") return "revoked";
  return "active";
}

function effectiveRenewalExpiry(
  current: { expires_at: string | null; revoked_at: string | null } | null,
  requested: string | null,
) {
  if (!current || !isCurrentGrant(current)) return requested;
  if (!current.expires_at || !requested) return null;
  return Date.parse(current.expires_at) >= Date.parse(requested) ? current.expires_at : requested;
}

export const adminListNotesAccess = createServerFn({ method: "GET" })
  .middleware([requireSupabaseAuth])
  .validator((input: unknown) => searchSchema.parse(input ?? {}))
  .handler(
    async ({
      context,
      data,
    }): Promise<{
      materials: {
        id: string;
        title: string;
        subject: string;
        chapter: string;
        access_type: string;
      }[];
      series: { id: string; name: string }[];
      grants: NotesGrantListItem[];
      historyHidingAvailable: boolean;
    }> => {
      await assertAdmin(context);

      const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
      const [
        materialsResult,
        seriesCatalog,
        materialGrantsResult,
        seriesGrantsResult,
        seriesVisibilityColumnResult,
        materialPurchasesResult,
      ] = await Promise.all([
        projectContent
          .from("materials")
          .select("id,title,subject,chapter,access_type,is_published,is_free_preview")
          .eq("is_published", true)
          .order("subject", { ascending: true })
          .order("sort_order", { ascending: true }),
        readAdminNotesSeriesCatalog(),
        context.supabase
          .from("material_access_grants")
          .select("*")
          .order("created_at", { ascending: false })
          .limit(500),
        context.supabase
          .from("series_access_grants")
          .select("*")
          .like("series_id", `${NOTES_SERIES_ACCESS_PREFIX}%`)
          .order("created_at", { ascending: false })
          .limit(1500),
        context.supabase.from("series_access_grants").select("admin_hidden_at").limit(1),
        supabaseAdmin
          .from("material_purchases")
          .select("*")
          .eq("status", "active")
          .order("created_at", { ascending: false })
          .limit(500),
      ]);

      if (materialsResult.error) throw new Error(materialsResult.error.message);
      if (materialGrantsResult.error) throw new Error(materialGrantsResult.error.message);
      if (seriesGrantsResult.error) throw new Error(seriesGrantsResult.error.message);
      if (materialPurchasesResult.error) throw new Error(materialPurchasesResult.error.message);

      const materials = (materialsResult.data ?? [])
        .filter(
          (row) => row.is_published && !row.is_free_preview && materialAccessMode(row) !== "free",
        )
        .map((row) => ({
          id: row.id,
          title: row.title || "Untitled note",
          subject: row.subject || "General",
          chapter: row.chapter || "",
          access_type: row.access_type || "course",
        }));
      const publishedSeries = seriesCatalog
        .filter((series) => series.published && series.kind === "paid")
        .map((series) => ({ id: series.id, name: series.name }));

      const materialById = new Map(materials.map((row) => [row.id, row]));
      const seriesById = new Map(seriesCatalog.map((series) => [series.id, series]));
      const materialGrants = (materialGrantsResult.data ?? []) as MaterialAccessGrantRow[];
      const seriesGrants = (seriesGrantsResult.data ?? []) as SeriesAccessGrantRow[];
      const materialPurchases = (materialPurchasesResult.data ?? []) as MaterialPurchaseRow[];
      const userIds = [
        ...new Set(
          [...materialGrants, ...seriesGrants, ...materialPurchases].map((grant) => grant.user_id),
        ),
      ];
      const profiles = userIds.length
        ? unwrap(
            await context.supabase.from("profiles").select("id,email,full_name").in("id", userIds),
          )
        : [];
      const profileById = new Map((profiles ?? []).map((profile) => [profile.id, profile]));

      const grants: NotesGrantListItem[] = [
        ...materialGrants.map((grant) => {
          const note = materialById.get(grant.material_id);
          const profile = profileById.get(grant.user_id);
          const state = statusOf(grant);
          return {
            id: grant.id,
            kind: "note" as const,
            item_id: grant.material_id,
            user_id: grant.user_id,
            student_name: profile?.full_name || "Student",
            student_email: profile?.email || "",
            title: note?.title || `Note ${grant.material_id}`,
            subject: note?.subject || "",
            chapter: note?.chapter || "",
            method: grant.method,
            note: grant.note,
            expires_at: grant.expires_at,
            revoked_at: grant.revoked_at,
            admin_hidden_at: null,
            created_at: grant.created_at,
            state,
          };
        }),
        ...materialPurchases.map((purchase) => {
          const note = materialById.get(purchase.material_id);
          const profile = profileById.get(purchase.user_id);
          return {
            id: purchase.id,
            kind: "purchase" as const,
            item_id: purchase.material_id,
            user_id: purchase.user_id,
            student_name: profile?.full_name || "Student",
            student_email: profile?.email || "",
            title: note?.title || `Note ${purchase.material_id}`,
            subject: note?.subject || "",
            chapter: note?.chapter || "",
            method: "paid purchase",
            note: `23KAAT paid: ${purchase.paid_coins}`,
            expires_at: null,
            revoked_at: null,
            admin_hidden_at: null,
            created_at: purchase.created_at,
            state: purchase.status === "active" ? ("active" as const) : ("revoked" as const),
          };
        }),
        ...seriesGrants
          .filter((grant) => grant.series_id.startsWith(NOTES_SERIES_ACCESS_PREFIX))
          .map((grant) => {
            const itemId = grant.series_id.slice(NOTES_SERIES_ACCESS_PREFIX.length);
            const profile = profileById.get(grant.user_id);
            const state = statusOf(grant);
            return {
              id: grant.id,
              kind: "series" as const,
              item_id: itemId,
              user_id: grant.user_id,
              student_name: profile?.full_name || "Student",
              student_email: profile?.email || "",
              title: seriesById.get(itemId)?.name || `Notes Series ${itemId}`,
              subject: "",
              chapter: "",
              method: grant.method,
              note: grant.note,
              expires_at: grant.expires_at,
              revoked_at: grant.revoked_at,
              admin_hidden_at: grant.admin_hidden_at ?? null,
              created_at: grant.created_at,
              state,
            };
          }),
      ]
        .filter(
          (grant) =>
            !data.query ||
            [
              grant.student_name,
              grant.student_email,
              grant.title,
              grant.subject,
              grant.chapter,
              grant.method,
              grant.note,
              grant.kind,
            ]
              .join(" ")
              .toLowerCase()
              .includes(data.query.toLowerCase()),
        )
        .sort((a, b) => Date.parse(b.created_at) - Date.parse(a.created_at));

      return {
        materials,
        series: publishedSeries,
        grants,
        historyHidingAvailable: !seriesVisibilityColumnResult.error,
      };
    },
  );

type ExistingGrant = {
  id: string;
  expires_at: string | null;
  revoked_at: string | null;
  method: string;
};

async function findGrant(
  context: Parameters<typeof assertAdmin>[0],
  kind: "note" | "series",
  userId: string,
  targetId: string,
): Promise<ExistingGrant | null> {
  if (kind === "note") {
    const result = await context.supabase
      .from("material_access_grants")
      .select("id,expires_at,revoked_at,method")
      .eq("user_id", userId)
      .eq("material_id", targetId)
      .is("revoked_at", null)
      .maybeSingle();
    if (result.error) throw new Error(result.error.message);
    return result.data;
  }
  const result = await context.supabase
    .from("series_access_grants")
    .select("id,expires_at,revoked_at,method")
    .eq("user_id", userId)
    .eq("series_id", targetId)
    .is("revoked_at", null)
    .maybeSingle();
  if (result.error) throw new Error(result.error.message);
  return result.data;
}

async function writeGrant(
  context: Parameters<typeof assertAdmin>[0],
  kind: "note" | "series",
  id: string | null,
  payload: Record<string, unknown>,
) {
  if (kind === "note") {
    const query = id
      ? context.supabase
          .from("material_access_grants")
          .update(payload as never)
          .eq("id", id)
      : context.supabase.from("material_access_grants").insert(payload as never);
    return query.select("id").single();
  }
  const query = id
    ? context.supabase
        .from("series_access_grants")
        .update(payload as never)
        .eq("id", id)
    : context.supabase.from("series_access_grants").insert(payload as never);
  return query.select("id").single();
}

export const adminGrantNotesAccess = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .validator((input: unknown) => grantSchema.parse(input))
  .handler(async ({ context, data }) => {
    await assertAdmin(context);
    const student = await findStudent(context, { email: data.email });
    if (unwrap(await context.supabase.rpc("is_user_blocked", { _user_id: student.id })))
      throw new Error("Student account is blocked; unblock it before granting notes access.");
    const expiresAt = data.expires_at ?? null;
    if (expiresAt && Date.parse(expiresAt) <= Date.now())
      throw new Error("Access expiry must be in the future.");

    let title = "";
    let targetId = data.item_id;
    if (data.kind === "note") {
      const material = unwrap(
        await projectContent
          .from("materials")
          .select("id,title,access_type,is_published,is_free_preview,price,coin_price")
          .eq("id", data.item_id)
          .eq("is_published", true)
          .maybeSingle(),
      );
      if (!material) throw new Error("Published note not found.");
      if (material.is_free_preview || materialAccessMode(material) === "free")
        throw new Error("This note is already free to students and does not need a manual grant.");
      title = material.title || "Study note";
    } else {
      const series = (await readAdminNotesSeriesCatalog()).find(
        (item) => item.id === data.item_id && item.published && item.kind === "paid",
      );
      if (!series) throw new Error("Published paid Notes Series not found.");
      title = series.name;
      targetId = notesSeriesAccessKey(series.id);
    }

    let existing = await findGrant(context, data.kind, student.id, targetId);
    if (existing && isCurrentGrant(existing) && existing.method !== "manual_notes") {
      return {
        ok: true,
        already_active: true,
        email: student.email,
        title,
        expires_at: existing.expires_at,
        kind: data.kind,
      };
    }

    const previouslyCurrent = Boolean(existing && isCurrentGrant(existing));
    const previousExpiry = existing?.expires_at ?? null;
    let finalExpiry = effectiveRenewalExpiry(existing, expiresAt);
    const now = new Date().toISOString();
    const commonPayload = {
      user_id: student.id,
      granted_by: context.userId,
      method: "manual_notes",
      amount_inr: 0,
      note: data.note,
      expires_at: finalExpiry,
      revoked_at: null,
    };
    const payload =
      data.kind === "note"
        ? {
            ...commonPayload,
            material_id: targetId,
            updated_at: now,
          }
        : { ...commonPayload, series_id: targetId };

    let grantId = existing?.id ?? null;
    if (existing) {
      const updated = await writeGrant(context, data.kind, existing.id, payload);
      if (updated.error) throw new Error(updated.error.message);
      grantId = updated.data.id;
    } else {
      const inserted = await writeGrant(context, data.kind, null, payload);
      if (inserted.error) {
        // A concurrent admin grant may have claimed the unique live entitlement.
        if (inserted.error.code !== "23505") throw new Error(inserted.error.message);
        existing = await findGrant(context, data.kind, student.id, targetId);
        if (!existing) throw new Error(inserted.error.message);
        if (existing.method !== "manual_notes" && isCurrentGrant(existing)) {
          return {
            ok: true,
            already_active: true,
            email: student.email,
            title,
            expires_at: existing.expires_at,
            kind: data.kind,
          };
        }
        finalExpiry = effectiveRenewalExpiry(existing, expiresAt);
        const retryPayload = { ...payload, expires_at: finalExpiry };
        const retried = await writeGrant(context, data.kind, existing.id, retryPayload);
        if (retried.error) throw new Error(retried.error.message);
        grantId = retried.data.id;
      } else {
        grantId = inserted.data.id;
      }
    }

    if (grantId && (!previouslyCurrent || previousExpiry !== finalExpiry)) {
      await sendStudentAccessNotification(context, {
        userId: student.id,
        eventKey: `access:notes:${data.kind}:${grantId}:grant:${finalExpiry ?? "lifetime"}`,
        action: previouslyCurrent ? "renewed" : "granted",
        productTitle: title,
        expiresAt: finalExpiry,
      });
    }
    return {
      ok: true,
      already_active: false,
      email: student.email,
      title,
      expires_at: finalExpiry,
      kind: data.kind,
    };
  });

export const adminRevokeNotesAccess = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .validator((input: unknown) => revokeSchema.parse(input))
  .handler(async ({ context, data }) => {
    await assertAdmin(context);
    const now = new Date().toISOString();
    if (data.kind === "purchase") {
      const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
      const current = await supabaseAdmin
        .from("material_purchases")
        .select("id,user_id,material_id,status")
        .eq("id", data.id)
        .maybeSingle();
      if (current.error) throw new Error(current.error.message);
      if (!current.data) throw new Error("Paid Note access record not found.");
      if (current.data.status !== "active") return { ok: true, already_revoked: true };
      const revoked = await supabaseAdmin
        .from("material_purchases")
        .update({ status: "revoked", updated_at: now })
        .eq("id", data.id)
        .eq("status", "active")
        .select("id")
        .maybeSingle();
      if (revoked.error) throw new Error(revoked.error.message);
      if (!revoked.data) return { ok: true, already_revoked: true };
      const material = await projectContent
        .from("materials")
        .select("title")
        .eq("id", current.data.material_id)
        .maybeSingle();
      await sendStudentAccessNotification(context, {
        userId: current.data.user_id,
        eventKey: `access:note-purchase:${current.data.id}:revoke:${now}`,
        action: "revoked",
        productTitle: material.data?.title || "paid Note access",
      });
      return { ok: true, already_revoked: false };
    }
    if (data.kind === "note") {
      const current = await context.supabase
        .from("material_access_grants")
        .select("id,user_id,material_id,revoked_at")
        .eq("id", data.id)
        .maybeSingle();
      if (current.error) throw new Error(current.error.message);
      if (!current.data) throw new Error("Notes access grant not found.");
      if (current.data.revoked_at) return { ok: true, already_revoked: true };
      const revoked = await context.supabase
        .from("material_access_grants")
        .update({ revoked_at: now, updated_at: now })
        .eq("id", data.id)
        .is("revoked_at", null)
        .select("id")
        .maybeSingle();
      if (revoked.error) throw new Error(revoked.error.message);
      if (!revoked.data) return { ok: true, already_revoked: true };
      const material = await projectContent
        .from("materials")
        .select("title")
        .eq("id", current.data.material_id)
        .maybeSingle();
      await sendStudentAccessNotification(context, {
        userId: current.data.user_id,
        eventKey: `access:note:${current.data.id}:revoke:${now}`,
        action: "revoked",
        productTitle: material.data?.title || "paid Note access",
      });
      return { ok: true, already_revoked: false };
    }

    const current = await context.supabase
      .from("series_access_grants")
      .select("id,user_id,series_id,revoked_at")
      .eq("id", data.id)
      .maybeSingle();
    if (current.error) throw new Error(current.error.message);
    if (!current.data || !current.data.series_id.startsWith(NOTES_SERIES_ACCESS_PREFIX))
      throw new Error("Notes Series access grant not found.");
    if (current.data.revoked_at) return { ok: true, already_revoked: true };
    const revoked = await context.supabase
      .from("series_access_grants")
      .update({ revoked_at: now })
      .eq("id", data.id)
      .is("revoked_at", null)
      .select("id")
      .maybeSingle();
    if (revoked.error) throw new Error(revoked.error.message);
    if (!revoked.data) return { ok: true, already_revoked: true };
    const notesSeriesId = current.data.series_id.slice(NOTES_SERIES_ACCESS_PREFIX.length);
    const notesSeries = await readAdminNotesSeriesCatalog().catch(() => []);
    const notesSeriesTitle = notesSeries.find((item) => item.id === notesSeriesId)?.name;
    await sendStudentAccessNotification(context, {
      userId: current.data.user_id,
      eventKey: `access:notes-series:${current.data.id}:revoke:${now}`,
      action: "revoked",
      productTitle: notesSeriesTitle || "Notes Series access",
    });
    return { ok: true, already_revoked: false };
  });

/** Hide or restore a Notes Series grant in the Admin list without changing access. */
export const adminSetNotesSeriesHistoryVisibility = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .validator((input: unknown) => notesSeriesHistoryVisibilitySchema.parse(input))
  .handler(async ({ context, data }) => {
    await assertAdmin(context);
    const result = await context.supabase
      .from("series_access_grants")
      .update({ admin_hidden_at: data.hidden ? new Date().toISOString() : null })
      .eq("id", data.id)
      .like("series_id", `${NOTES_SERIES_ACCESS_PREFIX}%`)
      .select("id")
      .maybeSingle();
    if (result.error) throw new Error(result.error.message);
    if (!result.data) throw new Error("Notes Series access record not found.");
    return { ok: true, hidden: data.hidden };
  });
