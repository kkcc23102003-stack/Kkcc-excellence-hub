import { randomUUID } from "node:crypto";
import { createServerFn } from "@tanstack/react-start";
import { z } from "zod";
import { requireSupabaseAuth } from "@/integrations/supabase/auth-middleware";
import { isFreeCourse, slugify } from "./cms";
import { resolveContentUrl, resolveNoteImages } from "./content-storage.server";
import { assertAdmin, readStudentAccess, unwrap } from "./learning.server";
import { readNoteBody } from "./note-body.server";
import { batchOutline, notesBatchSchema } from "./notes-batch";
import { notesSeriesSchema, seriesNoteIds } from "./notes-series";
import { projectContent } from "./project-content.server";
import {
  applySharedBatchPriceToCourse,
  getNotesBatchPricing,
  notesBatchPricingSchema,
} from "./notes-batch-pricing.server";
import { protectVideoUrl, validateVideoUrl, youtubeId } from "./video";
import { readNotesCatalogSetting, writeNotesCatalogObject } from "./notes-catalog-storage.server";

const PREFIX = "notes_batch_v1:";
const COURSE_INDEX = "notes_batch_course_v1:";
const idInput = z.object({ id: z.string().uuid() });

async function seriesById(id: string) {
  const row = unwrap(
    await projectContent
      .from("site_settings")
      .select("value")
      .eq("key", `notes_series_v1:${id}`)
      .maybeSingle(),
  );
  return row
    ? notesSeriesSchema.parse(
        (
          await readNotesCatalogSetting({
            table: "site_settings",
            key: `notes_series_v1:${id}`,
            kind: "series",
            id,
            value: row.value,
          })
        ).data,
      )
    : null;
}
async function batchBySeries(id: string) {
  // Private settings, not public site_settings: anon has SELECT on the old site_settings table.
  const row = unwrap(
    await projectContent
      .from("private_settings")
      .select("value")
      .eq("key", PREFIX + id)
      .maybeSingle(),
  );
  return row
    ? notesBatchSchema.parse(
        (
          await readNotesCatalogSetting({
            table: "private_settings",
            key: PREFIX + id,
            kind: "batch",
            id,
            value: row.value,
          })
        ).data,
      )
    : null;
}
async function batchByCourse(id: string) {
  // An exact private index avoids scanning every setting and cannot expose other batches.
  const index = unwrap(
    await projectContent
      .from("private_settings")
      .select("value")
      .eq("key", COURSE_INDEX + id)
      .maybeSingle(),
  );
  if (!index) return null;
  const seriesId = z.string().uuid().parse(index.value);
  const batch = await batchBySeries(seriesId);
  if (!batch || batch.courseId !== id)
    throw new Error("Batch link is inconsistent. Contact Admin.");
  return batch;
}
async function publishedNotes(ids: string[]) {
  if (!ids.length) return [];
  // Keep request URLs bounded on large series.
  const chunks = Array.from({ length: Math.ceil(ids.length / 250) }, (_, index) =>
    ids.slice(index * 250, (index + 1) * 250),
  );
  return (
    await Promise.all(
      chunks.map(async (chunk) =>
        unwrap(
          await projectContent.from("materials").select("id,title,is_published").in("id", chunk),
        ),
      ),
    )
  ).flat();
}

/** Metadata-only public course syllabus; never include videos, paid note bodies or private refs. */
export const getPublicBatchOutline = createServerFn({ method: "GET" })
  .validator((input: unknown) => idInput.parse(input))
  .handler(async ({ data }) => {
    const course = unwrap(
      await projectContent.from("courses").select("id,status").eq("id", data.id).maybeSingle(),
    );
    if (course?.status !== "published") return null;
    const batch = await batchByCourse(course.id);
    if (!batch) return null;
    const series = await seriesById(batch.seriesId);
    if (!series?.published) return null;
    return batchOutline(series, batch, await publishedNotes(seriesNoteIds(series)));
  });

/** Public purchase target for a published Notes Series; private batch media stays server-only. */
export const getPublicBatchForSeries = createServerFn({ method: "GET" })
  .validator((input: unknown) => idInput.parse(input))
  .handler(async ({ data }) => {
    const series = await seriesById(data.id);
    if (!series?.published || series.kind !== "paid") return null;
    const batch = await batchBySeries(series.id);
    let courseId = batch?.courseId ?? null;

    // Older Notes Series may predate the private Batch link but all linked materials
    // still share the existing course_id. Use that only when it identifies one course.
    if (!courseId) {
      const noteIds = seriesNoteIds(series);
      const chunks = Array.from({ length: Math.ceil(noteIds.length / 250) }, (_, index) =>
        noteIds.slice(index * 250, (index + 1) * 250),
      );
      const linkedNotes = (
        await Promise.all(
          chunks.map(async (chunk) =>
            unwrap(
              await projectContent
                .from("materials")
                .select("id,course_id")
                .eq("is_published", true)
                .in("id", chunk),
            ),
          ),
        )
      ).flat();
      const courseIds = [...new Set(linkedNotes.map((note) => note.course_id).filter(Boolean))];
      if (
        linkedNotes.length !== noteIds.length ||
        courseIds.length !== 1 ||
        linkedNotes.some((note) => note.course_id !== courseIds[0])
      )
        return null;
      courseId = courseIds[0] ?? null;
    }
    if (!courseId) return null;

    const course = unwrap(
      await projectContent
        .from("courses")
        .select("id,slug,title,status")
        .eq("id", courseId)
        .maybeSingle(),
    );
    if (course?.status !== "published") return null;
    return {
      courseId: course.id,
      courseSlug: course.slug,
      courseTitle: course.title,
      hasNotesBatch: Boolean(batch),
    };
  });

export const getAdminNotesBatchPricing = createServerFn({ method: "GET" })
  .middleware([requireSupabaseAuth])
  .handler(async ({ context }) => {
    await assertAdmin(context);
    return getNotesBatchPricing();
  });

export const saveAdminNotesBatchPricing = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .validator((input: unknown) => notesBatchPricingSchema.parse(input))
  .handler(async ({ context, data }) => {
    await assertAdmin(context);
    const { error } = await projectContent.from("private_settings").upsert(
      {
        key: "notes_batch_pricing_v1",
        value: JSON.stringify(data),
        updated_by: context.userId,
      },
      { onConflict: "key" },
    );
    if (error) throw new Error(error.message);
    return data;
  });

export const getAdminBatchForSeries = createServerFn({ method: "GET" })
  .middleware([requireSupabaseAuth])
  .validator((input: unknown) => idInput.parse(input))
  .handler(async ({ context, data }) => {
    await assertAdmin(context);
    const [series, batch] = await Promise.all([seriesById(data.id), batchBySeries(data.id)]);
    if (!series || !batch) return null;
    const course = unwrap(
      await projectContent.from("courses").select("*").eq("id", batch.courseId).maybeSingle(),
    );
    const effectiveCourse = course ? await applySharedBatchPriceToCourse(course) : null;
    return {
      batch,
      course: effectiveCourse,
      outline: batchOutline(
        series,
        batch,
        (await publishedNotes(seriesNoteIds(series))).map((note) => ({
          ...note,
          is_published: true,
        })),
      ),
    };
  });

export const getAdminBatchForCourse = createServerFn({ method: "GET" })
  .middleware([requireSupabaseAuth])
  .validator((input: unknown) => idInput.parse(input))
  .handler(async ({ context, data }) => {
    await assertAdmin(context);
    const batch = await batchByCourse(data.id);
    return batch ? { seriesId: batch.seriesId } : null;
  });

/** Creates a separate DRAFT course. Admin sets its price/status in the normal course editor. */
export const createBatchCourseForSeries = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .validator((input: unknown) => idInput.parse(input))
  .handler(async ({ context, data }) => {
    await assertAdmin(context);
    const series = await seriesById(data.id);
    if (!series || series.kind !== "paid")
      throw new Error("Create a paid Notes Series first; the existing notes remain unchanged.");
    if (await batchBySeries(series.id))
      throw new Error("This Notes Series already has a Batch. Open its linked course instead.");
    const id = randomUUID();
    const title = `${series.name} · Video Batch`;
    const slug = `${slugify(series.name) || "notes"}-batch-${id.slice(0, 8)}`.slice(0, 120);
    const course = unwrap(
      await projectContent
        .from("courses")
        .insert({
          id,
          title,
          slug,
          category: "School",
          class_level: "General",
          subject: "General",
          faculty: "KKCC Faculty",
          course_type: "Recorded",
          status: "draft",
          thumbnail_url: series.thumbnail_url ?? null,
          summary: `Videos, the same KKCC notes and repeatable practice for ${series.name}.`,
          description: "Batch access is independent from individual Notes purchases.",
          outcomes: [],
          price: 0,
          original_price: 0,
          discount_percent: 0,
          duration_hours: 0,
          lectures_count: 0,
          tests_count: 0,
          materials_count: seriesNoteIds(series).length,
          rating: 0,
          hue: 187,
          sort_order: 0,
        })
        .select("*")
        .single(),
    );
    const batch = { seriesId: series.id, courseId: course.id, revision: 0, videos: {} };
    const batchPointer = await writeNotesCatalogObject("batch", series.id, batch);
    const saved = await projectContent.from("private_settings").insert({
      key: PREFIX + series.id,
      value: batchPointer,
      updated_by: context.userId,
    });
    if (saved.error)
      throw new Error(
        `Course was created as draft, but linking failed. Contact Admin with course ID ${course.id}: ${saved.error.message}`,
      );
    const indexed = await projectContent.from("private_settings").insert({
      key: COURSE_INDEX + course.id,
      value: series.id,
      updated_by: context.userId,
    });
    if (indexed.error)
      throw new Error(
        `Batch exists as draft but its course link index failed. Contact Admin with course ID ${course.id}: ${indexed.error.message}`,
      );
    return { courseId: course.id, slug: course.slug };
  });

export const saveBatchVideo = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .validator((input: unknown) =>
    z
      .object({
        seriesId: z.string().uuid(),
        noteId: z.string().uuid(),
        revision: z.number().int().min(0),
        videoUrl: z.string().trim().max(4000),
      })
      .parse(input),
  )
  .handler(async ({ context, data }) => {
    await assertAdmin(context);
    const invalid = validateVideoUrl(data.videoUrl);
    if (invalid) throw new Error(invalid);
    const series = await seriesById(data.seriesId);
    if (!series || !seriesNoteIds(series).includes(data.noteId))
      throw new Error("This note is no longer linked to the series. Reload the page.");
    const key = PREFIX + series.id;
    const current = unwrap(
      await projectContent.from("private_settings").select("value").eq("key", key).maybeSingle(),
    );
    if (!current) throw new Error("Create a Batch course for this series first.");
    const currentStorage = await readNotesCatalogSetting({
      table: "private_settings",
      key,
      kind: "batch",
      id: data.seriesId,
      value: current.value,
    });
    const batch = notesBatchSchema.parse(currentStorage.data);
    if (batch.revision !== data.revision)
      throw new Error("Batch videos changed in another session. Reload before saving.");
    const videos = { ...batch.videos };
    if (data.videoUrl) videos[data.noteId] = data.videoUrl;
    else delete videos[data.noteId];
    const next = notesBatchSchema.parse({ ...batch, revision: batch.revision + 1, videos });
    const nextPointer = await writeNotesCatalogObject("batch", data.seriesId, next);
    const saved = await projectContent
      .from("private_settings")
      .update({
        value: nextPointer,
        updated_by: context.userId,
        updated_at: new Date().toISOString(),
      })
      .eq("key", key)
      .eq("value", currentStorage.storedValue)
      .select("key");
    if (saved.error) throw new Error(saved.error.message);
    if (!saved.data?.length)
      throw new Error("Batch videos changed while saving. Reload and retry.");
    return next;
  });

/** Single guarded endpoint for both video and the *same* paid note (no purchase mutation). */
export const getMyBatchLesson = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .validator((input: unknown) =>
    z.object({ courseId: z.string().uuid(), noteId: z.string().uuid() }).parse(input),
  )
  .handler(async ({ context, data }) => {
    const course = unwrap(
      await projectContent
        .from("courses")
        .select("*")
        .eq("id", data.courseId)
        .eq("status", "published")
        .maybeSingle(),
    );
    if (!course) throw new Error("Course not available.");
    const pricedCourse = await applySharedBatchPriceToCourse(course);
    const batch = await batchByCourse(course.id);
    if (!batch) throw new Error("Batch not available.");
    const series = await seriesById(batch.seriesId);
    if (!series?.published || !seriesNoteIds(series).includes(data.noteId))
      throw new Error("Lesson is not published in this Batch.");
    const access = await readStudentAccess(context);
    if (!access.is_admin && !isFreeCourse(pricedCourse) && !access.course_ids.includes(course.id))
      throw new Error("COURSE_ACCESS_REQUIRED");
    const note = unwrap(
      await projectContent
        .from("materials")
        .select("*")
        .eq("id", data.noteId)
        .eq("is_published", true)
        .maybeSingle(),
    );
    if (!note) throw new Error("This note is not published.");
    // Never return raw private refs. Resolve/signed URLs only AFTER the course grant check.
    const [videoUrl, fileUrl, description] = await Promise.all([
      youtubeId(batch.videos[data.noteId])
        ? Promise.resolve(protectVideoUrl(batch.videos[data.noteId]))
        : resolveContentUrl(batch.videos[data.noteId] || null),
      resolveContentUrl(note.file_url),
      readNoteBody(note).then(resolveNoteImages),
    ]);
    return {
      video_url: videoUrl,
      note: {
        id: note.id,
        title: note.title,
        subject: note.subject,
        chapter: note.chapter,
        material_type: note.material_type,
        file_url: fileUrl,
        description,
      },
    };
  });
