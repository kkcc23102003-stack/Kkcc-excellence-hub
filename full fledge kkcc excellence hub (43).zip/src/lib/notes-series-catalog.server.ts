import { projectContent } from "./project-content.server";
import { notesSeriesSchema, type NotesSeries } from "./notes-series";
import { readNotesCatalogSetting } from "./notes-catalog-storage.server";

const PREFIX = "notes_series_v1:";

/** Reads the private Notes Series catalogue for server-only administrative tasks. */
export async function readAdminNotesSeriesCatalog() {
  const { data, error } = await projectContent
    .from("site_settings")
    .select("key,value")
    .ilike("key", `${PREFIX}%`);
  if (error) throw new Error(error.message);
  return Promise.all(
    (data ?? [])
      .filter((row) => row.key.startsWith(PREFIX))
      .map(async (row) => {
        const id = row.key.slice(PREFIX.length);
        const stored = await readNotesCatalogSetting<NotesSeries>({
          table: "site_settings",
          key: row.key,
          kind: "series",
          id,
          value: row.value,
        });
        return notesSeriesSchema.parse(stored.data);
      }),
  );
}
