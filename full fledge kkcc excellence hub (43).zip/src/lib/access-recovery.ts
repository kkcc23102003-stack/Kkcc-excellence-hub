export type RecoveryState = "active" | "expired" | "revoked" | "pending";
export type RecoveryValidity =
  { mode: "keep" } | { mode: "days"; days: number } | { mode: "lifetime" };

export function accessRecoveryState(
  value: {
    status?: string | null;
    revoked_at?: string | null;
    expires_at?: string | null;
  },
  now = Date.now(),
): RecoveryState {
  if (value.revoked_at || value.status === "revoked") return "revoked";
  if (value.status === "pending") return "pending";
  if (value.status === "expired") return "expired";
  if (value.expires_at) {
    const expires = Date.parse(value.expires_at);
    if (!Number.isFinite(expires) || expires <= now) return "expired";
  }
  return "active";
}

export function recoveryExpiry(
  currentExpiry: string | null,
  validity: RecoveryValidity,
  now = Date.now(),
): string | null {
  if (validity.mode === "lifetime") return null;
  if (validity.mode === "keep") {
    if (currentExpiry && Date.parse(currentExpiry) <= now)
      throw new Error("This access has expired. Choose a renewal period instead.");
    return currentExpiry;
  }
  if (!Number.isInteger(validity.days) || validity.days < 1 || validity.days > 3650)
    throw new Error("Choose a validity between 1 and 3650 days.");
  return new Date(now + validity.days * 86_400_000).toISOString();
}

export function appendAccessRecoveryNote(
  original: string | null | undefined,
  input: {
    action: "restored" | "renewed" | "regranted";
    previousState: RecoveryState;
    previousExpiry: string | null;
    reason: string;
    adminEmail: string;
    at?: string;
  },
): string {
  const at = input.at ?? new Date().toISOString();
  const previous = input.previousExpiry ?? "lifetime";
  const entry = `[Access ${input.action} ${at} by ${input.adminEmail}] Previous state: ${input.previousState}; previous expiry: ${previous}; reason: ${input.reason.trim()}`;
  return [original?.trim(), entry].filter(Boolean).join("\n");
}
