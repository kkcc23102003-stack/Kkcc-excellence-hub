/** Small authored checkpoints stored with a note, never student attempts/results. */
export const MAX_NOTE_PRACTICE_QUESTIONS = 200;
export type NotePracticeQuestion = {
  id: string;
  topic: string;
  question: string;
  options: string[];
  correctIndex: number | null;
  answer: string;
  explanation: string;
  /** -1 = after the note; otherwise the 0-based source line after which to practice. */
  afterLine: number;
  /** Exact source-line fingerprint: never attach a moved question to an unrelated line. */
  afterText: string;
};
export type NotePracticeGroup = {
  key: string;
  topic: string;
  afterLine: number;
  questions: NotePracticeQuestion[];
};

/** Revision token only. Server recomputes it from the authorised saved note. */
export function notePracticeVersion(question: NotePracticeQuestion): string {
  const text = JSON.stringify(question);
  let hash = 2166136261;
  for (let index = 0; index < text.length; index++)
    hash = Math.imul(hash ^ text.charCodeAt(index), 16777619) >>> 0;
  return hash.toString(16).padStart(8, "0");
}

const LIMITS = {
  topic: 100,
  question: 500000,
  option: 500000,
  answer: 500000,
  explanation: 500000,
  anchor: 600,
};

/** Reject malformed/out-of-budget metadata rather than rendering arbitrary JSON as questions. */
export function parseNotePracticeQuestion(input: unknown): NotePracticeQuestion | null {
  if (!input || typeof input !== "object" || Array.isArray(input)) return null;
  const value = input as Record<string, unknown>;
  const field = (key: string, limit: number): string | null => {
    const text = value[key];
    return typeof text === "string" && text.length <= limit ? text.trim() : null;
  };
  const id = field("id", 64);
  const topic = field("topic", LIMITS.topic);
  const question = field("question", LIMITS.question);
  const explanation = field("explanation", LIMITS.explanation);
  const answer = field("answer", LIMITS.answer);
  const afterText = field("afterText", LIMITS.anchor);
  const afterLine = value["afterLine"];
  const options = value["options"];
  const correctIndex = value["correctIndex"];
  if (
    !id ||
    !/^[a-zA-Z0-9_-]{1,64}$/.test(id) ||
    !topic ||
    !question ||
    explanation === null ||
    answer === null ||
    afterText === null ||
    !Number.isSafeInteger(afterLine) ||
    (afterLine as number) < -1 ||
    (afterLine as number) > 10_000 ||
    (afterLine === -1 ? afterText !== "" : !afterText) ||
    !Array.isArray(options) ||
    options.length > 4 ||
    options.some(
      (option) => typeof option !== "string" || !option.trim() || option.length > LIMITS.option,
    )
  )
    return null;
  if (options.length > 0) {
    if (
      options.length < 2 ||
      !Number.isInteger(correctIndex) ||
      (correctIndex as number) < 0 ||
      (correctIndex as number) >= options.length
    )
      return null;
  } else if (!answer || correctIndex !== null) return null;
  return {
    id,
    topic,
    question,
    options: options.map((option: string) => option.trim()),
    correctIndex: options.length ? (correctIndex as number) : null,
    answer: options.length ? "" : answer!,
    explanation,
    afterLine: afterLine as number,
    afterText,
  };
}

export function parseNotePractice(input: unknown): NotePracticeQuestion[] {
  if (!Array.isArray(input)) return [];
  const seen = new Set<string>();
  return input.slice(0, MAX_NOTE_PRACTICE_QUESTIONS).flatMap((entry) => {
    const question = parseNotePracticeQuestion(entry);
    if (!question || seen.has(question.id)) return [];
    seen.add(question.id);
    return [question];
  });
}

/** Re-anchor only when the exact source line is unchanged or uniquely found. */
export function notePracticeGroups(
  source: string,
  questions: readonly NotePracticeQuestion[],
  renderedLines?: ReadonlySet<number>,
): NotePracticeGroup[] {
  const lines = (source ?? "").replace(/\r\n?/g, "\n").split("\n");
  const groups = new Map<string, NotePracticeGroup>();
  for (const question of questions) {
    let afterLine = question.afterLine;
    if (afterLine >= 0) {
      if (lines[afterLine]?.trim() !== question.afterText) {
        const matches = lines.flatMap((line, index) =>
          line.trim() === question.afterText ? [index] : [],
        );
        afterLine = matches.length === 1 ? matches[0]! : -1;
      }
      if (renderedLines && !renderedLines.has(afterLine)) afterLine = -1;
    }
    const key = `${afterLine}\u0000${question.topic}`;
    let group = groups.get(key);
    if (!group) {
      group = { key, topic: question.topic, afterLine, questions: [] };
      groups.set(key, group);
    }
    group.questions.push(question);
  }
  return [...groups.values()];
}
