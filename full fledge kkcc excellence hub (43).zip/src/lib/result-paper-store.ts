import { createHash } from "node:crypto";
import type { LearningAttemptRow } from "@/integrations/supabase/db";
import type { buildSelectedPaper } from "./learning.server";

export type ResultPaper = Awaited<ReturnType<typeof buildSelectedPaper>>;
export type ResultPaperReference = {
  attempt_id: string;
  path: string;
  sha256: string;
  bytes: number;
};
export const MAX_RESULT_PAPER_BYTES = 16 * 1024 * 1024;
const UUID = /^[a-f0-9]{8}-[a-f0-9]{4}-[1-8][a-f0-9]{3}-[89ab][a-f0-9]{3}-[a-f0-9]{12}$/;
const SHA256 = /^[a-f0-9]{64}$/;
const META_REF = "__kkcc_meta__:";
/** New attempts marked at insert time cannot fall back to today's source if
 * the snapshot upload/metadata write fails after the attempt was recorded.
 * Older unmarked attempts retain the documented source-based fallback.
 */
export const SNAPSHOT_REQUIRED_SUFFIX = ":snapshot=v1";
export function requiresSealedResultPaper(row: Pick<LearningAttemptRow, "source_refs">): boolean {
  return (row.source_refs || []).some(
    (ref) => ref.startsWith(META_REF) && ref.endsWith(SNAPSHOT_REQUIRED_SUFFIX),
  );
}

export function resultPaperHash(bytes: Buffer): string {
  return createHash("sha256").update(bytes).digest("hex");
}

/** A different or reordered source must never silently change a saved attempt's grading. */
export function assertPaperMatchesAttempt(
  row: Pick<LearningAttemptRow, "id" | "source_refs" | "question_count">,
  paper: ResultPaper,
): void {
  const ids = (row.source_refs || []).filter((ref) => !ref.startsWith(META_REF));
  if (
    (row.question_count > 0 && row.question_count !== paper.questions.length) ||
    (ids.length > 0 &&
      (ids.length !== paper.questions.length ||
        ids.some((id, index) => id !== paper.questions[index]?.id)))
  ) {
    throw new Error(
      `Attempt ${row.id} no longer matches its original question IDs/order. Restore the original source; results were not regraded.`,
    );
  }
}

function validatePaper(paper: unknown): asserts paper is ResultPaper {
  if (!paper || typeof paper !== "object" || !("test" in paper) || !("questions" in paper))
    throw new Error("Invalid result paper");
  const value = paper as { test: unknown; questions: unknown };
  if (!value.test || typeof value.test !== "object" || !Array.isArray(value.questions))
    throw new Error("Invalid result paper");
  const seen = new Set<string>();
  for (const entry of value.questions) {
    if (!entry || typeof entry !== "object") throw new Error("Invalid result paper question");
    const question = entry as {
      id?: unknown;
      question_text?: unknown;
      options?: unknown;
      correct_index?: unknown;
      explanation?: unknown;
      marks?: unknown;
      negative_marks?: unknown;
    };
    if (
      typeof question.id !== "string" ||
      !question.id ||
      seen.has(question.id) ||
      typeof question.question_text !== "string" ||
      !Array.isArray(question.options) ||
      !question.options.every((option) => typeof option === "string") ||
      !Number.isInteger(question.correct_index) ||
      (question.correct_index as number) < 0 ||
      (question.correct_index as number) >= question.options.length ||
      typeof question.explanation !== "string" ||
      typeof question.marks !== "number" ||
      !Number.isFinite(question.marks) ||
      typeof question.negative_marks !== "number" ||
      !Number.isFinite(question.negative_marks)
    )
      throw new Error("Invalid result paper question");
    seen.add(question.id);
  }
}

/** Serialization is immutable and retains the full question text, answer and explanation. */
export function sealResultPaper(attemptId: string, paper: ResultPaper) {
  if (!UUID.test(attemptId)) throw new Error("Invalid attempt ID for result paper");
  validatePaper(paper);
  const bytes = Buffer.from(JSON.stringify({ attempt_id: attemptId, paper }), "utf8");
  if (bytes.length < 1 || bytes.length > MAX_RESULT_PAPER_BYTES)
    throw new Error("Result paper exceeds private Storage limit; no questions were cleared.");
  return { bytes, sha256: resultPaperHash(bytes) };
}

/** Reject path traversal or foreign attempt references before reading from Storage. */
export function validateResultPaperReference(reference: ResultPaperReference): void {
  if (
    !UUID.test(reference.attempt_id) ||
    !UUID.test(reference.path.slice(reference.attempt_id.length + 1, -5)) ||
    !reference.path.startsWith(`${reference.attempt_id}/`) ||
    !reference.path.endsWith(".json") ||
    !SHA256.test(reference.sha256) ||
    !Number.isSafeInteger(reference.bytes) ||
    reference.bytes < 1 ||
    reference.bytes > MAX_RESULT_PAPER_BYTES
  )
    throw new Error("Invalid result paper reference");
}

/** Reject tampered bytes, wrong attempt IDs and malformed papers. */
export function openResultPaper(bytes: Buffer, reference: ResultPaperReference): ResultPaper {
  validateResultPaperReference(reference);
  if (bytes.length !== reference.bytes || resultPaperHash(bytes) !== reference.sha256)
    throw new Error("Result paper verification failed; restore backup.");
  let doc: unknown;
  try {
    doc = JSON.parse(bytes.toString("utf8"));
  } catch {
    throw new Error("Invalid result paper JSON; restore backup.");
  }
  if (
    !doc ||
    typeof doc !== "object" ||
    !("attempt_id" in doc) ||
    doc.attempt_id !== reference.attempt_id ||
    !("paper" in doc)
  )
    throw new Error("Invalid result paper attempt ID");
  validatePaper(doc.paper);
  return doc.paper;
}
