import { PDFDocument, StandardFonts, degrees, rgb } from "pdf-lib";
import { MAX_PDF_BYTES, parsePageSelection } from "./document-studio";
import { brandPdfDocument } from "./pdf-brand";

export async function readPdfFile(file: File): Promise<Uint8Array> {
  if (file.size > MAX_PDF_BYTES)
    throw new Error("Each PDF must be under 40 MB. Work with a smaller batch on mobile.");
  const bytes = new Uint8Array(await file.arrayBuffer());
  if (!new TextDecoder().decode(bytes.slice(0, 1024)).includes("%PDF-"))
    throw new Error(`${file.name} is not a PDF.`);
  return bytes;
}
export async function loadEditablePdf(bytes: Uint8Array) {
  try {
    const pdf = await PDFDocument.load(bytes);
    if (pdf.getPageCount() > 500) throw new Error("Limit: 500 pages per structural operation.");
    return pdf;
  } catch (error) {
    if (error instanceof Error && /encrypt/i.test(error.message))
      throw new Error(
        "Password-protected PDFs cannot be edited here. Export an unlocked copy using its owner password first.",
      );
    throw error;
  }
}
export type PdfAction = "extract" | "delete" | "reverse" | "rotate" | "watermark" | "optimise";
export async function transformPdf(
  bytes: Uint8Array,
  action: PdfAction,
  selection = "",
  rotation = 90,
  watermark = "KKCC",
) {
  const source = await loadEditablePdf(bytes),
    count = source.getPageCount();
  if (action === "optimise") {
    const data = await source.save({ useObjectStreams: true });
    return data.length < bytes.length ? data : bytes.slice();
  }
  const chosen = parsePageSelection(selection, count);
  if (action === "rotate" && ![90, 180, 270].includes(rotation))
    throw new Error("Rotation must be 90, 180 or 270 degrees.");
  const ids =
    action === "reverse"
      ? Array.from({ length: count }, (_, i) => count - 1 - i)
      : action === "delete"
        ? Array.from({ length: count }, (_, i) => i).filter((i) => !chosen.includes(i))
        : action === "extract"
          ? chosen
          : Array.from({ length: count }, (_, i) => i);
  if (!ids.length) throw new Error("At least one page must remain. Select fewer pages to delete.");
  const output = await PDFDocument.create();
  for (const page of await output.copyPages(source, ids)) output.addPage(page);
  if (action === "rotate")
    for (const index of new Set(chosen)) {
      const page = output.getPage(index);
      page.setRotation(degrees((page.getRotation().angle + rotation) % 360));
    }
  if (action === "watermark") {
    if (!watermark.trim() || !/^[\x20-\x7E]{1,80}$/.test(watermark))
      throw new Error("Watermark: use 1–80 English letters, numbers or punctuation.");
    const font = await output.embedFont(StandardFonts.HelveticaBold);
    for (const index of new Set(chosen)) {
      const page = output.getPage(index),
        { width, height } = page.getSize();
      const size = Math.min(28, (width * 0.75) / Math.max(1, font.widthOfTextAtSize(watermark, 1)));
      page.drawText(watermark, {
        x: width * 0.12,
        y: height * 0.45,
        size,
        font,
        color: rgb(0.2, 0.4, 0.3),
        opacity: 0.2,
        rotate: degrees(25),
      });
    }
  }
  const data = await output.save({ useObjectStreams: true });
  return data;
}
export async function mergePdfFiles(files: Uint8Array[]) {
  if (files.length < 2) throw new Error("Choose at least two PDFs to merge.");
  if (files.reduce((n, b) => n + b.length, 0) > 120 * 1024 * 1024)
    throw new Error("Merge input is limited to 120 MB total.");
  const out = await PDFDocument.create();
  for (const bytes of files) {
    const source = await loadEditablePdf(bytes);
    if (out.getPageCount() + source.getPageCount() > 500)
      throw new Error("Merge output limited to 500 pages.");
    for (const page of await out.copyPages(source, source.getPageIndices())) out.addPage(page);
  }
  return out.save();
}
export async function imagesToPdf(images: { bytes: Uint8Array; type: string }[]) {
  if (!images.length) throw new Error("Choose JPG/PNG images first.");
  const pdf = await PDFDocument.create();
  for (const image of images) {
    const embedded =
      image.type === "image/png"
        ? await pdf.embedPng(image.bytes)
        : await pdf.embedJpg(image.bytes);
    const page = pdf.addPage([595.28, 841.89]);
    const fit = embedded.scale(Math.min(555.28 / embedded.width, 801.89 / embedded.height));
    page.drawImage(embedded, {
      x: (595.28 - fit.width) / 2,
      y: (841.89 - fit.height) / 2,
      width: fit.width,
      height: fit.height,
    });
  }
  return pdf.save();
}

export async function splitPdfZip(bytes: Uint8Array) {
  const source = await loadEditablePdf(bytes);
  if (source.getPageCount() > 100)
    throw new Error("Split ZIP is limited to 100 pages; extract a smaller range first.");
  const { default: JSZip } = await import("jszip");
  const zip = new JSZip();
  let size = 0;
  for (const index of source.getPageIndices()) {
    const out = await PDFDocument.create();
    const [page] = await out.copyPages(source, [index]);
    out.addPage(page!);
    await brandPdfDocument(out);
    const data = await out.save();
    size += data.length;
    if (size > 120 * 1024 * 1024)
      throw new Error("Split output exceeds 120 MB; work with fewer pages.");
    zip.file(`page-${String(index + 1).padStart(3, "0")}.pdf`, data);
  }
  return zip.generateAsync({ type: "uint8array", compression: "DEFLATE" });
}
