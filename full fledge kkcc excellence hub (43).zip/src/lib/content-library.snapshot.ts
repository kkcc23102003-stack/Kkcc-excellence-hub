import { randomUUID } from "node:crypto";
import type { TestQuestionRow, TestRow } from "@/integrations/supabase/db";
import {
  getCustomChapterConfig,
  type CustomChapterQuestion,
  type CustomSeriesCatalog,
} from "@/lib/test-series-catalog";
import {
  generateCustomSyllabusPaper,
  isLegacyScienceFallbackForNonScienceSubject,
} from "@/lib/generated-test";

export type SnapshotQuestion = Pick<
  TestQuestionRow,
  | "question_text"
  | "subject"
  | "options"
  | "correct_index"
  | "marks"
  | "negative_marks"
  | "explanation"
>;

function normalizeQuestion(value: string) {
  return value.trim().toLocaleLowerCase().replace(/\s+/g, " ");
}

function customQuestionSnapshot(
  question: CustomChapterQuestion,
  subject: string,
): SnapshotQuestion {
  return {
    question_text: question.question_text,
    subject,
    options: [...question.options],
    correct_index: question.correct_index,
    marks: question.marks ?? 1,
    negative_marks: question.negative_marks ?? 0,
    explanation: question.explanation ?? "",
  };
}

function uniqueSnapshotQuestions(questions: SnapshotQuestion[]): SnapshotQuestion[] {
  const seen = new Set<string>();
  return questions.filter((question) => {
    const key = normalizeQuestion(question.question_text);
    if (!key || seen.has(key)) return false;
    seen.add(key);
    return true;
  });
}

/** Build an independent, bounded question snapshot for a copied Course/Test draft. */
export function snapshotSeriesChapter(input: {
  catalog: CustomSeriesCatalog;
  seriesId?: string;
  exam: string;
  subject: string;
  chapter: string;
  count: number;
  difficulty?: TestRow["generation_difficulty"];
  marks?: number;
  negativeMarks?: number;
  manualQuestions?: TestQuestionRow[];
}): SnapshotQuestion[] {
  const custom = getCustomChapterConfig(
    input.seriesId,
    input.subject,
    input.chapter,
    input.catalog,
  );
  const customQuestions = (custom?.questions ?? [])
    .filter(
      (question) =>
        !isLegacyScienceFallbackForNonScienceSubject(
          question.question_text,
          input.subject,
          input.chapter,
        ),
    )
    .map((question) => customQuestionSnapshot(question, input.subject));
  const manualQuestions = (input.manualQuestions ?? [])
    .filter(
      (question) =>
        !question.subject ||
        question.subject === "General" ||
        normalizeQuestion(question.subject) === normalizeQuestion(input.subject),
    )
    .map((question) => ({
      question_text: question.question_text,
      subject: input.subject,
      options: [...question.options],
      correct_index: question.correct_index,
      marks: question.marks,
      negative_marks: question.negative_marks,
      explanation: question.explanation,
    }));
  const curated = uniqueSnapshotQuestions([...customQuestions, ...manualQuestions]);

  if (custom?.mode === "custom_only") {
    const cap = custom.questionCount
      ? Math.min(curated.length, custom.questionCount)
      : curated.length;
    return curated.slice(0, cap);
  }

  const targetCount = Math.max(1, Math.min(200, Math.floor(input.count)));
  const priority = curated.slice(0, targetCount);
  const remaining = Math.max(0, targetCount - priority.length);
  if (remaining === 0) return priority;
  const generated = generateCustomSyllabusPaper({
    exam: input.exam,
    subject: input.subject,
    topic: input.chapter,
    difficulty: input.difficulty ?? "Mixed",
    count: remaining,
    marks: input.marks ?? 1,
    negative_marks: input.negativeMarks ?? 0,
    seed: randomUUID(),
  })
    .filter(
      (question) =>
        !isLegacyScienceFallbackForNonScienceSubject(
          question.question_text,
          input.subject,
          input.chapter,
        ),
    )
    .map((question) => ({
      question_text: question.question_text,
      subject: input.subject,
      options: [...question.options],
      correct_index: question.correct_index,
      marks: question.marks,
      negative_marks: question.negative_marks,
      explanation: question.explanation,
    }));
  return uniqueSnapshotQuestions([...priority, ...generated]).slice(0, targetCount);
}
