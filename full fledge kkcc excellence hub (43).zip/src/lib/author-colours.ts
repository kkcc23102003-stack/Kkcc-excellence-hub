/* Strict, portable colour values for Notes and Tests. Never trust authored CSS. */
// Restrained ink, teal and warm-gold presets inspired by the existing KKCC
// palette. Legacy named colours and any saved custom HEX stay fully supported.
export const AUTHOR_SWATCHES = [
  "#172b36",
  "#0f766e",
  "#315b82",
  "#684f7d",
  "#a44148",
  "#23634d",
  "#7b571e",
  "#ffffff", // for authors writing on dark surfaces
] as const;

export const LEGACY_INKS: Readonly<Record<string, string>> = {
  teal: "#0f766e",
  blue: "#1d4ed8",
  purple: "#7e22ce",
  red: "#b91c1c",
  green: "#166534",
};

export function normaliseAuthorColour(input: string): string | null {
  const value = input.trim().toLowerCase();
  if (value in LEGACY_INKS) return LEGACY_INKS[value]!;
  if (/^#[0-9a-f]{3}$/.test(value))
    return `#${value[1]}${value[1]}${value[2]}${value[2]}${value[3]}${value[3]}`;
  return /^#[0-9a-f]{6}$/.test(value) ? value : null;
}

export function hsvToHex(hue: number, saturation: number, brightness: number): string {
  const h = (((Number.isFinite(hue) ? hue : 0) % 360) + 360) % 360;
  const s = Math.max(0, Math.min(1, (Number.isFinite(saturation) ? saturation : 0) / 100));
  const v = Math.max(0, Math.min(1, (Number.isFinite(brightness) ? brightness : 0) / 100));
  const chroma = v * s;
  const x = chroma * (1 - Math.abs(((h / 60) % 2) - 1));
  const m = v - chroma;
  const [r, g, b] =
    h < 60
      ? [chroma, x, 0]
      : h < 120
        ? [x, chroma, 0]
        : h < 180
          ? [0, chroma, x]
          : h < 240
            ? [0, x, chroma]
            : h < 300
              ? [x, 0, chroma]
              : [chroma, 0, x];
  return `#${[r, g, b]
    .map((channel) =>
      Math.round((channel + m) * 255)
        .toString(16)
        .padStart(2, "0"),
    )
    .join("")}`;
}

export function mixAuthorColours(first: string, second: string, amount: number): string {
  const left = normaliseAuthorColour(first) ?? "#000000";
  const right = normaliseAuthorColour(second) ?? "#ffffff";
  const ratio = Math.max(0, Math.min(1, (Number.isFinite(amount) ? amount : 0) / 100));
  return `#${[1, 3, 5]
    .map((i) =>
      Math.round(
        parseInt(left.slice(i, i + 2), 16) * (1 - ratio) +
          parseInt(right.slice(i, i + 2), 16) * ratio,
      )
        .toString(16)
        .padStart(2, "0"),
    )
    .join("")}`;
}

export function authorContrast(colour: string, background: string): number {
  const luminance = (hex: string) => {
    const value = normaliseAuthorColour(hex) ?? "#000000";
    const channels = [1, 3, 5].map((i) => {
      const x = parseInt(value.slice(i, i + 2), 16) / 255;
      return x <= 0.04045 ? x / 12.92 : ((x + 0.055) / 1.055) ** 2.4;
    });
    return channels[0]! * 0.2126 + channels[1]! * 0.7152 + channels[2]! * 0.0722;
  };
  const a = luminance(colour),
    b = luminance(background);
  return (Math.max(a, b) + 0.05) / (Math.min(a, b) + 0.05);
}

/** Existing notes use bracket tokens rather than unsafe HTML. The same tokens can live in test strings. */
export function wrapAuthorSelection(
  text: string,
  kind: "color" | "highlight",
  colour: string,
): string {
  const safe = normaliseAuthorColour(colour);
  if (!safe) return text;
  return `[${kind}=${safe}]${text || "Text"}[/${kind}]`;
}

export function clearAuthorColour(text: string, kind: "color" | "highlight"): string {
  const pattern = new RegExp(`^\\[${kind}=[^\\]\\n]+\\]([\\s\\S]*)\\[\\/${kind}\\]$`);
  return text.replace(pattern, "$1");
}
