import { GetObjectCommand, S3Client } from "@aws-sdk/client-s3";
import { Buffer } from "node:buffer";
import { supabaseAdmin } from "@/integrations/supabase/client.server";
import {
  projectContent,
  type AIContentRow,
  flushProjectContentCaches,
} from "@/lib/project-content.server";
import {
  AI_QUESTION_ARCHIVE_BUCKET,
  MAX_AI_QUESTION_ARCHIVE_BYTES,
  decodeArchivedAIQuestion,
  encodeArchivedAIQuestion,
  type ArchivedAIQuestion,
} from "./ai-question-archive-store";

export type { ArchivedAIQuestion } from "./ai-question-archive-store";

function assertSafeKey(key: string) {
  if (!/^kkcc-question-bank\/v1\/[0-9a-f]{2}\/[0-9a-f-]{36}\.json$/i.test(key))
    throw new Error("AI archive object path is invalid.");
}

async function privateSupabaseBucket() {
  const { data, error } = await supabaseAdmin.storage.getBucket(AI_QUESTION_ARCHIVE_BUCKET);
  if (error || !data || data.public)
    throw new Error(
      `Private AI archive bucket unavailable. Run the latest Supabase SQL bundle before using the AI question engine. ${error?.message || ""}`,
    );
  return supabaseAdmin.storage.from(AI_QUESTION_ARCHIVE_BUCKET);
}

/** Write and read back the full question object before saving its compact DB index. */
export async function putArchivedQuestion(question: ArchivedAIQuestion) {
  const encoded = encodeArchivedAIQuestion(question);
  const storage = await privateSupabaseBucket();
  const { error } = await storage.upload(encoded.key, encoded.bytes, {
    contentType: "application/json",
    cacheControl: "0",
    upsert: false,
  });
  // A retry for the same immutable candidate is safe only if the existing object
  // already has the exact expected hash. Never overwrite a different payload.
  if (error) {
    const { data: existing, error: existingError } = await storage.download(encoded.key);
    if (existingError || !existing)
      throw new Error(`Supabase AI archive upload failed: ${error.message}`);
    const existingBytes = Buffer.from(await existing.arrayBuffer());
    decodeArchivedAIQuestion(encoded.key, existingBytes, encoded.content_hash);
  }
  const { data, error: readError } = await storage.download(encoded.key);
  if (readError || !data)
    throw new Error(
      `Supabase AI archive read-back failed: ${readError?.message || "missing object"}`,
    );
  const verified = Buffer.from(await data.arrayBuffer());
  if (verified.byteLength > MAX_AI_QUESTION_ARCHIVE_BYTES)
    throw new Error("Supabase AI archive read-back exceeded the object size limit.");
  decodeArchivedAIQuestion(encoded.key, verified, encoded.content_hash);
  return {
    key: encoded.key,
    provider: "supabase",
    bucket: AI_QUESTION_ARCHIVE_BUCKET,
    content_hash: encoded.content_hash,
  };
}

async function legacyExternalSettings(archiveProvider: string) {
  if (!["aws_s3", "cloudflare_r2", "backblaze_b2", "wasabi", "minio"].includes(archiveProvider))
    throw new Error("This legacy AI archive provider is not supported.");
  const [publicRows, privateRows] = await Promise.all([
    projectContent
      .from("site_settings")
      .select("key,value")
      .in("key", ["storage_bucket", "storage_region", "storage_endpoint"]),
    projectContent
      .from("private_settings")
      .select("key,value")
      .in("key", ["storage_access_key_id", "storage_secret_access_key"]),
  ]);
  if (publicRows.error || privateRows.error)
    throw new Error(
      publicRows.error?.message || privateRows.error?.message || "Archive settings failed.",
    );
  const values = new Map(
    [...publicRows.data, ...privateRows.data].map((row) => [row.key, row.value]),
  );
  const bucket = values.get("storage_bucket") || "";
  const endpoint = values.get("storage_endpoint") || "";
  const accessKeyId = values.get("storage_access_key_id") || "";
  const secretAccessKey = values.get("storage_secret_access_key") || "";
  if (!bucket || !accessKeyId || !secretAccessKey)
    throw new Error(
      "Legacy external archive credentials/bucket are unavailable. Keep the existing archive configuration until it is migrated.",
    );
  return {
    bucket,
    client: new S3Client({
      region: values.get("storage_region") || "auto",
      ...(endpoint ? { endpoint } : {}),
      forcePathStyle: archiveProvider !== "aws_s3",
      credentials: { accessKeyId, secretAccessKey },
    }),
  };
}

/** Read legacy external objects only when an existing DB index names that provider. */
export async function getArchivedQuestion(
  key: string,
  archiveProvider = "supabase",
  expectedHash?: string | null,
): Promise<ArchivedAIQuestion> {
  assertSafeKey(key);
  let bytes: Buffer;
  if (archiveProvider === "supabase") {
    const storage = await privateSupabaseBucket();
    const { data, error } = await storage.download(key);
    if (error || !data) throw new Error(error?.message || "AI archive object is missing.");
    bytes = Buffer.from(await data.arrayBuffer());
  } else {
    // Compatibility for old records. New candidates are always saved to Supabase Storage.
    const legacy = await legacyExternalSettings(archiveProvider);
    const out = await legacy.client.send(new GetObjectCommand({ Bucket: legacy.bucket, Key: key }));
    if (typeof out.ContentLength === "number" && out.ContentLength > MAX_AI_QUESTION_ARCHIVE_BYTES)
      throw new Error("Legacy AI archive object exceeds the 256 KB limit.");
    const text = await out.Body?.transformToString();
    if (!text) throw new Error("Legacy AI archive object is empty or missing.");
    bytes = Buffer.from(text, "utf8");
  }
  return decodeArchivedAIQuestion(key, bytes, expectedHash);
}

export async function removeArchivedQuestion(key: string) {
  assertSafeKey(key);
  const storage = await privateSupabaseBucket();
  const { error } = await storage.remove([key]);
  if (error) throw new Error(`Supabase AI archive cleanup failed: ${error.message}`);
}

async function countRows(
  query: PromiseLike<{ count: number | null; error: { message: string } | null }>,
) {
  const result = await query;
  if (result.error) throw new Error(result.error.message);
  return result.count ?? 0;
}

export async function archiveStatus() {
  const [{ data, error }, legacyInlineCount, nonSupabaseArchiveCount, missingProviderArchiveCount] =
    await Promise.all([
      supabaseAdmin.storage.getBucket(AI_QUESTION_ARCHIVE_BUCKET),
      countRows(
        projectContent
          .from("ai_question_candidates")
          .select("id", { count: "exact", head: true })
          .is("archive_key", null),
      ),
      countRows(
        projectContent
          .from("ai_question_candidates")
          .select("id", { count: "exact", head: true })
          .neq("archive_provider", "supabase"),
      ),
      countRows(
        projectContent
          .from("ai_question_candidates")
          .select("id", { count: "exact", head: true })
          .is("archive_provider", null)
          .neq("archive_key", null),
      ),
    ]);
  const legacyExternalCount = nonSupabaseArchiveCount + missingProviderArchiveCount;
  return {
    configured: !error && Boolean(data) && data?.public === false,
    provider: "Supabase Storage",
    bucket: AI_QUESTION_ARCHIVE_BUCKET,
    legacyInlineCount,
    legacyExternalCount,
    ...(error?.message ? { message: error.message } : {}),
  };
}

function inlineQuestion(row: AIContentRow): ArchivedAIQuestion {
  const options = row.options;
  if (!row.prompt || !options || !row.explanation)
    throw new Error("Legacy AI candidate is missing inline question content.");
  return {
    id: row.id,
    prompt: row.prompt,
    options,
    correct_index: row.correct_index,
    explanation: row.explanation,
    exam: row.exam,
    subject: row.subject,
    topic: row.topic,
    difficulty: row.difficulty as ArchivedAIQuestion["difficulty"],
    quality_score: row.quality_score,
    source_urls: Array.isArray(row.source_urls)
      ? row.source_urls.filter((url): url is string => typeof url === "string")
      : [],
    source_notes: row.source_notes || "",
    created_at: row.created_at,
  };
}

async function legacyCandidateQuestion(row: AIContentRow) {
  if (row.archive_key && row.archive_provider === "project") return inlineQuestion(row);
  if (row.archive_key && !row.archive_provider)
    throw new Error("Archive provider metadata is missing; source content was left unchanged.");
  if (row.archive_key)
    return getArchivedQuestion(row.archive_key, row.archive_provider!, row.content_hash);
  return inlineQuestion(row);
}

/** Explicit Admin-only migration. Legacy content stays until a verified object and CAS row update succeed. */
export async function migrateLegacyAIQuestionArchive(limit = 50) {
  const batchSize = Math.max(1, Math.min(100, Math.floor(limit)));
  const [inlineRows, nonSupabaseRows, missingProviderRows] = await Promise.all([
    projectContent
      .from("ai_question_candidates")
      .select("*")
      .is("archive_key", null)
      .order("created_at", { ascending: true })
      .limit(batchSize),
    projectContent
      .from("ai_question_candidates")
      .select("*")
      .neq("archive_provider", "supabase")
      .order("created_at", { ascending: true })
      .limit(batchSize),
    projectContent
      .from("ai_question_candidates")
      .select("*")
      .is("archive_provider", null)
      .order("created_at", { ascending: true })
      .limit(batchSize),
  ]);
  for (const result of [inlineRows, nonSupabaseRows, missingProviderRows])
    if (result.error) throw new Error(`Legacy AI candidate list failed: ${result.error.message}`);

  const uniqueRows = new Map<string, AIContentRow>();
  for (const row of [
    ...(inlineRows.data ?? []),
    ...(nonSupabaseRows.data ?? []),
    ...(missingProviderRows.data ?? []),
  ]) {
    if (!row.archive_key || row.archive_provider !== "supabase" || !row.content_hash)
      uniqueRows.set(row.id, row);
  }
  const candidates = [...uniqueRows.values()].slice(0, batchSize);
  let migrated = 0;
  const errors: { id: string; message: string }[] = [];
  for (const row of candidates) {
    let uploaded: Awaited<ReturnType<typeof putArchivedQuestion>> | undefined;
    try {
      const question = await legacyCandidateQuestion(row);
      uploaded = await putArchivedQuestion(question);
      const { data, error } = await projectContent
        .from("ai_question_candidates")
        .update({
          prompt: null,
          options: null,
          explanation: null,
          source_urls: [],
          source_notes: "",
          archive_key: uploaded.key,
          archive_provider: "supabase",
          content_hash: uploaded.content_hash,
        } as Partial<AIContentRow>)
        .eq("id", row.id)
        .eq("updated_at", row.updated_at)
        .select("id")
        .maybeSingle();
      if (error) throw new Error(error.message);
      if (!data) throw new Error("Candidate changed during migration; reload and retry.");
      migrated += 1;
    } catch (error) {
      if (uploaded && (row.archive_provider !== "supabase" || row.archive_key !== uploaded.key)) {
        try {
          await removeArchivedQuestion(uploaded.key);
        } catch {
          // Unreferenced immutable objects are safe to clean up later; never delete DB history.
        }
      }
      errors.push({ id: row.id, message: error instanceof Error ? error.message : String(error) });
    }
  }
  if (migrated) flushProjectContentCaches();
  return {
    migrated,
    attempted: candidates.length,
    errors,
    status: await archiveStatus(),
  };
}
