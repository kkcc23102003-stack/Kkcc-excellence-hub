import { z } from "zod";

export const MAX_PDF_BYTES = 40 * 1024 * 1024;
export function parsePageSelection(input: string, total: number): number[] {
  if (!Number.isInteger(total) || total < 1 || total > 500)
    throw new Error("PDF must have 1–500 pages.");
  if (!input.trim()) return Array.from({ length: total }, (_, i) => i);
  const pages: number[] = [];
  for (const token of input.split(",")) {
    const match = token.trim().match(/^(\d+)(?:\s*-\s*(\d+))?$/);
    if (!match) throw new Error("Use page numbers/ranges, e.g. 3,1-2. Page numbers start at 1.");
    const first = Number(match[1]),
      last = Number(match[2] ?? match[1]);
    if (first < 1 || last < 1 || first > total || last > total)
      throw new Error(`Pages must be between 1 and ${total}.`);
    const step = last >= first ? 1 : -1;
    for (let p = first; ; p += step) {
      pages.push(p - 1);
      if (pages.length > 500) throw new Error("Output limited to 500 pages.");
      if (p === last) break;
    }
  }
  return pages;
}
export function safeFilename(value: string) {
  return (
    value
      .replace(/[^\p{L}\p{N} ._-]/gu, "")
      .trim()
      .slice(0, 100) || "KKCC-document"
  );
}
export function downloadFile(
  data: Blob | Uint8Array | string,
  filename: string,
  type = "application/octet-stream",
) {
  const blob =
    data instanceof Blob
      ? data
      : new Blob([typeof data === "string" ? data : new Uint8Array(data)], { type });
  const url = URL.createObjectURL(blob),
    link = document.createElement("a");
  link.href = url;
  link.download = safeFilename(filename);
  document.body.append(link);
  link.click();
  link.remove();
  setTimeout(() => URL.revokeObjectURL(url), 15_000);
}
export const DEFAULT_SLIDE_SIZE = { width: 1280, height: 720 };
export const slideSizeSchema = z
  .object({
    width: z.number().int().min(320).max(2560),
    height: z.number().int().min(320).max(2560),
  })
  .refine(
    (s) =>
      s.width * s.height <= 4_000_000 && s.width / s.height >= 1 / 3 && s.width / s.height <= 3,
    "Choose dimensions up to 4 megapixels with aspect ratio between 1:3 and 3:1.",
  );
export const DEFAULT_SLIDE_BRAND = {
  appName: "Kusum Kartik Coaching Centre",
  series: "Brahmastra",
  subject: "Science",
  teacher: "Kartik",
};
export const slideBrandSchema = z.object({
  appName: z.string().max(100),
  series: z.string().max(100),
  subject: z.string().max(100),
  teacher: z.string().max(100),
});
const colour = z.string().regex(/^#[0-9a-fA-F]{6}$/);
// v1 stays readable: text remains plain; optional runs carry selected-character styles.
const slideTextRun = z.object({
  text: z.string().min(1).max(12000),
  bold: z.boolean().optional(),
  italic: z.boolean().optional(),
  underline: z.boolean().optional(),
  color: colour.optional(),
});
const element = z
  .object({
    id: z.string().uuid(),
    type: z.enum(["text", "image", "rectangle", "ellipse"]),
    x: z.number().min(0).max(99.9),
    y: z.number().min(0).max(99.9),
    w: z.number().min(0.1).max(100),
    h: z.number().min(0.1).max(100),
    text: z.string().max(12000).default(""),
    runs: z.array(slideTextRun).max(1500).optional(),
    image: z
      .string()
      .max(4_000_000)
      .regex(/^$|^data:image\/(png|jpeg);base64,[A-Za-z0-9+/=]+$/)
      .default(""),
    colour,
    fill: colour,
    fontSize: z.number().min(10).max(140),
    font: z.enum(["sans", "display", "condensed"]).optional(),
    italic: z.boolean().optional(),
    glow: z.boolean().optional(),
    opacity: z.number().min(0).max(1).optional(),
    role: z.enum(["content", "brand", "decoration"]).optional(),
    slot: z.enum(["appName", "series", "teacher", "subject", "logo", "title", "body"]).optional(),
    bold: z.boolean(),
    align: z.enum(["left", "center", "right"]),
  })
  .refine((v) => v.x + v.w <= 100.01 && v.y + v.h <= 100.01, "Element must fit inside the slide.")
  .refine(
    (v) => !v.runs || (v.type === "text" && v.runs.map((run) => run.text).join("") === v.text),
    "Styled text must match the editable slide text.",
  );
export const deckSchema = z
  .object({
    version: z.literal(1),
    size: slideSizeSchema.optional(),
    brand: slideBrandSchema.optional(),
    title: z.string().min(1).max(150),
    slides: z
      .array(
        z.object({
          id: z.string().uuid(),
          background: colour,
          design: z.enum(["legacy", "galaxy", "paper", "teal", "sunset", "royal"]).optional(),
          purpose: z.enum(["lesson", "cover", "thumbnail"]).optional(),
          generated: z.boolean().optional(),
          hidePageNumber: z.boolean().optional(),
          // Optional stable template marker. Old saved projects remain valid without it.
          templateId: z
            .string()
            .regex(/^[a-z0-9-]{1,80}$/)
            .optional(),
          notes: z.string().max(10000),
          elements: z.array(element).max(40),
        }),
      )
      .min(1)
      .max(60),
  })
  .superRefine((deck, ctx) => {
    const total = deck.slides.reduce(
      (n, s) =>
        n +
        s.elements.reduce(
          (a, e) =>
            a + e.image.length + e.text.length + (e.runs ? JSON.stringify(e.runs).length : 0),
          0,
        ),
      0,
    );
    if (total > 24_000_000)
      ctx.addIssue({
        code: "custom",
        message: "Project exceeds 24 MB of image/text data. Split or optimise it.",
      });
    const ids = new Set<string>();
    for (const slide of deck.slides) {
      for (const id of [slide.id, ...slide.elements.map((e) => e.id)]) {
        if (ids.has(id)) ctx.addIssue({ code: "custom", message: "Duplicate slide/element ID" });
        ids.add(id);
      }
    }
  });
export type Deck = z.infer<typeof deckSchema>;
export type Slide = Deck["slides"][number];
export type SlideElement = Slide["elements"][number];
export function textElement(text = "New text", y = 22): SlideElement {
  return {
    id: crypto.randomUUID(),
    type: "text",
    x: 7,
    y,
    w: 86,
    h: 20,
    text,
    image: "",
    colour: "#173e32",
    fill: "#dff3e9",
    fontSize: 36,
    bold: false,
    align: "left",
  };
}
export function makeSlide(template = "lesson"): Slide {
  const title = {
    ...textElement(template === "quiz" ? "Check your understanding" : "Lesson title", 18),
    fontSize: 48,
    bold: true,
  };
  const body = {
    ...textElement(
      template === "quiz"
        ? "Write your question here\n\nA. Option one\nB. Option two\nC. Option three\nD. Option four"
        : "• Add your main idea\n• Explain with an example\n• Summarise the key point",
      40,
    ),
    h: 48,
    fontSize: 30,
  };
  return {
    id: crypto.randomUUID(),
    background: template === "title" ? "#e6f5ee" : "#ffffff",
    notes: "",
    elements: template === "blank" ? [] : template === "title" ? [title] : [title, body],
  };
}
export function cloneSlide(slide: Slide): Slide {
  const copy = structuredClone(slide);
  return {
    ...copy,
    id: crypto.randomUUID(),
    elements: copy.elements.map((e) => ({ ...e, id: crypto.randomUUID() })),
  };
}

export function invertHex(value: string): string {
  if (!/^#[0-9a-f]{6}$/i.test(value)) throw new Error("Invalid colour");
  return (
    "#" +
    [1, 3, 5]
      .map((i) => (255 - parseInt(value.slice(i, i + 2), 16)).toString(16).padStart(2, "0"))
      .join("")
  );
}
