import { openBrowserPdf, renderPdfPage } from "./pdf-browser";
import {
  CUSTOM_PAMPHLET_MAX_PAGES,
  pamphletSlideSize,
  type CustomPamphletPage,
} from "./custom-pamphlet";
import type { SlideSize } from "./presentation-design";

const MAX_SOURCE_BYTES = 25 * 1024 * 1024;
const MAX_SINGLE_IMAGE_BYTES = 12 * 1024 * 1024;
const MAX_PIXELS = 40_000_000;
const MAX_IMAGE_CHARS = 390_000;

export type ImportedPamphlet = {
  pages: CustomPamphletPage[];
  size: SlideSize;
  mixedRatios: boolean;
};

/** Browser-local import. Canva's original artwork is preserved as an image; no OCR or network. */
function encodeArtwork(
  source: CanvasImageSource,
  sourceWidth: number,
  sourceHeight: number,
  size: SlideSize,
) {
  const canvas = document.createElement("canvas");
  canvas.width = size.width;
  canvas.height = size.height;
  const ctx = canvas.getContext("2d");
  if (!ctx) throw new Error("This browser cannot edit image canvases.");
  ctx.fillStyle = "#ffffff";
  ctx.fillRect(0, 0, size.width, size.height);
  const scale = Math.min(size.width / sourceWidth, size.height / sourceHeight);
  const drawW = sourceWidth * scale,
    drawH = sourceHeight * scale;
  ctx.drawImage(source, (size.width - drawW) / 2, (size.height - drawH) / 2, drawW, drawH);
  try {
    const png = canvas.toDataURL("image/png");
    if (png.length <= MAX_IMAGE_CHARS) return png; // Keep crisp Canva typography if possible.
    for (const quality of [0.9, 0.82, 0.74, 0.64]) {
      const jpg = canvas.toDataURL("image/jpeg", quality);
      if (jpg.length <= MAX_IMAGE_CHARS) return jpg;
    }
    // Dense photos need fewer pixels for 24-MB editable projects and Android memory.
    const shrink = 1100 / Math.max(size.width, size.height);
    const reduced = document.createElement("canvas");
    reduced.width = Math.max(1, Math.round(size.width * shrink));
    reduced.height = Math.max(1, Math.round(size.height * shrink));
    try {
      const smaller = reduced.getContext("2d");
      if (!smaller) throw new Error("This browser cannot compress the artwork.");
      smaller.drawImage(canvas, 0, 0, reduced.width, reduced.height);
      for (const quality of [0.82, 0.72, 0.62]) {
        const jpg = reduced.toDataURL("image/jpeg", quality);
        if (jpg.length <= MAX_IMAGE_CHARS) return jpg;
      }
    } finally {
      reduced.width = 0;
      reduced.height = 0;
    }
    throw new Error(
      "This page has too much visual detail. Export it from Canva as a smaller PDF/JPG and retry.",
    );
  } finally {
    canvas.width = 0;
    canvas.height = 0;
  }
}
function kind(file: File): "pdf" | "image" | "unsupported" {
  const name = file.name.toLowerCase();
  if (file.type === "application/pdf" || name.endsWith(".pdf")) return "pdf";
  if (
    ["image/jpeg", "image/png", "image/webp"].includes(file.type) ||
    /\.(?:png|jpe?g|webp)$/.test(name)
  )
    return "image";
  return "unsupported";
}
export async function importPamphletArtwork(
  files: readonly File[],
  progress: (done: number, total: number) => void = () => {},
  cancelled: () => boolean = () => false,
): Promise<ImportedPamphlet> {
  if (!files.length || files.length > CUSTOM_PAMPHLET_MAX_PAGES)
    throw new Error(`Choose 1–${CUSTOM_PAMPHLET_MAX_PAGES} Canva pages.`);
  if (files.some((file) => !file.size)) throw new Error("An uploaded file is empty.");
  if (files.reduce((total, file) => total + file.size, 0) > MAX_SOURCE_BYTES)
    throw new Error("Canva upload is over 25 MB. Export smaller JPG/PDF pages.");
  const types = files.map(kind);
  if (types.includes("unsupported"))
    throw new Error(
      "Choose Canva PNG/JPG/WEBP images or PDF Standard. For Canva PPTX, export PDF first; direct PPTX import is not supported.",
    );
  if (types.includes("pdf") && files.length !== 1)
    throw new Error("Select one Canva PDF at a time, or select up to 12 images together.");
  if (types[0] === "pdf") {
    const file = files[0]!;
    let pdf;
    try {
      pdf = await openBrowserPdf(new Uint8Array(await file.arrayBuffer()));
    } catch {
      throw new Error("Cannot read this PDF. Export an unprotected Canva PDF Standard and retry.");
    }
    try {
      if (pdf.numPages < 1 || pdf.numPages > CUSTOM_PAMPHLET_MAX_PAGES)
        throw new Error(
          `Canva PDF must have 1–${CUSTOM_PAMPHLET_MAX_PAGES} pages. Split a longer PDF first.`,
        );
      const first = await pdf.getPage(1);
      const view = first.getViewport({ scale: 1 });
      const size = pamphletSlideSize(view.width, view.height);
      const pages: CustomPamphletPage[] = [];
      let mixedRatios = false;
      for (let n = 1; n <= pdf.numPages; n++) {
        if (cancelled()) throw new Error("Import cancelled. Your previous project is unchanged.");
        progress(n - 1, pdf.numPages);
        const page = await pdf.getPage(n);
        const viewport = page.getViewport({ scale: 1 });
        if (Math.abs(viewport.width / viewport.height - size.width / size.height) > 0.015)
          mixedRatios = true;
        const factor = Math.min(
          2,
          Math.min(size.width / viewport.width, size.height / viewport.height),
        );
        const { canvas } = await renderPdfPage(pdf, n, factor);
        try {
          pages.push({
            name: `${file.name.replace(/\.pdf$/i, "")} · page ${n}`,
            image: encodeArtwork(canvas, canvas.width, canvas.height, size),
          });
        } finally {
          canvas.width = 0;
          canvas.height = 0;
        }
        progress(n, pdf.numPages);
        await new Promise((resolve) => setTimeout(resolve, 0));
      }
      return { pages, size, mixedRatios };
    } finally {
      await pdf.loadingTask.destroy();
    }
  }
  const pages: CustomPamphletPage[] = [];
  let size: SlideSize | undefined;
  let mixedRatios = false;
  for (const [index, file] of files.entries()) {
    if (file.size > MAX_SINGLE_IMAGE_BYTES)
      throw new Error("One image exceeds 12 MB. Export a smaller image from Canva.");
    if (cancelled()) throw new Error("Import cancelled. Your previous project is unchanged.");
    progress(index, files.length);
    let bitmap: ImageBitmap;
    try {
      bitmap = await createImageBitmap(file);
    } catch {
      throw new Error(`Cannot open ${file.name}. Export a standard PNG or JPG from Canva.`);
    }
    try {
      if (bitmap.width * bitmap.height > MAX_PIXELS)
        throw new Error("Image over 40 megapixels. Resize it before uploading.");
      size ??= pamphletSlideSize(bitmap.width, bitmap.height);
      if (Math.abs(bitmap.width / bitmap.height - size.width / size.height) > 0.015)
        mixedRatios = true;
      pages.push({
        name: file.name,
        image: encodeArtwork(bitmap, bitmap.width, bitmap.height, size),
      });
    } finally {
      bitmap.close();
    }
    progress(index + 1, files.length);
    await new Promise((resolve) => setTimeout(resolve, 0));
  }
  return { pages, size: size!, mixedRatios };
}
