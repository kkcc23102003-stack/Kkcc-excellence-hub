/** Unicode keys only; changing languages never rewrites or translates existing notes. */
export const NOTE_LANGUAGES = [
  {
    id: "en",
    label: "English",
    rows: [
      "q w e r t y u i o p",
      "a s d f g h j k l",
      "z x c v b n m",
      "0 1 2 3 4 5 6 7 8 9 . , ? !",
    ],
  },
  {
    id: "hi",
    label: "हिन्दी — Hindi",
    rows: [
      "अ आ इ ई उ ऊ ऋ ए ऐ ओ औ",
      "क ख ग घ ङ च छ ज झ ञ",
      "ट ठ ड ढ ण त थ द ध न",
      "प फ ब भ म य र ल व श ष स ह",
      "ा ि ी ु ू ृ े ै ो ौ ं ँ ः ् ़",
      "ड़ ढ़ क्ष त्र ज्ञ श्र ॐ । ० १ २ ३ ४ ५ ६ ७ ८ ९",
    ],
  },
  {
    id: "pa",
    label: "ਪੰਜਾਬੀ — Punjabi (Gurmukhi)",
    rows: [
      "ੳ ਅ ੲ ਸ ਹ ਆ ਇ ਈ ਉ ਊ ਏ ਐ ਓ ਔ",
      "ਕ ਖ ਗ ਘ ਙ ਚ ਛ ਜ ਝ ਞ",
      "ਟ ਠ ਡ ਢ ਣ ਤ ਥ ਦ ਧ ਨ",
      "ਪ ਫ ਬ ਭ ਮ ਯ ਰ ਲ ਵ ੜ",
      "ਸ਼ ਖ਼ ਗ਼ ਜ਼ ਫ਼ ਲ਼",
      "ਾ ਿ ੀ ੁ ੂ ੇ ੈ ੋ ੌ ੰ ਂ ੱ ਼ ੍",
      "ੴ । ੦ ੧ ੨ ੩ ੪ ੫ ੬ ੭ ੮ ੯",
    ],
  },
  {
    id: "ur",
    label: "اردو — Urdu / Shahmukhi",
    rows: [
      "ا آ ب پ ت ٹ ث ج چ ح خ",
      "د ڈ ذ ر ڑ ز ژ س ش ص ض",
      "ط ظ ع غ ف ق ک گ ل م ن ں",
      "و ؤ ہ ھ ء ی ئ ے ۓ",
      "َ ِ ُ ّ ْ ۔ ، ؟ ۰ ۱ ۲ ۳ ۴ ۵ ۶ ۷ ۸ ۹",
    ],
  },
  { id: "other", label: "Other languages — device keyboard / paste", rows: [] },
] as const;
export type NoteLanguage = (typeof NOTE_LANGUAGES)[number]["id"];
export function editNoteSelection(
  value: string,
  start: number,
  end: number,
  insertion: string,
  maxLength = 1500000,
  backspace = false,
) {
  let from = Math.max(0, Math.min(start, value.length));
  const to = Math.max(from, Math.min(end, value.length));
  if (backspace && from === to && from > 0) {
    const previous = Array.from(value.slice(0, from)).at(-1)!;
    from -= previous.length; // Do not split surrogate pairs (e.g. emoji).
  }
  const text = value.slice(0, from) + insertion + value.slice(to);
  return text.length > maxLength ? null : { text, caret: from + insertion.length };
}
