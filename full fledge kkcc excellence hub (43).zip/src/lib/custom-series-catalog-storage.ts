import { Buffer } from "node:buffer";
import { createHash } from "node:crypto";
import { parseCustomSeriesCatalog, type CustomSeriesCatalog } from "./test-series-catalog";

export const CUSTOM_SERIES_CATALOG_BUCKET = "kkcc-test-series-catalog";
export const CUSTOM_SERIES_CATALOG_POINTER_PREFIX = "kkcc-storage-json:v1:";
export const MAX_CUSTOM_SERIES_CATALOG_BYTES = 20_000_000;

export type CustomSeriesCatalogPointer = {
  bucket: typeof CUSTOM_SERIES_CATALOG_BUCKET;
  path: string;
  sha256: string;
  bytes: number;
};

export type CustomSeriesCatalogStorageIO = {
  write: (path: string, bytes: Buffer) => Promise<void>;
  read: (path: string) => Promise<Buffer>;
  compareAndSwap: (oldValue: string, newValue: string) => Promise<boolean>;
  readCurrentValue: () => Promise<string | null>;
};

const sha256 = (bytes: Buffer) => createHash("sha256").update(bytes).digest("hex");
const objectPath = (hash: string) => `catalog/v1/${hash}.json`;

export function parseCustomSeriesCatalogPointer(value: string): CustomSeriesCatalogPointer | null {
  if (!value.startsWith(CUSTOM_SERIES_CATALOG_POINTER_PREFIX)) return null;
  let pointer: CustomSeriesCatalogPointer;
  try {
    pointer = JSON.parse(
      value.slice(CUSTOM_SERIES_CATALOG_POINTER_PREFIX.length),
    ) as CustomSeriesCatalogPointer;
  } catch {
    throw new Error(
      "Test-series Storage pointer is invalid. Restore its Database backup before editing.",
    );
  }
  if (
    pointer.bucket !== CUSTOM_SERIES_CATALOG_BUCKET ||
    !/^[a-f0-9]{64}$/.test(pointer.sha256) ||
    pointer.path !== objectPath(pointer.sha256) ||
    !Number.isSafeInteger(pointer.bytes) ||
    pointer.bytes < 2 ||
    pointer.bytes > MAX_CUSTOM_SERIES_CATALOG_BYTES
  ) {
    throw new Error("Test-series Storage pointer is outside its private catalogue path.");
  }
  return pointer;
}

function encodeCatalog(catalog: CustomSeriesCatalog) {
  const bytes = Buffer.from(JSON.stringify(catalog), "utf8");
  if (bytes.byteLength > MAX_CUSTOM_SERIES_CATALOG_BYTES)
    throw new Error("The custom test-series catalogue exceeds the 20 MB Storage limit.");
  const digest = sha256(bytes);
  const pointer: CustomSeriesCatalogPointer = {
    bucket: CUSTOM_SERIES_CATALOG_BUCKET,
    path: objectPath(digest),
    sha256: digest,
    bytes: bytes.byteLength,
  };
  return {
    bytes,
    value: `${CUSTOM_SERIES_CATALOG_POINTER_PREFIX}${JSON.stringify(pointer)}`,
  };
}

function decodeCatalog(bytes: Buffer, pointer: CustomSeriesCatalogPointer) {
  if (
    bytes.byteLength !== pointer.bytes ||
    bytes.byteLength > MAX_CUSTOM_SERIES_CATALOG_BYTES ||
    sha256(bytes) !== pointer.sha256
  )
    throw new Error(
      "Test-series Storage integrity check failed. The Database pointer was not changed.",
    );
  let raw: unknown;
  try {
    raw = JSON.parse(bytes.toString("utf8"));
  } catch {
    throw new Error(
      "Test-series JSON in Supabase Storage is invalid. The Database pointer was not changed.",
    );
  }
  if (!raw || typeof raw !== "object" || Array.isArray(raw))
    throw new Error("Test-series JSON in Supabase Storage has an invalid structure.");
  return parseCustomSeriesCatalog(raw);
}

function parseLegacyCatalog(value: string) {
  if (Buffer.byteLength(value, "utf8") > MAX_CUSTOM_SERIES_CATALOG_BYTES)
    throw new Error("Legacy test-series catalogue exceeds the 20 MB Storage limit.");
  let raw: unknown;
  try {
    raw = JSON.parse(value);
  } catch {
    throw new Error(
      "Legacy test-series catalogue JSON is invalid. No Database content was removed.",
    );
  }
  if (!raw || typeof raw !== "object" || Array.isArray(raw))
    throw new Error("Legacy test-series catalogue has an invalid structure.");
  return parseCustomSeriesCatalog(raw);
}

/** Upload immutable JSON and return the compact value suitable for a settings row. */
export async function writeCustomSeriesCatalogObject(
  io: Pick<CustomSeriesCatalogStorageIO, "write" | "read">,
  catalog: CustomSeriesCatalog,
) {
  const encoded = encodeCatalog(catalog);
  const pointer = parseCustomSeriesCatalogPointer(encoded.value)!;
  await io.write(pointer.path, encoded.bytes);
  decodeCatalog(await io.read(pointer.path), pointer);
  return encoded.value;
}

/**
 * Read a pointer or safely migrate a legacy JSON settings value. The object is
 * verified before compare-and-swap; a concurrent Admin save always wins.
 */
export async function readCustomSeriesCatalogValue(
  io: CustomSeriesCatalogStorageIO,
  value: string,
  retries = 0,
): Promise<{ data: CustomSeriesCatalog; storedValue: string }> {
  const pointer = parseCustomSeriesCatalogPointer(value);
  if (pointer)
    return { data: decodeCatalog(await io.read(pointer.path), pointer), storedValue: value };

  const legacy = parseLegacyCatalog(value);
  const nextValue = await writeCustomSeriesCatalogObject(io, legacy);
  if (await io.compareAndSwap(value, nextValue)) return { data: legacy, storedValue: nextValue };

  if (retries >= 4)
    throw new Error(
      "Test-series catalogue changed repeatedly during Storage migration. Reload and retry.",
    );
  const current = await io.readCurrentValue();
  if (current === null)
    throw new Error(
      "Test-series catalogue row disappeared during Storage migration. No content was deleted.",
    );
  if (current === value)
    throw new Error("Test-series catalogue pointer could not be updated. Retry the request.");
  return readCustomSeriesCatalogValue(io, current, retries + 1);
}
