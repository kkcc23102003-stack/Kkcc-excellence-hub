import { materialAccessMode } from "./material-access-mode";
import { projectContent } from "@/lib/project-content.server";
import { effectiveSeries, readStudentAccess, unwrap } from "@/lib/learning.server";
import { coinPriceOf } from "@/lib/cms";
import { applySharedBatchPriceToCourse } from "@/lib/notes-batch-pricing.server";
import { resolveServerCouponDiscount } from "@/lib/coupons.functions";
import {
  grantCoinPackPurchase,
  grantLearningPurchase,
  hasLearningAccess,
  loadCoinPack,
  resolveLearningPrice,
  type LearningKind,
} from "@/lib/learning-purchase.server";
import { readRazorpayCredentials, verifyRazorpayPayment } from "@/lib/razorpay.server";
import {
  claimRazorpayPayment,
  markPaymentPaid,
  markRazorpayPaymentClaimPaid,
  releaseRazorpayPaymentClaim,
} from "@/lib/payment-ledger.server";
import { materialForStudent } from "@/lib/material-access.server";
import { createServerFn } from "@tanstack/react-start";
import { createClient } from "@supabase/supabase-js";
import type { SupabaseClient } from "@supabase/supabase-js";
import { z } from "zod";
import { requireSupabaseAuth } from "@/integrations/supabase/auth-middleware";
import type {
  CoinPackageRow,
  CoinTransactionRow,
  DB as Database,
  ProfileRow,
} from "@/integrations/supabase/db";
import { getSupabasePublicConfig } from "@/integrations/supabase/env";
import { createSupabaseFetch } from "@/integrations/supabase/fetch";

function publicClient() {
  const config = getSupabasePublicConfig();
  if (!config) return null;

  return createClient<Database>(config.url, config.publishableKey, {
    auth: { storage: undefined, persistSession: false, autoRefreshToken: false },
    global: { fetch: createSupabaseFetch(config.publishableKey) },
  });
}

const emailOrUserSchema = z.object({
  email: z.string().trim().email().optional(),
  user_id: z.string().uuid().optional(),
  amount: z.number().int().min(1).max(10_000_000),
  reason: z.string().trim().max(600).default("Admin 23KAAT grant"),
  related_type: z.string().trim().max(80).optional().default(""),
  related_id: z.string().uuid().nullable().optional(),
});

const courseSpendSchema = z.object({
  course_id: z.string().uuid(),
  expected_coins: z.number().int().min(0).max(1_000_000).optional(),
  coupon_code: z.string().trim().max(40).optional().default(""),
});
const seriesSpendSchema = z.object({
  series_id: z.string().trim().min(1).max(120),
  expected_coins: z.number().int().min(0).max(1_000_000).optional(),
  coupon_code: z.string().trim().max(40).optional().default(""),
});
const notesSeriesSpendSchema = z.object({
  notes_series_id: z.string().uuid(),
  expected_coins: z.number().int().min(0).max(1_000_000).optional(),
  coupon_code: z.string().trim().max(40).optional().default(""),
});
const testSpendSchema = z.object({
  test_id: z.string().uuid(),
  expected_coins: z.number().int().min(0).max(1_000_000).optional(),
  coupon_code: z.string().trim().max(40).optional().default(""),
});
const razorpayCompleteSchema = z.object({
  kind: z.enum(["course", "series", "notes_series", "test", "material"]),
  item_id: z.string().trim().min(1).max(120),
  coupon_code: z.string().trim().max(40).optional().default(""),
  razorpay_payment_id: z.string().trim().min(3).max(200),
  razorpay_order_id: z.string().trim().min(1).max(200),
  razorpay_signature: z.string().trim().min(1).max(500),
});
const razorpayCoinPackSchema = z.object({
  package_id: z.string().uuid(),
  razorpay_payment_id: z.string().trim().min(3).max(200),
  razorpay_order_id: z.string().trim().min(1).max(200),
  razorpay_signature: z.string().trim().min(1).max(500),
});
const materialSchema = z.object({ material_id: z.string().uuid() });
const materialSpendSchema = materialSchema.extend({
  expected_coins: z.number().int().min(0).max(1_000_000).optional(),
  coupon_code: z.string().trim().max(40).optional().default(""),
});

async function assertAdmin(context: { supabase: SupabaseClient<Database>; userId: string }) {
  const { data, error } = await context.supabase.rpc("has_role", {
    _user_id: context.userId,
    _role: "admin",
  });
  if (error || !data) throw new Error("Forbidden — admin access required");
}

async function findProfileByEmailOrId(
  supabase: SupabaseClient<Database>,
  payload: { user_id?: string | undefined; email?: string | undefined },
) {
  if (payload.user_id) {
    const { data, error } = await supabase
      .from("profiles")
      .select("*")
      .eq("id", payload.user_id)
      .maybeSingle();
    if (error) throw new Error(error.message);
    if (!data) throw new Error("Student profile not found. Ask the student to sign up once first.");
    return data as ProfileRow;
  }

  const email = payload.email?.toLowerCase();
  if (!email) throw new Error("Student email or user ID is required.");
  const { data, error } = await supabase
    .from("profiles")
    .select("*")
    .ilike("email", email)
    .limit(5);
  if (error) throw new Error(error.message);
  const profile = (data ?? []).find((item) => item.email.toLowerCase() === email);
  if (!profile) throw new Error("Student not found. Ask the student to sign up once first.");
  return profile as ProfileRow;
}

type CoinRpcResult = {
  ok: boolean;
  locked: boolean;
  already_owned: boolean;
  free: boolean;
  spent: number;
  amount: number;
  balance: number;
  price: number;
  file_url: string;
  reason: string;
};

function toNumber(value: unknown) {
  const number = Number(value);
  return Number.isFinite(number) ? number : 0;
}

function jsonResult(value: unknown): CoinRpcResult {
  const row = value && typeof value === "object" ? (value as Record<string, unknown>) : {};
  return {
    ok: Boolean(row["ok"]),
    locked: Boolean(row["locked"]),
    already_owned: Boolean(row["already_owned"]),
    free: Boolean(row["free"]),
    spent: toNumber(row["spent"]),
    amount: toNumber(row["amount"]),
    balance: toNumber(row["balance"]),
    price: toNumber(row["price"]),
    file_url: typeof row["file_url"] === "string" ? row["file_url"] : "",
    reason: typeof row["reason"] === "string" ? row["reason"] : "",
  };
}

export const list23KaatCoinPackages = createServerFn({ method: "GET" }).handler(async () => {
  const supabase = publicClient();
  if (!supabase) return [] as CoinPackageRow[];

  const { data, error } = await supabase
    .from("coin_packages")
    .select("*")
    .eq("is_active", true)
    .order("sort_order", { ascending: true })
    .order("price", { ascending: true });
  if (error) throw new Error(error.message);
  return (data ?? []) as CoinPackageRow[];
});

export const getMy23KaatWallet = createServerFn({ method: "GET" })
  .middleware([requireSupabaseAuth])
  .handler(async ({ context }) => {
    const [
      { data: balanceData, error: balanceError },
      { data: txs, error: txError },
      packagesResult,
    ] = await Promise.all([
      context.supabase.rpc("get_23kaat_balance", { _user_id: context.userId }),
      context.supabase
        .from("coin_transactions")
        .select("*")
        .eq("user_id", context.userId)
        .order("created_at", { ascending: false })
        .limit(20),
      context.supabase
        .from("coin_packages")
        .select("*")
        .eq("is_active", true)
        .order("sort_order", { ascending: true })
        .order("price", { ascending: true }),
    ]);

    if (balanceError) throw new Error(balanceError.message);
    if (txError) throw new Error(txError.message);
    if (packagesResult.error) throw new Error(packagesResult.error.message);

    return {
      balance: Number(balanceData ?? 0),
      transactions: (txs ?? []) as CoinTransactionRow[],
      packages: packagesResult.data ?? [],
    };
  });

export const adminGrant23Kaat = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .validator((input: unknown) => emailOrUserSchema.parse(input))
  .handler(async ({ context, data }) => {
    await assertAdmin(context);
    const profile = await findProfileByEmailOrId(context.supabase, data);
    const { data: result, error } = await context.supabase.rpc("grant_23kaat_to_user", {
      _user_id: profile.id,
      _amount: data.amount,
      _reason: data.reason,
      _related_type: data.related_type || "admin_grant",
      _related_id: data.related_id ?? null,
    });
    if (error) throw new Error(error.message);
    return { ...jsonResult(result), email: profile.email, full_name: profile.full_name };
  });

export const adminList23KaatLedger = createServerFn({ method: "GET" })
  .middleware([requireSupabaseAuth])
  .validator((input: unknown) =>
    z.object({ query: z.string().trim().max(120).default("") }).parse(input ?? {}),
  )
  .handler(async ({ context, data }) => {
    await assertAdmin(context);
    const [{ data: txs, error: txError }, { data: profiles, error: profileError }] =
      await Promise.all([
        context.supabase
          .from("coin_transactions")
          .select("*")
          .order("created_at", { ascending: false })
          .limit(300),
        context.supabase.from("profiles").select("*").limit(500),
      ]);
    if (txError) throw new Error(txError.message);
    if (profileError) throw new Error(profileError.message);

    const profileById = new Map((profiles ?? []).map((profile) => [profile.id, profile]));
    const query = data.query.toLowerCase();
    return ((txs ?? []) as CoinTransactionRow[])
      .map((tx) => ({ ...tx, student: profileById.get(tx.user_id) ?? null }))
      .filter((tx) => {
        if (!query) return true;
        const student = tx.student as ProfileRow | null;
        return [student?.full_name, student?.email, tx.reason, tx.source]
          .join(" ")
          .toLowerCase()
          .includes(query);
      });
  });

export const spend23KaatForCourse = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .validator((input: unknown) => courseSpendSchema.parse(input))
  .handler(async ({ context, data }) => {
    const course = unwrap(
      await projectContent
        .from("courses")
        .select("*")
        .eq("id", data.course_id)
        .eq("status", "published")
        .single(),
    );
    const pricedCourse = await applySharedBatchPriceToCourse(course);
    const baseCoins = coinPriceOf(pricedCourse);
    if (baseCoins <= 0) throw new Error("This Batch has no 23KAAT coin price configured.");
    const couponInfo = data.coupon_code
      ? await resolveServerCouponDiscount({
          code: data.coupon_code,
          targetCourseId: course.id,
          targetItemId: course.id,
          originalAmountInr: Math.max(0, pricedCourse.price ?? 0),
          originalCoins: baseCoins,
          userId: context.userId,
          recordRedemption: true,
        })
      : null;
    const effectiveCoins = couponInfo ? couponInfo.finalCoins : baseCoins;
    if (
      data.expected_coins !== undefined &&
      data.expected_coins !== effectiveCoins &&
      data.expected_coins !== baseCoins
    )
      throw new Error("Course coin price changed. Refresh checkout before paying.");
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    const { data: result, error } = await supabaseAdmin.rpc("purchase_learning_item", {
      p_actor: context.userId,
      p_kind: "course",
      p_key: course.id,
      p_price: effectiveCoins,
    });
    if (error) throw new Error(error.message);
    return jsonResult(result);
  });

export const spend23KaatForSeries = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .validator((input: unknown) => seriesSpendSchema.parse(input))
  .handler(async ({ context, data }) => {
    const series = await effectiveSeries(data.series_id);
    if (!series.enabled) throw new Error("This test series is currently unavailable.");
    const baseCoins = Math.max(0, series.priceCoins ?? series.priceInr ?? 0);
    const couponInfo = data.coupon_code
      ? await resolveServerCouponDiscount({
          code: data.coupon_code,
          targetCourseId: null,
          targetItemId: series.id,
          originalAmountInr: Math.max(0, series.priceInr ?? 0),
          originalCoins: baseCoins,
          userId: context.userId,
          recordRedemption: true,
        })
      : null;
    const coinPrice = couponInfo ? couponInfo.finalCoins : baseCoins;
    if (
      data.expected_coins !== undefined &&
      data.expected_coins !== coinPrice &&
      data.expected_coins !== baseCoins
    )
      throw new Error("Test series coin price changed. Refresh checkout before paying.");
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    const { data: result, error } = await supabaseAdmin.rpc("purchase_learning_item", {
      p_actor: context.userId,
      p_kind: "series",
      p_key: series.id,
      p_price: coinPrice,
    });
    if (error) throw new Error(error.message);
    return jsonResult(result);
  });

export const spend23KaatForNotesSeries = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .validator((input: unknown) => notesSeriesSpendSchema.parse(input))
  .handler(async ({ context, data }) => {
    if (await hasLearningAccess(context.userId, "notes_series", data.notes_series_id))
      return { ok: true, already_owned: true, spent: 0 };
    const quote = await resolveLearningPrice({
      kind: "notes_series",
      itemId: data.notes_series_id,
      couponCode: data.coupon_code,
      userId: context.userId,
      recordRedemption: Boolean(data.coupon_code),
    });
    if (
      data.expected_coins !== undefined &&
      data.expected_coins !== quote.finalCoins &&
      data.expected_coins !== quote.baseCoins
    )
      throw new Error("Notes Series coin price changed. Refresh checkout before paying.");
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    const { data: result, error } = await supabaseAdmin.rpc("purchase_notes_series_access", {
      p_actor: context.userId,
      p_series_id: data.notes_series_id,
      p_price: quote.finalCoins,
    });
    if (error) throw new Error(error.message);
    return jsonResult(result);
  });

export const spend23KaatForTest = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .validator((input: unknown) => testSpendSchema.parse(input))
  .handler(async ({ context, data }) => {
    const test = unwrap(
      await projectContent
        .from("tests")
        .select("*")
        .eq("id", data.test_id)
        .eq("is_published", true)
        .single(),
    );
    const baseCoins = test.is_paid ? Math.max(0, test.price_coins || test.price_inr || 0) : 0;
    const couponInfo = data.coupon_code
      ? await resolveServerCouponDiscount({
          code: data.coupon_code,
          targetCourseId: null,
          targetItemId: test.id,
          originalAmountInr: Math.max(0, test.price_inr ?? 0),
          originalCoins: baseCoins,
          userId: context.userId,
          recordRedemption: true,
        })
      : null;
    const coinPrice = couponInfo ? couponInfo.finalCoins : baseCoins;
    if (
      data.expected_coins !== undefined &&
      data.expected_coins !== coinPrice &&
      data.expected_coins !== baseCoins
    )
      throw new Error("Test coin price changed. Refresh checkout before paying.");
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    const { data: result, error } = await supabaseAdmin.rpc("purchase_learning_item", {
      p_actor: context.userId,
      p_kind: "test",
      p_key: test.id,
      p_price: coinPrice,
    });
    if (error) throw new Error(error.message);
    return jsonResult(result);
  });

export const completeRazorpayLearningPurchase = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .validator((input: unknown) => razorpayCompleteSchema.parse(input))
  .handler(async ({ context, data }) => {
    const credentials = await readRazorpayCredentials();
    if (!credentials.enabled || !credentials.keyId || !credentials.verifiable) {
      throw new Error(
        "Verified Razorpay checkout is not configured. Please contact Admin for offline payment or use 23KAAT.",
      );
    }

    const kind = data.kind as LearningKind;
    const alreadyUnlocked = await hasLearningAccess(context.userId, kind, data.item_id);

    // 1. Quote the item on the server. A retry must never burn a coupon twice,
    //    so the coupon is skipped entirely when access already exists.
    const quote = await resolveLearningPrice({
      kind,
      itemId: data.item_id,
      couponCode: alreadyUnlocked ? "" : data.coupon_code,
      userId: context.userId,
      recordRedemption: false,
    });

    // 2. Confirm the payment with Razorpay *before* anything is unlocked:
    //    signature, captured status, amount and the student on the order notes.
    const verification = await verifyRazorpayPayment({
      credentials,
      paymentId: data.razorpay_payment_id,
      orderId: data.razorpay_order_id,
      signature: data.razorpay_signature,
      userId: context.userId,
      expectedAmountInr: quote.finalInr,
    });

    if (
      !verification.verified ||
      verification.notes.user_id !== context.userId ||
      verification.notes.kind !== kind ||
      verification.notes.item_id !== quote.item.id
    ) {
      throw new Error(
        `Razorpay could not verify that this captured payment belongs to this student and product. No access was granted. Contact Admin with Payment ID ${verification.paymentId}.`,
      );
    }

    const claim = await claimRazorpayPayment({
      paymentId: data.razorpay_payment_id,
      userId: context.userId,
      kind,
      itemId: quote.item.id,
    });
    if (claim === "already_paid")
      return {
        ok: true,
        kind,
        item_id: quote.item.id,
        amountInr: verification.amountInr,
        title: quote.item.title,
        already_unlocked: true,
        verified: true,
        warning: "",
      };

    try {
      // 3. Record the coupon exactly once, after the money is confirmed.
      let couponNote = quote.note;
      if (quote.coupon && !alreadyUnlocked) {
        try {
          const recorded = await resolveServerCouponDiscount({
            code: quote.coupon.code,
            targetCourseId: kind === "course" ? quote.item.id : null,
            targetItemId: quote.item.id,
            originalAmountInr: quote.baseInr,
            originalCoins: quote.baseCoins,
            userId: context.userId,
            recordRedemption: true,
          });
          couponNote = recorded.coupon
            ? ` · Coupon ${recorded.coupon.code} (${recorded.discountPercent}% OFF)`
            : "";
        } catch (error) {
          // The student has already paid — never block access because the coupon
          // bookkeeping failed. Access is granted at the quoted price.
          console.error("Coupon redemption could not be recorded after payment", error);
        }
      }

      // 4. Grant access. Amount recorded is what Razorpay actually captured when
      //    it differs from the quote (an extra rupee can never lose access).
      const paidAmount = verification.amountInr;

      const granted = await grantLearningPurchase({
        userId: context.userId,
        kind,
        itemId: quote.item.id,
        amountInr: paidAmount,
        couponCode: "",
        reference: `Razorpay payment ${data.razorpay_payment_id}`,
        method: "razorpay",
      });
      await markRazorpayPaymentClaimPaid(data.razorpay_payment_id);
      if (couponNote && verification.verified) {
        // Keep the coupon trail on the enrollment note for the admin ledger.
        const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
        if (kind === "course") {
          await supabaseAdmin
            .from("course_enrollments")
            .update({
              admin_note: `Razorpay payment ${data.razorpay_payment_id}${couponNote}`,
            } as never)
            .eq("user_id", context.userId)
            .eq("course_id", quote.item.id);
        }
      }

      // Ledger: the confirmed payment with the amount Razorpay actually captured.
      await markPaymentPaid({
        userId: context.userId,
        kind,
        itemId: quote.item.id,
        itemTitle: granted.title,
        amountInr: granted.amountInr,
        orderId: verification.orderId || data.razorpay_order_id,
        paymentId: data.razorpay_payment_id,
        couponCode: quote.coupon?.code ?? "",
        note: couponNote ? `Coupon applied${couponNote}` : "",
      });

      console.info(
        `[razorpay] ${kind}:${quote.item.id} ${alreadyUnlocked ? "re-confirmed" : "granted"} for ${context.userId} (captured and API verified)`,
      );

      return {
        ok: true,
        kind: granted.kind,
        item_id: granted.itemId,
        amountInr: granted.amountInr,
        title: granted.title,
        already_unlocked: alreadyUnlocked,
        verified: verification.verified,
        warning: verification.warning,
      };
    } catch (error) {
      await releaseRazorpayPaymentClaim(data.razorpay_payment_id);
      throw error;
    }
  });

export const completeRazorpayCoinPackPurchase = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .validator((input: unknown) => razorpayCoinPackSchema.parse(input))
  .handler(async ({ context, data }) => {
    const credentials = await readRazorpayCredentials();
    if (!credentials.enabled || !credentials.keyId || !credentials.verifiable) {
      throw new Error(
        "Verified Razorpay checkout is not configured. Please contact Admin for offline payment.",
      );
    }

    const pack = await loadCoinPack(data.package_id);
    const verification = await verifyRazorpayPayment({
      credentials,
      paymentId: data.razorpay_payment_id,
      orderId: data.razorpay_order_id,
      signature: data.razorpay_signature,
      userId: context.userId,
      expectedAmountInr: pack.priceInr,
    });
    if (
      !verification.verified ||
      verification.notes.user_id !== context.userId ||
      verification.notes.kind !== "coin_pack" ||
      verification.notes.item_id !== pack.id
    ) {
      throw new Error(
        `Razorpay could not verify that this captured payment belongs to this coin pack. No coins were credited. Contact Admin with Payment ID ${verification.paymentId}.`,
      );
    }

    const claim = await claimRazorpayPayment({
      paymentId: data.razorpay_payment_id,
      userId: context.userId,
      kind: "coin_pack",
      itemId: pack.id,
    });
    if (claim === "already_paid")
      return {
        ok: true,
        already_credited: true,
        credited: pack.totalCoins,
        title: pack.title,
        balance: null,
        verified: true,
      };

    try {
      // A retried callback must not credit the same pack twice.
      const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
      const { count: alreadyCredited } = await supabaseAdmin
        .from("coin_transactions")
        .select("*", { count: "exact", head: true })
        .eq("user_id", context.userId)
        .eq("related_id", pack.id)
        .ilike("reason", `%${data.razorpay_payment_id}%`);

      if ((alreadyCredited ?? 0) > 0) {
        await markRazorpayPaymentClaimPaid(data.razorpay_payment_id);
        return {
          ok: true,
          already_credited: true,
          credited: pack.totalCoins,
          title: pack.title,
          balance: null,
          verified: verification.verified,
        };
      }

      const result = await grantCoinPackPurchase({
        userId: context.userId,
        packageId: pack.id,
        reference: data.razorpay_payment_id,
      });
      await markRazorpayPaymentClaimPaid(data.razorpay_payment_id);

      await markPaymentPaid({
        userId: context.userId,
        kind: "coin_pack",
        itemId: pack.id,
        itemTitle: result.title,
        amountInr: verification.amountInr,
        orderId: verification.orderId || data.razorpay_order_id,
        paymentId: data.razorpay_payment_id,
      });

      return {
        ok: true,
        already_credited: false,
        credited: result.credited,
        title: result.title,
        balance: result.balance,
        verified: verification.verified,
      };
    } catch (error) {
      await releaseRazorpayPaymentClaim(data.razorpay_payment_id);
      throw error;
    }
  });

export const getMyMaterialAccessUrl = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .validator((input: unknown) => materialSchema.parse(input))
  .handler(async ({ context, data }) => {
    return materialForStudent(context, data.material_id);
  });

export const spend23KaatForMaterial = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .validator((input: unknown) => materialSpendSchema.parse(input))
  .handler(async ({ context, data }) => {
    const material = unwrap(
      await projectContent
        .from("materials")
        .select("*")
        .eq("id", data.material_id)
        .eq("is_published", true)
        .single(),
    );
    if (material.is_free_preview)
      throw new Error("This is the free first note for its subject; no purchase is needed.");
    const mode = materialAccessMode(material);
    if (mode === "course") return materialForStudent(context, material.id);
    if (mode !== "paid") return materialForStudent(context, material.id);

    const baseCoins = Math.max(0, Number(material.coin_price) || 0);
    if (baseCoins <= 0) throw new Error("Admin has not configured a 23KAAT price for this note.");
    const couponInfo = data.coupon_code
      ? await resolveServerCouponDiscount({
          code: data.coupon_code,
          targetCourseId: null,
          targetItemId: material.id,
          originalAmountInr: Math.max(0, Number(material.price) || 0),
          originalCoins: baseCoins,
          userId: context.userId,
          recordRedemption: true,
        })
      : null;
    const effectiveCoins = couponInfo ? couponInfo.finalCoins : baseCoins;
    if (
      data.expected_coins !== undefined &&
      data.expected_coins !== effectiveCoins &&
      data.expected_coins !== baseCoins
    ) {
      throw new Error("Notes coin price changed. Refresh checkout before paying.");
    }

    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    const result = unwrap(
      await supabaseAdmin.rpc("purchase_learning_item", {
        p_actor: context.userId,
        p_kind: "material",
        p_key: material.id,
        p_price: effectiveCoins,
      }),
    );
    return {
      ...(result as Record<string, unknown>),
      ...(await materialForStudent(context, material.id)),
    };
  });
