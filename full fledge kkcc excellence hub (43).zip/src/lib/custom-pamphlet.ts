import {
  deckSchema,
  slideSizeSchema,
  textElement,
  type Deck,
  type Slide,
  type SlideElement,
} from "./document-studio";
import {
  approximateMeasure,
  fittedElement,
  wrapSlideText,
  type MeasureText,
  type SlideBrand,
  type SlideSize,
} from "./presentation-design";
import { NOTES_PRINT_LOGO } from "./notes-print-logo";

/** Canva art is intentionally a replaceable image layer. Added lettering stays native/editable. */
export type CustomPamphletPage = { name: string; image: string };
export type CustomPamphletOptions = {
  pages: CustomPamphletPage[];
  size: SlideSize;
  teachingIndex: number;
  keepSourcePages: boolean;
  addBranding: boolean;
  readingPanel: boolean;
  ink: "dark" | "light";
  contentTop: number;
  contentBottom: number;
  title: string;
  topic: string;
  text: string;
  brand: SlideBrand;
};
export const CUSTOM_PAMPHLET_MAX_PAGES = 12;
export const CUSTOM_PAMPHLET_MAX_TEXT = 60_000;

/** Add PDF artwork without replacing, resizing, or changing any existing slide. */
export function insertCustomPdfSlides(
  deck: Deck,
  pages: readonly CustomPamphletPage[],
  afterIndex: number,
): Deck {
  if (!pages.length || pages.length > CUSTOM_PAMPHLET_MAX_PAGES)
    throw new Error(`Choose 1–${CUSTOM_PAMPHLET_MAX_PAGES} PDF pages to add.`);
  if (!Number.isInteger(afterIndex) || afterIndex < 0 || afterIndex >= deck.slides.length)
    throw new Error("Choose an existing slide to insert after.");
  const additions: Slide[] = pages.map((page) => ({
    id: crypto.randomUUID(),
    background: "#ffffff",
    design: "paper",
    purpose: "lesson",
    hidePageNumber: true,
    notes: `Imported PDF artwork: ${page.name.slice(0, 200)}. This page is an image layer; add separate editable text over it.`,
    elements: [
      {
        ...textElement("", 0),
        type: "image",
        image: page.image,
        x: 0,
        y: 0,
        w: 100,
        h: 100,
        role: "decoration",
      },
    ],
  }));
  return deckSchema.parse({
    ...deck,
    slides: [
      ...deck.slides.slice(0, afterIndex + 1),
      ...additions,
      ...deck.slides.slice(afterIndex + 1),
    ],
  });
}

/** Preserve the first Canva page's ratio, within the editor's safe canvas limits. */
export function pamphletSlideSize(width: number, height: number): SlideSize {
  if (
    !Number.isFinite(width) ||
    !Number.isFinite(height) ||
    width < 1 ||
    height < 1 ||
    width / height < 1 / 3 ||
    width / height > 3
  )
    throw new Error("Choose a normal Canva slide ratio (from 1:3 to 3:1).");
  const scale = Math.min(1600, Math.max(1280, width, height)) / Math.max(width, height);
  const size = { width: Math.round(width * scale), height: Math.round(height * scale) };
  // Rounding a 1:3 or 3:1 edge ratio must not push it outside the schema's limit.
  if (size.width * 3 < size.height) size.width = Math.ceil(size.height / 3);
  if (size.height * 3 < size.width) size.height = Math.ceil(size.width / 3);
  return slideSizeSchema.parse(size);
}

function artwork(page: CustomPamphletPage): SlideElement {
  return {
    ...textElement("", 0),
    type: "image",
    x: 0,
    y: 0,
    w: 100,
    h: 100,
    image: page.image,
    fill: "#ffffff",
    role: "decoration",
  };
}
function editableLabel(
  value: string,
  slot: SlideElement["slot"],
  x: number,
  y: number,
  w: number,
  h: number,
  size: number,
  colour: string,
  align: SlideElement["align"] = "left",
): SlideElement {
  return {
    ...textElement(value, y),
    slot,
    role: "brand",
    x,
    y,
    w,
    h,
    fontSize: size,
    bold: true,
    colour,
    align,
  };
}
function brandOverlay(options: CustomPamphletOptions, measure: MeasureText): SlideElement[] {
  const { size, brand, contentBottom, contentTop, ink } = options;
  const color = ink === "dark" ? "#173b38" : "#ffffff";
  const panel = ink === "dark" ? "#ffffff" : "#061c30";
  const logoPixels = Math.min(size.width, size.height) * 0.068;
  const logoW = (logoPixels / size.width) * 100;
  const logoH = (logoPixels / size.height) * 100;
  const footerY = Math.min(93, contentBottom + 2);
  const headerName = editableLabel(
    brand.appName,
    "appName",
    7 + logoW,
    2.5,
    84 - logoW,
    Math.min(7, contentTop - 3),
    Math.min(26, Math.max(14, size.height * 0.026)),
    color,
    "center",
  );
  return [
    {
      ...textElement("", 0),
      type: "rectangle",
      x: 0,
      y: 0,
      w: 100,
      h: Math.min(11, contentTop - 1),
      role: "decoration",
      fill: panel,
      opacity: 0.82,
    },
    {
      ...textElement("", footerY - 1),
      type: "rectangle",
      x: 0,
      y: footerY - 1,
      w: 100,
      h: 100 - footerY + 1,
      role: "decoration",
      fill: panel,
      opacity: 0.82,
    },
    {
      ...textElement("", 2),
      type: "image",
      x: 4,
      y: 2,
      w: logoW,
      h: logoH,
      image: NOTES_PRINT_LOGO,
      role: "brand",
      slot: "logo",
    },
    fittedElement(headerName, size, measure),
    fittedElement(
      editableLabel(
        brand.teacher,
        "teacher",
        6,
        footerY,
        41,
        Math.min(5, 99 - footerY),
        Math.min(23, Math.max(13, size.height * 0.023)),
        color,
      ),
      size,
      measure,
    ),
    fittedElement(
      editableLabel(
        brand.series,
        "series",
        51,
        footerY,
        42,
        Math.min(5, 99 - footerY),
        Math.min(23, Math.max(13, size.height * 0.023)),
        color,
        "right",
      ),
      size,
      measure,
    ),
  ];
}
function makeArtworkSlide(
  page: CustomPamphletPage,
  options: CustomPamphletOptions,
  measure: MeasureText,
): Slide {
  return {
    id: crypto.randomUUID(),
    background: "#ffffff",
    design: "paper", // Disables the editor's legacy automatic header. Custom art is its own layer.
    purpose: "lesson",
    hidePageNumber: true, // Never print the app's slide number over a Canva footer.
    notes: `Custom artwork: ${page.name.slice(0, 100)}. The uploaded design is a replaceable image, not OCR. Text added in KKCC is separately editable.`,
    elements: [artwork(page), ...(options.addBranding ? brandOverlay(options, measure) : [])],
  };
}
function sections(text: string, fallbackTitle: string) {
  const output: { title: string; body: string[] }[] = [];
  let current = { title: fallbackTitle || "Teaching notes", body: [] as string[] };
  let hasHeading = false;
  for (const line of text.replace(/\r\n?/g, "\n").split("\n")) {
    const heading = line.match(/^#{1,3}\s+(.+)$/);
    if (heading && heading[1]!.trim().length <= 120) {
      if (hasHeading || current.body.some((s) => s.trim())) output.push(current);
      current = { title: heading[1]!.trim(), body: [] };
      hasHeading = true;
    } else current.body.push(line);
  }
  output.push(current);
  return output;
}
function bodyChunks(
  body: string,
  box: SlideElement,
  size: SlideSize,
  measure: MeasureText,
): string[] {
  const lines = wrapSlideText(
    body,
    (box.w / 100) * size.width * 0.96,
    box.fontSize,
    measure,
    box.font,
    box.bold,
  );
  const capacity = Math.max(
    1,
    Math.floor(((box.h / 100) * size.height) / (box.fontSize * 1.35)) - 1,
  );
  const result: string[] = [];
  for (let i = 0; i < lines.length; i += capacity)
    result.push(lines.slice(i, i + capacity).join("\n"));
  return result.length ? result : [""];
}

/** Stateless; throws before replacing anything if 60-slide/24-MB limits would drop content. */
export function generateCustomPamphlet(
  options: CustomPamphletOptions,
  measure: MeasureText = approximateMeasure,
): Deck {
  const { pages, size, teachingIndex, contentTop, contentBottom } = options;
  slideSizeSchema.parse(size);
  if (!pages.length || pages.length > CUSTOM_PAMPHLET_MAX_PAGES)
    throw new Error(`Choose 1–${CUSTOM_PAMPHLET_MAX_PAGES} Canva pages.`);
  if (!Number.isInteger(teachingIndex) || teachingIndex < 0 || teachingIndex >= pages.length)
    throw new Error("Choose which uploaded page is the blank teaching template.");
  if (
    !Number.isFinite(contentTop) ||
    !Number.isFinite(contentBottom) ||
    contentTop < 10 ||
    contentTop > 35 ||
    contentBottom < 65 ||
    contentBottom > 92 ||
    contentBottom - contentTop < 45
  )
    throw new Error("Keep a clear text area: top 10–35%, bottom 65–92%, at least 45% apart.");
  if (options.text.length > CUSTOM_PAMPHLET_MAX_TEXT)
    throw new Error("Up to 60,000 characters per PPT. Split longer lessons; no text was cut.");
  if (!options.title.trim() || options.title.length > 150)
    throw new Error("Give the PowerPoint a name (up to 150 characters).");
  const slides: Slide[] = [];
  if (options.keepSourcePages)
    slides.push(...pages.map((page) => makeArtworkSlide(page, options, measure)));
  if (options.text.trim()) {
    const master = pages[teachingIndex]!;
    const ink = options.ink === "dark" ? "#17314b" : "#f8fcff";
    const titleInk = options.ink === "dark" ? "#0b7359" : "#62f5a8";
    const template = makeArtworkSlide(master, options, measure);
    if (options.readingPanel)
      template.elements.push({
        ...textElement("", contentTop + 1),
        type: "rectangle",
        x: 6,
        y: contentTop + 1,
        w: 88,
        h: contentBottom - contentTop - 2,
        fill: options.ink === "dark" ? "#ffffff" : "#061525",
        opacity: 0.85,
        role: "decoration",
      });
    const title = {
      ...textElement("", contentTop + 3),
      slot: "title" as const,
      role: "content" as const,
      x: 9,
      y: contentTop + 3,
      w: 82,
      h: 9,
      colour: titleInk,
      bold: true,
      fontSize: Math.min(48, Math.max(22, Math.round(size.height * 0.045))),
    };
    const body = {
      ...textElement("", contentTop + 15),
      slot: "body" as const,
      role: "content" as const,
      x: 9,
      y: contentTop + 15,
      w: 82,
      h: contentBottom - contentTop - 18,
      colour: ink,
      fontSize: Math.min(30, Math.max(17, Math.round(size.height * 0.031))),
    };
    for (const section of sections(options.text, options.topic.trim() || options.brand.subject)) {
      const fittedTitle = fittedElement({ ...title, text: section.title }, size, measure);
      for (const chunk of bodyChunks(section.body.join("\n"), body, size, measure)) {
        slides.push({
          ...template,
          id: crypto.randomUUID(),
          generated: true,
          elements: [
            ...template.elements.map((item) => ({ ...item, id: crypto.randomUUID() })),
            { ...fittedTitle, id: crypto.randomUUID() },
            { ...body, text: chunk, id: crypto.randomUUID() },
          ],
        });
        if (slides.length > 60)
          throw new Error(
            "60-slide limit reached. Split the lesson; the original text was not truncated.",
          );
      }
    }
  } else if (!slides.length) slides.push(makeArtworkSlide(pages[teachingIndex]!, options, measure));
  const total = slides.reduce(
    (sum, slide) =>
      sum + slide.elements.reduce((bytes, e) => bytes + e.image.length + e.text.length, 0),
    0,
  );
  if (total > 24_000_000)
    throw new Error(
      "This design plus text exceeds the 24 MB editable-project limit. Use fewer Canva pages, compress the images, or split the lesson; nothing was lost.",
    );
  return deckSchema.parse({
    version: 1,
    title: options.title.trim(),
    size,
    brand: options.brand,
    slides,
  });
}
