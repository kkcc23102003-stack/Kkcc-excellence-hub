export type BatchVideoMapping = { sourceId: string; targetId: string };
export type BatchVideoCopyResult = { addedCount: number; warning?: string };

/**
 * Copy only missing Batch video links, mapping each source Note ID to its destination ID.
 * The destination catalogue is written with its current revision as a CAS guard. A CAS or
 * Storage failure is reported as a partial result instead of making the already-completed
 * Notes reuse look like a wholly failed operation that is safe to repeat blindly.
 */
export async function copyBatchVideoSettings(input: {
  sourceVideos: Readonly<Record<string, string>>;
  destinationVideos: Readonly<Record<string, string>>;
  mappings: readonly BatchVideoMapping[];
  validateUrl: (url: string) => string | null;
  save: (videos: Record<string, string>) => Promise<boolean>;
}): Promise<BatchVideoCopyResult> {
  const videos = { ...input.destinationVideos };
  let addedCount = 0;

  for (const mapping of input.mappings) {
    const url = input.sourceVideos[mapping.sourceId];
    if (!url || videos[mapping.targetId]) continue;
    const invalid = input.validateUrl(url);
    if (invalid)
      return {
        addedCount: 0,
        warning: `Notes are present in the destination, but no Batch video settings were saved. ${invalid}`,
      };
    videos[mapping.targetId] = url;
    addedCount += 1;
  }

  if (!addedCount) return { addedCount: 0 };

  try {
    const saved = await input.save(videos);
    if (!saved)
      return {
        addedCount: 0,
        warning:
          "Notes are present in the destination, but its Batch changed before video links could be saved. Reload and retry the video step.",
      };
    return { addedCount };
  } catch (error) {
    return {
      addedCount: 0,
      warning: `Notes are present in the destination, but Batch videos were not saved: ${error instanceof Error ? error.message : String(error)}`,
    };
  }
}
