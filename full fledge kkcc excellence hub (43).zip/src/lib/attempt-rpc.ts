type AttemptRpcResult<T> = {
  data: T;
  error: { code?: string; message: string } | null;
};

/** Autosave and finalization must remain atomic with revisions and question timers.
 * A legacy three-argument RPC or a direct service-role UPDATE cannot enforce
 * those guarantees. Missing migrations/schema cache are a setup error, not a
 * reason to write an unverified result.
 */
export function requireAtomicAttemptRpc<T>(result: AttemptRpcResult<T>): T {
  if (!result.error) return result.data;
  const { code, message } = result.error;
  if (
    code === "PGRST202" ||
    code === "42883" ||
    /Could not find the function|schema cache|function .* does not exist/i.test(message)
  ) {
    throw new Error(
      "Saved test setup required: the versioned attempt RPC is unavailable. Answers and results were not updated; ask Admin to verify the student-only SQL and refresh the Supabase schema cache, then retry.",
    );
  }
  throw new Error(message);
}
