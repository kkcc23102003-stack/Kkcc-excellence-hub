import { z } from "zod";
import { projectContent } from "./project-content.server";
import {
  requireDisposableCourse,
  requireDisposableMaterial,
  requireDisposableTest,
  requireUnlinkedSeries,
} from "./admin-content-deletion.server";
import { CUSTOM_SERIES_CATALOG_KEY } from "./learning.server";
import { readStoredCustomSeriesCatalog } from "./custom-series-catalog-storage.server";
import { getEffectiveLearningSeries, type CustomSeriesCatalog } from "./test-series-catalog";

/** Select exact IDs only. Never infer that a row is disposable from its title. */
export const bulkCleanupSelectionSchema = z
  .object({
    courseIds: z.array(z.string().uuid()).max(100),
    noteIds: z.array(z.string().uuid()).max(100),
    testIds: z.array(z.string().uuid()).max(100),
    seriesIds: z.array(z.string().trim().min(1).max(120)).max(100),
  })
  .strict()
  .superRefine((value, context) => {
    const groups = [value.courseIds, value.noteIds, value.testIds, value.seriesIds];
    if (groups.reduce((sum, ids) => sum + ids.length, 0) > 100)
      context.addIssue({ code: "custom", message: "Review no more than 100 items at a time." });
    if (groups.some((ids) => new Set(ids).size !== ids.length))
      context.addIssue({ code: "custom", message: "Duplicate IDs are not allowed." });
  });

export type BulkCleanupSelection = z.infer<typeof bulkCleanupSelectionSchema>;
export type BulkCleanupKind = "course" | "note" | "test" | "series";
export type BulkCleanupItem = {
  id: string;
  kind: BulkCleanupKind;
  title: string;
  action: "delete draft" | "hide series";
  ready: boolean;
  reason?: string;
};

/** Unlike the public catalogue reader, a failed admin read cannot silently become an empty catalogue. */
export async function readBulkCleanupCatalog(): Promise<CustomSeriesCatalog> {
  const row = await projectContent
    .from("site_settings")
    .select("value")
    .eq("key", CUSTOM_SERIES_CATALOG_KEY)
    .maybeSingle();
  if (row.error) throw new Error("Cannot verify test-series catalogue. Nothing changed.");
  if (!row.data) return {};
  try {
    return (await readStoredCustomSeriesCatalog(row.data.value)).data;
  } catch (error) {
    throw new Error(
      `Cannot verify test-series catalogue from private Storage. Nothing changed. ${error instanceof Error ? error.message : String(error)}`,
    );
  }
}

/** Lightweight inventory; does not download note bodies or student records. */
export async function listBulkCleanupInventory() {
  const [courseRows, noteRows, testRows, catalog] = await Promise.all([
    projectContent
      .from("courses")
      .select("id,title,status")
      .order("created_at", { ascending: false })
      .limit(1000),
    projectContent
      .from("materials")
      .select("id,title,is_published")
      .order("created_at", { ascending: false })
      .limit(1000),
    projectContent
      .from("tests")
      .select("id,title,is_published")
      .order("created_at", { ascending: false })
      .limit(1000),
    readBulkCleanupCatalog(),
  ]);
  if (courseRows.error || noteRows.error || testRows.error)
    throw new Error("Cannot load the complete cleanup inventory. Nothing changed.");
  return {
    courses: (courseRows.data ?? []).map((row) => ({
      id: row.id,
      title: row.title,
      status: row.status,
    })),
    notes: (noteRows.data ?? []).map((row) => ({
      id: row.id,
      title: row.title,
      isPublished: row.is_published,
    })),
    tests: (testRows.data ?? []).map((row) => ({
      id: row.id,
      title: row.title,
      isPublished: row.is_published,
    })),
    series: getEffectiveLearningSeries(catalog).map((series) => ({
      id: series.id,
      title: series.name,
      source: catalog.addedSeries?.some((item) => item.id === series.id) ? "custom" : "built-in",
    })),
  };
}

function selectedKeys(selection: BulkCleanupSelection): { kind: BulkCleanupKind; id: string }[] {
  return [
    ...selection.seriesIds.map((id) => ({ kind: "series" as const, id })),
    ...selection.noteIds.map((id) => ({ kind: "note" as const, id })),
    ...selection.testIds.map((id) => ({ kind: "test" as const, id })),
    ...selection.courseIds.map((id) => ({ kind: "course" as const, id })),
  ];
}

/** A read-only preview. A linked or unverified item blocks the *whole* batch. */
export async function reviewBulkCleanup(selection: BulkCleanupSelection) {
  const keys = selectedKeys(selection);
  if (!keys.length) throw new Error("Choose at least one item to review.");
  const catalog = selection.seriesIds.length ? await readBulkCleanupCatalog() : {};
  const seriesById = new Map(
    getEffectiveLearningSeries(catalog).map((series) => [series.id, series]),
  );
  const items: BulkCleanupItem[] = [];
  // Limit simultaneous dependency probes on the live backend.
  for (let offset = 0; offset < keys.length; offset += 6) {
    items.push(
      ...(await Promise.all(
        keys.slice(offset, offset + 6).map(async ({ kind, id }): Promise<BulkCleanupItem> => {
          let title = id;
          const action = kind === "series" ? "hide series" : "delete draft";
          try {
            if (kind === "series") {
              const series = seriesById.get(id);
              if (!series)
                throw new Error("Series not visible or already hidden. Refresh the list.");
              title = series.name;
              await requireUnlinkedSeries([id]);
            } else if (kind === "course") {
              const row = await projectContent
                .from("courses")
                .select("id,title,status")
                .eq("id", id)
                .maybeSingle();
              if (row.error) throw new Error("Cannot verify course. Nothing changed.");
              if (!row.data) throw new Error("Course not found. Refresh the list.");
              title = row.data.title;
              await requireDisposableCourse(id);
            } else if (kind === "note") {
              const row = await projectContent
                .from("materials")
                .select("id,title,is_published")
                .eq("id", id)
                .maybeSingle();
              if (row.error) throw new Error("Cannot verify note. Nothing changed.");
              if (!row.data) throw new Error("Note not found. Refresh the list.");
              title = row.data.title;
              await requireDisposableMaterial(id);
            } else {
              const row = await projectContent
                .from("tests")
                .select("id,title,is_published")
                .eq("id", id)
                .maybeSingle();
              if (row.error) throw new Error("Cannot verify test. Nothing changed.");
              if (!row.data) throw new Error("Test not found. Refresh the list.");
              title = row.data.title;
              await requireDisposableTest(id);
            }
            return { id, kind, title, action, ready: true };
          } catch (error) {
            return {
              id,
              kind,
              title,
              action,
              ready: false,
              reason:
                error instanceof Error ? error.message : "Cannot verify item. Nothing changed.",
            };
          }
        }),
      )),
    );
  }
  return { items, canApply: items.every((item) => item.ready) };
}

/** Recheck at application time. Rows are removed one at a time, never student data. */
export async function applyBulkCleanup(
  selection: BulkCleanupSelection,
  hideSeries: (catalog: CustomSeriesCatalog) => Promise<unknown>,
) {
  const review = await reviewBulkCleanup(selection);
  if (!review.canApply)
    return {
      ok: false,
      completed: [] as BulkCleanupItem[],
      review,
      error: "No changes made. Remove blocked items from the selection and review again.",
    };

  const completed: BulkCleanupItem[] = [];
  let current: BulkCleanupItem | undefined;
  try {
    // Hide selected series with one write. Keep definitions, syllabuses, overrides and grants.
    if (selection.seriesIds.length) {
      const catalog = await readBulkCleanupCatalog();
      const visibleIds = new Set(getEffectiveLearningSeries(catalog).map((series) => series.id));
      if (selection.seriesIds.some((id) => !visibleIds.has(id)))
        throw new Error("A series changed while reviewing. Refresh and try again.");
      await requireUnlinkedSeries(selection.seriesIds);
      await hideSeries({
        ...catalog,
        removedSeriesIds: [
          ...new Set([...(catalog.removedSeriesIds ?? []), ...selection.seriesIds]),
        ],
      });
      completed.push(...review.items.filter((item) => item.kind === "series"));
    }
    for (const item of review.items.filter((candidate) => candidate.kind !== "series")) {
      current = item;
      const { id, kind } = item;
      if (kind === "course") await requireDisposableCourse(id);
      else if (kind === "note") await requireDisposableMaterial(id);
      else if (kind === "test") await requireDisposableTest(id);
      // Repeat the draft predicate on the write in case an editor published it meanwhile.
      const result =
        kind === "course"
          ? await projectContent
              .from("courses")
              .delete()
              .eq("id", id)
              .eq("status", "draft")
              .select("id")
          : kind === "note"
            ? await projectContent
                .from("materials")
                .delete()
                .eq("id", id)
                .eq("is_published", false)
                .select("id")
            : await projectContent
                .from("tests")
                .delete()
                .eq("id", id)
                .eq("is_published", false)
                .select("id");
      if (result.error || !result.data?.some((row) => row.id === id))
        throw new Error("Draft changed or deletion failed. Refresh and review again.");
      completed.push(item);
    }
    return { ok: true, completed, review, error: null };
  } catch (error) {
    return {
      ok: false,
      completed,
      review,
      error: `Stopped${current ? ` at ${current.title}` : " before deletion"}: ${error instanceof Error ? error.message : "Cannot verify safety."} ${completed.length ? "Earlier completed items remain changed; review the list again." : "Nothing changed."}`,
    };
  }
}
