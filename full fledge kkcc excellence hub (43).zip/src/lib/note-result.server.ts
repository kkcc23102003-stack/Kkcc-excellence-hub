import { isLocalManagedFixture } from "./managed-content-tables";
import {
  MAX_NOTE_RESULT_BYTES,
  NOTE_RESULT_BUCKET,
  makeNoteResult,
  readNoteResult,
  resultPath,
  resultSummary,
  type NoteResult,
  type NoteResultSummary,
} from "./note-result-store";
import type { NoteFollowUpTest } from "./note-follow-up-test";
import type { NotePracticeQuestion } from "./note-practice";
import {
  makePracticeResult,
  practiceResultPath,
  practiceSummary,
  readPracticeResult,
  type NotePracticeResult,
  type NotePracticeSummary,
} from "./note-practice-result-store";

const setup =
  "Ask Admin to review and install supabase/migrations/20261017120000_note_results_storage.sql. No result was saved.";
type IO = {
  write: (path: string, bytes: Buffer) => Promise<void>;
  read: (path: string) => Promise<Buffer>;
  list: (userId: string) => Promise<string[]>;
};
async function noteResultIO(): Promise<IO> {
  if (isLocalManagedFixture("materials", process.env)) {
    const fs = await import("node:fs/promises");
    const path = await import("node:path");
    const root = path.resolve(".cache/fixture-note-results");
    return {
      write: async (key, bytes) => {
        const target = path.join(root, key);
        await fs.mkdir(path.dirname(target), { recursive: true });
        await fs.writeFile(target, bytes, { flag: "wx" });
      },
      read: (key) => fs.readFile(path.join(root, key)),
      list: async (userId) => {
        try {
          return (await fs.readdir(path.join(root, userId))).filter((name) =>
            name.endsWith(".json"),
          );
        } catch (error) {
          if ((error as NodeJS.ErrnoException).code === "ENOENT") return [];
          throw error;
        }
      },
    };
  }
  const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
  const bucket = await supabaseAdmin.storage.getBucket(NOTE_RESULT_BUCKET);
  if (bucket.error || !bucket.data || bucket.data.public)
    throw new Error(`Private result bucket unavailable. ${setup}`);
  const storage = supabaseAdmin.storage.from(NOTE_RESULT_BUCKET);
  return {
    write: async (key, bytes) => {
      const { error } = await storage.upload(key, bytes, {
        contentType: "application/json",
        cacheControl: "0",
        upsert: false,
      });
      if (error) throw new Error(`Result upload failed: ${error.message}. ${setup}`);
    },
    read: async (key) => {
      const { data, error } = await storage.download(key);
      if (error || !data) throw new Error(`Saved result is unavailable. ${error?.message || ""}`);
      const bytes = Buffer.from(await data.arrayBuffer());
      if (bytes.byteLength > MAX_NOTE_RESULT_BYTES)
        throw new Error("Saved result exceeds the size limit.");
      return bytes;
    },
    list: async (userId) => {
      const { data, error } = await storage.list(userId, {
        limit: 100,
        sortBy: { column: "created_at", order: "desc" },
      });
      if (error) throw new Error(`Saved results could not be listed: ${error.message}`);
      return (data || []).map((item) => item.name).filter((name) => name.endsWith(".json"));
    },
  };
}

/** No database attempt rows are created. The authenticated owner is taken from the session. */
export async function storeNoteResult(input: {
  id: string;
  userId: string;
  materialId: string;
  materialTitle: string;
  test: NoteFollowUpTest;
  answers: (number | null)[];
}): Promise<NoteResultSummary> {
  const result = makeNoteResult(input);
  const io = await noteResultIO();
  const key = resultPath(input.userId, input.id);
  try {
    await io.write(key, Buffer.from(JSON.stringify(result), "utf8"));
  } catch (error) {
    // A lost response after a successful upload can be retried with the same
    // client-generated UUID. Never overwrite a different result under that ID.
    const previous = await io.read(key).catch(() => null);
    if (!previous) throw error;
    const saved = readNoteResult(previous, input.userId, input.id);
    if (
      saved.material_id !== result.material_id ||
      saved.test_sha256 !== result.test_sha256 ||
      JSON.stringify(saved.answers) !== JSON.stringify(result.answers)
    )
      throw new Error("This attempt ID is already used by a different result.");
    return resultSummary(saved);
  }
  return resultSummary(result);
}

export async function findMyNoteResult(userId: string, attemptId: string): Promise<NoteResult> {
  return readNoteResult(
    await (await noteResultIO()).read(resultPath(userId, attemptId)),
    userId,
    attemptId,
  );
}

/** Bounded owner-only listing; never enumerate another student's prefix. */
export async function listMyNoteResults(userId: string): Promise<NoteResultSummary[]> {
  const io = await noteResultIO();
  const names = (await io.list(userId))
    .filter((name) => /^[0-9a-f-]{36}\.json$/i.test(name))
    .slice(0, 100);
  const results: NoteResultSummary[] = [];
  for (let index = 0; index < names.length; index += 8) {
    const batch = names.slice(index, index + 8);
    results.push(
      ...(await Promise.all(
        batch.map(async (name) => {
          const attemptId = name.slice(0, -5);
          return resultSummary(
            readNoteResult(await io.read(resultPath(userId, attemptId)), userId, attemptId),
          );
        }),
      )),
    );
  }
  return results.sort((a, b) => b.submitted_at.localeCompare(a.submitted_at)).slice(0, 30);
}

/** Practice check-ins are separate objects so a written self-check is never graded like an MCQ. */
export async function storePracticeResult(input: {
  id: string;
  userId: string;
  materialId: string;
  materialTitle: string;
  question: NotePracticeQuestion;
  response: number | string;
}): Promise<NotePracticeSummary> {
  const result = makePracticeResult(input);
  const io = await noteResultIO();
  const key = practiceResultPath(input.userId, input.id);
  try {
    await io.write(key, Buffer.from(JSON.stringify(result), "utf8"));
  } catch (error) {
    const previous = await io.read(key).catch(() => null);
    if (!previous) throw error;
    const saved = readPracticeResult(previous, input.userId, input.id);
    if (
      saved.material_id !== result.material_id ||
      saved.question.id !== result.question.id ||
      JSON.stringify(saved.question) !== JSON.stringify(result.question) ||
      saved.response !== result.response
    )
      throw new Error("This practice attempt ID already belongs to another response.");
    return practiceSummary(saved);
  }
  return practiceSummary(result);
}

export async function findMyPracticeResult(
  userId: string,
  attemptId: string,
): Promise<NotePracticeResult> {
  return readPracticeResult(
    await (await noteResultIO()).read(practiceResultPath(userId, attemptId)),
    userId,
    attemptId,
  );
}

export async function listMyPracticeResults(userId: string): Promise<NotePracticeSummary[]> {
  const io = await noteResultIO();
  const names = (await io.list(`${userId}/practice`))
    .filter((name) => /^[0-9a-f-]{36}\.json$/i.test(name))
    .slice(0, 100);
  const results: NotePracticeSummary[] = [];
  for (let index = 0; index < names.length; index += 8) {
    results.push(
      ...(await Promise.all(
        names.slice(index, index + 8).map(async (name) => {
          const id = name.slice(0, -5);
          return practiceSummary(
            readPracticeResult(await io.read(practiceResultPath(userId, id)), userId, id),
          );
        }),
      )),
    );
  }
  return results.sort((a, b) => b.submitted_at.localeCompare(a.submitted_at)).slice(0, 30);
}
