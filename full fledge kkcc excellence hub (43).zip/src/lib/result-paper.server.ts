import { randomUUID } from "node:crypto";
import { supabaseAdmin } from "@/integrations/supabase/client.server";
import type { LearningAttemptRow } from "@/integrations/supabase/db";
import { testBodyIO, RESULT_PAPER_BUCKET } from "./test-body.server";
import {
  assertResultSnapshot,
  learningResultPath,
  requiresArchivedLearningResult,
  resultSnapshotBytes,
  type LearningResultSnapshot,
} from "./learning-result-store";
import {
  assertPaperMatchesAttempt,
  requiresSealedResultPaper,
  openResultPaper,
  sealResultPaper,
  validateResultPaperReference,
  type ResultPaper,
  type ResultPaperReference,
} from "./result-paper-store";
import {
  learningPlan,
  readCustomSeriesCatalog,
  readStudentAccess,
  testPermission,
  type StudentContext,
} from "./learning.server";

let missingTableWarned = false;
function missingResultPaperTable(error: { code?: string; message?: string } | null): boolean {
  const missing = error?.code === "PGRST205" || error?.code === "42P01";
  if (missing && !missingTableWarned) {
    console.warn(
      "Result-paper snapshot table is not installed. Existing test attempts still work, but original papers cannot be preserved until the separately approved snapshot-only migration is installed.",
    );
    missingTableWarned = true;
  }
  return missing;
}

/** Schema may not yet be installed on a live project; do not break normal attempts. */
export async function resultPaperSnapshotsAvailable(): Promise<boolean> {
  const status = await supabaseAdmin.from("kkcc_attempt_papers").select("attempt_id").limit(0);
  if (missingResultPaperTable(status.error)) return false;
  if (status.error) throw new Error(status.error.message);
  return true;
}

/** Check the private bucket before recording a new attempt that will require it. */
export async function requireResultPaperStorage(): Promise<boolean> {
  if (!(await resultPaperSnapshotsAvailable())) return false;
  await testBodyIO(RESULT_PAPER_BUCKET);
  return true;
}

const cache = new Map<string, { paper: ResultPaper; bytes: number; until: number }>();
let cacheSize = 0;
function remember(key: string, paper: ResultPaper, size: number) {
  const previous = cache.get(key);
  if (previous) {
    cacheSize -= previous.bytes;
    cache.delete(key);
  }
  cache.set(key, { paper: structuredClone(paper), bytes: size, until: Date.now() + 120_000 });
  cacheSize += size;
  while (cacheSize > 16 * 1024 * 1024 || cache.size > 32) {
    const oldest = cache.keys().next().value!;
    cacheSize -= cache.get(oldest)!.bytes;
    cache.delete(oldest);
  }
}

function assertMissingPaperAllowed(row: LearningAttemptRow) {
  if (requiresSealedResultPaper(row))
    throw new Error(
      "The original saved test paper is missing. Answers and results were not updated; ask Admin to investigate the private paper/metadata and approved backup. Today's questions cannot replace it.",
    );
}

/** Only call after looking up the attempt by user_id with the authenticated client.
 * Missing metadata is allowed only during the first save immediately after insert;
 * a later retry must never rebuild a marked attempt from changed live content.
 */
export async function readResultPaper(
  row: LearningAttemptRow,
  force = false,
  initialWrite = false,
): Promise<ResultPaper | null> {
  const result = await supabaseAdmin
    .from("kkcc_attempt_papers")
    .select("*")
    .eq("attempt_id", row.id)
    .maybeSingle();
  if (missingResultPaperTable(result.error)) {
    assertMissingPaperAllowed(row);
    return null;
  }
  if (result.error) throw new Error(result.error.message);
  if (!result.data) {
    if (!initialWrite) assertMissingPaperAllowed(row);
    return null;
  }
  const reference = result.data as ResultPaperReference;
  if (reference.attempt_id !== row.id) throw new Error("Wrong result paper attempt ID");
  // Validate every metadata read, including cache hits: never reuse a foreign
  // attempt's cached paper simply because its hash/path happens to match.
  validateResultPaperReference(reference);
  const key = `${reference.path}:${reference.sha256}:${reference.bytes}`;
  const hit = cache.get(key);
  if (!force && hit && hit.until > Date.now()) {
    assertPaperMatchesAttempt(row, hit.paper);
    return structuredClone(hit.paper);
  }
  // openResultPaper rechecks the reference after reading its SHA-256 bytes.
  const bytes = await (await testBodyIO(RESULT_PAPER_BUCKET)).read(reference.path);
  const paper = openResultPaper(bytes, reference);
  assertPaperMatchesAttempt(row, paper);
  remember(key, paper, bytes.length);
  return paper;
}

/** Save once, immediately after inserting a new marked attempt. Never backfill
 * an older unsnapshotted row with today's potentially edited questions.
 */
export async function saveResultPaper(
  row: LearningAttemptRow,
  paper: ResultPaper,
): Promise<ResultPaper> {
  if (!requiresSealedResultPaper(row))
    throw new Error("Only newly started, snapshot-marked attempts can seal an original paper.");
  assertPaperMatchesAttempt(row, paper);
  const existing = await readResultPaper(row, false, true);
  if (existing) return existing;
  const sealed = sealResultPaper(row.id, paper);
  const path = `${row.id}/${randomUUID()}.json`;
  const io = await testBodyIO(RESULT_PAPER_BUCKET);
  await io.write(path, sealed.bytes);
  const checked = await io.read(path);
  openResultPaper(checked, {
    attempt_id: row.id,
    path,
    sha256: sealed.sha256,
    bytes: sealed.bytes.length,
  });
  const saved = await supabaseAdmin
    .from("kkcc_attempt_papers")
    .upsert(
      { attempt_id: row.id, path, sha256: sealed.sha256, bytes: sealed.bytes.length },
      { onConflict: "attempt_id", ignoreDuplicates: true },
    );
  if (saved.error) throw new Error(saved.error.message);
  const final = await readResultPaper(row, true);
  if (!final)
    throw new Error("Result paper could not be verified; retry without editing the source.");
  return final;
}

/** A separate immutable JSON result next to the original sealed paper in PRIVATE Storage.
 * This additive archive never replaces the existing atomic DB attempt RPC.
 */
export async function archiveSubmittedResult(row: LearningAttemptRow): Promise<boolean> {
  if (!requiresArchivedLearningResult(row)) return false;
  const key = learningResultPath(row.id);
  let bytes: Buffer;
  try {
    bytes = resultSnapshotBytes(row);
  } catch (error) {
    throw new Error(
      `The attempt was submitted, but its private result snapshot is invalid. Retry Submit after investigating: ${error instanceof Error ? error.message : String(error)}`,
    );
  }
  const io = await testBodyIO(RESULT_PAPER_BUCKET);
  try {
    await io.write(key, bytes);
  } catch (error) {
    // The response to an earlier upload may have been lost. Do not overwrite a
    // different result or regrade from today's question bank.
    const previous = await io.read(key).catch(() => null);
    if (!previous)
      throw new Error(
        `The attempt is submitted in the database, but its private Storage copy was not confirmed. Retry Submit with the same attempt ID. ${error instanceof Error ? error.message : String(error)}`,
      );
    assertResultSnapshot(previous, row);
    return true;
  }
  assertResultSnapshot(await io.read(key), row);
  return true;
}

/** Historical DB-only attempts have no marker. New marked results must pass a
 * private Storage read; never silently substitute database numbers for missing
 * or tampered Storage bytes.
 */
export async function readArchivedSubmittedResult(
  row: LearningAttemptRow,
): Promise<LearningResultSnapshot | null> {
  if (row.status !== "submitted" || !requiresArchivedLearningResult(row)) return null;
  const io = await testBodyIO(RESULT_PAPER_BUCKET);
  let bytes: Buffer;
  try {
    bytes = await io.read(learningResultPath(row.id));
  } catch (error) {
    throw new Error(
      `Private result Storage copy is unavailable. The database attempt is retained; retry Submit with the same attempt ID or ask Admin to restore its backup. ${error instanceof Error ? error.message : String(error)}`,
    );
  }
  return assertResultSnapshot(bytes, row);
}

/** Archived questions still need the student's current access; submitted results remain theirs. */
export async function requireArchivedAttemptAccess(
  context: StudentContext,
  row: LearningAttemptRow,
  paper: ResultPaper,
) {
  const blocked = await context.supabase.rpc("is_user_blocked", { _user_id: context.userId });
  if (blocked.error || blocked.data) throw new Error("Account access unavailable");
  if (row.status === "submitted") return;
  const access = await readStudentAccess(context);
  if (row.test_id) {
    const { projectContent } = await import("./project-content.server");
    const live = await projectContent.from("tests").select("*").eq("id", row.test_id).maybeSingle();
    if (live.error) throw new Error(live.error.message);
    const allowed = testPermission(
      live.data || { ...paper.test, is_published: true },
      access,
    ).allowed;
    const archivedSeriesGrant =
      !live.data && row.series_id && access.series_ids.includes(row.series_id);
    if (!allowed && !archivedSeriesGrant) throw new Error("TEST_ACCESS_REQUIRED");
  } else {
    const catalog = await readCustomSeriesCatalog();
    if (!(catalog.removedSeriesIds || []).includes(row.series_id || "")) {
      const metadata = (row.source_refs || [])
        .find((ref) => ref.startsWith("__kkcc_meta__:"))
        ?.slice("__kkcc_meta__:".length)
        .split(":");
      await learningPlan(context, {
        series_id: row.series_id ?? undefined,
        subject: decodeURIComponent(metadata?.[0] || "") || row.subject || undefined,
        chapter: decodeURIComponent(metadata?.[1] || "") || row.chapter || undefined,
      });
    } else if (
      !access.is_admin &&
      paper.test.is_paid &&
      !access.series_ids.includes(row.series_id || "")
    )
      throw new Error("SERIES_ACCESS_REQUIRED");
  }
}
