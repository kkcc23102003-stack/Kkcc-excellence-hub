import { createServerFn } from "@tanstack/react-start";
import { z } from "zod";
import { requireSupabaseAuth } from "@/integrations/supabase/auth-middleware";
import { projectContent } from "./project-content.server";
import { assertAdmin } from "./learning.server";
import {
  notesSeriesSchema,
  seriesNoteIds,
  buildNotesLibrary,
  type NotesSeries,
} from "./notes-series";
import { listPublicMaterialCards } from "./content.functions";
import { materialAccessMode } from "./material-access-mode";
import { resolveContentUrl } from "./content-storage.server";
import { readNotesCatalogSetting, writeNotesCatalogObject } from "./notes-catalog-storage.server";
import {
  applyNotesSeriesPricingFromConfig,
  getNotesSeriesPricing,
  notesSeriesPricingSchema,
} from "./notes-series-pricing.server";

const PREFIX = "notes_series_v1:";
async function readSeries() {
  const { data, error } = await projectContent
    .from("site_settings")
    .select("key,value")
    .ilike("key", `${PREFIX}%`);
  if (error) throw new Error(error.message);
  return Promise.all(
    (data ?? [])
      .filter((row) => row.key.startsWith(PREFIX))
      .map(async (row) => {
        const id = row.key.slice(PREFIX.length);
        const stored = await readNotesCatalogSetting<NotesSeries>({
          table: "site_settings",
          key: row.key,
          kind: "series",
          id,
          value: row.value,
        });
        return notesSeriesSchema.parse(stored.data);
      }),
  );
}

export const getAdminNotesSeries = createServerFn({ method: "GET" })
  .middleware([requireSupabaseAuth])
  .handler(async ({ context }) => {
    await assertAdmin(context);
    return readSeries();
  });

export const getAdminNotesSeriesPricing = createServerFn({ method: "GET" })
  .middleware([requireSupabaseAuth])
  .handler(async ({ context }) => {
    await assertAdmin(context);
    return getNotesSeriesPricing();
  });

export const saveAdminNotesSeriesPricing = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .validator((input: unknown) => notesSeriesPricingSchema.parse(input))
  .handler(async ({ context, data }) => {
    await assertAdmin(context);
    const { error } = await projectContent.from("site_settings").upsert(
      {
        key: "notes_series_pricing_v1",
        value: JSON.stringify(data),
        updated_at: new Date().toISOString(),
      },
      { onConflict: "key" },
    );
    if (error) throw new Error(error.message);
    return data;
  });

export const saveNotesSeries = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .validator((input: unknown) => notesSeriesSchema.parse(input))
  .handler(async ({ context, data }) => {
    await assertAdmin(context);
    const key = PREFIX + data.id;
    const current = await projectContent
      .from("site_settings")
      .select("key,value")
      .eq("key", key)
      .maybeSingle();
    if (current.error) throw new Error(current.error.message);
    const currentStorage = current.data
      ? await readNotesCatalogSetting<NotesSeries>({
          table: "site_settings",
          key,
          kind: "series",
          id: data.id,
          value: current.data.value,
        })
      : null;
    const previous = currentStorage ? notesSeriesSchema.parse(currentStorage.data) : null;
    if ((previous?.revision ?? 0) !== data.revision)
      throw new Error("This series changed in another session. Reload it before saving.");
    // Validate links and access modes, but never rewrite note prices, bodies or grants.
    const ids = seriesNoteIds(data);
    if (ids.length) {
      const rows = await projectContent
        .from("materials")
        .select("id,access_type,price,coin_price,course_id")
        .in("id", ids);
      if (rows.error) throw new Error(rows.error.message);
      const found = new Map((rows.data ?? []).map((row) => [row.id, row]));
      for (const id of ids) {
        const note = found.get(id);
        if (!note)
          throw new Error(
            "A linked note was removed. Remove its reference, or reload and try again.",
          );
        const free = materialAccessMode(note) === "free";
        if (free !== (data.kind === "sample"))
          throw new Error(
            "Free-note series accept free notes only. Paid series accept paid or course-access notes only. Edit the note access mode first.",
          );
      }
    }
    const next = { ...data, revision: data.revision + 1 };
    const value = await writeNotesCatalogObject("series", data.id, next);
    if (previous && current.data && currentStorage) {
      const saved = await projectContent
        .from("site_settings")
        .update({ value, updated_at: new Date().toISOString() })
        .eq("key", key)
        .eq("value", currentStorage.storedValue)
        .select("key");
      if (saved.error) throw new Error(saved.error.message);
      if (!saved.data?.length)
        throw new Error("This series changed while saving. Reload and retry.");
    } else {
      const saved = await projectContent
        .from("site_settings")
        .insert({ key, value, updated_at: new Date().toISOString() });
      if (saved.error) throw new Error(saved.error.message);
    }
    return next;
  });
export const deleteNotesSeries = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .validator((input: unknown) =>
    z.object({ id: z.string().uuid(), revision: z.number().int() }).parse(input),
  )
  .handler(async ({ context, data }) => {
    await assertAdmin(context);
    const key = PREFIX + data.id;
    const current = await projectContent
      .from("site_settings")
      .select("key,value")
      .eq("key", key)
      .maybeSingle();
    if (current.error) throw new Error(current.error.message);
    if (!current.data) return { ok: true };
    const currentStorage = await readNotesCatalogSetting<NotesSeries>({
      table: "site_settings",
      key,
      kind: "series",
      id: data.id,
      value: current.data.value,
    });
    if (notesSeriesSchema.parse(currentStorage.data).revision !== data.revision)
      throw new Error("This series changed. Reload before deleting.");
    const removed = await projectContent
      .from("site_settings")
      .delete()
      .eq("key", key)
      .eq("value", currentStorage.storedValue)
      .select("key");
    if (removed.error) throw new Error(removed.error.message);
    if (!removed.data?.length) throw new Error("This series changed. Reload and retry.");
    // Keep immutable private Storage versions: concurrent readers may already hold this pointer.
    return { ok: true };
  });

export const getNotesSeriesLibrary = createServerFn({ method: "GET" })
  .validator((input: unknown) => z.object({ kind: z.enum(["paid", "sample"]) }).parse(input))
  .handler(async ({ data }) => {
    const [rawCatalog, materials, pricing] = await Promise.all([
      readSeries(),
      listPublicMaterialCards(),
      getNotesSeriesPricing(),
    ]);
    const catalog = rawCatalog.map((item) => applyNotesSeriesPricingFromConfig(item, pricing));
    const series = buildNotesLibrary(catalog, materials, data.kind);
    const used = new Set(series.flatMap(seriesNoteIds));
    const freePreviewIds =
      data.kind === "paid"
        ? materials.filter((note) => note.free_series_preview).map((note) => note.id)
        : [];
    const covers = await Promise.all(
      series.map(async (item) => ({
        ...item,
        thumbnail_url: item.thumbnail_url ? await resolveContentUrl(item.thumbnail_url) : null,
      })),
    );
    return {
      series: covers,
      materials: materials.filter((note) => used.has(note.id)),
      freePreviewIds,
    };
  });
