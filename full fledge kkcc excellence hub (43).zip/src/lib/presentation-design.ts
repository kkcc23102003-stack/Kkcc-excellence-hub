import {
  DEFAULT_SLIDE_BRAND,
  DEFAULT_SLIDE_SIZE,
  cloneSlide,
  deckSchema,
  slideSizeSchema,
  textElement,
  type Deck,
  type Slide,
  type SlideElement,
} from "./document-studio";
import { NOTES_PRINT_LOGO } from "./notes-print-logo";
import { layoutSlideRuns } from "./presentation-rich";
export type SlideSize = { width: number; height: number };
export type SlideBrand = typeof DEFAULT_SLIDE_BRAND;
export const RATIOS = {
  "16:9": { width: 1280, height: 720 },
  "9:16": { width: 720, height: 1280 },
  "1:1": { width: 1080, height: 1080 },
  "4:5": { width: 1080, height: 1350 },
  "3:4": { width: 1080, height: 1440 },
  "4:3": { width: 1200, height: 900 },
};
export const THEMES = {
  galaxy: {
    name: "Galaxy neon",
    background: "#051725",
    ink: "#e9f7ff",
    accent: "#48f5ae",
    panel: "#143451",
  },
  paper: {
    name: "White classroom",
    background: "#ffffff",
    ink: "#163b36",
    accent: "#127b65",
    panel: "#e8f5ef",
  },
  teal: {
    name: "Teal studio",
    background: "#063c40",
    ink: "#e8fffa",
    accent: "#77efd1",
    panel: "#0b6367",
  },
  sunset: {
    name: "Warm peach",
    background: "#fff2e8",
    ink: "#5d2933",
    accent: "#b43e66",
    panel: "#ffddc9",
  },
  royal: {
    name: "Royal violet",
    background: "#201c45",
    ink: "#f3efff",
    accent: "#d0aeff",
    panel: "#463b70",
  },
};
export type ThemeName = keyof typeof THEMES;
export type MeasureText = (
  text: string,
  size: number,
  font?: "sans" | "display" | "condensed",
  bold?: boolean,
) => number;
export const fontFamily = (font?: string) =>
  font === "condensed"
    ? '"Anton", "Noto Sans Devanagari", "Noto Sans Gurmukhi", sans-serif'
    : font === "display"
      ? '"Great Vibes", "Noto Sans Devanagari", "Noto Sans Gurmukhi", cursive'
      : '"Noto Sans Devanagari", "Noto Sans Gurmukhi", "Nirmala UI", Arial, sans-serif';
export const approximateMeasure: MeasureText = (text, size) => Array.from(text).length * size * 0.7;
function graphemes(text: string) {
  if (typeof Intl.Segmenter !== "function")
    return text.match(/\P{Mark}\p{Mark}*|\p{Mark}+/gu) ?? Array.from(text);
  return Array.from(
    new Intl.Segmenter(undefined, { granularity: "grapheme" }).segment(text),
    (part) => part.segment,
  );
}
/** Same wrapping algorithm drives auto pagination and canvas export. Never drops a word. */
export function wrapSlideText(
  text: string,
  width: number,
  size: number,
  measure: MeasureText = approximateMeasure,
  font?: "sans" | "display" | "condensed",
  bold = false,
): string[] {
  const lines: string[] = [];
  for (const paragraph of text.replace(/\r\n?/g, "\n").split("\n")) {
    if (!paragraph) {
      lines.push("");
      continue;
    }
    let line = "";
    for (const word of paragraph.match(/\S+\s*|\s+/gu) ?? []) {
      if (measure(line + word, size, font, bold) <= width) {
        line += word;
        continue;
      }
      if (line.trim()) {
        lines.push(line.trimEnd());
        line = "";
      }
      if (measure(word.trimEnd(), size, font, bold) <= width) {
        line = word;
        continue;
      }
      for (const part of graphemes(word)) {
        if (line && measure(line + part, size, font, bold) > width) {
          lines.push(line);
          line = "";
        }
        line += part;
      }
    }
    if (line) lines.push(line.trimEnd());
  }
  return lines;
}
function elementLines(e: SlideElement, width: number, size: number, measure: MeasureText) {
  return e.runs?.length
    ? layoutSlideRuns(e.runs, width, (run) => measure(run.text, size, e.font, !!run.bold)).length
    : wrapSlideText(e.text, width, size, measure, e.font, e.bold).length;
}
export function fittedElement(
  e: SlideElement,
  size: SlideSize,
  measure: MeasureText = approximateMeasure,
): SlideElement {
  if (e.type !== "text") return e;
  const width = (e.w / 100) * size.width * 0.98,
    height = (e.h / 100) * size.height;
  let fontSize = e.fontSize;
  while (fontSize > 10 && elementLines(e, width, fontSize, measure) * fontSize * 1.3 > height)
    fontSize = Math.max(10, fontSize - 1);
  return { ...e, fontSize };
}
export function textOverflows(
  e: SlideElement,
  size: SlideSize,
  measure: MeasureText = approximateMeasure,
) {
  return (
    e.type === "text" &&
    elementLines(e, (e.w / 100) * size.width * 0.98, e.fontSize, measure) * e.fontSize * 1.3 >
      (e.h / 100) * size.height
  );
}
function box(
  type: SlideElement["type"],
  x: number,
  y: number,
  w: number,
  h: number,
  fill: string,
  opacity = 1,
): SlideElement {
  return {
    ...textElement("", y),
    type,
    x,
    y,
    w: Math.max(0.1, w),
    h: Math.max(0.1, h),
    fill,
    opacity,
    role: "decoration",
  };
}
function label(
  text: string,
  slot: SlideElement["slot"],
  x: number,
  y: number,
  w: number,
  h: number,
  colour: string,
  fontSize: number,
  role: "brand" | "content" = "brand",
  font: "sans" | "display" | "condensed" = "sans",
): SlideElement {
  return {
    ...textElement(text, y),
    slot,
    x,
    y,
    w,
    h,
    colour,
    fontSize: Math.max(10, Math.min(140, fontSize)),
    role,
    font,
    bold: font !== "display",
  };
}
/** Original editable vector layout: no uploaded reference photograph is used. */
export function makeDesignedSlide(
  theme: ThemeName,
  purpose: "lesson" | "cover" | "thumbnail",
  size: SlideSize,
  brand: SlideBrand,
  measure: MeasureText = approximateMeasure,
): Slide {
  slideSizeSchema.parse(size);
  const palette = THEMES[theme],
    scale = Math.min(size.width, size.height) / 720;
  const decorations: SlideElement[] = [];
  if (theme === "galaxy") {
    decorations.push(
      box("ellipse", 0, 20, 68, 45, "#0f6595", 0.12),
      box("ellipse", 7, 23, 49, 33, "#2689ae", 0.12),
      box("ellipse", 11, 29, 35, 20, "#54bde0", 0.09),
    );
    for (let i = 0; i < 12; i++) {
      const r = i % 3 === 0 ? 3 : 1.5;
      decorations.push(
        box(
          "ellipse",
          4 + ((i * 29) % 91),
          17 + ((i * 17) % 68),
          (r / size.width) * 100,
          (r / size.height) * 100,
          i % 2 ? "#8bdfff" : "#ffffff",
          0.55,
        ),
      );
    }
  } else
    decorations.push(
      box("rectangle", 0, 0, 1.3, 100, palette.accent),
      box("rectangle", 81, 17, 19, 67, palette.panel, 0.55),
    );
  decorations.push(
    box("rectangle", 4, 13, 92, 0.2, palette.accent),
    box("rectangle", 4, 87, 92, 0.2, palette.accent),
  );
  const logo = Math.min(size.width, size.height) * 0.075;
  const brandElements = [
    {
      ...box(
        "image",
        100 - (logo / size.width) * 100 - 4,
        3,
        (logo / size.width) * 100,
        (logo / size.height) * 100,
        "#ffffff",
      ),
      image: NOTES_PRINT_LOGO,
      role: "brand" as const,
      slot: "logo" as const,
    },
    label(brand.appName, "appName", 6, 3, 77, 7, palette.ink, 22 * scale),
    label(brand.teacher, "teacher", 6, 90, 42, 7, palette.accent, 30 * scale, "brand", "display"),
    {
      ...label(
        brand.series,
        "series",
        52,
        89,
        42,
        4.5,
        palette.accent,
        22 * scale,
        "brand",
        "display",
      ),
      align: "right" as const,
    },
    {
      ...label(brand.subject, "subject", 52, 94, 42, 4.5, palette.ink, 18 * scale),
      align: "right" as const,
    },
  ];
  const content =
    purpose === "lesson"
      ? [
          label("Lesson title", "title", 7, 17, 86, 10, palette.accent, 42 * scale, "content"),
          {
            ...label(
              "Add your teaching notes here.",
              "body",
              7,
              30,
              86,
              53,
              palette.ink,
              30 * scale,
              "content",
            ),
            bold: false,
          },
        ]
      : [
          {
            ...label(
              brand.series,
              "series",
              7,
              21,
              86,
              20,
              palette.accent,
              90 * scale,
              "content",
              "display",
            ),
            align: "center" as const,
          },
          {
            ...label(brand.subject, "subject", 7, 43, 86, 21, palette.ink, 82 * scale, "content"),
            align: "center" as const,
          },
          {
            ...label(
              brand.teacher,
              "teacher",
              7,
              69,
              86,
              12,
              palette.accent,
              46 * scale,
              "content",
              "display",
            ),
            align: "center" as const,
          },
        ];
  return {
    id: crypto.randomUUID(),
    background: palette.background,
    design: theme,
    purpose,
    notes: "",
    elements: [...decorations, ...brandElements, ...content].map((e) =>
      fittedElement(e, size, measure),
    ),
  };
}
function paginateBody(text: string, body: SlideElement, size: SlideSize, measure: MeasureText) {
  const lines = wrapSlideText(
    text,
    (body.w / 100) * size.width * 0.96,
    body.fontSize,
    measure,
    body.font,
    body.bold,
  );
  const capacity = Math.max(
    1,
    Math.floor(((body.h / 100) * size.height) / (body.fontSize * 1.35)) - 1,
  );
  const result: string[] = [];
  for (let i = 0; i < lines.length; i += capacity)
    result.push(lines.slice(i, i + capacity).join("\n"));
  return result.length ? result : [""];
}
export function generateTeachingDeck(
  text: string,
  theme: ThemeName,
  size: SlideSize,
  brand: SlideBrand,
  measure: MeasureText = approximateMeasure,
): Deck {
  if (!text.trim()) throw new Error("Paste your lesson text first.");
  if (text.length > 60000)
    throw new Error("Use up to 60,000 characters per generation; split longer lessons.");
  const slides: Slide[] = [];
  const sections: { title: string; body: string[] }[] = [];
  let hasHeading = false;
  let section = { title: brand.subject || "Study notes", body: [] as string[] };
  for (const line of text.replace(/\r\n?/g, "\n").split("\n")) {
    if (/^#{1,3}\s/.test(line) && line.length <= 120) {
      if (section.body.length || hasHeading) sections.push(section);
      hasHeading = true;
      section = { title: line.replace(/^#{1,3}\s+/, ""), body: [] };
    } else section.body.push(line);
  }
  sections.push(section);
  for (const entry of sections) {
    const base = makeDesignedSlide(theme, "lesson", size, brand, measure),
      title = base.elements.find((e) => e.slot === "title")!,
      body = base.elements.find((e) => e.slot === "body")!;
    title.text = entry.title;
    Object.assign(title, fittedElement(title, size, measure));
    for (const chunk of paginateBody(entry.body.join("\n"), body, size, measure)) {
      const slide = cloneSlide(base);
      slide.generated = true;
      slide.elements.find((e) => e.slot === "body")!.text = chunk;
      slides.push(slide);
      if (slides.length > 60)
        throw new Error(
          "This text needs more than 60 slides. Split it into smaller projects; no content has been saved or truncated.",
        );
    }
  }
  return deckSchema.parse({
    version: 1,
    title: brand.series || brand.subject || "KKCC lesson",
    size,
    brand,
    slides,
  });
}
/** Turn a long lesson into editable slide objects without replacing or resizing any old slide. */
export function insertTeachingSlides(
  deck: Deck,
  text: string,
  theme: ThemeName,
  afterIndex: number,
  measure: MeasureText = approximateMeasure,
): { deck: Deck; added: number } {
  if (!Number.isInteger(afterIndex) || afterIndex < 0 || afterIndex >= deck.slides.length)
    throw new Error("Choose an existing slide to insert after.");
  if (deck.slides.length >= 60)
    throw new Error(
      "60-slide limit: start a second project for more lessons. Nothing was changed.",
    );
  const generated = generateTeachingDeck(
    text,
    theme,
    deck.size ?? DEFAULT_SLIDE_SIZE,
    deck.brand ?? DEFAULT_SLIDE_BRAND,
    measure,
  );
  if (deck.slides.length + generated.slides.length > 60)
    throw new Error(
      "This lesson needs more than the remaining slides (60 maximum). Split it into another project; nothing was changed.",
    );
  // Preserve the existing title, size, brand, element IDs and per-character styles.
  // Parse once, before the caller commits, so an oversized project fails atomically.
  return {
    deck: deckSchema.parse({
      ...deck,
      slides: [
        ...deck.slides.slice(0, afterIndex + 1),
        ...generated.slides,
        ...deck.slides.slice(afterIndex + 1),
      ],
    }),
    added: generated.slides.length,
  };
}

export function resizePresentation(
  deck: Deck,
  size: SlideSize,
  measure: MeasureText = approximateMeasure,
): Deck {
  slideSizeSchema.parse(size);
  const old = deck.size ?? DEFAULT_SLIDE_SIZE,
    scale = Math.min(size.width, size.height) / Math.min(old.width, old.height),
    slides: Slide[] = [];
  for (const original of deck.slides) {
    const base = cloneSlide(original);
    base.elements = base.elements.map((e) => {
      let next = { ...e, fontSize: Math.max(10, Math.min(140, Math.round(e.fontSize * scale))) };
      if (e.type === "image" || e.type === "ellipse") {
        const aspect = (e.w * old.width) / (e.h * old.height),
          availableW = (e.w / 100) * size.width,
          availableH = (e.h / 100) * size.height;
        const w = Math.min(availableW, availableH * aspect),
          h = w / aspect;
        next = {
          ...next,
          w: Math.max(0.1, (w / size.width) * 100),
          h: Math.max(0.1, (h / size.height) * 100),
        };
      }
      return e.slot === "body" && base.generated ? next : fittedElement(next, size, measure);
    });
    const body = base.elements.find((e) => e.slot === "body");
    if (base.generated && body && !body.runs?.length) {
      for (const chunk of paginateBody(body.text, body, size, measure)) {
        const page = cloneSlide(base);
        page.elements.find((e) => e.slot === "body")!.text = chunk;
        slides.push(page);
      }
    } else slides.push(base);
    if (slides.length > 60)
      throw new Error(
        "This ratio needs more than 60 slides. Split the project first; original remains unchanged.",
      );
  }
  return deckSchema.parse({ ...deck, size, slides });
}
const REFERENCE_TEMPLATE_IDS = ["kkcc-reference-teaching-v2", "kkcc-reference-cover-v2"] as const;

/** Add the built-in reference designs without replacing an existing project or its branding.
 * Each stable marker prevents a second click (including after save/reopen) from duplicating them.
 * Legacy copies from the previous replace-only release are recognised by their original notes.
 */
export function appendReferenceSlides(
  deck: Deck,
  reference: Deck,
  measure: MeasureText = approximateMeasure,
): { deck: Deck; added: number } {
  if (reference.slides.length !== REFERENCE_TEMPLATE_IDS.length)
    throw new Error(
      "The reference pack must contain exactly two slides. Original slides are unchanged.",
    );
  const missing = REFERENCE_TEMPLATE_IDS.flatMap((id, index) => {
    const alreadyPresent = deck.slides.some(
      (slide) =>
        slide.templateId === id ||
        (!slide.templateId &&
          slide.notes.startsWith("Reference reconstruction.") &&
          slide.design === "galaxy" &&
          slide.purpose === (index === 0 ? "lesson" : "cover") &&
          slide.elements.some((element) => element.slot === "logo" && element.type === "image")),
    );
    return alreadyPresent ? [] : [index];
  });
  if (!missing.length) return { deck, added: 0 };
  if (deck.slides.length + missing.length > 60)
    throw new Error(
      "60-slide limit: save/open a second project for the reference designs. Nothing was replaced.",
    );
  const target = deck.size ?? DEFAULT_SLIDE_SIZE;
  const source = reference.size ?? DEFAULT_SLIDE_SIZE;
  const slides =
    source.width === target.width && source.height === target.height
      ? reference.slides
      : resizePresentation(reference, target, measure).slides;
  const additions = missing.map((index) => ({
    ...cloneSlide(slides[index]!),
    templateId: REFERENCE_TEMPLATE_IDS[index]!,
  }));
  const next: Deck = { ...deck, slides: [...deck.slides, ...additions] };
  const bytes = next.slides.reduce(
    (total, slide) =>
      total +
      slide.elements.reduce((sum, element) => sum + element.text.length + element.image.length, 0),
    0,
  );
  if (bytes > 24_000_000)
    throw new Error(
      "24 MB project limit: save/open a second project for the reference designs. Nothing was replaced.",
    );
  deckSchema.parse(next);
  return { deck: next, added: additions.length };
}

export function updateSlideBrand(
  deck: Deck,
  brand: SlideBrand,
  measure: MeasureText = approximateMeasure,
): Deck {
  const size = deck.size ?? DEFAULT_SLIDE_SIZE;
  return {
    ...deck,
    brand,
    slides: deck.slides.map((s) => ({
      ...s,
      elements: s.elements.map((e) =>
        e.slot && e.slot in brand
          ? fittedElement({ ...e, text: brand[e.slot as keyof SlideBrand] }, size, measure)
          : e,
      ),
    })),
  };
}
export async function browserSlideMeasure(): Promise<MeasureText> {
  await Promise.all([
    document.fonts.load('32px "Noto Sans Gurmukhi"', "ਪੰਜਾਬੀ"),
    document.fonts.load('bold 32px "Noto Sans Gurmukhi"', "ਪੰਜਾਬੀ"),
    document.fonts.load('32px "Noto Sans Devanagari"', "हिन्दी"),
    document.fonts.load('bold 32px "Noto Sans Devanagari"', "हिन्दी"),
    document.fonts.load('40px "Great Vibes"', "KKCC"),
    document.fonts.load('40px "Anton"', "PSTET"),
  ]);
  const ctx = document.createElement("canvas").getContext("2d")!;
  return (text, size, font, bold) => {
    ctx.font = `${bold ? "bold " : ""}${size}px ${fontFamily(font)}`;
    return ctx.measureText(text).width;
  };
}
