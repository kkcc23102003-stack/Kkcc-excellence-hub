import { normaliseAuthorRuns, plainAuthorRuns, type AuthorRun } from "./author-inline";

export type RichLine = { runs: AuthorRun[]; width: number };
const graphemes = (text: string) =>
  typeof Intl.Segmenter === "function"
    ? Array.from(
        new Intl.Segmenter(undefined, { granularity: "grapheme" }).segment(text),
        (x) => x.segment,
      )
    : (text.match(/\P{Mark}\p{Mark}*|\p{Mark}+/gu) ?? Array.from(text));

/** Word wrapping with each native text run's real measured font width. Used by PDF and thumbnails. */
export function layoutSlideRuns(
  input: readonly AuthorRun[],
  maxWidth: number,
  measure: (run: AuthorRun) => number,
): RichLine[] {
  const runs = normaliseAuthorRuns(input);
  const text = plainAuthorRuns(runs);
  const slice = (start: number, end: number): AuthorRun[] => {
    const pieces: AuthorRun[] = [];
    let offset = 0;
    for (const run of runs) {
      const from = Math.max(0, start - offset),
        to = Math.min(run.text.length, end - offset);
      if (from < to) pieces.push({ ...run, text: run.text.slice(from, to) });
      offset += run.text.length;
      if (offset >= end) break;
    }
    return pieces;
  };
  const output: RichLine[] = [];
  let line: AuthorRun[] = [];
  let width = 0;
  const add = (pieces: AuthorRun[], measured: number) => {
    line.push(...pieces);
    width += measured;
  };
  const flush = () => {
    const value = plainAuthorRuns(line);
    const trimmed = value.length - value.trimEnd().length;
    if (trimmed) line = sliceLine(line, value.length - trimmed);
    output.push({
      runs: normaliseAuthorRuns(line),
      width: line.reduce((n, run) => n + measure(run), 0),
    });
    line = [];
    width = 0;
  };
  for (const match of text.matchAll(/\n|\S+[^\S\n]*|[^\S\n]+/gu)) {
    const token = match[0],
      start = match.index!;
    if (token === "\n") {
      flush();
      continue;
    }
    const pieces = slice(start, start + token.length);
    const tokenWidth = pieces.reduce((n, run) => n + measure(run), 0);
    if (width && width + tokenWidth > maxWidth) flush();
    if (tokenWidth <= maxWidth) {
      add(pieces, tokenWidth);
      continue;
    }
    // Unbroken long text/Unicode: wrap at grapheme boundaries, not UTF-16 code units.
    let cursor = start;
    for (const char of graphemes(token)) {
      const unit = slice(cursor, cursor + char.length),
        size = unit.reduce((n, run) => n + measure(run), 0);
      if (width && width + size > maxWidth) flush();
      add(unit, size);
      cursor += char.length;
    }
  }
  flush();
  return output;
}
function sliceLine(runs: AuthorRun[], length: number): AuthorRun[] {
  const trimmed: AuthorRun[] = [];
  let remaining = length;
  for (const run of runs) {
    if (!remaining) break;
    const text = run.text.slice(0, remaining);
    trimmed.push({ ...run, text });
    remaining -= text.length;
  }
  return trimmed;
}
