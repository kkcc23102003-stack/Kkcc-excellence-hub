export type CouponScope = "all" | "course" | "material" | "test" | "series" | "notes_series";

export type CouponScopeRecord = {
  applies_to_kind?: CouponScope | null;
  applies_to_course_id?: string | null;
  applies_to_item_id?: string | null;
};

const couponScopeLabels: Record<CouponScope, string> = {
  all: "all paid products",
  course: "batches/courses",
  material: "individual paid Notes",
  test: "individual tests",
  series: "Test Series",
  notes_series: "Notes Series",
};

/** Return an explanation when a coupon's persisted scope does not match a product. */
export function couponScopeError(
  coupon: CouponScopeRecord,
  targetKind: Exclude<CouponScope, "all">,
  targetCourseId: string | null,
  targetItemId: string | null = null,
) {
  const scope = coupon.applies_to_kind ?? (coupon.applies_to_course_id ? "course" : "all");
  if (scope !== "all" && scope !== targetKind) {
    return `This coupon is restricted to ${couponScopeLabels[scope]}.`;
  }
  if (scope === "course" && coupon.applies_to_course_id) {
    if (!targetCourseId || coupon.applies_to_course_id !== targetCourseId) {
      return "This coupon is only valid for its assigned batch/course.";
    }
  }
  if (coupon.applies_to_item_id && coupon.applies_to_item_id !== targetItemId) {
    return "This coupon is restricted to its selected product item.";
  }
  return "";
}
