import type { SeriesAccessGrantRow } from "@/integrations/supabase/db";
import { projectContent } from "./project-content.server";
import { applyNotesSeriesPricing } from "./notes-series-pricing.server";
import { freePreviewNoteIds } from "./notes-free-preview";
import {
  NOTES_SERIES_ACCESS_PREFIX,
  notesSeriesAccessKey,
  notesSeriesSchema,
  seriesNoteIds,
  type NotesSeries,
} from "./notes-series";
import { readNotesCatalogSetting } from "./notes-catalog-storage.server";

const PREFIX = "notes_series_v1:";
export const NOTES_SERIES_GRANT_PREFIX = NOTES_SERIES_ACCESS_PREFIX;
export const notesSeriesGrantId = notesSeriesAccessKey;

export async function getNotesSeriesById(id: string) {
  const { data, error } = await projectContent
    .from("site_settings")
    .select("value")
    .eq("key", PREFIX + id)
    .maybeSingle();
  if (error) throw new Error(error.message);
  if (!data) return null;
  const stored = await readNotesCatalogSetting<NotesSeries>({
    table: "site_settings",
    key: PREFIX + id,
    kind: "series",
    id,
    value: data.value,
  });
  return applyNotesSeriesPricing(notesSeriesSchema.parse(stored.data));
}

export async function getPaidNotesSeriesForMaterial(noteId: string) {
  const { data, error } = await projectContent
    .from("site_settings")
    .select("key,value")
    .ilike("key", `${PREFIX}%`);
  if (error) throw new Error(error.message);
  const catalog = (
    await Promise.all(
      (data ?? [])
        .filter((row) => row.key.startsWith(PREFIX))
        .map(async (row) => {
          const id = row.key.slice(PREFIX.length);
          const stored = await readNotesCatalogSetting<NotesSeries>({
            table: "site_settings",
            key: row.key,
            kind: "series",
            id,
            value: row.value,
          });
          return notesSeriesSchema.parse(stored.data);
        }),
    )
  )
    .filter((series) => series.published && series.kind === "paid")
    .filter((series) => seriesNoteIds(series).includes(noteId))
    .sort(
      (a, b) =>
        Number(b.priceInr > 0 || b.priceCoins > 0) - Number(a.priceInr > 0 || a.priceCoins > 0),
    );
  return catalog[0] ?? null;
}

export async function getNotesSeriesMaterialMetadata(publishedNoteIds: string[]) {
  const { data, error } = await projectContent
    .from("site_settings")
    .select("key,value")
    .ilike("key", `${PREFIX}%`);
  if (error) throw new Error(error.message);
  const available = new Set(publishedNoteIds);
  const catalog = (
    await Promise.all(
      (data ?? [])
        .filter((row) => row.key.startsWith(PREFIX))
        .map(async (row) => {
          const id = row.key.slice(PREFIX.length);
          const stored = await readNotesCatalogSetting<NotesSeries>({
            table: "site_settings",
            key: row.key,
            kind: "series",
            id,
            value: row.value,
          });
          return notesSeriesSchema.parse(stored.data);
        }),
    )
  ).filter((series) => series.published && series.kind === "paid");
  const materialChunks = Array.from(
    { length: Math.ceil(publishedNoteIds.length / 250) },
    (_, index) => publishedNoteIds.slice(index * 250, (index + 1) * 250),
  );
  const previewNotes = (
    await Promise.all(
      materialChunks.map(async (chunk) => {
        if (!chunk.length) return [];
        const { data: rows, error: materialError } = await projectContent
          .from("materials")
          .select("id,subject,sort_order,created_at,is_free_preview")
          .eq("is_published", true)
          .in("id", chunk);
        if (materialError) throw new Error(materialError.message);
        return rows ?? [];
      }),
    )
  ).flat();
  const freePreviewIds = freePreviewNoteIds(previewNotes);
  const membership = new Map<string, { id: string; name: string }>();
  for (const series of [...catalog].sort(
    (a, b) =>
      Number(b.priceInr > 0 || b.priceCoins > 0) - Number(a.priceInr > 0 || a.priceCoins > 0),
  )) {
    for (const id of seriesNoteIds(series)) {
      if (available.has(id) && !membership.has(id))
        membership.set(id, { id: series.id, name: series.name });
    }
  }
  return { freePreviewIds, membership };
}

export async function getFreeNotesSeriesPreviewIds() {
  const { data, error } = await projectContent
    .from("materials")
    .select("id,subject,sort_order,created_at,is_free_preview")
    .eq("is_published", true);
  if (error) throw new Error(error.message);
  return [...freePreviewNoteIds(data ?? [])];
}

export async function isFreeNotesSeriesPreview(noteId: string) {
  return (await getFreeNotesSeriesPreviewIds()).includes(noteId);
}

export async function hasNotesSeriesGrantForMaterial(
  grants: SeriesAccessGrantRow[],
  noteId: string,
) {
  const seriesIds = grants
    .filter(
      (grant) => grant.revoked_at === null && grant.series_id.startsWith(NOTES_SERIES_GRANT_PREFIX),
    )
    .map((grant) => grant.series_id.slice(NOTES_SERIES_GRANT_PREFIX.length));
  if (!seriesIds.length) return false;
  const keys = seriesIds.map((id) => PREFIX + id);
  const { data, error } = await projectContent
    .from("site_settings")
    .select("key,value")
    .in("key", keys);
  if (error) throw new Error(error.message);
  const catalog = await Promise.all(
    (data ?? []).map(async (row) => {
      const id = row.key.slice(PREFIX.length);
      const stored = await readNotesCatalogSetting<NotesSeries>({
        table: "site_settings",
        key: row.key,
        kind: "series",
        id,
        value: row.value,
      });
      return notesSeriesSchema.parse(stored.data);
    }),
  );
  return catalog.some((series) => seriesNoteIds(series).includes(noteId));
}
