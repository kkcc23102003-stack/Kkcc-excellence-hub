import { Buffer } from "node:buffer";
import { createHash } from "node:crypto";
import { supabaseAdmin } from "@/integrations/supabase/client.server";
import { isLocalManagedFixture } from "./managed-content-tables";
import { projectContent } from "./project-content.server";

export type NotesCatalogKind = "series" | "batch";
export const NOTES_CATALOG_BUCKET = "course-content";
const POINTER_PREFIX = "kkcc-storage-json:v1:";
const MAX_CATALOG_BYTES = 20_000_000;
const UUID = /^[0-9a-f]{8}-[0-9a-f]{4}-[1-8][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i;

type StoredPointer = { bucket: string; path: string; sha256: string };
type SettingsTable = "site_settings" | "private_settings";

function objectPath(kind: NotesCatalogKind, id: string, sha256: string) {
  return `notes-catalog/${kind}/${id}/${sha256}.json`;
}

function parsePointer(value: string, kind: NotesCatalogKind, id: string): StoredPointer | null {
  if (!UUID.test(id)) throw new Error("Notes catalogue ID is invalid.");
  if (!value.startsWith(POINTER_PREFIX)) return null;
  let pointer: StoredPointer;
  try {
    pointer = JSON.parse(value.slice(POINTER_PREFIX.length)) as StoredPointer;
  } catch {
    throw new Error("Notes catalogue Storage pointer is invalid. Contact Admin.");
  }
  if (
    pointer.bucket !== NOTES_CATALOG_BUCKET ||
    !/^[a-f0-9]{64}$/.test(pointer.sha256) ||
    pointer.path !== objectPath(kind, id, pointer.sha256)
  ) {
    throw new Error("Notes catalogue Storage pointer is outside its private catalogue path.");
  }
  return pointer;
}

async function adminStorage() {
  const { data, error } = await supabaseAdmin.storage.getBucket(NOTES_CATALOG_BUCKET);
  if (error || !data || data.public)
    throw new Error(
      `Notes catalogue Storage bucket is missing or public; run the latest SQL bundle. ${error?.message || ""}`,
    );
  return supabaseAdmin.storage.from(NOTES_CATALOG_BUCKET);
}

/** Write an immutable, private JSON version and return its compact DB pointer. */
export async function writeNotesCatalogObject(
  kind: NotesCatalogKind,
  id: string,
  value: unknown,
): Promise<string> {
  if (!UUID.test(id)) throw new Error("Notes catalogue ID is invalid.");
  const json = JSON.stringify(value);
  const bytes = Buffer.from(json, "utf8");
  if (bytes.byteLength > MAX_CATALOG_BYTES)
    throw new Error("This Notes Series/Batch configuration exceeds the 20 MB catalogue limit.");
  const sha256 = createHash("sha256").update(bytes).digest("hex");
  const path = objectPath(kind, id, sha256);
  const storage = await adminStorage();
  const { error } = await storage.upload(path, bytes, {
    contentType: "application/json",
    cacheControl: "0",
    upsert: false,
  });
  if (error) {
    const { data: existing, error: existingError } = await storage.download(path);
    if (existingError || !existing)
      throw new Error(
        `Could not save catalogue data to private Supabase Storage: ${error.message}`,
      );
    const existingBytes = Buffer.from(await existing.arrayBuffer());
    if (createHash("sha256").update(existingBytes).digest("hex") !== sha256)
      throw new Error("Existing Notes catalogue object failed its content-hash check.");
  }
  const { data: readBack, error: readError } = await storage.download(path);
  if (readError || !readBack)
    throw new Error(
      `Catalogue Storage read-back failed: ${readError?.message || "missing object"}`,
    );
  const storedBytes = Buffer.from(await readBack.arrayBuffer());
  if (
    storedBytes.byteLength > MAX_CATALOG_BYTES ||
    createHash("sha256").update(storedBytes).digest("hex") !== sha256
  )
    throw new Error("Catalogue Storage read-back failed its size or integrity check.");
  return `${POINTER_PREFIX}${JSON.stringify({ bucket: NOTES_CATALOG_BUCKET, path, sha256 })}`;
}

async function readPointer<T>(pointer: StoredPointer): Promise<T> {
  const storage = await adminStorage();
  const { data, error } = await storage.download(pointer.path);
  if (error || !data)
    throw new Error(
      "Notes catalogue data is missing from private Supabase Storage. No content was deleted.",
    );
  const bytes = Buffer.from(await data.arrayBuffer());
  if (bytes.byteLength > MAX_CATALOG_BYTES)
    throw new Error("Stored Notes Series/Batch data exceeds the 20 MB catalogue limit.");
  const actualHash = createHash("sha256").update(bytes).digest("hex");
  if (actualHash !== pointer.sha256)
    throw new Error("Notes catalogue Storage integrity check failed. Contact Admin.");
  try {
    return JSON.parse(bytes.toString("utf8")) as T;
  } catch {
    throw new Error("Notes catalogue JSON in Storage is invalid. No content was deleted.");
  }
}

/**
 * Read a catalogue setting, lazily moving legacy JSON values to Storage.
 * The DB row becomes only an index/pointer. Compare-and-swap prevents a
 * simultaneous Admin save from being overwritten during this one-time copy.
 */
export async function readNotesCatalogSetting<T>(input: {
  table: SettingsTable;
  key: string;
  kind: NotesCatalogKind;
  id: string;
  value: string;
}): Promise<{ data: T; storedValue: string }> {
  const pointer = parsePointer(input.value, input.kind, input.id);
  if (pointer) return { data: await readPointer<T>(pointer), storedValue: input.value };

  if (Buffer.byteLength(input.value, "utf8") > MAX_CATALOG_BYTES)
    throw new Error(`Legacy ${input.kind} catalogue exceeds the 20 MB Storage limit.`);
  let legacy: T;
  try {
    legacy = JSON.parse(input.value) as T;
  } catch {
    throw new Error(`Legacy ${input.kind} catalogue JSON is invalid at ${input.key}.`);
  }
  const nextPointer = await writeNotesCatalogObject(input.kind, input.id, legacy);
  let pointerUpdated = false;
  if (isLocalManagedFixture(input.table, process.env)) {
    const { data: changed, error: updateError } = await projectContent
      .from(input.table)
      .update({ value: nextPointer })
      .eq("key", input.key)
      .eq("value", input.value)
      .select("key")
      .limit(1);
    if (updateError)
      throw new Error(
        `Storage copy succeeded, but the local catalogue index could not be updated: ${updateError.message}`,
      );
    pointerUpdated = Boolean(changed?.length);
  } else {
    const p_old_md5 = createHash("md5").update(input.value, "utf8").digest("hex");
    const { data, error } = await supabaseAdmin.rpc("move_notes_catalog_pointer", {
      p_table: input.table,
      p_key: input.key,
      p_old_md5,
      p_new_value: nextPointer,
    });
    if (error)
      throw new Error(
        `Storage copy succeeded, but the catalogue index could not be updated: ${error.message}`,
      );
    pointerUpdated = Boolean(data);
  }
  if (pointerUpdated) return { data: legacy, storedValue: nextPointer };

  // Another editor may have saved while the legacy object was being copied.
  // Follow the winner's pointer/value; never serve the stale copy as current.
  const latest = await projectContent
    .from(input.table)
    .select("value")
    .eq("key", input.key)
    .maybeSingle();
  if (latest.error || !latest.data)
    throw new Error("Notes catalogue changed during Storage migration. Reload and retry.");
  if (latest.data.value === input.value)
    throw new Error("Notes catalogue index could not be migrated to Storage. Retry the request.");
  return readNotesCatalogSetting<T>({ ...input, value: latest.data.value });
}
