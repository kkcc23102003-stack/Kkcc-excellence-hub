/** Local, optimised 3D-style illustrations; uploaded covers always take precedence. */
export function subjectArtwork(subject: string): string {
  if (/math|algebra|geometry|गणित|ਗਣਿਤ|account|commerce|reasoning/i.test(subject))
    return "/artwork/math.webp";
  if (/physics|chemistry|biology|science|medical|neet|विज्ञान|ਵਿਗਿਆਨ/i.test(subject))
    return "/artwork/science.webp";
  if (
    /history|geography|polity|social|sst|general knowledge|punjab gk|world|environment/i.test(
      subject,
    )
  )
    return "/artwork/world.webp";
  return "/artwork/learning.webp";
}

/** Display only: these rows were already authorised/filtered by the existing access endpoint. */
export function accessValidity(
  grants: readonly { expires_at?: string | null }[],
): string | undefined {
  if (!grants.length) return undefined;
  if (grants.some((grant) => grant.expires_at === null)) return "No expiry";
  const dates = grants.map((grant) => Date.parse(grant.expires_at ?? "")).filter(Number.isFinite);
  return dates.length
    ? `Valid till ${new Date(Math.max(...dates)).toLocaleDateString("en-IN", { day: "2-digit", month: "short", year: "numeric" })}`
    : undefined;
}
