/** Touch-sized one-tap note colours; the full mixer remains available for custom shades. */
export const QUICK_NOTE_TEXT_COLOURS = [
  { name: "Ink", hex: "#172b36" },
  { name: "Blue", hex: "#1d4ed8" },
  { name: "Red", hex: "#b91c1c" },
  { name: "Green", hex: "#166534" },
  { name: "Purple", hex: "#7e22ce" },
] as const;
export const QUICK_NOTE_HIGHLIGHTS = [
  { name: "Yellow", hex: "#fff0a6" },
  { name: "Mint", hex: "#bcead8" },
  { name: "Pink", hex: "#ffd4e5" },
  { name: "Blue", hex: "#cde8ff" },
  { name: "Orange", hex: "#ffe0bc" },
] as const;
