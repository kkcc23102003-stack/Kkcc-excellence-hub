import { Buffer } from "node:buffer";
import { createHash } from "node:crypto";
import { supabaseAdmin } from "@/integrations/supabase/client.server";
import { projectContent } from "@/lib/project-content.server";
import { isLocalManagedFixture } from "./managed-content-tables";
import { parseCustomSeriesCatalog, type CustomSeriesCatalog } from "./test-series-catalog";
import {
  CUSTOM_SERIES_CATALOG_BUCKET,
  CUSTOM_SERIES_CATALOG_POINTER_PREFIX,
  MAX_CUSTOM_SERIES_CATALOG_BYTES,
  readCustomSeriesCatalogValue,
  writeCustomSeriesCatalogObject,
  type CustomSeriesCatalogStorageIO,
} from "./custom-series-catalog-storage";

export const CUSTOM_SERIES_CATALOG_KEY = "test_series_custom_catalog";

async function storageIO(): Promise<CustomSeriesCatalogStorageIO> {
  const bucket = await supabaseAdmin.storage.getBucket(CUSTOM_SERIES_CATALOG_BUCKET);
  if (bucket.error || !bucket.data || bucket.data.public)
    throw new Error(
      `Private test-series Storage bucket unavailable. Run the latest Supabase SQL bundle before deploying this release. ${bucket.error?.message || ""}`,
    );
  const storage = supabaseAdmin.storage.from(CUSTOM_SERIES_CATALOG_BUCKET);
  return {
    write: async (path, bytes) => {
      const { error } = await storage.upload(path, bytes, {
        contentType: "application/json",
        cacheControl: "0",
        upsert: false,
      });
      if (error) {
        const { data, error: readError } = await storage.download(path);
        if (readError || !data)
          throw new Error(`Test-series catalogue upload failed: ${error.message}`);
        const existing = Buffer.from(await data.arrayBuffer());
        if (!existing.equals(bytes))
          throw new Error("Existing test-series catalogue object failed its content-hash check.");
      }
    },
    read: async (path) => {
      const { data, error } = await storage.download(path);
      if (error || !data)
        throw new Error(
          `Test-series catalogue is missing from private Supabase Storage. ${error?.message || ""}`,
        );
      const bytes = Buffer.from(await data.arrayBuffer());
      if (bytes.byteLength > MAX_CUSTOM_SERIES_CATALOG_BYTES)
        throw new Error("Test-series catalogue exceeds the 20 MB Storage limit.");
      return bytes;
    },
    compareAndSwap: async (oldValue, newValue) => {
      // Hash in PostgreSQL instead of sending potentially megabytes of old JSON
      // through a PostgREST filter URL.
      const p_old_md5 = createHash("md5").update(oldValue).digest("hex");
      const { data, error } = await supabaseAdmin.rpc("move_test_series_catalog_pointer", {
        p_old_md5,
        p_new_value: newValue,
      });
      if (error) throw new Error(`Test-series Storage pointer update failed: ${error.message}`);
      return Boolean(data);
    },
    readCurrentValue: async () => {
      const { data, error } = await projectContent
        .from("site_settings")
        .select("value")
        .eq("key", CUSTOM_SERIES_CATALOG_KEY)
        .maybeSingle();
      if (error) throw new Error(`Test-series catalogue could not be reloaded: ${error.message}`);
      return data?.value ?? null;
    },
  };
}

export async function readStoredCustomSeriesCatalog(value: string) {
  if (isLocalManagedFixture("site_settings", process.env))
    return { data: parseCustomSeriesCatalog(value), storedValue: value };
  return readCustomSeriesCatalogValue(await storageIO(), value);
}

/** Persist a new immutable Storage object before replacing the small Database index. */
export async function writeStoredCustomSeriesCatalog(catalog: CustomSeriesCatalog) {
  if (isLocalManagedFixture("site_settings", process.env)) {
    const value = JSON.stringify(catalog);
    const { error } = await projectContent
      .from("site_settings")
      .upsert(
        { key: CUSTOM_SERIES_CATALOG_KEY, value, updated_at: new Date().toISOString() } as never,
        { onConflict: "key" },
      );
    if (error) throw new Error(`Local test-series catalogue could not be saved: ${error.message}`);
    return value;
  }
  const io = await storageIO();
  const value = await writeCustomSeriesCatalogObject(io, catalog);
  if (!value.startsWith(CUSTOM_SERIES_CATALOG_POINTER_PREFIX))
    throw new Error("Test-series catalogue pointer creation failed.");
  const { error } = await projectContent.from("site_settings").upsert(
    {
      key: CUSTOM_SERIES_CATALOG_KEY,
      value,
      updated_at: new Date().toISOString(),
    } as never,
    { onConflict: "key" },
  );
  if (error) throw new Error(`Test-series Storage pointer could not be saved: ${error.message}`);
  return value;
}
