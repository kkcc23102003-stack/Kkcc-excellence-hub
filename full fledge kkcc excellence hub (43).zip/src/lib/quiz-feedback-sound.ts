/** Small, local Web Audio cues for questions that are graded immediately.
 * No downloaded sounds, network requests, speech, result writes or autoplay.
 * Never call this for an unanswered exam question or a timer expiry. */
export type QuizFeedback = "correct" | "wrong";
export const QUIZ_SOUND_KEY = "kkcc:quiz-feedback-sound:v1";

export function quizSoundEnabled(value: string | null): boolean {
  return value !== "off";
}

export type QuizTone = Readonly<{
  frequency: number;
  offset: number;
  duration: number;
  volume: number;
}>;

export function feedbackTones(result: QuizFeedback): readonly QuizTone[] {
  return result === "correct"
    ? [
        { frequency: 523.25, offset: 0, duration: 0.11, volume: 0.045 },
        { frequency: 659.25, offset: 0.11, duration: 0.17, volume: 0.055 },
      ]
    : [
        { frequency: 330, offset: 0, duration: 0.14, volume: 0.04 },
        { frequency: 246.94, offset: 0.13, duration: 0.18, volume: 0.035 },
      ];
}

let audioContext: AudioContext | null = null;

/** Silently no-op if the browser lacks Web Audio or declines playback. */
export function playQuizFeedback(result: QuizFeedback): boolean {
  if (typeof window === "undefined") return false;
  const AudioCtor =
    window.AudioContext ??
    (window as Window & { webkitAudioContext?: typeof AudioContext }).webkitAudioContext;
  if (!AudioCtor) return false;
  try {
    if (!audioContext || audioContext.state === "closed") audioContext = new AudioCtor();
    const context = audioContext;
    if (context.state === "suspended") void context.resume().catch(() => {});
    const start = context.currentTime + 0.012;
    for (const tone of feedbackTones(result)) {
      const oscillator = context.createOscillator();
      const gain = context.createGain();
      const from = start + tone.offset;
      const to = from + tone.duration;
      oscillator.type = result === "correct" ? "sine" : "triangle";
      oscillator.frequency.setValueAtTime(tone.frequency, from);
      gain.gain.setValueAtTime(0.0001, from);
      gain.gain.exponentialRampToValueAtTime(tone.volume, from + 0.024);
      gain.gain.exponentialRampToValueAtTime(0.0001, to);
      oscillator.connect(gain);
      gain.connect(context.destination);
      oscillator.onended = () => {
        oscillator.disconnect();
        gain.disconnect();
      };
      oscillator.start(from);
      oscillator.stop(to + 0.02);
    }
    return true;
  } catch {
    // Some mobile browsers reject or suspend audio despite a tap. Quiz feedback
    // still appears visually; never interrupt scoring or a paid quiz over sound.
    return false;
  }
}
