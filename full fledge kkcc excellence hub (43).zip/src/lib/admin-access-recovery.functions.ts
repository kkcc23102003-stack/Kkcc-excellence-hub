import { createServerFn } from "@tanstack/react-start";
import { z } from "zod";
import { requireSupabaseAuth } from "@/integrations/supabase/auth-middleware";
import type { AdminAccessRecoveryEventRow } from "@/integrations/supabase/db";
import { accessRecoveryState } from "@/lib/access-recovery";
import { materialAccessMode } from "@/lib/material-access-mode";
import { NOTES_SERIES_ACCESS_PREFIX } from "@/lib/notes-series";
import { projectContent } from "@/lib/project-content.server";
import {
  assertAdmin,
  effectiveSeries,
  findStudent,
  readCustomSeriesCatalogForAccess,
  unwrap,
} from "@/lib/learning.server";
import { getEffectiveLearningSeries } from "@/lib/test-series-catalog";
import { readAdminNotesSeriesCatalog } from "@/lib/notes-series-catalog.server";

const emailSchema = z.object({ email: z.string().trim().email().max(200) });
const recoverSchema = z
  .object({
    user_id: z.string().uuid(),
    record_kind: z.enum(["course", "test", "series", "notes_series", "note", "note_purchase"]),
    record_id: z.string().uuid(),
    validity_mode: z.enum(["keep", "days", "lifetime"]),
    valid_days: z.number().int().min(1).max(3650).nullable(),
    reason: z.string().trim().min(4).max(500),
  })
  .superRefine((data, ctx) => {
    if (data.validity_mode === "days" && data.valid_days === null) {
      ctx.addIssue({ code: "custom", path: ["valid_days"], message: "Choose the number of days." });
    }
  });

export type AccessRecoveryKind =
  "course" | "test" | "series" | "notes_series" | "note" | "note_purchase";

export type AccessRecoveryRecord = {
  id: string;
  kind: AccessRecoveryKind;
  product_id: string;
  product_title: string;
  state: "active" | "expired" | "revoked" | "pending";
  source: string;
  amount_label: string | null;
  expires_at: string | null;
  created_at: string;
  note: string;
  can_recover: boolean;
};

function escapeLike(value: string) {
  return value.replace(/[%_]/g, "\\$&");
}

function formatRupees(value: number) {
  return `₹${new Intl.NumberFormat("en-IN").format(value)}`;
}

function buildRecord(
  input: Omit<AccessRecoveryRecord, "state" | "can_recover"> & {
    status?: string | null;
    revoked_at?: string | null;
    expires_at: string | null;
  },
): AccessRecoveryRecord {
  const state = accessRecoveryState(input);
  return {
    id: input.id,
    kind: input.kind,
    product_id: input.product_id,
    product_title: input.product_title,
    state,
    source: input.source,
    amount_label: input.amount_label,
    expires_at: input.expires_at,
    created_at: input.created_at,
    note: input.note,
    can_recover: state === "expired" || state === "revoked",
  };
}

export const adminLookupAccessRecovery = createServerFn({ method: "GET" })
  .middleware([requireSupabaseAuth])
  .validator((input: unknown) => emailSchema.parse(input))
  .handler(async ({ context, data }) => {
    await assertAdmin(context);
    const email = data.email.trim().toLowerCase();
    const matches = unwrap(
      await context.supabase
        .from("profiles")
        .select("id,email,full_name")
        .ilike("email", escapeLike(email))
        .limit(5),
    );
    const profile = (matches ?? []).find((item) => item.email.trim().toLowerCase() === email);
    const coursesResult = await projectContent.from("courses").select("id,title,status");
    if (coursesResult.error) throw new Error(coursesResult.error.message);
    const courses = coursesResult.data ?? [];
    const courseById = new Map(
      courses.map((course) => [course.id, course.title || "Untitled course"]),
    );

    if (!profile) {
      const pendingResult = await context.supabase
        .from("offline_access_grants")
        .select("id,email,full_name,course_id,status,expires_at,admin_note,created_at")
        .ilike("email", escapeLike(email))
        .order("created_at", { ascending: false })
        .limit(50);
      if (pendingResult.error) throw new Error(pendingResult.error.message);
      return {
        profile: null,
        blocked: false,
        records: [],
        coupon_redemptions: [],
        recovery_events: [],
        recovery_history_available: false,
        pending_offline: (pendingResult.data ?? []).map((grant) => ({
          id: grant.id,
          name: grant.full_name,
          email: grant.email,
          course_title: courseById.get(grant.course_id) ?? grant.course_id,
          status: accessRecoveryState({ status: grant.status, expires_at: grant.expires_at }),
          expires_at: grant.expires_at,
          note: grant.admin_note,
          created_at: grant.created_at,
        })),
      };
    }

    const blockedResult = await context.supabase.rpc("is_user_blocked", { _user_id: profile.id });
    if (blockedResult.error) throw new Error(blockedResult.error.message);
    const [
      enrollmentsResult,
      testGrantsResult,
      seriesGrantsResult,
      materialGrantsResult,
      redemptionsResult,
      offlineByEmailResult,
      offlineByUserResult,
      testCatalogResult,
      materialCatalogResult,
      notesSeriesCatalog,
      customSeriesCatalog,
      overridesResult,
    ] = await Promise.all([
      context.supabase
        .from("course_enrollments")
        .select("*")
        .eq("user_id", profile.id)
        .order("created_at", { ascending: false })
        .limit(500),
      context.supabase
        .from("test_access_grants")
        .select("*")
        .eq("user_id", profile.id)
        .order("created_at", { ascending: false })
        .limit(500),
      context.supabase
        .from("series_access_grants")
        .select("*")
        .eq("user_id", profile.id)
        .order("created_at", { ascending: false })
        .limit(1000),
      context.supabase
        .from("material_access_grants")
        .select("*")
        .eq("user_id", profile.id)
        .order("created_at", { ascending: false })
        .limit(500),
      context.supabase
        .from("coupon_redemptions")
        .select("*")
        .eq("user_id", profile.id)
        .order("created_at", { ascending: false })
        .limit(200),
      context.supabase
        .from("offline_access_grants")
        .select(
          "id,email,full_name,course_id,status,expires_at,admin_note,created_at,activated_user_id",
        )
        .ilike("email", escapeLike(profile.email))
        .order("created_at", { ascending: false })
        .limit(100),
      context.supabase
        .from("offline_access_grants")
        .select(
          "id,email,full_name,course_id,status,expires_at,admin_note,created_at,activated_user_id",
        )
        .eq("activated_user_id", profile.id)
        .order("created_at", { ascending: false })
        .limit(100),
      projectContent.from("tests").select("id,title,series_name,is_published,is_paid,course_id"),
      projectContent
        .from("materials")
        .select(
          "id,title,subject,chapter,is_published,is_free_preview,access_type,price,coin_price,course_id",
        ),
      readAdminNotesSeriesCatalog().catch(() => []),
      readCustomSeriesCatalogForAccess(),
      projectContent.from("test_series_overrides").select("series_id,name,enabled"),
    ]);

    if (enrollmentsResult.error) throw new Error(enrollmentsResult.error.message);
    if (testGrantsResult.error) throw new Error(testGrantsResult.error.message);
    if (seriesGrantsResult.error) throw new Error(seriesGrantsResult.error.message);
    if (materialGrantsResult.error) throw new Error(materialGrantsResult.error.message);
    if (redemptionsResult.error) throw new Error(redemptionsResult.error.message);
    if (offlineByEmailResult.error) throw new Error(offlineByEmailResult.error.message);
    if (offlineByUserResult.error) throw new Error(offlineByUserResult.error.message);
    if (testCatalogResult.error) throw new Error(testCatalogResult.error.message);
    if (materialCatalogResult.error) throw new Error(materialCatalogResult.error.message);
    if (overridesResult.error) throw new Error(overridesResult.error.message);

    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    const purchasesResult = await supabaseAdmin
      .from("material_purchases")
      .select("*")
      .eq("user_id", profile.id)
      .order("created_at", { ascending: false })
      .limit(500);
    if (purchasesResult.error) throw new Error(purchasesResult.error.message);
    const couponIds = [...new Set((redemptionsResult.data ?? []).map((row) => row.coupon_id))];
    const couponsResult = couponIds.length
      ? await context.supabase.from("coupon_codes").select("id,code").in("id", couponIds)
      : { data: [], error: null };
    if (couponsResult.error) throw new Error(couponsResult.error.message);

    const testById = new Map((testCatalogResult.data ?? []).map((test) => [test.id, test]));
    const materialById = new Map(
      (materialCatalogResult.data ?? []).map((material) => [material.id, material]),
    );
    const notesSeriesById = new Map(notesSeriesCatalog.map((series) => [series.id, series]));
    const effectiveSeries = getEffectiveLearningSeries(customSeriesCatalog);
    const seriesById = new Map(effectiveSeries.map((series) => [series.id, series]));
    const overridesById = new Map((overridesResult.data ?? []).map((row) => [row.series_id, row]));
    const couponById = new Map(
      (couponsResult.data ?? []).map((coupon) => [coupon.id, coupon.code]),
    );

    const records: AccessRecoveryRecord[] = [];
    for (const enrollment of enrollmentsResult.data ?? []) {
      records.push(
        buildRecord({
          id: enrollment.id,
          kind: "course",
          product_id: enrollment.course_id,
          product_title: courseById.get(enrollment.course_id) ?? enrollment.course_id,
          status: enrollment.status,
          expires_at: enrollment.expires_at,
          source: `${enrollment.source} · ${enrollment.payment_method}`,
          amount_label: formatRupees(enrollment.amount_paid),
          created_at: enrollment.created_at,
          note: enrollment.admin_note,
        }),
      );
    }
    for (const grant of testGrantsResult.data ?? []) {
      const test = testById.get(grant.test_id);
      records.push(
        buildRecord({
          id: grant.id,
          kind: "test",
          product_id: grant.test_id,
          product_title: test?.title || grant.test_id,
          revoked_at: grant.revoked_at,
          expires_at: grant.expires_at,
          source: grant.method,
          amount_label: formatRupees(grant.amount_inr),
          created_at: grant.created_at,
          note: grant.note,
        }),
      );
    }
    for (const grant of seriesGrantsResult.data ?? []) {
      const isNotesSeries = grant.series_id.startsWith(NOTES_SERIES_ACCESS_PREFIX);
      const targetId = isNotesSeries
        ? grant.series_id.slice(NOTES_SERIES_ACCESS_PREFIX.length)
        : grant.series_id;
      const notesSeries = isNotesSeries ? notesSeriesById.get(targetId) : undefined;
      const testSeries = !isNotesSeries ? seriesById.get(grant.series_id) : undefined;
      const override = overridesById.get(grant.series_id);
      records.push(
        buildRecord({
          id: grant.id,
          kind: isNotesSeries ? "notes_series" : "series",
          product_id: grant.series_id,
          product_title:
            (isNotesSeries ? notesSeries?.name : override?.name || testSeries?.name) ||
            grant.series_id,
          revoked_at: grant.revoked_at,
          expires_at: grant.expires_at,
          source: grant.method,
          amount_label: formatRupees(grant.amount_inr),
          created_at: grant.created_at,
          note: grant.note,
        }),
      );
    }
    for (const grant of materialGrantsResult.data ?? []) {
      const material = materialById.get(grant.material_id);
      records.push(
        buildRecord({
          id: grant.id,
          kind: "note",
          product_id: grant.material_id,
          product_title: material?.title || grant.material_id,
          revoked_at: grant.revoked_at,
          expires_at: grant.expires_at,
          source: grant.method,
          amount_label: formatRupees(grant.amount_inr),
          created_at: grant.created_at,
          note: grant.note,
        }),
      );
    }
    for (const purchase of purchasesResult.data ?? []) {
      const material = materialById.get(purchase.material_id);
      records.push(
        buildRecord({
          id: purchase.id,
          kind: "note_purchase",
          product_id: purchase.material_id,
          product_title: material?.title || purchase.material_id,
          status: purchase.status,
          expires_at: null,
          source: "23KAAT paid Note purchase",
          amount_label: `${purchase.paid_coins} coins`,
          created_at: purchase.created_at,
          note: "Purchase history is read-only; restoring access creates a separate access grant.",
        }),
      );
    }

    const recoveryHistoryResult = await context.supabase
      .from("admin_access_recovery_events")
      .select("*")
      .eq("user_id", profile.id)
      .order("created_at", { ascending: false })
      .limit(50);
    const recoveryHistoryAvailable = !recoveryHistoryResult.error;
    const recoveryEvents = recoveryHistoryAvailable
      ? ((recoveryHistoryResult.data ?? []) as AdminAccessRecoveryEventRow[])
      : [];
    const couponRedemptions = (redemptionsResult.data ?? []).map((row) => {
      const itemTitle =
        row.item_kind === "course"
          ? courseById.get(row.course_id ?? row.item_id)
          : row.item_kind === "material"
            ? materialById.get(row.item_id)?.title
            : row.item_kind === "test"
              ? testById.get(row.item_id)?.title
              : row.item_kind === "notes_series"
                ? notesSeriesById.get(row.item_id)?.name
                : row.item_kind === "series"
                  ? seriesById.get(row.item_id)?.name
                  : undefined;
      return {
        id: row.id,
        code: couponById.get(row.coupon_id) ?? "Legacy coupon",
        item_kind: row.item_kind,
        item_id: row.item_id,
        item_title: itemTitle || row.item_id,
        discount_percent: row.discount_percent,
        final_amount: row.final_amount,
        currency: row.currency,
        status: row.status,
        created_at: row.created_at,
        hidden: Boolean(row.admin_hidden_at),
      };
    });

    records.sort((a, b) => Date.parse(b.created_at) - Date.parse(a.created_at));
    const offlineGrants = new Map(
      [...(offlineByEmailResult.data ?? []), ...(offlineByUserResult.data ?? [])].map((grant) => [
        grant.id,
        grant,
      ]),
    );
    const pendingOffline = [...offlineGrants.values()].map((grant) => ({
      id: grant.id,
      name: grant.full_name,
      email: grant.email,
      course_title: courseById.get(grant.course_id) ?? grant.course_id,
      status: accessRecoveryState({ status: grant.status, expires_at: grant.expires_at }),
      expires_at: grant.expires_at,
      note: grant.admin_note,
      created_at: grant.created_at,
    }));
    return {
      profile: { id: profile.id, email: profile.email, full_name: profile.full_name },
      blocked: Boolean(blockedResult.data),
      records,
      coupon_redemptions: couponRedemptions,
      recovery_events: recoveryEvents,
      recovery_history_available: recoveryHistoryAvailable,
      pending_offline: pendingOffline,
    };
  });

export const adminRecoverStudentAccess = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .validator((input: unknown) => recoverSchema.parse(input))
  .handler(async ({ context, data }) => {
    await assertAdmin(context);
    const profile = await findStudent(context, { user_id: data.user_id });
    const blocked = unwrap(await context.supabase.rpc("is_user_blocked", { _user_id: profile.id }));
    if (blocked) throw new Error("Student account is blocked; unblock it separately first.");

    let productId = "";
    if (data.record_kind === "course") {
      const row = unwrap(
        await context.supabase
          .from("course_enrollments")
          .select("course_id")
          .eq("id", data.record_id)
          .eq("user_id", profile.id)
          .maybeSingle(),
      );
      if (!row) throw new Error("Course access record not found for this student.");
      const course = unwrap(
        await projectContent
          .from("courses")
          .select("id,title,status")
          .eq("id", row.course_id)
          .maybeSingle(),
      );
      if (!course || course.status !== "published")
        throw new Error(
          "This course is not currently published; review it before restoring access.",
        );
      productId = row.course_id;
    } else if (data.record_kind === "test") {
      const row = unwrap(
        await context.supabase
          .from("test_access_grants")
          .select("test_id")
          .eq("id", data.record_id)
          .eq("user_id", profile.id)
          .maybeSingle(),
      );
      if (!row) throw new Error("Test access record not found for this student.");
      const test = unwrap(
        await projectContent
          .from("tests")
          .select("id,is_published,is_paid")
          .eq("id", row.test_id)
          .maybeSingle(),
      );
      if (!test?.is_published) throw new Error("This test is not currently published.");
      if (!test.is_paid) throw new Error("This test is now free; no access grant is needed.");
      productId = row.test_id;
    } else if (data.record_kind === "series" || data.record_kind === "notes_series") {
      const row = unwrap(
        await context.supabase
          .from("series_access_grants")
          .select("series_id")
          .eq("id", data.record_id)
          .eq("user_id", profile.id)
          .maybeSingle(),
      );
      if (!row) throw new Error("Series access record not found for this student.");
      if (data.record_kind === "notes_series") {
        if (!row.series_id.startsWith(NOTES_SERIES_ACCESS_PREFIX))
          throw new Error("This record is not a Notes Series grant.");
        const id = row.series_id.slice(NOTES_SERIES_ACCESS_PREFIX.length);
        const notesSeries = (await readAdminNotesSeriesCatalog()).find(
          (item) => item.id === id && item.published && item.kind === "paid",
        );
        if (!notesSeries) throw new Error("This paid Notes Series is not currently published.");
      } else {
        if (row.series_id.startsWith(NOTES_SERIES_ACCESS_PREFIX))
          throw new Error("This record is a Notes Series grant, not a Test Series grant.");
        const series = await effectiveSeries(row.series_id);
        if (!series.enabled)
          throw new Error("This Test Series is hidden; enable it before restoring access.");
        if (Number(series.priceInr || 0) <= 0 && Number(series.priceCoins || 0) <= 0)
          throw new Error("This Test Series is now free; no access grant is needed.");
      }
      productId = row.series_id;
    } else if (data.record_kind === "note" || data.record_kind === "note_purchase") {
      if (data.record_kind === "note") {
        const row = unwrap(
          await context.supabase
            .from("material_access_grants")
            .select("material_id")
            .eq("id", data.record_id)
            .eq("user_id", profile.id)
            .maybeSingle(),
        );
        if (!row) throw new Error("Note access record not found for this student.");
        productId = row.material_id;
      } else {
        const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
        const row = unwrap(
          await supabaseAdmin
            .from("material_purchases")
            .select("material_id,status")
            .eq("id", data.record_id)
            .eq("user_id", profile.id)
            .maybeSingle(),
        );
        if (!row || row.status !== "revoked")
          throw new Error("Only a revoked paid Note purchase can be regranted here.");
        productId = row.material_id;
      }
      const material = unwrap(
        await projectContent
          .from("materials")
          .select("id,title,is_published,is_free_preview,access_type,price,coin_price,course_id")
          .eq("id", productId)
          .maybeSingle(),
      );
      if (
        !material?.is_published ||
        material.is_free_preview ||
        materialAccessMode(material) !== "paid"
      )
        throw new Error("This paid Note is not currently published or no longer needs a grant.");
    }

    const result = unwrap(
      await context.supabase.rpc("admin_recover_access", {
        p_user_id: profile.id,
        p_kind: data.record_kind,
        p_record_id: data.record_id,
        p_validity_mode: data.validity_mode,
        p_valid_days: data.validity_mode === "days" ? data.valid_days : null,
        p_reason: data.reason,
      }),
    );
    if (!result || typeof result !== "object" || Array.isArray(result))
      throw new Error("Access recovery did not return a valid confirmation.");
    const payload = result as Record<string, unknown>;
    if (payload["ok"] !== true) throw new Error("Access recovery was not confirmed.");
    return {
      ok: true,
      action: String(payload["action"] ?? "restored"),
      product_id: String(payload["product_id"] ?? productId),
      expires_at: typeof payload["expires_at"] === "string" ? payload["expires_at"] : null,
      event_id: String(payload["event_id"] ?? ""),
    };
  });
