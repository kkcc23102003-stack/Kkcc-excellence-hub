export type SeriesCouponAccessState = "active" | "expired" | "revoked" | "missing";

export type PriorSeriesCouponRedemption = {
  discount_percent: number;
  final_amount: number;
};

export type SeriesCouponRecoveryDecision =
  | { kind: "already_accessible" }
  | { kind: "restore_access" }
  | { kind: "blocked"; reason: "expired" | "revoked" };

/**
 * A recorded full-discount redemption is an entitlement even if the grant write
 * failed. It may be repaired when no grant exists, but an explicit revocation or
 * expiry must not be silently undone.
 */
export function decideSeriesCouponRecovery(
  redemption: PriorSeriesCouponRedemption | null | undefined,
  accessState: SeriesCouponAccessState,
): SeriesCouponRecoveryDecision | null {
  if (!redemption || redemption.discount_percent < 100 || redemption.final_amount > 0) return null;
  if (accessState === "active") return { kind: "already_accessible" };
  if (accessState === "missing") return { kind: "restore_access" };
  return { kind: "blocked", reason: accessState };
}
