export type OrderedPreviewNote = {
  id: string;
  subject: string | null | undefined;
  sort_order?: number | null;
  created_at?: string | null;
  is_free_preview?: boolean | null;
};

export function normalizeNoteSubject(subject: string | null | undefined) {
  return subject?.trim().toLocaleLowerCase() || "general";
}

function compareNotes(a: OrderedPreviewNote, b: OrderedPreviewNote) {
  const order = Number(a.sort_order ?? 0) - Number(b.sort_order ?? 0);
  if (order) return order;
  const created = (a.created_at ?? "").localeCompare(b.created_at ?? "");
  return created || a.id.localeCompare(b.id);
}

/** One published preview per subject: prefer Admin's explicit choice, otherwise the first note. */
export function freePreviewNoteIds<T extends OrderedPreviewNote>(notes: T[]): Set<string> {
  const bySubject = new Map<string, T[]>();
  for (const note of notes) {
    const key = normalizeNoteSubject(note.subject);
    const group = bySubject.get(key) ?? [];
    group.push(note);
    bySubject.set(key, group);
  }

  const selected = new Set<string>();
  for (const group of bySubject.values()) {
    const explicit = group.filter((note) => note.is_free_preview).sort(compareNotes);
    const candidate = explicit[0] ?? [...group].sort(compareNotes)[0];
    if (candidate) selected.add(candidate.id);
  }
  return selected;
}
