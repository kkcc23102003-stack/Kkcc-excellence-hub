import { materialAccessMode } from "./material-access-mode";
import { normalizeAccessValidDays } from "./course-validity";
import { getNotesSeriesById, notesSeriesGrantId } from "./notes-series-purchase.server";
/**
 * One place that decides what a learning item costs and how access is granted.
 *
 * Everything that can unlock a Batch, a Test Series or a Test — Razorpay,
 * 23KAAT coins, an offline request approved by the admin, a recovered payment —
 * goes through here, so the price the student sees, the price the server
 * charges and the price recorded in the database can never drift apart.
 *
 * Server only.
 */
import { coinPriceOf } from "@/lib/cms";
import { resolveServerCouponDiscount } from "@/lib/coupons.functions";
import { effectiveSeries, unwrap } from "@/lib/learning.server";
import { projectContent } from "@/lib/project-content.server";
import { applySharedBatchPriceToCourse } from "@/lib/notes-batch-pricing.server";
import type { CourseRow, MaterialRow, TestRow } from "@/integrations/supabase/db";

/**
 * Everything a student can buy. `material` is a set of Notes — the admin
 * switches each note between Free, Paid (₹ + 23KAAT) and Batch-only.
 */
export type LearningKind = "course" | "series" | "notes_series" | "test" | "material";

export type LearningItem = {
  id: string;
  kind: LearningKind;
  title: string;
  /** Rupee price before any coupon. */
  baseInr: number;
  /** 23KAAT coin price before any coupon. */
  baseCoins: number;
  /** Default course access duration; null means lifetime. */
  accessValidDays?: number | null;
};

export type ResolvedLearningPrice = {
  item: LearningItem;
  baseInr: number;
  baseCoins: number;
  finalInr: number;
  finalCoins: number;
  coupon: {
    code: string;
    title: string;
    discountPercent: number;
    discountAmount: number;
    discountCoins: number;
  } | null;
  /** Human readable suffix recorded with the enrollment. */
  note: string;
};

async function adminClient() {
  const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
  return supabaseAdmin;
}

/** Load one item with its real server side price. */
export async function loadLearningItem(kind: LearningKind, itemId: string): Promise<LearningItem> {
  if (kind === "course") {
    const course = unwrap(
      await projectContent
        .from("courses")
        .select("*")
        .eq("id", itemId)
        .eq("status", "published")
        .single(),
    ) as CourseRow;
    const pricedCourse = await applySharedBatchPriceToCourse(course);
    if (pricedCourse.is_notes_batch && !pricedCourse.batch_price_configured)
      throw new Error("Admin has not configured a price for this Batch yet.");
    return {
      id: course.id,
      kind,
      title: course.title,
      baseInr: Math.max(0, pricedCourse.price ?? 0),
      baseCoins: coinPriceOf(pricedCourse),
      accessValidDays: normalizeAccessValidDays(course.access_valid_days),
    };
  }

  if (kind === "series") {
    const series = await effectiveSeries(itemId);
    if (!series.enabled) throw new Error("This test series is currently unavailable.");
    const baseInr = Math.max(0, series.priceInr ?? 0);
    return {
      id: series.id,
      kind,
      title: series.name,
      baseInr,
      baseCoins: Math.max(0, series.priceCoins ?? baseInr),
    };
  }

  if (kind === "notes_series") {
    const series = await getNotesSeriesById(itemId);
    if (!series?.published || series.kind !== "paid")
      throw new Error("This paid Notes Series is not available.");
    const baseInr = Math.max(0, series.priceInr ?? 0);
    const baseCoins = Math.max(0, series.priceCoins ?? 0);
    if (baseInr <= 0 && baseCoins <= 0)
      throw new Error("The Notes Series price has not been set by Admin yet.");
    return { id: series.id, kind, title: series.name, baseInr, baseCoins };
  }

  if (kind === "material") {
    const material = unwrap(
      await projectContent
        .from("materials")
        .select("*")
        .eq("id", itemId)
        .eq("is_published", true)
        .single(),
    ) as MaterialRow;
    if (material.is_free_preview)
      throw new Error("This is the free first note for its subject; no purchase is needed.");
    const isPaid = materialAccessMode(material) === "paid";
    if (!isPaid) throw new Error("This note is not configured as an individual paid item.");
    const baseInr = Math.max(0, material.price ?? 0);
    const baseCoins = Math.max(0, material.coin_price ?? 0);
    if (baseInr <= 0 && baseCoins <= 0)
      throw new Error("The individual note price has not been set by Admin yet.");
    return {
      id: material.id,
      kind,
      title: material.title || "Study Notes",
      // INR and 23KAAT remain independently configured; a zero coin price stays zero.
      baseInr,
      baseCoins,
    };
  }

  const test = unwrap(
    await projectContent
      .from("tests")
      .select("*")
      .eq("id", itemId)
      .eq("is_published", true)
      .single(),
  ) as TestRow;
  const baseInr = test.is_paid ? Math.max(0, test.price_inr ?? 0) : 0;
  return {
    id: test.id,
    kind,
    title: test.title,
    baseInr,
    baseCoins: test.is_paid ? Math.max(0, test.price_coins || test.price_inr || 0) : 0,
  };
}

/**
 * Price an item for one student with an optional coupon.
 *
 * `recordRedemption` must be true only on the call that actually unlocks the
 * item — pricing/quoting a coupon must never burn a use.
 */
export async function resolveLearningPrice(input: {
  kind: LearningKind;
  itemId: string;
  couponCode?: string | undefined;
  userId?: string | undefined;
  recordRedemption?: boolean;
}): Promise<ResolvedLearningPrice> {
  const item = await loadLearningItem(input.kind, input.itemId);
  const code = (input.couponCode ?? "").trim();

  if (!code) {
    return {
      item,
      baseInr: item.baseInr,
      baseCoins: item.baseCoins,
      finalInr: item.baseInr,
      finalCoins: item.baseCoins,
      coupon: null,
      note: "",
    };
  }

  const couponInfo = await resolveServerCouponDiscount({
    code,
    targetKind:
      input.kind === "course"
        ? "course"
        : input.kind === "material"
          ? "material"
          : input.kind === "test"
            ? "test"
            : input.kind === "series"
              ? "series"
              : "notes_series",
    targetCourseId: input.kind === "course" ? item.id : null,
    targetItemId: item.id,
    originalAmountInr: item.baseInr,
    originalCoins: item.baseCoins,
    ...(input.userId ? { userId: input.userId } : {}),
    recordRedemption: input.recordRedemption ?? false,
  });

  const coupon = couponInfo.coupon
    ? {
        code: couponInfo.coupon.code,
        title: couponInfo.coupon.title ?? "",
        discountPercent: couponInfo.discountPercent,
        discountAmount: couponInfo.discountAmount,
        discountCoins: couponInfo.discountCoins,
      }
    : null;

  return {
    item,
    baseInr: item.baseInr,
    baseCoins: item.baseCoins,
    finalInr: couponInfo.finalAmount,
    finalCoins: couponInfo.finalCoins,
    coupon,
    note: coupon ? ` · Coupon ${coupon.code} (${coupon.discountPercent}% OFF)` : "",
  };
}

/**
 * Grant access after a payment is confirmed. Safe to call twice: every branch
 * is an idempotent upsert or a guarded insert, so a retried callback, a
 * recovered payment or an admin re-grant never double-enrolls a student.
 */
export async function grantLearningPurchase(input: {
  userId: string;
  kind: LearningKind;
  itemId: string;
  amountInr: number;
  couponCode?: string | undefined;
  /** Captured in the verified order notes so recovery uses the purchase-time period. */
  accessValidDays?: number | null;
  /** e.g. "Razorpay payment pay_xxx" or "Razorpay recovery pay_xxx". */
  reference: string;
  /** "razorpay" for online, "offline" for admin approved, "coins" for 23KAAT. */
  method?: string;
}): Promise<{ kind: LearningKind; itemId: string; title: string; amountInr: number }> {
  const supabaseAdmin = await adminClient();
  // Price is recomputed (coupon NOT re-recorded here — the calling handler owns
  // that exactly once) so a tampered client cannot under-report what was paid.
  const price = await resolveLearningPrice({
    kind: input.kind,
    itemId: input.itemId,
    couponCode: input.couponCode,
    userId: input.userId,
    recordRedemption: false,
  });

  const couponNote = price.coupon
    ? ` · Coupon ${price.coupon.code} (${price.coupon.discountPercent}% OFF)`
    : "";
  const note = `${input.reference}${couponNote}`;
  const method = input.method ?? "razorpay";
  const amountInr = Math.max(0, Math.round(input.amountInr));
  const paidAmount = amountInr > 0 ? amountInr : price.finalInr;

  if (input.kind === "course") {
    const accessValidDays =
      input.accessValidDays === undefined
        ? (price.item.accessValidDays ?? null)
        : normalizeAccessValidDays(input.accessValidDays);
    const expiresAt = accessValidDays
      ? new Date(Date.now() + accessValidDays * 86_400_000).toISOString()
      : null;
    const { error } = await supabaseAdmin.from("course_enrollments").upsert(
      {
        user_id: input.userId,
        course_id: price.item.id,
        status: "active",
        source: method,
        payment_method: method,
        amount_paid: paidAmount,
        currency: "INR",
        admin_note: note,
        expires_at: expiresAt,
        created_by: input.userId,
      } as never,
      { onConflict: "user_id,course_id" },
    );
    if (error) throw new Error(error.message);
  } else if (input.kind === "notes_series") {
    const seriesId = notesSeriesGrantId(price.item.id);
    const grant = {
      user_id: input.userId,
      series_id: seriesId,
      granted_by: input.userId,
      method,
      amount_inr: paidAmount,
      note,
      expires_at: null,
      revoked_at: null,
    };
    const { error } = await supabaseAdmin
      .from("series_access_grants")
      .upsert(grant as never, { onConflict: "series_id,user_id" });
    if (error) {
      const inserted = await supabaseAdmin.from("series_access_grants").insert(grant as never);
      if (inserted.error && !(await hasLearningAccess(input.userId, "notes_series", price.item.id)))
        throw new Error(inserted.error.message);
    }
  } else if (input.kind === "series") {
    const { error } = await supabaseAdmin.from("series_access_grants").upsert(
      {
        user_id: input.userId,
        series_id: price.item.id,
        granted_by: input.userId,
        method,
        amount_inr: paidAmount,
        note,
        expires_at: null,
        revoked_at: null,
      } as never,
      { onConflict: "series_id,user_id" },
    );
    if (error) {
      await supabaseAdmin.from("series_access_grants").insert({
        user_id: input.userId,
        series_id: price.item.id,
        granted_by: input.userId,
        method,
        amount_inr: paidAmount,
        note,
      } as never);
    }
  } else if (input.kind === "material") {
    // Notes unlock through material_purchases — that is what the reader checks.
    const { error } = await supabaseAdmin.from("material_purchases").upsert(
      {
        user_id: input.userId,
        material_id: price.item.id,
        paid_coins: 0,
        status: "active",
        created_by: input.userId,
      } as never,
      { onConflict: "user_id,material_id" },
    );
    if (error) throw new Error(error.message);
  } else {
    await supabaseAdmin.from("test_access_grants").insert({
      user_id: input.userId,
      test_id: price.item.id,
      granted_by: input.userId,
      method,
      amount_inr: paidAmount,
      note,
    } as never);
  }

  return {
    kind: input.kind,
    itemId: price.item.id,
    title: price.item.title,
    amountInr: paidAmount,
  };
}

/** True when the student already has access, so a retry never double-charges. */
export async function hasLearningAccess(
  userId: string,
  kind: LearningKind,
  itemId: string,
): Promise<boolean> {
  const supabaseAdmin = await adminClient();
  if (kind === "course") {
    const { count } = await supabaseAdmin
      .from("course_enrollments")
      .select("*", { count: "exact", head: true })
      .eq("user_id", userId)
      .eq("course_id", itemId)
      .eq("status", "active")
      .or(`expires_at.is.null,expires_at.gt.${new Date().toISOString()}`);
    return (count ?? 0) > 0;
  }
  if (kind === "notes_series") {
    const { count } = await supabaseAdmin
      .from("series_access_grants")
      .select("*", { count: "exact", head: true })
      .eq("user_id", userId)
      .eq("series_id", notesSeriesGrantId(itemId))
      .is("revoked_at", null)
      .or(`expires_at.is.null,expires_at.gt.${new Date().toISOString()}`);
    return (count ?? 0) > 0;
  }
  if (kind === "series") {
    const { count } = await supabaseAdmin
      .from("series_access_grants")
      .select("*", { count: "exact", head: true })
      .eq("user_id", userId)
      .eq("series_id", itemId)
      .is("revoked_at", null)
      .or(`expires_at.is.null,expires_at.gt.${new Date().toISOString()}`);
    return (count ?? 0) > 0;
  }
  if (kind === "material") {
    const [{ count: purchaseCount }, { count: grantCount }] = await Promise.all([
      supabaseAdmin
        .from("material_purchases")
        .select("*", { count: "exact", head: true })
        .eq("user_id", userId)
        .eq("material_id", itemId)
        .eq("status", "active"),
      supabaseAdmin
        .from("material_access_grants")
        .select("*", { count: "exact", head: true })
        .eq("user_id", userId)
        .eq("material_id", itemId)
        .is("revoked_at", null)
        .or(`expires_at.is.null,expires_at.gt.${new Date().toISOString()}`),
    ]);
    if ((purchaseCount ?? 0) > 0 || (grantCount ?? 0) > 0) return true;
    // A note the admin switched to Free opens immediately, no purchase needed.
    const { data } = await projectContent
      .from("materials")
      .select("access_type,price,coin_price,course_id")
      .eq("id", itemId)
      .maybeSingle();
    return Boolean(data && materialAccessMode(data as MaterialRow) === "free");
  }
  const { count } = await supabaseAdmin
    .from("test_access_grants")
    .select("*", { count: "exact", head: true })
    .eq("user_id", userId)
    .eq("test_id", itemId)
    .is("revoked_at", null)
    .or(`expires_at.is.null,expires_at.gt.${new Date().toISOString()}`);
  return (count ?? 0) > 0;
}

export type CoinPack = {
  id: string;
  title: string;
  coins: number;
  bonusCoins: number;
  totalCoins: number;
  priceInr: number;
};

export async function loadCoinPack(packageId: string): Promise<CoinPack> {
  const supabaseAdmin = await adminClient();
  const { data, error } = await supabaseAdmin
    .from("coin_packages")
    .select("*")
    .eq("id", packageId)
    .eq("is_active", true)
    .single();
  if (error || !data) throw new Error("Coin pack not found.");
  const pack = data as unknown as {
    id: string;
    title: string;
    coins: number | null;
    bonus_coins: number | null;
    price: number | null;
  };
  const coins = Math.max(0, pack.coins ?? 0);
  const bonusCoins = Math.max(0, pack.bonus_coins ?? 0);
  return {
    id: pack.id,
    title: pack.title,
    coins,
    bonusCoins,
    totalCoins: Math.max(1, coins + bonusCoins),
    priceInr: Math.max(0, pack.price ?? 0),
  };
}

/** Credit a purchased coin pack. Idempotency is enforced by the payment guard. */
export async function grantCoinPackPurchase(input: {
  userId: string;
  packageId: string;
  reference: string;
}): Promise<{ credited: number; title: string; balance: number | null }> {
  const supabaseAdmin = await adminClient();
  const pack = await loadCoinPack(input.packageId);
  const reason = `Razorpay coin pack purchase payment id ${input.reference}`;
  const { data: priorGrant, error: priorGrantError } = await supabaseAdmin
    .from("coin_transactions")
    .select("id")
    .eq("user_id", input.userId)
    .eq("source", "admin_grant")
    .eq("related_type", "coin_package")
    .eq("related_id", pack.id)
    .eq("reason", reason)
    .limit(1)
    .maybeSingle();
  if (priorGrantError) throw new Error(priorGrantError.message);
  if (priorGrant) {
    const { data: balance, error: balanceError } = await supabaseAdmin.rpc("get_23kaat_balance", {
      _user_id: input.userId,
    });
    if (balanceError) throw new Error(balanceError.message);
    return {
      credited: 0,
      title: pack.title,
      balance: typeof balance === "number" ? balance : null,
    };
  }
  const { data, error } = await supabaseAdmin.rpc("grant_23kaat_to_user", {
    _user_id: input.userId,
    _amount: pack.totalCoins,
    _reason: reason,
    _related_type: "coin_package",
    _related_id: pack.id,
  });
  if (error) throw new Error(error.message);
  const result = data as { balance?: number; already_granted?: boolean } | null;
  const balance = result?.balance;
  return {
    credited: result?.already_granted ? 0 : pack.totalCoins,
    title: pack.title,
    balance: typeof balance === "number" ? balance : null,
  };
}
