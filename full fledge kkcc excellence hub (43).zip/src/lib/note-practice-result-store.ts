import { parseNotePracticeQuestion, type NotePracticeQuestion } from "./note-practice";

/** A single checked in-note practice response. Written responses have no invented score. */
export type NotePracticeResult = {
  version: 1;
  kind: "note-practice";
  id: string;
  user_id: string;
  material_id: string;
  material_title: string;
  submitted_at: string;
  question: NotePracticeQuestion;
  response: number | string;
  correct: boolean | null;
};
export type NotePracticeSummary = Pick<
  NotePracticeResult,
  "id" | "material_id" | "material_title" | "submitted_at" | "correct"
> & { topic: string; question_text: string; response_kind: "mcq" | "written" };

const UUID = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i;
const MAX_BYTES = 16 * 1024;
export function practiceResultPath(userId: string, attemptId: string) {
  if (!UUID.test(userId) || !UUID.test(attemptId))
    throw new Error("Invalid practice result owner or ID.");
  return `${userId}/practice/${attemptId}.json`;
}
export function makePracticeResult(input: {
  id: string;
  userId: string;
  materialId: string;
  materialTitle: string;
  question: NotePracticeQuestion;
  response: number | string;
  submittedAt?: string;
}): NotePracticeResult {
  practiceResultPath(input.userId, input.id);
  if (!UUID.test(input.materialId)) throw new Error("Invalid practice note ID.");
  const question = parseNotePracticeQuestion(input.question);
  if (!question) throw new Error("This practice question is no longer available.");
  const mcq = question.options.length > 0;
  if (
    (mcq &&
      (typeof input.response !== "number" ||
        !Number.isInteger(input.response) ||
        input.response < 0 ||
        input.response >= question.options.length)) ||
    (!mcq &&
      (typeof input.response !== "string" ||
        !input.response.trim() ||
        input.response.length > 1000))
  )
    throw new Error("Invalid practice response.");
  const result: NotePracticeResult = {
    version: 1,
    kind: "note-practice",
    id: input.id,
    user_id: input.userId,
    material_id: input.materialId,
    material_title: input.materialTitle.slice(0, 200),
    submitted_at: input.submittedAt ?? new Date().toISOString(),
    question,
    response: input.response,
    correct: mcq ? input.response === question.correctIndex : null,
  };
  if (Buffer.byteLength(JSON.stringify(result)) > MAX_BYTES)
    throw new Error("Practice result exceeds the private Storage limit.");
  return result;
}

export function readPracticeResult(
  bytes: Uint8Array,
  userId: string,
  attemptId: string,
): NotePracticeResult {
  if (bytes.byteLength > MAX_BYTES) throw new Error("Practice result is too large.");
  let raw: unknown;
  try {
    raw = JSON.parse(Buffer.from(bytes).toString("utf8"));
  } catch {
    throw new Error("Practice result is not valid JSON.");
  }
  if (!raw || typeof raw !== "object" || Array.isArray(raw))
    throw new Error("Practice result is invalid.");
  const value = raw as Record<string, unknown>;
  if (
    value["version"] !== 1 ||
    value["kind"] !== "note-practice" ||
    value["id"] !== attemptId ||
    value["user_id"] !== userId ||
    typeof value["material_id"] !== "string" ||
    typeof value["material_title"] !== "string" ||
    value["material_title"].length > 200 ||
    typeof value["submitted_at"] !== "string" ||
    !Number.isFinite(Date.parse(value["submitted_at"]))
  )
    throw new Error("Practice result does not match its owner or schema.");
  const result = makePracticeResult({
    id: attemptId,
    userId,
    materialId: value["material_id"],
    materialTitle: value["material_title"],
    question: value["question"] as NotePracticeQuestion,
    response: value["response"] as number | string,
    submittedAt: value["submitted_at"],
  });
  if (value["correct"] !== result.correct)
    throw new Error("Practice result failed integrity check.");
  return result;
}
export function practiceSummary(result: NotePracticeResult): NotePracticeSummary {
  return {
    id: result.id,
    material_id: result.material_id,
    material_title: result.material_title,
    submitted_at: result.submitted_at,
    correct: result.correct,
    topic: result.question.topic,
    question_text: result.question.question,
    response_kind: result.question.options.length ? "mcq" : "written",
  };
}
