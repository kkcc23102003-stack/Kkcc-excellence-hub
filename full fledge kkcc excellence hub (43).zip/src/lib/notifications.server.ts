import type { SupabaseClient } from "@supabase/supabase-js";
import type { DB as Database } from "@/integrations/supabase/db";
import {
  buildStudentAccessNotificationCopy,
  type StudentAccessNotificationAction,
} from "./student-access-notification";

export type NotificationWriteContext = {
  supabase: SupabaseClient<Database>;
  userId: string;
};

export type NotificationPayload = {
  title: string;
  message: string;
  type: string;
  audience: "all" | "students" | "admins" | "course" | "user";
  course_id?: string | null;
  target_user_id?: string | null;
  event_key?: string | null;
  priority?: "low" | "normal" | "high";
  action_label?: string;
  action_url?: string;
  is_published?: boolean;
  send_at?: string | null;
  expires_at?: string | null;
};

export type NotificationWriteResult = "sent" | "duplicate" | "failed";

/** Write an in-app notification without turning a successful admin action into a failure. */
export async function insertNotificationSafe(
  context: NotificationWriteContext,
  payload: NotificationPayload,
): Promise<NotificationWriteResult> {
  try {
    const { error } = await context.supabase.from("notifications").insert({
      title: payload.title,
      message: payload.message,
      type: payload.type,
      audience: payload.audience,
      course_id: payload.course_id ?? null,
      target_user_id: payload.target_user_id ?? null,
      event_key: payload.event_key ?? null,
      priority: payload.priority ?? "normal",
      action_label: payload.action_label ?? "Open",
      action_url: payload.action_url ?? "",
      is_published: payload.is_published ?? true,
      send_at: payload.send_at ?? null,
      expires_at: payload.expires_at ?? null,
      created_by: context.userId,
    });

    if (error?.code === "23505") return "duplicate";
    if (error) {
      console.error("[notifications] notification write failed", error.message);
      return "failed";
    }
    return "sent";
  } catch (error) {
    console.error("[notifications] notification write failed", error);
    return "failed";
  }
}

export async function sendStudentAccessNotification(
  context: NotificationWriteContext,
  input: {
    userId: string;
    eventKey: string;
    action: StudentAccessNotificationAction;
    productTitle?: string | null;
    expiresAt?: string | null;
  },
): Promise<NotificationWriteResult> {
  const copy = buildStudentAccessNotificationCopy(input);
  return insertNotificationSafe(context, {
    title: copy.title,
    message: copy.message,
    type: "access",
    audience: "user",
    target_user_id: input.userId,
    event_key: input.eventKey,
    priority: copy.priority,
    action_label: "Open notifications",
    action_url: "/dashboard/notifications",
  });
}
