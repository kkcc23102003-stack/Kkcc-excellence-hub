import { createServerFn } from "@tanstack/react-start";
import { requireSupabaseAuth } from "@/integrations/supabase/auth-middleware";
import { assertAdmin } from "@/lib/learning.server";
import { z } from "zod";
export type { ArchivedAIQuestion } from "@/lib/ai-question-archive.server";

export const getAIQuestionArchiveStatus = createServerFn({ method: "GET" })
  .middleware([requireSupabaseAuth])
  .handler(async ({ context }) => {
    await assertAdmin(context);
    const { archiveStatus } = await import("@/lib/ai-question-archive.server");
    return archiveStatus();
  });

/** Explicit, bounded legacy migration; it never deletes a row before verification/CAS succeeds. */
export const migrateLegacyAIQuestionArchive = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .validator((input: unknown) =>
    z.object({ limit: z.number().int().min(1).max(100).default(50) }).parse(input),
  )
  .handler(async ({ context, data }) => {
    await assertAdmin(context);
    const { migrateLegacyAIQuestionArchive: migrate } =
      await import("@/lib/ai-question-archive.server");
    return migrate(data.limit);
  });
