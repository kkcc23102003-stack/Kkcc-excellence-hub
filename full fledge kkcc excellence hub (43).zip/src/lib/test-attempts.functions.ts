import { testAnswersSchema as responses } from "./test-answer-schema";
import { randomUUID } from "node:crypto";
import { createServerFn } from "@tanstack/react-start";
import { z } from "zod";
import { requireSupabaseAuth } from "@/integrations/supabase/auth-middleware";
import {
  buildSelectedPaper,
  learningPlan,
  readStudentAccess,
  resolveTestExam,
  unwrap,
} from "@/lib/learning.server";
import { canonicalSeriesId } from "@/lib/learning-access";
import { gradePaper, publicQuestions } from "@/lib/test-scoring";
import { requireAtomicAttemptRpc } from "@/lib/attempt-rpc";
import { RESULT_REQUIRED_SUFFIX } from "@/lib/learning-result-store";
import type { LearningAttemptRow, LearningAttemptView } from "@/integrations/supabase/db";

const selection = z.object({
  request_id: z.string().uuid().optional(),
  test_id: z.string().uuid().optional(),
  series_id: z.string().max(200).optional(),
  subject: z.string().min(1).max(160),
  chapter: z.string().min(1).max(240),
});

const attemptId = z.object({
  attempt_id: z.string().uuid(),
});

const answerMap = (value: unknown) => responses.parse(value ?? {});

type AttemptPaper = Awaited<ReturnType<typeof buildSelectedPaper>>;

const META_PREFIX = "__kkcc_meta__:";
const attemptSelectionCache = new Map<string, { subject: string; chapter: string; seed: string }>();

function encodeMetaRef(
  subject: string,
  chapter: string,
  seed: string,
  requireSnapshot: boolean,
): string {
  return `${META_PREFIX}${encodeURIComponent(subject)}:${encodeURIComponent(chapter)}:${encodeURIComponent(seed)}${requireSnapshot ? RESULT_REQUIRED_SUFFIX : ""}`;
}

function decodeMetaRef(refs: string[] | null | undefined): {
  subject?: string;
  chapter?: string;
  seed?: string;
} {
  const ref = (refs ?? []).find((item) => item.startsWith(META_PREFIX));
  if (!ref) return {};
  const parts = ref.slice(META_PREFIX.length).split(":");
  return {
    subject: decodeURIComponent(parts[0] ?? ""),
    chapter: decodeURIComponent(parts[1] ?? ""),
    seed: decodeURIComponent(parts[2] ?? ""),
  };
}

function getAttemptMeta(row: LearningAttemptRow) {
  const cached = attemptSelectionCache.get(row.id);
  const decoded = decodeMetaRef(row.source_refs);
  return {
    subject: decoded.subject || row.subject || cached?.subject || "",
    chapter: decoded.chapter || row.chapter || cached?.chapter || "",
    seed: row.seed || cached?.seed || decoded.seed || row.id,
  };
}

function attemptView(row: LearningAttemptRow, paper: AttemptPaper): LearningAttemptView {
  const meta = getAttemptMeta(row);
  return {
    ...row,
    exam: resolveTestExam(paper.test),
    subject: meta.subject || paper.test.subject || "",
    chapter: meta.chapter || paper.test.generation_topic || "",
  };
}

async function verifiedResultRow(row: LearningAttemptRow): Promise<LearningAttemptRow> {
  const { readArchivedSubmittedResult } = await import("./result-paper.server");
  const saved = await readArchivedSubmittedResult(row);
  return saved
    ? {
        ...row,
        answers: saved.answers,
        score: saved.score,
        total_marks: saved.total_marks,
        correct_count: saved.correct_count,
        attempted_count: saved.attempted_count,
        submitted_at: saved.submitted_at,
      }
    : row;
}

async function rebuildPaper(
  context: Parameters<typeof buildSelectedPaper>[0],
  row: LearningAttemptRow,
) {
  const { readResultPaper, requireArchivedAttemptAccess } = await import("./result-paper.server");
  const preserved = await readResultPaper(row);
  if (preserved) {
    await requireArchivedAttemptAccess(context, row, preserved);
    return preserved;
  }
  // Historical attempts without snapshots still use the existing source path;
  // never silently grade a different number or order of questions.
  const { assertPaperMatchesAttempt } = await import("./result-paper-store");
  const meta = getAttemptMeta(row);
  const rebuilt = await buildSelectedPaper(
    context,
    {
      test_id: row.test_id ?? undefined,
      series_id: row.series_id ?? undefined,
      subject: meta.subject || undefined,
      chapter: meta.chapter || undefined,
    },
    meta.seed,
  );
  assertPaperMatchesAttempt(row, rebuilt);
  return rebuilt;
}

export const startLearningAttempt = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .validator((input: unknown) => selection.parse(input))
  .handler(async ({ context, data }) => {
    if (!data.test_id && !data.series_id) throw new Error("Select a test or test series.");
    const id = data.request_id ?? randomUUID();
    const { readTestRetention } = await import("./test-retention.server");
    const policy = await readTestRetention(context.supabase);

    // A retry must find its own already-saved attempt BEFORE rechecking the
    // current catalogue. A published/free source may since have been removed
    // or repriced; only the original sealed paper can answer that retry.
    if (policy.save_results) {
      const existing = unwrap(
        await context.supabase
          .from("learning_attempts")
          .select("*")
          .eq("id", id)
          .eq("user_id", context.userId)
          .maybeSingle(),
      );

      if (existing) {
        const existingMeta = getAttemptMeta(existing);
        let sameSeries = data.series_id === undefined || existing.series_id === data.series_id;
        if (data.series_id !== undefined && !sameSeries) {
          const access = await readStudentAccess(context);
          const canonical = canonicalSeriesId(data.series_id, access.series_aliases);
          sameSeries = Boolean(canonical && existing.series_id === canonical);
        }
        if (
          existing.test_id !== (data.test_id ?? null) ||
          (existingMeta.subject && existingMeta.subject !== data.subject) ||
          (existingMeta.chapter && existingMeta.chapter !== data.chapter) ||
          !sameSeries
        ) {
          throw new Error("This start request belongs to another selection.");
        }

        // Reuse the same ownership, current-access and original-paper checks
        // as getLearningAttempt. Never save a rebuilt historical paper here.
        const paper = await rebuildPaper(context, existing);
        return {
          attempt: attemptView(await verifiedResultRow(existing), paper),
          test: paper.test,
          questions:
            existing.status === "submitted" ? paper.questions : publicQuestions(paper.questions),
          server_now: new Date().toISOString(),
          temporary: false as const,
          token: null as string | null,
        };
      }
    }

    const learning = await learningPlan(context, data);
    if (!policy.save_results) {
      const { startTemporaryTest } = await import("./temporary-test.server");
      return startTemporaryTest(
        context,
        {
          test_id: data.test_id,
          series_id: data.series_id,
          subject: data.subject,
          chapter: data.chapter,
        },
        id,
        policy.epoch,
        learning.access.is_admin,
      );
    }

    if (!learning.access.is_admin) {
      const limit = await context.supabase
        .from("learning_attempts")
        .select("id", { count: "exact", head: true })
        .eq("user_id", context.userId)
        .gte("started_at", new Date(Date.now() - 3_600_000).toISOString());

      if (limit.error) throw new Error(limit.error.message);

      if ((limit.count ?? 0) >= 30) {
        throw new Error(
          "Practice start limit reached (30/hour). Resume an existing attempt or try later.",
        );
      }
    }

    const seed = id;
    attemptSelectionCache.set(id, {
      subject: data.subject ?? "",
      chapter: data.chapter ?? "",
      seed,
    });
    const paper = await buildSelectedPaper(context, data, seed);
    const { requireResultPaperStorage, saveResultPaper } = await import("./result-paper.server");
    // Check readiness before inserting the attempt. Missing schema leaves the
    // existing source-based flow working; a half-installed private bucket fails.
    const canPreservePaper = await requireResultPaperStorage();

    const durationSeconds =
      paper.test.timer_mode === "unlimited"
        ? 0
        : paper.test.timer_mode === "question"
          ? paper.test.question_timer_seconds * paper.questions.length
          : paper.test.duration_minutes * 60;

    const questionTimerSeconds =
      paper.test.timer_mode === "question" ? paper.test.question_timer_seconds : 0;

    const sourceRefs = [
      ...paper.questions.map((question) => question.id),
      encodeMetaRef(data.subject, data.chapter, seed, canPreservePaper),
    ];

    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");

    let result = await supabaseAdmin
      .from("learning_attempts")
      .insert({
        id,
        user_id: context.userId,
        test_id: data.test_id ?? null,
        series_id: learning.series_id ?? null,
        duration_seconds: durationSeconds,
        question_timer_seconds: questionTimerSeconds,
        question_count: paper.questions.length,
        source_refs: sourceRefs,
        status: "started",
      })
      .select("*")
      .single();

    if (result.error && /question_timer_seconds/i.test(result.error.message)) {
      result = await supabaseAdmin
        .from("learning_attempts")
        .insert({
          id,
          user_id: context.userId,
          test_id: data.test_id ?? null,
          series_id: learning.series_id ?? null,
          duration_seconds: durationSeconds,
          question_count: paper.questions.length,
          source_refs: sourceRefs,
          status: "started",
        } as never)
        .select("*")
        .single();
    }

    const concurrentStart = result.error?.code === "23505";
    const row = concurrentStart
      ? unwrap(
          await context.supabase
            .from("learning_attempts")
            .select("*")
            .eq("id", id)
            .eq("user_id", context.userId)
            .single(),
        )
      : unwrap(result);

    if (!row) {
      throw new Error("Attempt could not be recorded. Retry Start Test with the same request.");
    }

    // A concurrent retry must use the paper that won the first write, never
    // replace it with a freshly generated/edited answer key.
    const finalPaper = concurrentStart
      ? await rebuildPaper(context, row)
      : canPreservePaper
        ? await saveResultPaper(row, paper)
        : paper;
    return {
      attempt: attemptView(row, finalPaper),
      test: finalPaper.test,
      questions: publicQuestions(finalPaper.questions),
      server_now: new Date().toISOString(),
      temporary: false as const,
      token: null as string | null,
    };
  });

export const getLearningAttempt = createServerFn({ method: "GET" })
  .middleware([requireSupabaseAuth])
  .validator((input: unknown) => attemptId.parse(input))
  .handler(async ({ context, data }) => {
    const row = unwrap(
      await context.supabase
        .from("learning_attempts")
        .select("*")
        .eq("id", data.attempt_id)
        .eq("user_id", context.userId)
        .maybeSingle(),
    );

    if (!row) throw new Error("Attempt not found for this account.");

    // The snapshot access check permits an already-started paper to resume
    // even if its original library entry was removed. Historical attempts
    // without a snapshot still go through the existing learningPlan checks.
    const paper = await rebuildPaper(context, row);

    return {
      attempt: attemptView(await verifiedResultRow(row), paper),
      test: paper.test,
      questions: row.status === "submitted" ? paper.questions : publicQuestions(paper.questions),
      server_now: new Date().toISOString(),
      temporary: false as const,
      token: null as string | null,
    };
  });

export const saveLearningAttemptAnswers = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .validator((input: unknown) =>
    attemptId
      .extend({
        answers: responses,
        revision: z.number().int().min(1).max(1_000_000),
      })
      .parse(input),
  )
  .handler(async ({ context, data }) => {
    const { requireSavedTestMode } = await import("./test-retention.server");
    await requireSavedTestMode(context.supabase);

    const row = unwrap(
      await context.supabase
        .from("learning_attempts")
        .select("*")
        .eq("id", data.attempt_id)
        .eq("user_id", context.userId)
        .maybeSingle(),
    );

    if (!row || row.status !== "started") {
      return { ok: false, reason: "submitted" };
    }

    const paper = await rebuildPaper(context, row);

    gradePaper(paper.questions, data.answers);

    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");

    const rpcResult = await supabaseAdmin.rpc("save_learning_attempt_answers", {
      p_actor: context.userId,
      p_attempt: row.id,
      p_answers: data.answers,
      p_revision: data.revision,
    });

    return requireAtomicAttemptRpc(rpcResult) as { ok: boolean; reason?: string };
  });

export const submitLearningAttempt = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .validator((input: unknown) => attemptId.extend({ answers: responses }).parse(input))
  .handler(async ({ context, data }) => {
    const { requireSavedTestMode } = await import("./test-retention.server");
    await requireSavedTestMode(context.supabase);

    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");

    for (let retry = 0; retry < 3; retry += 1) {
      const row = unwrap(
        await context.supabase
          .from("learning_attempts")
          .select("*")
          .eq("id", data.attempt_id)
          .eq("user_id", context.userId)
          .maybeSingle(),
      );

      if (!row) {
        throw new Error("Attempt not found for this account.");
      }

      const paper = await rebuildPaper(context, row);

      if (row.status === "submitted") {
        const { archiveSubmittedResult } = await import("./result-paper.server");
        const result_saved_to_storage = await archiveSubmittedResult(row);
        return {
          attempt: attemptView(await verifiedResultRow(row), paper),
          questions: paper.questions,
          result_saved_to_storage,
        };
      }

      const savedAnswers = answerMap(row.answers);
      const freshResult = gradePaper(paper.questions, data.answers);
      const savedResult = gradePaper(paper.questions, savedAnswers);

      const result = await supabaseAdmin.rpc("finalize_learning_attempt", {
        p_actor: context.userId,
        p_attempt: row.id,
        p_answers: data.answers,
        p_expected_saved_answers: savedAnswers,
        p_fresh_result: freshResult,
        p_saved_result: savedResult,
      });

      if (result.error?.message.includes("ATTEMPT_RETRY")) {
        continue;
      }

      const submitted = requireAtomicAttemptRpc(result) as unknown as LearningAttemptRow;
      const { archiveSubmittedResult } = await import("./result-paper.server");
      const result_saved_to_storage = await archiveSubmittedResult(submitted);

      return {
        attempt: attemptView(await verifiedResultRow(submitted), paper),
        questions: paper.questions,
        result_saved_to_storage,
      };
    }

    throw new Error(
      "Answers changed during submission. Retry Submit Test; no result was overwritten.",
    );
  });

export const listMyLearningResults = createServerFn({ method: "GET" })
  .middleware([requireSupabaseAuth])
  .handler(async ({ context }) => {
    const rows =
      unwrap(
        await context.supabase
          .from("learning_attempts")
          .select("*")
          .eq("user_id", context.userId)
          .eq("status", "submitted")
          .order("submitted_at", { ascending: false })
          .limit(100),
      ) ?? [];

    return Promise.all(
      rows.map(async (row) => {
        // A newly marked result without its private bytes must surface an
        // actionable error, never a silent database-only fallback.
        const verified = await verifiedResultRow(row);
        try {
          const paper = await rebuildPaper(context, row);
          return attemptView(verified, paper);
        } catch {
          const meta = getAttemptMeta(row);
          return {
            ...verified,
            exam: "Saved result",
            subject: meta.subject || "Archived selection",
            chapter: meta.chapter || "Context temporarily unavailable",
          };
        }
      }),
    );
  });
