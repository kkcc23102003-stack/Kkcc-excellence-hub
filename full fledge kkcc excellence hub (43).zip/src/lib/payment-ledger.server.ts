export type LedgerKind = "course" | "series" | "notes_series" | "test" | "material" | "coin_pack";

export type LedgerEntry = {
  userId: string;
  kind: LedgerKind;
  itemId: string;
  itemTitle?: string;
  amountInr: number;
  /** "pending" when the checkout opened, "paid" once money is confirmed. */
  status: "pending" | "paid" | "failed";
  /** "razorpay" or "offline"; mirrors the access grant method. */
  provider?: string;
  orderId?: string;
  paymentId?: string;
  couponCode?: string;
  note?: string;
};

async function adminClient() {
  const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
  return supabaseAdmin;
}

/** Atomically reserve one verified Razorpay payment ID for one student/product. */
export async function claimRazorpayPayment(input: {
  paymentId: string;
  userId: string;
  kind: LedgerKind;
  itemId: string;
}): Promise<"claimed" | "already_paid"> {
  const supabaseAdmin = await adminClient();
  const { error } = await supabaseAdmin.from("razorpay_payment_claims").insert({
    payment_id: input.paymentId,
    user_id: input.userId,
    kind: input.kind,
    item_id: input.itemId,
    status: "processing",
  });
  if (!error) return "claimed";
  if (error.code !== "23505") throw new Error(error.message);

  const { data: existing, error: readError } = await supabaseAdmin
    .from("razorpay_payment_claims")
    .select("user_id,kind,item_id,status,updated_at")
    .eq("payment_id", input.paymentId)
    .maybeSingle();
  if (readError) throw new Error(readError.message);
  if (!existing) throw new Error("Payment callback is already being processed. Retry shortly.");
  if (
    existing.user_id !== input.userId ||
    existing.kind !== input.kind ||
    existing.item_id !== input.itemId
  ) {
    throw new Error("This Razorpay payment ID has already been associated with another purchase.");
  }
  if (existing.status === "paid") return "already_paid";
  const leaseStartedAt = Date.parse(existing.updated_at ?? "");
  if (Number.isFinite(leaseStartedAt) && Date.now() - leaseStartedAt > 2 * 60 * 1000) {
    // Recover claims abandoned by a crashed server. The compare-and-swap keeps
    // two simultaneous recovery attempts from taking over the same lease.
    const { data: reclaimed, error: reclaimError } = await supabaseAdmin
      .from("razorpay_payment_claims")
      .update({ updated_at: new Date().toISOString() })
      .eq("payment_id", input.paymentId)
      .eq("status", "processing")
      .eq("updated_at", existing.updated_at)
      .select("payment_id");
    if (reclaimError) throw new Error(reclaimError.message);
    if (reclaimed?.length) return "claimed";
  }
  throw new Error("This verified payment is already being processed. Retry shortly.");
}

export async function markRazorpayPaymentClaimPaid(paymentId: string): Promise<void> {
  const supabaseAdmin = await adminClient();
  const { error } = await supabaseAdmin
    .from("razorpay_payment_claims")
    .update({ status: "paid", updated_at: new Date().toISOString() })
    .eq("payment_id", paymentId)
    .eq("status", "processing");
  if (error) throw new Error(error.message);
}

export async function releaseRazorpayPaymentClaim(paymentId: string): Promise<void> {
  try {
    const supabaseAdmin = await adminClient();
    const { error } = await supabaseAdmin
      .from("razorpay_payment_claims")
      .delete()
      .eq("payment_id", paymentId)
      .eq("status", "processing");
    if (error) console.warn("[razorpay] could not release payment claim", error.message);
  } catch (error) {
    console.warn("[razorpay] could not release payment claim", error);
  }
}

function metadataOf(entry: LedgerEntry) {
  return {
    kind: entry.kind,
    item_id: entry.itemId,
    item_title: entry.itemTitle ?? "",
    coupon_code: entry.couponCode ?? "",
  };
}

/** Insert a ledger row. Returns the row id, or null when the write failed. */
export async function recordPaymentEntry(entry: LedgerEntry): Promise<string | null> {
  try {
    const supabaseAdmin = await adminClient();
    const { data, error } = await supabaseAdmin
      .from("payment_transactions")
      .insert({
        user_id: entry.userId,
        course_id: entry.kind === "course" ? entry.itemId : null,
        provider: entry.provider ?? "razorpay",
        status: entry.status,
        amount: Math.max(0, Math.round(entry.amountInr)),
        currency: "INR",
        provider_order_id: entry.orderId ?? "",
        provider_payment_id: entry.paymentId ?? "",
        admin_note: entry.note ?? "",
        metadata: metadataOf(entry),
        created_by: entry.userId,
      } as never)
      .select("id")
      .single();
    if (error) {
      console.warn("[ledger] could not record payment entry", error.message);
      return null;
    }
    return (data as { id: string } | null)?.id ?? null;
  } catch (error) {
    console.warn("[ledger] could not record payment entry", error);
    return null;
  }
}

/** Mark a previously opened order as paid; callbacks can safely retry this write. */
export async function markPaymentPaid(input: {
  userId: string;
  kind: LedgerKind;
  itemId: string;
  itemTitle?: string;
  amountInr: number;
  orderId?: string;
  paymentId: string;
  couponCode?: string;
  note?: string;
}): Promise<void> {
  try {
    const supabaseAdmin = await adminClient();
    const { data: existing } = await supabaseAdmin
      .from("payment_transactions")
      .select("id, status")
      .eq("provider_payment_id", input.paymentId)
      .limit(1)
      .maybeSingle();
    if (existing) {
      const row = existing as { id: string; status: string };
      if (row.status !== "paid") {
        await supabaseAdmin
          .from("payment_transactions")
          .update({
            status: "paid",
            admin_note: input.note ?? "",
            provider_order_id: input.orderId ?? "",
            updated_at: new Date().toISOString(),
          } as never)
          .eq("id", row.id);
      }
      return;
    }

    const { data: pendingRow } = input.orderId
      ? await supabaseAdmin
          .from("payment_transactions")
          .select("id")
          .eq("provider_order_id", input.orderId)
          .eq("status", "pending")
          .limit(1)
          .maybeSingle()
      : { data: null };

    if (pendingRow) {
      await supabaseAdmin
        .from("payment_transactions")
        .update({
          status: "paid",
          provider_payment_id: input.paymentId,
          amount: Math.max(0, Math.round(input.amountInr)),
          admin_note: input.note ?? "",
          updated_at: new Date().toISOString(),
        } as never)
        .eq("id", (pendingRow as { id: string }).id);
      return;
    }

    await recordPaymentEntry({ ...input, status: "paid" });
  } catch (error) {
    console.warn("[ledger] could not mark payment paid", error);
  }
}

/** Server-only audit data: Razorpay payments and coin-paid learning purchases stay distinct. */
export async function readAdminPaymentHistoryData() {
  const supabaseAdmin = await adminClient();
  const [paymentsResult, coinResult, profileResult] = await Promise.all([
    supabaseAdmin
      .from("payment_transactions")
      .select("*")
      .order("created_at", { ascending: false })
      .limit(200),
    supabaseAdmin
      .from("coin_transactions")
      .select("*")
      .eq("source", "purchase")
      .lt("amount", 0)
      .order("created_at", { ascending: false })
      .limit(200),
    supabaseAdmin.from("profiles").select("id,email,full_name").limit(1000),
  ]);
  if (paymentsResult.error) throw new Error(paymentsResult.error.message);
  if (coinResult.error) throw new Error(coinResult.error.message);
  if (profileResult.error) throw new Error(profileResult.error.message);
  const profiles = new Map((profileResult.data ?? []).map((profile) => [profile.id, profile]));
  const payments = (paymentsResult.data ?? []).map((row) => {
    const profile = row.user_id ? profiles.get(row.user_id) : undefined;
    const metadata =
      row.metadata && typeof row.metadata === "object" && !Array.isArray(row.metadata)
        ? (row.metadata as Record<string, unknown>)
        : {};
    return {
      ...row,
      student_email: profile?.email ?? "unknown student",
      student_name: profile?.full_name ?? "",
      item_kind: typeof metadata["kind"] === "string" ? metadata["kind"] : "unknown",
      item_title: typeof metadata["item_title"] === "string" ? metadata["item_title"] : "",
      item_id: typeof metadata["item_id"] === "string" ? metadata["item_id"] : "",
      coupon_code: typeof metadata["coupon_code"] === "string" ? metadata["coupon_code"] : "",
    };
  });
  const coinPurchases = (coinResult.data ?? []).map((row) => {
    const profile = profiles.get(row.user_id);
    return {
      ...row,
      student_email: profile?.email ?? "unknown student",
      student_name: profile?.full_name ?? "",
    };
  });
  return { payments, coinPurchases };
}
