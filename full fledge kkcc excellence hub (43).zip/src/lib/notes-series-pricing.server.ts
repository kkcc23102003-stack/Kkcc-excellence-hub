import { z } from "zod";
import { projectContent } from "./project-content.server";
import type { NotesSeries } from "./notes-series";

const SETTINGS_KEY = "notes_series_pricing_v1";
export const notesSeriesPricingSchema = z
  .object({
    mode: z.enum(["shared", "per_series"]).default("per_series"),
    priceInr: z.number().int().min(0).max(1_000_000).default(0),
    priceCoins: z.number().int().min(0).max(1_000_000).default(0),
  })
  .superRefine((pricing, ctx) => {
    if (pricing.mode === "shared" && pricing.priceInr <= 0 && pricing.priceCoins <= 0)
      ctx.addIssue({ code: "custom", message: "Set a shared INR or 23KAAT price above zero." });
  });
export type NotesSeriesPricing = z.infer<typeof notesSeriesPricingSchema>;

export async function getNotesSeriesPricing(): Promise<NotesSeriesPricing> {
  const { data, error } = await projectContent
    .from("site_settings")
    .select("value")
    .eq("key", SETTINGS_KEY)
    .maybeSingle();
  if (error) throw new Error(error.message);
  return data
    ? notesSeriesPricingSchema.parse(JSON.parse(data.value))
    : notesSeriesPricingSchema.parse({});
}

export function applyNotesSeriesPricingFromConfig<T extends NotesSeries>(
  series: T,
  pricing: NotesSeriesPricing,
): T {
  if (series.kind !== "paid" || pricing.mode !== "shared") return series;
  return { ...series, priceInr: pricing.priceInr, priceCoins: pricing.priceCoins };
}

export async function applyNotesSeriesPricing<T extends NotesSeries>(series: T): Promise<T> {
  return applyNotesSeriesPricingFromConfig(series, await getNotesSeriesPricing());
}
