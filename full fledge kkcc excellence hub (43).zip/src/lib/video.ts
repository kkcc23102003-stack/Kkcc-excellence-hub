/** Video URL helpers. Video sources are stored in the database, never hard-coded. */

const SECURE_VIDEO_PREFIX = "kkccv1.";

/** Extract a YouTube video id from watch / youtu.be / shorts / embed URLs. */
export function youtubeId(url?: string | null): string | null {
  if (!url) return null;
  const value = url.trim();
  if (/^[\w-]{11}$/.test(value)) return value;
  try {
    const parsed = new URL(/^https?:\/\//i.test(value) ? value : `https://${value}`);
    if (
      !["https:", "http:"].includes(parsed.protocol) ||
      parsed.username ||
      parsed.password ||
      parsed.port
    )
      return null;
    const host = parsed.hostname.toLowerCase();
    const parts = parsed.pathname.split("/").filter(Boolean);
    let id: string | null = null;
    if (host === "youtu.be" || host === "www.youtu.be")
      id = parts.length === 1 ? (parts[0] ?? null) : null;
    else if (
      [
        "youtube.com",
        "www.youtube.com",
        "m.youtube.com",
        "music.youtube.com",
        "youtube-nocookie.com",
        "www.youtube-nocookie.com",
      ].includes(host)
    ) {
      if (parsed.pathname === "/watch") id = parsed.searchParams.get("v");
      else if (parts.length === 2 && ["embed", "shorts", "live", "v"].includes(parts[0] ?? ""))
        id = parts[1] ?? null;
    }
    return id && /^[A-Za-z0-9_-]{11}$/.test(id) ? id : null;
  } catch {
    return null;
  }
}

function base64UrlEncode(value: string) {
  const encoded =
    typeof btoa === "function" ? btoa(value) : Buffer.from(value, "utf8").toString("base64");
  return encoded.replace(/\+/g, "-").replace(/\//g, "_").replace(/=+$/g, "");
}

function base64UrlDecode(value: string) {
  const normalized = value.replace(/-/g, "+").replace(/_/g, "/");
  const padded = normalized.padEnd(normalized.length + ((4 - (normalized.length % 4)) % 4), "=");
  return typeof atob === "function" ? atob(padded) : Buffer.from(padded, "base64").toString("utf8");
}

export function encodeSecureVideoToken(url?: string | null): string | null {
  const id = youtubeId(url);
  if (!id) return null;
  const payload = ["yt", id.split("").reverse().join(""), "kkcc-secure-video"].join("|");
  return `${SECURE_VIDEO_PREFIX}${base64UrlEncode(payload)}`;
}

export function isSecureVideoToken(value?: string | null) {
  return Boolean(value?.trim().startsWith(SECURE_VIDEO_PREFIX));
}

export function decodeSecureVideoToken(
  value?: string | null,
): { provider: "youtube"; id: string } | null {
  const token = value?.trim();
  if (!token?.startsWith(SECURE_VIDEO_PREFIX)) return null;
  try {
    const decoded = base64UrlDecode(token.slice(SECURE_VIDEO_PREFIX.length));
    const [provider, reversedId, marker] = decoded.split("|");
    const id = reversedId?.split("").reverse().join("");
    if (provider !== "yt" || marker !== "kkcc-secure-video" || !/^[\w-]{11}$/.test(id ?? "")) {
      return null;
    }
    return { provider: "youtube", id: id ?? "" };
  } catch {
    return null;
  }
}

export function protectVideoUrl(url?: string | null): string | null {
  return encodeSecureVideoToken(url) ?? url?.trim() ?? null;
}

export function youtubeEmbedUrlFromId(id: string): string {
  if (!/^[A-Za-z0-9_-]{11}$/.test(id)) throw new Error("Invalid YouTube video id.");
  return `https://www.youtube-nocookie.com/embed/${id}?rel=0&controls=1&iv_load_policy=3&playsinline=1`;
}

export function youtubeEmbedUrl(url?: string | null): string | null {
  const id = youtubeId(url);
  return id ? youtubeEmbedUrlFromId(id) : null;
}

export type VideoSource =
  | { kind: "youtube"; src: string }
  | { kind: "file"; src: string }
  | { kind: "external"; src: string; original: string }
  | { kind: "none" };

export function videoSource(url?: string | null): VideoSource {
  const value = url?.trim();
  const secure = decodeSecureVideoToken(value);
  if (secure?.provider === "youtube") {
    return { kind: "youtube", src: `/secure-video.html?token=${encodeURIComponent(value ?? "")}` };
  }

  const embed = youtubeEmbedUrl(value);
  if (embed) {
    const token = encodeSecureVideoToken(value);
    return {
      kind: "youtube",
      src: token ? `/secure-video.html?token=${encodeURIComponent(token)}` : embed,
    };
  }

  // The disposable local fixture returns a same-origin signed Storage path;
  // production Storage links are full http(s) URLs. Only the private Batch
  // folder is accepted here, never a relative third-party/script URL.
  if (
    value &&
    /^\/(?:__fixture__\/supabase\/)?storage\/v1\/object\/sign\/[^/?#]+\/batch-videos\/[^?#]+\.(?:mp4|webm|ogv|mov|m4v)(?:\?[^#]*)?$/i.test(
      value,
    )
  ) {
    return { kind: "file", src: value };
  }
  if (value && (/^https?:\/\//i.test(value) || value.startsWith("/uploads/batch-videos/"))) {
    try {
      const parsed = new URL(value, "https://kkcc.invalid");
      const path = parsed.pathname;
      // Signed Storage URLs retain the file extension in the path. Other hosted
      // pages might not be direct media: use an iframe plus a manual finish control.
      if (/\.(mp4|webm|ogv|mov|m4v)$/i.test(path)) return { kind: "file", src: value };
      const host = parsed.hostname.toLowerCase();
      const vimeo = /^(?:www\.)?vimeo\.com$/.test(host) ? path.match(/^\/(\d+)(?:\/)?$/) : null;
      const daily = /^(?:www\.)?dailymotion\.com$/.test(host)
        ? path.match(/^\/video\/([a-zA-Z0-9]+)(?:\/)?$/)
        : null;
      const drive =
        host === "drive.google.com" ? path.match(/^\/file\/d\/([a-zA-Z0-9_-]+)(?:\/.*)?$/) : null;
      const src = vimeo?.[1]
        ? `https://player.vimeo.com/video/${vimeo[1]}`
        : daily?.[1]
          ? `https://www.dailymotion.com/embed/video/${daily[1]}`
          : drive?.[1]
            ? `https://drive.google.com/file/d/${drive[1]}/preview`
            : value;
      return { kind: "external", src, original: value };
    } catch {
      return { kind: "none" };
    }
  }
  return { kind: "none" };
}

/** Accept safe hosted videos and private uploads; third-party pages may forbid embedding. */
export function validateVideoUrl(value: string): string | null {
  const v = value.trim();
  if (!v) return null;
  if (v.startsWith("kkcc-file://"))
    return /^kkcc-file:\/\/[^/\s]+\/[^\s]+$/.test(v) ? null : "Invalid private video reference.";
  // Local fixture fallback only; production uploads use private kkcc-file references.
  if (/^\/uploads\/batch-videos\/[A-Za-z0-9_/.-]+\.(mp4|webm|mov|m4v)$/i.test(v)) return null;
  if (youtubeId(v)) return null;
  try {
    const url = new URL(v);
    if (
      !["https:", "http:"].includes(url.protocol) ||
      !url.hostname ||
      url.username ||
      url.password
    )
      return "Use a full http(s) video URL without embedded credentials.";
    if (/^(localhost|127\.|0\.0\.0\.0|\[?::1\]?)/i.test(url.hostname))
      return "Use a public video host, not a local address.";
    if (/youtube|youtu\.be/i.test(url.hostname + url.pathname))
      return "This looks like a YouTube link, but its host or video ID is invalid.";
    return null;
  } catch {
    return "Paste a full http(s) video URL or upload a video file.";
  }
}
