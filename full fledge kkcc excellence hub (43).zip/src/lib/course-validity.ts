/** Normalize the optional per-course access period. Null means lifetime. */
export function normalizeAccessValidDays(value: unknown): number | null {
  if (value === null || value === undefined || value === "") return null;
  const days = Number(value);
  if (!Number.isInteger(days) || days < 1 || days > 3650)
    throw new Error("Course access validity must be between 1 and 3650 days.");
  return days;
}
