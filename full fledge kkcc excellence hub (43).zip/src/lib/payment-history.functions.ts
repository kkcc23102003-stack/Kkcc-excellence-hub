import { createServerFn } from "@tanstack/react-start";
import { requireSupabaseAuth } from "@/integrations/supabase/auth-middleware";

/** Admin-only bridge to server-side payment history data. */
export const getAdminPaymentHistory = createServerFn({ method: "GET" })
  .middleware([requireSupabaseAuth])
  .handler(async ({ context }) => {
    const { assertAdmin } = await import("@/lib/learning.server");
    await assertAdmin(context);
    const { readAdminPaymentHistoryData } = await import("@/lib/payment-ledger.server");
    return readAdminPaymentHistoryData();
  });
