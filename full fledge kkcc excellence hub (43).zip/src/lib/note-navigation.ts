export type NotePath = { subject: string | null; chapter: string | null; noteId: string | null };
export type NoteEntry = {
  id: string;
  title: string;
  subject?: string | null;
  chapter?: string | null;
};
export const EMPTY_NOTE_PATH: NotePath = { subject: null, chapter: null, noteId: null };
export const noteGroup = (value?: string | null) => (value || "").trim();
export function notesInPath<T extends NoteEntry>(notes: T[], path: NotePath): T[] {
  if (path.subject === null || path.chapter === null) return [];
  return notes.filter(
    (note) =>
      noteGroup(note.subject) === path.subject &&
      noteGroup(note.chapter) === path.chapter &&
      (!path.noteId || note.id === path.noteId),
  );
}
