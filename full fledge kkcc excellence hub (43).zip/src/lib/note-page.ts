/** Printable page presets for the in-note handwriting composer (millimetres). */
export type NotePaperPattern = "blank" | "ruled" | "grid" | "dotted";
export type NotePagePreset = "a4" | "a5" | "letter" | "custom";
export type NotePageSize = { widthMm: number; heightMm: number };
export type NotePageLayout = NotePageSize & {
  pattern: NotePaperPattern;
  paperColour: string;
};

export const NOTE_PAGE_PRESETS: Record<Exclude<NotePagePreset, "custom">, NotePageSize> = {
  a4: { widthMm: 210, heightMm: 297 },
  a5: { widthMm: 148, heightMm: 210 },
  letter: { widthMm: 216, heightMm: 279 },
};
export const DEFAULT_NOTE_PAGE: NotePageLayout = {
  ...NOTE_PAGE_PRESETS.a4,
  pattern: "blank",
  paperColour: "#ffffff",
};
/** First sheet for the visible Custom page shortcut. Subsequent sheets inherit the chosen size. */
export const STARTER_CUSTOM_NOTE_PAGE: NotePageLayout = {
  widthMm: 180,
  heightMm: 240,
  pattern: "blank",
  paperColour: "#ffffff",
};
export function validNotePageSize(size: NotePageSize): boolean {
  return (
    Number.isFinite(size.widthMm) &&
    Number.isFinite(size.heightMm) &&
    size.widthMm >= 90 &&
    size.widthMm <= 420 &&
    size.heightMm >= 90 &&
    size.heightMm <= 594
  );
}

export function notePagePixels(size: NotePageSize): { width: number; height: number } {
  if (!validNotePageSize(size))
    throw new Error("Page dimensions must be 90–420 mm wide and 90–594 mm tall.");
  // A4 is ~1240×1754 px. Cap *both* pixel axes and total pixels for phone RAM.
  const density = Math.min(
    5.91,
    2400 / Math.max(size.widthMm, size.heightMm),
    Math.sqrt(3_600_000 / (size.widthMm * size.heightMm)),
  );
  return { width: Math.floor(size.widthMm * density), height: Math.floor(size.heightMm * density) };
}

export function notePageLayout(input: NotePageLayout): NotePageLayout {
  if (!validNotePageSize(input))
    throw new Error("Page dimensions must be 90–420 mm wide and 90–594 mm tall.");
  return {
    widthMm: Math.round(input.widthMm),
    heightMm: Math.round(input.heightMm),
    pattern: (["blank", "ruled", "grid", "dotted"] as const).includes(input.pattern)
      ? input.pattern
      : "blank",
    paperColour: /^#[a-f0-9]{6}$/i.test(input.paperColour)
      ? input.paperColour.toLowerCase()
      : "#ffffff",
  };
}

/** Draw the *real exported background* behind transparent ink. No CSS-only ruling. */
export function paintNotePage(
  ctx: CanvasRenderingContext2D,
  width: number,
  height: number,
  layout: NotePageLayout,
  template?: CanvasImageSource,
): void {
  ctx.save();
  ctx.fillStyle = layout.paperColour;
  ctx.fillRect(0, 0, width, height);
  if (template) {
    const image = template as HTMLImageElement;
    const imageWidth = image.naturalWidth || image.width;
    const imageHeight = image.naturalHeight || image.height;
    if (imageWidth && imageHeight) {
      const scale = Math.min(width / imageWidth, height / imageHeight);
      ctx.drawImage(
        template,
        (width - imageWidth * scale) / 2,
        (height - imageHeight * scale) / 2,
        imageWidth * scale,
        imageHeight * scale,
      );
    }
  }
  const step = Math.max(20, Math.round((width / layout.widthMm) * 8));
  ctx.strokeStyle = "#d0d8db";
  ctx.fillStyle = "#aebbc0";
  ctx.lineWidth = Math.max(1, width / 1100);
  if (layout.pattern === "ruled" || layout.pattern === "grid") {
    for (let y = step; y < height; y += step) {
      ctx.beginPath();
      ctx.moveTo(0, y);
      ctx.lineTo(width, y);
      ctx.stroke();
    }
  }
  if (layout.pattern === "grid") {
    for (let x = step; x < width; x += step) {
      ctx.beginPath();
      ctx.moveTo(x, 0);
      ctx.lineTo(x, height);
      ctx.stroke();
    }
  }
  if (layout.pattern === "dotted") {
    for (let x = step; x < width; x += step) {
      for (let y = step; y < height; y += step) {
        ctx.beginPath();
        ctx.arc(x, y, Math.max(1, width / 950), 0, Math.PI * 2);
        ctx.fill();
      }
    }
  }
  ctx.restore();
}
