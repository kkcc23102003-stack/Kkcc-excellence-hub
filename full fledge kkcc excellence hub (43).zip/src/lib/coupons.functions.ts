import { effectiveSeries, readCustomSeriesCatalog } from "@/lib/learning.server";
import { getNotesSeriesById, notesSeriesGrantId } from "@/lib/notes-series-purchase.server";
import { projectContent } from "@/lib/project-content.server";
import { getEffectiveLearningSeries } from "@/lib/test-series-catalog";
import { notesSeriesSchema, type NotesSeries } from "@/lib/notes-series";
import { readNotesCatalogSetting } from "@/lib/notes-catalog-storage.server";
import { readOptionalAdminCatalog } from "@/lib/optional-admin-catalog";
import { couponScopeError } from "@/lib/coupon-scope";
import { applySharedBatchPriceToCourse } from "@/lib/notes-batch-pricing.server";
import { coinPriceOf } from "@/lib/cms";
import { normalizeAccessValidDays } from "@/lib/course-validity";
import { createServerFn } from "@tanstack/react-start";
import type { SupabaseClient } from "@supabase/supabase-js";
import { z } from "zod";
import { requireSupabaseAuth } from "@/integrations/supabase/auth-middleware";
import type {
  CouponCodeRow,
  CouponRedemptionRow,
  CouponScopeKind,
  CourseRow,
  DB as Database,
} from "@/integrations/supabase/db";

const couponCodeSchema = z
  .string()
  .trim()
  .min(2)
  .max(40)
  .transform((value) => value.toUpperCase().replace(/\s+/g, ""));

const adminCouponSchema = z
  .object({
    id: z.string().uuid().optional(),
    code: couponCodeSchema,
    title: z.string().trim().min(1).max(120),
    description: z.string().trim().max(500).default(""),
    discount_percent: z.number().int().min(1).max(100),
    max_uses: z.number().int().min(0).max(100000).default(0),
    per_user_limit: z.number().int().min(1).max(100).default(1),
    starts_at: z.string().datetime().nullable().optional(),
    expires_at: z.string().datetime().nullable().optional(),
    is_active: z.boolean().default(true),
    applies_to_kind: z
      .enum(["all", "course", "material", "test", "series", "notes_series"])
      .default("all"),
    applies_to_course_id: z.string().uuid().nullable().optional(),
    applies_to_item_id: z.string().trim().min(1).max(500).nullable().optional(),
  })
  .superRefine((data, context) => {
    if (data.applies_to_course_id && data.applies_to_kind !== "course") {
      context.addIssue({
        code: "custom",
        path: ["applies_to_course_id"],
        message: "A selected batch can only be used with the Batches / Courses scope.",
      });
    }
    if (
      data.applies_to_item_id &&
      !["material", "test", "series", "notes_series"].includes(data.applies_to_kind)
    ) {
      context.addIssue({
        code: "custom",
        path: ["applies_to_item_id"],
        message: "Choose a supported product category before selecting a specific item.",
      });
    }
  });

const deleteCouponSchema = z.object({ id: z.string().uuid() });
const redemptionVisibilitySchema = z.object({ id: z.string().uuid(), hidden: z.boolean() });
const validateCouponSchema = z.object({
  code: couponCodeSchema,
  course_slug: z.string().trim().optional().default(""),
  series_id: z.string().trim().optional().default(""),
  test_id: z.string().trim().optional().default(""),
  /** Paid study notes / notes bundle — coupons work here too. */
  material_id: z.string().trim().optional().default(""),
  notes_series_id: z.string().trim().optional().default(""),
});
const redeemCouponSchema = z.object({
  code: couponCodeSchema,
  course_slug: z.string().trim().optional().default(""),
  series_id: z.string().trim().optional().default(""),
  test_id: z.string().trim().optional().default(""),
  material_id: z.string().trim().optional().default(""),
  notes_series_id: z.string().trim().optional().default(""),
});

type CourseCoupon = CouponCodeRow & { course?: CourseRow | null };

async function assertAdmin(context: { supabase: SupabaseClient<Database>; userId: string }) {
  const { data, error } = await context.supabase.rpc("has_role", {
    _user_id: context.userId,
    _role: "admin",
  });
  if (error || !data) throw new Error("Forbidden — admin access required");
}

function isCouponTimeValid(coupon: CouponCodeRow) {
  const now = Date.now();
  if (coupon.starts_at && new Date(coupon.starts_at).getTime() > now) return false;
  if (coupon.expires_at && new Date(coupon.expires_at).getTime() <= now) return false;
  return true;
}

function checkCouponValidity(
  coupon: CouponCodeRow,
  targetKind: Exclude<CouponScopeKind, "all">,
  targetCourseId: string | null,
  targetItemId: string | null = null,
) {
  if (!coupon.is_active) return "Coupon is inactive or expired.";
  if (coupon.starts_at && new Date(coupon.starts_at).getTime() > Date.now()) {
    return "Coupon is not active yet.";
  }
  if (coupon.expires_at && new Date(coupon.expires_at).getTime() <= Date.now()) {
    return "Coupon validity has ended.";
  }
  if (coupon.max_uses > 0 && coupon.used_count >= coupon.max_uses) {
    return "Coupon usage limit is full.";
  }
  return couponScopeError(coupon, targetKind, targetCourseId, targetItemId);
}

function calculateCouponBreakdown(
  originalAmountInr: number,
  originalCoins: number,
  discountPercent: number,
) {
  const pct = Math.min(100, Math.max(0, Math.round(Number(discountPercent) || 0)));
  const origInr = Math.max(0, Math.round(Number(originalAmountInr) || 0));
  const discountAmount = Math.min(origInr, Math.round((origInr * pct) / 100));
  const finalAmount = Math.max(0, origInr - discountAmount);

  const origCoins = Math.max(0, Math.round(Number(originalCoins) || 0));
  const discountCoins = Math.min(origCoins, Math.round((origCoins * pct) / 100));
  const finalCoins = Math.max(0, origCoins - discountCoins);

  return {
    discountPercent: pct,
    originalAmount: origInr,
    discountAmount,
    finalAmount,
    originalCoins: origCoins,
    discountCoins,
    finalCoins,
  };
}

export async function resolveServerCouponDiscount(input: {
  code: string;
  targetKind: Exclude<CouponScopeKind, "all">;
  targetCourseId: string | null;
  /** Item identifier for redemption history and per-user limits (all learning item types). */
  targetItemId?: string | null;
  originalAmountInr: number;
  originalCoins: number;
  userId?: string;
  recordRedemption?: boolean;
}) {
  const cleanCode = input.code.trim().toUpperCase().replace(/\s+/g, "");
  if (!cleanCode) {
    return {
      coupon: null,
      ...calculateCouponBreakdown(input.originalAmountInr, input.originalCoins, 0),
    };
  }

  const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
  const { data: couponRow, error } = await supabaseAdmin
    .from("coupon_codes")
    .select("*")
    .eq("code", cleanCode)
    .maybeSingle();
  if (error) throw new Error(error.message);
  if (!couponRow) throw new Error("Coupon code not found.");

  const coupon = couponRow as CouponCodeRow;
  const reason = checkCouponValidity(
    coupon,
    input.targetKind,
    input.targetCourseId,
    input.targetItemId ?? null,
  );
  if (reason) throw new Error(reason);

  if (input.userId && coupon.per_user_limit > 0) {
    const { count } = await supabaseAdmin
      .from("coupon_redemptions")
      .select("*", { count: "exact", head: true })
      .eq("coupon_id", coupon.id)
      .eq("user_id", input.userId);
    if ((count ?? 0) >= coupon.per_user_limit) {
      throw new Error("You have already used this coupon code the maximum number of times.");
    }
  }

  const breakdown = calculateCouponBreakdown(
    input.originalAmountInr,
    input.originalCoins,
    coupon.discount_percent,
  );

  if (input.recordRedemption && input.userId) {
    await supabaseAdmin
      .from("coupon_codes")
      .update({
        used_count: (coupon.used_count ?? 0) + 1,
        updated_at: new Date().toISOString(),
      } as never)
      .eq("id", coupon.id);

    const redemptionItemId = input.targetItemId ?? input.targetCourseId;
    if (redemptionItemId) {
      const legacyCourseId = input.targetKind === "course" ? redemptionItemId : null;
      const { error: redemptionError } = await supabaseAdmin.from("coupon_redemptions").insert({
        coupon_id: coupon.id,
        user_id: input.userId,
        course_id: legacyCourseId,
        item_kind: input.targetKind,
        item_id: redemptionItemId,
        discount_percent: breakdown.discountPercent,
        discount_amount: breakdown.discountAmount,
        original_amount: breakdown.originalAmount,
        final_amount: breakdown.finalAmount,
        currency: "INR",
        status: breakdown.finalAmount === 0 && breakdown.finalCoins === 0 ? "enrolled" : "applied",
      } as never);
      if (redemptionError) throw new Error(redemptionError.message);
    }
  }

  return { coupon, ...breakdown };
}

export const adminListCoupons = createServerFn({ method: "GET" })
  .middleware([requireSupabaseAuth])
  .handler(async ({ context }) => {
    await assertAdmin(context);
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    const [
      couponResult,
      courseResult,
      redemptionResult,
      hiddenRedemptionResult,
      profileResult,
      testResult,
      materialResult,
      notesSeriesSettingsResult,
      testSeriesCatalogResult,
    ] = await Promise.all([
      supabaseAdmin
        .from("coupon_codes")
        .select("*")
        .order("created_at", { ascending: false })
        .limit(500),
      projectContent
        .from("courses")
        .select("*")
        .order("sort_order", { ascending: true })
        .order("created_at", { ascending: true }),
      supabaseAdmin
        .from("coupon_redemptions")
        .select("*")
        .is("admin_hidden_at", null)
        .order("created_at", { ascending: false })
        .limit(500),
      supabaseAdmin
        .from("coupon_redemptions")
        .select("*")
        .not("admin_hidden_at", "is", null)
        .order("created_at", { ascending: false })
        .limit(1000),
      supabaseAdmin.from("profiles").select("id,email,full_name").limit(1000),
      projectContent.from("tests").select("id,title,is_published,is_paid"),
      projectContent.from("materials").select("id,title,access_type,is_published,is_free_preview"),
      projectContent.from("site_settings").select("key,value").ilike("key", "notes_series_v1:%"),
      readOptionalAdminCatalog(async () =>
        getEffectiveLearningSeries(await readCustomSeriesCatalog()).map((series) => ({
          id: series.id,
          title: `${series.name} · ${series.examTrack}`,
        })),
      ),
    ]);

    if (couponResult.error) throw new Error(couponResult.error.message);
    if (courseResult.error) throw new Error(courseResult.error.message);
    if (redemptionResult.error) throw new Error(redemptionResult.error.message);
    if (hiddenRedemptionResult.error) throw new Error(hiddenRedemptionResult.error.message);
    if (profileResult.error) throw new Error(profileResult.error.message);
    if (testResult.error) throw new Error(testResult.error.message);
    if (materialResult.error) throw new Error(materialResult.error.message);

    const courses = (courseResult.data ?? []) as CourseRow[];
    const courseById = new Map(courses.map((course) => [course.id, course]));
    const coupons = (couponResult.data ?? []) as CouponCodeRow[];
    const couponById = new Map(coupons.map((coupon) => [coupon.id, coupon]));
    const profiles = profileResult.data ?? [];
    const profileById = new Map(profiles.map((profile) => [profile.id, profile]));
    const redemptionRows = [
      ...(redemptionResult.data ?? []),
      ...(hiddenRedemptionResult.data ?? []),
    ].sort((a, b) => Date.parse(b.created_at) - Date.parse(a.created_at));
    const materialOptions = (materialResult.data ?? []) as {
      id: string;
      title: string | null;
      access_type: string | null;
      is_published: boolean;
      is_free_preview: boolean | null;
    }[];
    const testOptions = (testResult.data ?? []) as {
      id: string;
      title: string | null;
      is_published: boolean;
      is_paid: boolean;
    }[];
    const testSeries = testSeriesCatalogResult.items;
    const notesSeriesCatalogResult = await readOptionalAdminCatalog(async () => {
      if (notesSeriesSettingsResult.error)
        throw new Error(
          `Notes Series catalogue could not be read: ${notesSeriesSettingsResult.error.message}`,
        );
      const notesSeriesRows = (notesSeriesSettingsResult.data ?? []) as {
        key: string;
        value: string;
      }[];
      return (
        await Promise.all(
          notesSeriesRows.map(async (row) => {
            const id = row.key.slice("notes_series_v1:".length);
            const stored = await readNotesCatalogSetting<NotesSeries>({
              table: "site_settings",
              key: row.key,
              kind: "series",
              id,
              value: row.value,
            });
            const series = notesSeriesSchema.parse(stored.data);
            return series.published && series.kind === "paid"
              ? { id: series.id, title: series.name }
              : null;
          }),
        )
      ).filter((item): item is { id: string; title: string } => Boolean(item));
    });
    const notesSeries = notesSeriesCatalogResult.items;

    return {
      coupons: coupons.map((coupon) => ({
        ...coupon,
        course: coupon.applies_to_course_id
          ? (courseById.get(coupon.applies_to_course_id) ?? null)
          : null,
        is_time_valid: isCouponTimeValid(coupon),
        is_limit_full: coupon.max_uses > 0 && coupon.used_count >= coupon.max_uses,
      })) as CourseCoupon[],
      courses,
      profiles,
      materials: materialOptions
        .filter((item) => item.is_published && item.access_type === "paid" && !item.is_free_preview)
        .map((item) => ({ id: item.id, title: item.title })),
      tests: testOptions
        .filter((item) => item.is_published && item.is_paid)
        .map((item) => ({ id: item.id, title: item.title })),
      testSeries,
      notesSeries,
      catalogErrors: {
        testSeries: testSeriesCatalogResult.error,
        notesSeries: notesSeriesCatalogResult.error,
      },
      redemptions: (redemptionRows as CouponRedemptionRow[]).map((redemption) => ({
        ...redemption,
        item_kind: redemption.item_kind ?? "legacy",
        item_id: redemption.item_id ?? redemption.course_id ?? "",
        coupon_code: couponById.get(redemption.coupon_id)?.code ?? "(deleted coupon)",
        user_email: profileById.get(redemption.user_id)?.email ?? "unknown student",
        user_name: profileById.get(redemption.user_id)?.full_name ?? "",
      })),
    };
  });

export const adminSaveCoupon = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .validator((input: unknown) => adminCouponSchema.parse(input))
  .handler(async ({ context, data }) => {
    await assertAdmin(context);
    if (
      data.starts_at &&
      data.expires_at &&
      new Date(data.starts_at) >= new Date(data.expires_at)
    ) {
      throw new Error("Expiry date must be after start date.");
    }

    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    let specificItemId = data.applies_to_item_id ?? null;
    if (specificItemId) {
      if (data.applies_to_kind === "material") {
        const { data: material, error } = await projectContent
          .from("materials")
          .select("id")
          .eq("id", specificItemId)
          .eq("is_published", true)
          .eq("access_type", "paid")
          .eq("is_free_preview", false)
          .maybeSingle();
        if (error) throw new Error(error.message);
        if (!material) throw new Error("Choose a published paid Note.");
      } else if (data.applies_to_kind === "test") {
        const { data: test, error } = await projectContent
          .from("tests")
          .select("id")
          .eq("id", specificItemId)
          .eq("is_published", true)
          .eq("is_paid", true)
          .maybeSingle();
        if (error) throw new Error(error.message);
        if (!test) throw new Error("Choose a published paid Test.");
      } else if (data.applies_to_kind === "series") {
        const series = await effectiveSeries(specificItemId);
        if (!series.enabled) throw new Error("Choose an active Test Series.");
        specificItemId = series.id;
      } else if (data.applies_to_kind === "notes_series") {
        const series = await getNotesSeriesById(specificItemId);
        if (!series?.published || series.kind !== "paid")
          throw new Error("Choose a published paid Notes Series.");
        specificItemId = series.id;
      }
    }
    if (data.applies_to_course_id) {
      const { data: course, error } = await projectContent
        .from("courses")
        .select("id")
        .eq("id", data.applies_to_course_id)
        .eq("status", "published")
        .maybeSingle();
      if (error) throw new Error(error.message);
      if (!course) throw new Error("Choose a published Batch / Course.");
    }

    const payload = {
      code: data.code,
      title: data.title,
      description: data.description,
      discount_percent: Math.min(100, Math.max(1, data.discount_percent)),
      max_uses: data.max_uses,
      per_user_limit: data.per_user_limit,
      starts_at: data.starts_at ?? null,
      expires_at: data.expires_at ?? null,
      is_active: data.is_active,
      applies_to_kind: data.applies_to_kind,
      applies_to_course_id:
        data.applies_to_kind === "course" ? (data.applies_to_course_id ?? null) : null,
      applies_to_item_id: specificItemId,
      created_by: context.userId,
      updated_at: new Date().toISOString(),
    };

    if (data.id) {
      const { data: updated, error } = await supabaseAdmin
        .from("coupon_codes")
        .update(payload as never)
        .eq("id", data.id)
        .select("*")
        .single();
      if (error) throw new Error(error.message);
      return updated as CouponCodeRow;
    }

    const { data: inserted, error } = await supabaseAdmin
      .from("coupon_codes")
      .insert(payload as never)
      .select("*")
      .single();
    if (error) throw new Error(error.message);
    return inserted as CouponCodeRow;
  });

export const adminDeleteCoupon = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .validator((input: unknown) => deleteCouponSchema.parse(input))
  .handler(async ({ context, data }) => {
    await assertAdmin(context);
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    const { data: coupon, error: couponError } = await supabaseAdmin
      .from("coupon_codes")
      .select("id,used_count")
      .eq("id", data.id)
      .maybeSingle();
    if (couponError) throw new Error(couponError.message);
    if (!coupon) throw new Error("Coupon not found.");
    const { count, error: countError } = await supabaseAdmin
      .from("coupon_redemptions")
      .select("id", { count: "exact", head: true })
      .eq("coupon_id", data.id);
    if (countError) throw new Error(countError.message);
    const redemptions = Math.max(count ?? 0, coupon.used_count ?? 0);
    if (redemptions > 0) {
      const { error } = await supabaseAdmin
        .from("coupon_codes")
        .update({ is_active: false, updated_at: new Date().toISOString() } as never)
        .eq("id", data.id);
      if (error) throw new Error(error.message);
      return {
        ok: true,
        deleted: false,
        deactivated: true,
        redemptions: count ?? coupon.used_count,
      };
    }
    const { error } = await supabaseAdmin.from("coupon_codes").delete().eq("id", data.id);
    if (error) throw new Error(error.message);
    return { ok: true, deleted: true, deactivated: false, redemptions: 0 };
  });

/** Reversible Admin list hiding; the redemption remains in the ledger. */
export const adminSetCouponRedemptionHistoryVisibility = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .validator((input: unknown) => redemptionVisibilitySchema.parse(input))
  .handler(async ({ context, data }) => {
    await assertAdmin(context);
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    const result = await supabaseAdmin
      .from("coupon_redemptions")
      .update({ admin_hidden_at: data.hidden ? new Date().toISOString() : null } as never)
      .eq("id", data.id)
      .select("id")
      .maybeSingle();
    if (result.error) throw new Error(result.error.message);
    if (!result.data) throw new Error("Coupon redemption record not found.");
    return { ok: true, hidden: data.hidden };
  });

export const validateCouponForCourse = createServerFn({ method: "GET" })
  .validator((input: unknown) => validateCouponSchema.parse(input))
  .handler(async ({ data }) => {
    let targetKind: Exclude<CouponScopeKind, "all">;
    let targetCourseId: string | null = null;
    let targetItemId: string | null = null;
    let originalAmountInr = 0;
    let originalCoins = 0;

    if (data.notes_series_id) {
      targetKind = "notes_series";
      const series = await getNotesSeriesById(data.notes_series_id);
      if (!series?.published || series.kind !== "paid")
        return { valid: false, message: "Paid Notes Series not found." };
      if ((series.priceInr ?? 0) <= 0 && (series.priceCoins ?? 0) <= 0)
        return { valid: false, message: "Admin has not set a price for this Notes Series yet." };
      targetItemId = series.id;
      originalAmountInr = Math.max(0, series.priceInr ?? 0);
      originalCoins = Math.max(0, Number(series.priceCoins) || 0);
    } else if (data.series_id) {
      targetKind = "series";
      const series = await effectiveSeries(data.series_id);
      targetItemId = series.id;
      originalAmountInr = Math.max(0, Number(series.priceInr) || 0);
      originalCoins = Math.max(0, Number(series.priceCoins || series.priceInr) || 0);
    } else if (data.test_id) {
      targetKind = "test";
      const { data: test } = await projectContent
        .from("tests")
        .select("*")
        .eq("id", data.test_id)
        .eq("is_published", true)
        .maybeSingle();
      if (!test) return { valid: false, message: "Test not found." };
      targetItemId = test.id;
      originalAmountInr = Math.max(0, Number(test.price_inr) || 0);
      originalCoins = Math.max(0, Number(test.price_coins || test.price_inr) || 0);
    } else if (data.material_id) {
      targetKind = "material";
      const { data: material } = await projectContent
        .from("materials")
        .select("*")
        .eq("id", data.material_id)
        .eq("is_published", true)
        .maybeSingle();
      if (!material) return { valid: false, message: "Notes not found." };
      targetItemId = material.id;
      if (material.is_free_preview)
        return { valid: false, message: "This is the free first note for its subject." };
      if (material.access_type !== "paid")
        return { valid: false, message: "These notes are not an individually paid item." };
      originalAmountInr = Math.max(0, Number(material.price) || 0);
      originalCoins = Math.max(0, Number(material.coin_price) || 0);
      if (originalAmountInr <= 0 && originalCoins <= 0)
        return { valid: false, message: "Admin has not configured a price for this note." };
    } else if (data.course_slug) {
      targetKind = "course";
      const { data: course, error: courseError } = await projectContent
        .from("courses")
        .select("*")
        .eq("slug", data.course_slug)
        .eq("status", "published")
        .maybeSingle();
      if (courseError) throw new Error(courseError.message);
      if (!course) return { valid: false, message: "Batch / course not found." };
      const pricedCourse = await applySharedBatchPriceToCourse(course as CourseRow);
      targetCourseId = course.id;
      targetItemId = course.id;
      originalAmountInr = Math.max(0, Number(pricedCourse.price) || 0);
      originalCoins = coinPriceOf(pricedCourse);
    } else {
      return { valid: false, message: "Please select a batch or test series first." };
    }

    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    const { data: coupon, error: couponError } = await supabaseAdmin
      .from("coupon_codes")
      .select("*")
      .eq("code", data.code)
      .maybeSingle();
    if (couponError) throw new Error(couponError.message);
    if (!coupon) return { valid: false, message: "Coupon code not found." };

    const row = coupon as CouponCodeRow;
    const reason = checkCouponValidity(row, targetKind, targetCourseId, targetItemId);
    if (reason) return { valid: false, message: reason };

    const breakdown = calculateCouponBreakdown(
      originalAmountInr,
      originalCoins,
      row.discount_percent,
    );

    return {
      valid: true,
      coupon_id: row.id,
      code: row.code,
      title: row.title,
      discount_percent: breakdown.discountPercent,
      discount_amount: breakdown.discountAmount,
      original_amount: breakdown.originalAmount,
      final_amount: breakdown.finalAmount,
      original_coins: breakdown.originalCoins,
      discount_coins: breakdown.discountCoins,
      final_coins: breakdown.finalCoins,
      remaining_uses: row.max_uses > 0 ? Math.max(row.max_uses - row.used_count, 0) : null,
      message: `${breakdown.discountPercent}% discount applied!`,
    };
  });

type NotesSeriesCouponAccessState = "active" | "expired" | "revoked" | "missing";

async function notesSeriesCouponAccessState(
  userId: string,
  seriesId: string,
): Promise<NotesSeriesCouponAccessState> {
  const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
  const { data, error } = await supabaseAdmin
    .from("series_access_grants")
    .select("expires_at,revoked_at")
    .eq("user_id", userId)
    .eq("series_id", notesSeriesGrantId(seriesId))
    .order("created_at", { ascending: false })
    .limit(1)
    .maybeSingle();
  if (error) throw new Error(error.message);
  if (!data) return "missing";
  if (data.revoked_at) return "revoked";
  if (data.expires_at && Date.parse(data.expires_at) <= Date.now()) return "expired";
  return "active";
}

function couponWindowIsOpen(coupon: {
  is_active: boolean;
  starts_at: string | null;
  expires_at: string | null;
}) {
  const now = Date.now();
  return (
    coupon.is_active &&
    (!coupon.starts_at || Date.parse(coupon.starts_at) <= now) &&
    (!coupon.expires_at || Date.parse(coupon.expires_at) > now)
  );
}

export const checkCouponUserLimit = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .validator((input: unknown) =>
    z
      .object({ code: couponCodeSchema, notes_series_id: z.string().uuid().optional() })
      .parse(input),
  )
  .handler(async ({ context, data }) => {
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    const { data: coupon, error: couponError } = await supabaseAdmin
      .from("coupon_codes")
      .select("id,per_user_limit,is_active,starts_at,expires_at")
      .eq("code", data.code)
      .maybeSingle();
    if (couponError) throw new Error(couponError.message);
    if (!coupon) return { valid: false, message: "Coupon code not found." };
    if (coupon.per_user_limit > 0) {
      const { count, error } = await supabaseAdmin
        .from("coupon_redemptions")
        .select("id", { count: "exact", head: true })
        .eq("coupon_id", coupon.id)
        .eq("user_id", context.userId);
      if (error) throw new Error(error.message);
      if ((count ?? 0) >= coupon.per_user_limit) {
        if (data.notes_series_id) {
          const { data: priorSeriesRedemption, error: priorError } = await supabaseAdmin
            .from("coupon_redemptions")
            .select("discount_percent,final_amount")
            .eq("coupon_id", coupon.id)
            .eq("user_id", context.userId)
            .eq("item_kind", "notes_series")
            .eq("item_id", data.notes_series_id)
            .order("created_at", { ascending: false })
            .limit(1)
            .maybeSingle();
          if (priorError) throw new Error(priorError.message);
          if (
            priorSeriesRedemption?.discount_percent === 100 &&
            priorSeriesRedemption.final_amount <= 0
          ) {
            const accessState = await notesSeriesCouponAccessState(
              context.userId,
              data.notes_series_id,
            );
            if (accessState === "active") return { valid: true, already_redeemed: true };
            if (accessState === "revoked" || accessState === "expired") {
              return {
                valid: false,
                message:
                  "This Notes Series coupon access has been revoked or expired; ask an admin for help.",
              };
            }
            if (couponWindowIsOpen(coupon)) return { valid: true, already_redeemed: false };
          }
        }
        return {
          valid: false,
          message: "You have already used this coupon code the maximum number of times.",
        };
      }
    }
    return { valid: true };
  });

async function grantCouponMaterialAccess(userId: string, materialId: string, code: string) {
  const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
  const { data: existing, error: existingError } = await supabaseAdmin
    .from("material_access_grants")
    .select("id,expires_at")
    .eq("user_id", userId)
    .eq("material_id", materialId)
    .is("revoked_at", null)
    .maybeSingle();
  if (existingError) throw new Error(existingError.message);
  const now = new Date().toISOString();
  if (existing && (!existing.expires_at || Date.parse(existing.expires_at) > Date.now())) return;
  const payload = {
    user_id: userId,
    material_id: materialId,
    granted_by: userId,
    method: "coupon",
    amount_inr: 0,
    note: `100% Coupon ${code}`,
    expires_at: null,
    revoked_at: null,
    updated_at: now,
  };
  if (existing) {
    const { error } = await supabaseAdmin
      .from("material_access_grants")
      .update(payload as never)
      .eq("id", existing.id);
    if (error) throw new Error(error.message);
    return;
  }
  const { error } = await supabaseAdmin.from("material_access_grants").insert(payload as never);
  if (error?.code !== "23505") {
    if (error) throw new Error(error.message);
    return;
  }
  const { data: racedGrant, error: racedError } = await supabaseAdmin
    .from("material_access_grants")
    .select("id")
    .eq("user_id", userId)
    .eq("material_id", materialId)
    .is("revoked_at", null)
    .maybeSingle();
  if (racedError) throw new Error(racedError.message);
  if (!racedGrant) throw new Error("Could not issue Notes access for this coupon.");
}

async function grantNotesSeriesCouponAccess(userId: string, seriesId: string, code: string) {
  const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
  const seriesGrantId = notesSeriesGrantId(seriesId);
  const { data: existing, error: existingError } = await supabaseAdmin
    .from("series_access_grants")
    .select("id,expires_at")
    .eq("user_id", userId)
    .eq("series_id", seriesGrantId)
    .is("revoked_at", null)
    .maybeSingle();
  if (existingError) throw new Error(existingError.message);
  if (existing && (!existing.expires_at || Date.parse(existing.expires_at) > Date.now())) return;
  const grant = {
    user_id: userId,
    series_id: seriesGrantId,
    granted_by: userId,
    method: "coupon",
    amount_inr: 0,
    note: `100% Coupon ${code}`,
    expires_at: null,
    revoked_at: null,
  };
  if (existing) {
    const { error } = await supabaseAdmin
      .from("series_access_grants")
      .update(grant as never)
      .eq("id", existing.id);
    if (error) throw new Error(error.message);
    return;
  }
  const { error } = await supabaseAdmin.from("series_access_grants").insert(grant as never);
  if (error?.code !== "23505") {
    if (error) throw new Error(error.message);
    return;
  }
  const { data: racedGrant, error: racedError } = await supabaseAdmin
    .from("series_access_grants")
    .select("id")
    .eq("user_id", userId)
    .eq("series_id", seriesGrantId)
    .is("revoked_at", null)
    .maybeSingle();
  if (racedError) throw new Error(racedError.message);
  if (!racedGrant) throw new Error("Could not issue Notes Series access for this coupon.");
}

export const redeemCouponForCourse = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .validator((input: unknown) => redeemCouponSchema.parse(input))
  .handler(async ({ context, data }) => {
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");

    // Standalone paid Notes Series 100% coupon unlock.
    if (data.notes_series_id) {
      const series = await getNotesSeriesById(data.notes_series_id);
      if (!series?.published || series.kind !== "paid")
        throw new Error("Paid Notes Series not found.");
      if ((series.priceInr ?? 0) <= 0 && (series.priceCoins ?? 0) <= 0)
        throw new Error("Admin has not set a price for this Notes Series yet.");
      const { data: replayCoupon, error: replayCouponError } = await supabaseAdmin
        .from("coupon_codes")
        .select("id,code,is_active,starts_at,expires_at")
        .eq("code", data.code)
        .maybeSingle();
      if (replayCouponError) throw new Error(replayCouponError.message);
      if (replayCoupon) {
        const { data: priorRedemption, error: priorRedemptionError } = await supabaseAdmin
          .from("coupon_redemptions")
          .select("discount_percent,discount_amount,final_amount")
          .eq("coupon_id", replayCoupon.id)
          .eq("user_id", context.userId)
          .eq("item_kind", "notes_series")
          .eq("item_id", series.id)
          .order("created_at", { ascending: false })
          .limit(1)
          .maybeSingle();
        if (priorRedemptionError) throw new Error(priorRedemptionError.message);
        if (
          priorRedemption &&
          priorRedemption.discount_percent >= 100 &&
          priorRedemption.final_amount <= 0
        ) {
          const accessState = await notesSeriesCouponAccessState(context.userId, series.id);
          if (accessState === "revoked" || accessState === "expired")
            throw new Error(
              "This Notes Series coupon access has been revoked or expired; ask an admin for help.",
            );
          if (accessState === "missing") {
            if (!couponWindowIsOpen(replayCoupon))
              throw new Error(
                "This coupon is no longer active; contact an admin to restore access.",
              );
            await grantNotesSeriesCouponAccess(context.userId, series.id, replayCoupon.code);
          }
          return {
            ok: true,
            code: replayCoupon.code,
            series_id: series.id,
            final_amount: 0,
            discount_amount: priorRedemption.discount_amount,
            discount_percent: priorRedemption.discount_percent,
            enrolled: true,
            already_redeemed: true,
          };
        }
      }
      let res: Awaited<ReturnType<typeof resolveServerCouponDiscount>>;
      try {
        res = await resolveServerCouponDiscount({
          code: data.code,
          targetKind: "notes_series",
          targetCourseId: null,
          targetItemId: series.id,
          originalAmountInr: Math.max(0, Number(series.priceInr) || 0),
          originalCoins: Math.max(0, Number(series.priceCoins) || 0),
          userId: context.userId,
          recordRedemption: true,
        });
      } catch (error) {
        // Two taps can pass the preflight check concurrently. If the first request
        // already recorded this exact 100% Notes Series redemption, treat the
        // second request as a successful retry rather than surfacing a false error.
        if (
          replayCoupon &&
          error instanceof Error &&
          error.message.includes("already used this coupon code")
        ) {
          const { data: racedRedemption, error: racedError } = await supabaseAdmin
            .from("coupon_redemptions")
            .select("discount_percent,discount_amount,final_amount")
            .eq("coupon_id", replayCoupon.id)
            .eq("user_id", context.userId)
            .eq("item_kind", "notes_series")
            .eq("item_id", series.id)
            .order("created_at", { ascending: false })
            .limit(1)
            .maybeSingle();
          if (racedError) throw new Error(racedError.message);
          if (racedRedemption?.discount_percent === 100 && racedRedemption.final_amount <= 0) {
            const accessState = await notesSeriesCouponAccessState(context.userId, series.id);
            if (accessState === "revoked" || accessState === "expired")
              throw new Error(
                "This Notes Series coupon access has been revoked or expired; ask an admin for help.",
              );
            if (accessState === "missing") {
              if (!couponWindowIsOpen(replayCoupon))
                throw new Error(
                  "This coupon is no longer active; contact an admin to restore access.",
                );
              await grantNotesSeriesCouponAccess(context.userId, series.id, replayCoupon.code);
            }
            return {
              ok: true,
              code: replayCoupon.code,
              series_id: series.id,
              final_amount: 0,
              discount_amount: racedRedemption.discount_amount,
              discount_percent: racedRedemption.discount_percent,
              enrolled: true,
              already_redeemed: true,
            };
          }
        }
        throw error;
      }
      const enrolled = res.finalAmount <= 0 && res.finalCoins <= 0;
      if (enrolled)
        await grantNotesSeriesCouponAccess(
          context.userId,
          series.id,
          res.coupon?.code ?? data.code,
        );
      return {
        ok: true,
        code: res.coupon?.code ?? data.code,
        series_id: series.id,
        final_amount: res.finalAmount,
        discount_amount: res.discountAmount,
        discount_percent: res.discountPercent,
        enrolled,
      };
    }

    // Case 1: Test Series 100% coupon unlock
    if (data.series_id) {
      const series = await effectiveSeries(data.series_id);
      const res = await resolveServerCouponDiscount({
        code: data.code,
        targetKind: "series",
        targetCourseId: null,
        targetItemId: series.id,
        originalAmountInr: Math.max(0, Number(series.priceInr) || 0),
        originalCoins: Math.max(0, Number(series.priceCoins || series.priceInr) || 0),
        userId: context.userId,
        recordRedemption: true,
      });
      const enrolled = res.finalAmount <= 0 && res.finalCoins <= 0;
      if (enrolled) {
        const { error } = await supabaseAdmin.from("series_access_grants").upsert(
          {
            user_id: context.userId,
            series_id: series.id,
            granted_by: context.userId,
            method: "coupon",
            amount_inr: 0,
            note: `100% Coupon ${res.coupon?.code ?? data.code}`,
            expires_at: null,
            revoked_at: null,
          } as never,
          { onConflict: "series_id,user_id" },
        );
        if (error) {
          await supabaseAdmin.from("series_access_grants").insert({
            user_id: context.userId,
            series_id: series.id,
            granted_by: context.userId,
            method: "coupon",
            amount_inr: 0,
            note: `100% Coupon ${res.coupon?.code ?? data.code}`,
          } as never);
        }
      }
      return {
        ok: true,
        code: res.coupon?.code ?? data.code,
        course_id: series.id,
        final_amount: res.finalAmount,
        discount_amount: res.discountAmount,
        discount_percent: res.discountPercent,
        enrolled,
      };
    }

    // Case 2: Individual Paid Test 100% coupon unlock
    if (data.test_id) {
      const { data: test } = await projectContent
        .from("tests")
        .select("*")
        .eq("id", data.test_id)
        .eq("is_published", true)
        .maybeSingle();
      if (!test) throw new Error("Test not found.");
      const res = await resolveServerCouponDiscount({
        code: data.code,
        targetKind: "test",
        targetCourseId: null,
        targetItemId: test.id,
        originalAmountInr: Math.max(0, Number(test.price_inr) || 0),
        originalCoins: Math.max(0, Number(test.price_coins || test.price_inr) || 0),
        userId: context.userId,
        recordRedemption: true,
      });
      const enrolled = res.finalAmount <= 0 && res.finalCoins <= 0;
      if (enrolled) {
        await supabaseAdmin.from("test_access_grants").insert({
          user_id: context.userId,
          test_id: test.id,
          granted_by: context.userId,
          method: "coupon",
          amount_inr: 0,
          note: `100% Coupon ${res.coupon?.code ?? data.code}`,
        } as never);
      }
      return {
        ok: true,
        code: res.coupon?.code ?? data.code,
        course_id: test.id,
        final_amount: res.finalAmount,
        discount_amount: res.discountAmount,
        discount_percent: res.discountPercent,
        enrolled,
      };
    }

    // Case 2b: Paid Notes 100% coupon unlock
    if (data.material_id) {
      const { data: material } = await projectContent
        .from("materials")
        .select("*")
        .eq("id", data.material_id)
        .eq("is_published", true)
        .maybeSingle();
      if (!material) throw new Error("Notes not found.");
      if (material.is_free_preview || material.access_type !== "paid")
        throw new Error("This note is not an individually paid item.");
      const originalAmountInr = Math.max(0, Number(material.price) || 0);
      const originalCoins = Math.max(0, Number(material.coin_price) || 0);
      if (originalAmountInr <= 0 && originalCoins <= 0)
        throw new Error("Admin has not configured a price for this note.");
      const res = await resolveServerCouponDiscount({
        code: data.code,
        targetKind: "material",
        targetCourseId: null,
        targetItemId: material.id,
        originalAmountInr,
        originalCoins,
        userId: context.userId,
        recordRedemption: true,
      });
      const enrolled = res.finalAmount <= 0 && res.finalCoins <= 0;
      if (enrolled) {
        await grantCouponMaterialAccess(context.userId, material.id, res.coupon?.code ?? data.code);
      }
      return {
        ok: true,
        code: res.coupon?.code ?? data.code,
        course_id: material.id,
        final_amount: res.finalAmount,
        discount_amount: res.discountAmount,
        discount_percent: res.discountPercent,
        enrolled,
      };
    }

    // Case 3: Course / Batch coupon redemption
    const { data: course, error: courseError } = await projectContent
      .from("courses")
      .select("*")
      .eq("slug", data.course_slug)
      .eq("status", "published")
      .maybeSingle();
    if (courseError) throw new Error(courseError.message);
    if (!course) throw new Error("Course not found.");
    const pricedCourse = await applySharedBatchPriceToCourse(course as CourseRow);
    if (pricedCourse.price <= 0 && pricedCourse.coin_price > 0)
      throw new Error("Rupee coupons cannot unlock a coin-only course for free.");

    await resolveServerCouponDiscount({
      code: data.code,
      targetKind: "course",
      targetCourseId: course.id,
      targetItemId: course.id,
      originalAmountInr: Math.max(0, Math.round(Number(pricedCourse.price))),
      originalCoins: 0,
      recordRedemption: false,
    });
    const { data: result, error } = await supabaseAdmin.rpc("redeem_project_course_coupon", {
      p_actor: context.userId,
      p_code: data.code,
      p_course_id: course.id,
      p_original_amount: Math.max(0, Math.round(Number(pricedCourse.price))),
      p_access_valid_days: normalizeAccessValidDays(course.access_valid_days),
    });
    if (error) throw new Error(error.message);
    return result as {
      ok: boolean;
      code: string;
      course_id: string;
      final_amount: number;
      discount_amount: number;
      discount_percent: number;
      enrolled: boolean;
      already_redeemed?: boolean;
      message?: string;
    };
  });
