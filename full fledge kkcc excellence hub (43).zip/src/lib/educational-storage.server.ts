import { z } from "zod";
import { supabaseAdmin } from "@/integrations/supabase/client.server";
import {
  EDUCATIONAL_STORAGE_BUCKET,
  EDUCATIONAL_STORAGE_MAX_BYTES,
} from "./educational-storage.config";

const setupStatusSchema = z.object({
  bucket_exists: z.boolean(),
  bucket_private: z.boolean(),
  file_size_limit: z.number().nullable(),
  upload_policy: z.boolean(),
  read_policy: z.boolean(),
  update_policy: z.boolean(),
  delete_policy: z.boolean(),
  boundary_policy: z.boolean(),
  ready: z.boolean(),
});

export type EducationalStorageStatus = {
  bucketExists: boolean;
  bucketPrivate: boolean;
  fileSizeLimit: number | null;
  policiesReady: boolean | null;
};

function isMissingBucket(error: unknown) {
  if (!error || typeof error !== "object") return false;
  const candidate = error as { message?: unknown; status?: unknown; statusCode?: unknown };
  const message = typeof candidate.message === "string" ? candidate.message.toLowerCase() : "";
  return (
    candidate.status === 404 ||
    candidate.statusCode === "404" ||
    message.includes("bucket not found") ||
    message.includes("bucket does not exist")
  );
}

async function readEducationalBucket() {
  const { data, error } = await supabaseAdmin.storage.getBucket(EDUCATIONAL_STORAGE_BUCKET);
  if (error) {
    if (isMissingBucket(error)) return null;
    throw new Error(`Could not inspect the educational Storage bucket: ${error.message}`);
  }
  return data;
}

export async function getEducationalStorageStatus(): Promise<EducationalStorageStatus> {
  const bucket = await readEducationalBucket();
  const { data, error } = await supabaseAdmin.rpc("kkcc_educational_storage_setup_status");
  const setup = error ? null : setupStatusSchema.safeParse(data).data;
  return {
    bucketExists: Boolean(bucket),
    bucketPrivate: bucket ? !bucket.public : false,
    fileSizeLimit: bucket?.file_size_limit ?? null,
    policiesReady: setup?.ready ?? null,
  };
}

/** Create only the missing canonical bucket, always private; never change an existing bucket's visibility. */
export async function ensureEducationalStorageBucket(): Promise<EducationalStorageStatus> {
  const existing = await readEducationalBucket();
  if (existing?.public)
    throw new Error(
      "The course-content bucket is public. Apply KKCC-Excellence-Hub-EDUCATIONAL-STORAGE.sql to restore private access before uploading.",
    );
  if (!existing) {
    const { error } = await supabaseAdmin.storage.createBucket(EDUCATIONAL_STORAGE_BUCKET, {
      public: false,
      fileSizeLimit: EDUCATIONAL_STORAGE_MAX_BYTES,
    });
    if (error) {
      // A concurrent Admin repair may have created it between read and create.
      const raced = await readEducationalBucket();
      if (!raced) {
        throw new Error(
          `Could not create the private course-content bucket: ${error.message}. Apply KKCC-Excellence-Hub-EDUCATIONAL-STORAGE.sql and retry.`,
        );
      }
      if (raced.public)
        throw new Error(
          "The course-content bucket is public. Apply KKCC-Excellence-Hub-EDUCATIONAL-STORAGE.sql to restore private access before uploading.",
        );
    }
  }
  return getEducationalStorageStatus();
}
