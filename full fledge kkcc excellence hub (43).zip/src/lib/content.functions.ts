import { materialAccessMode } from "./material-access-mode";
import { notesPrintDocument } from "./notes-visuals";
import { NOTES_PRINT_LOGO_COMPACT } from "./notes-print-logo-compact";
import { readNoteBody, mapNoteBodyReads } from "./note-body.server";
import { isFreeCourse } from "@/lib/cms";
import { resolveContentUrl, resolveNoteImages } from "@/lib/content-storage.server";
import { createServerFn } from "@tanstack/react-start";
import { createClient } from "@supabase/supabase-js";
import { z } from "zod";
import type { DB as Database } from "@/integrations/supabase/db";
import { getSupabasePublicConfig } from "@/integrations/supabase/env";
import { createSupabaseFetch } from "@/integrations/supabase/fetch";
import { requireSupabaseAuth } from "@/integrations/supabase/auth-middleware";
import { projectContent } from "@/lib/project-content.server";
import { readCustomSeriesCatalog } from "@/lib/learning.server";
import { protectVideoUrl } from "@/lib/video";
import { getEffectivePaidTestSeries } from "@/lib/test-series-catalog";
import { isCurrentEnrollment } from "@/lib/learning-access";
import {
  applySharedBatchPriceToCourses,
  applySharedBatchPriceToCourse,
} from "@/lib/notes-batch-pricing.server";
import {
  getNotesSeriesMaterialMetadata,
  isFreeNotesSeriesPreview,
} from "@/lib/notes-series-purchase.server";

function publicStudentClient() {
  const config = getSupabasePublicConfig();
  if (!config) return null;
  return createClient<Database>(config.url, config.publishableKey, {
    auth: { persistSession: false, autoRefreshToken: false },
    global: { fetch: createSupabaseFetch(config.publishableKey) },
  });
}
type Row<T extends keyof Database["public"]["Tables"]> = Database["public"]["Tables"][T]["Row"];
function unwrap<T>(result: { data: T; error: { message: string } | null }) {
  if (result.error) throw new Error(result.error.message);
  return result.data;
}
async function protectLectures(lectures: Row<"lectures">[]) {
  return Promise.all(
    lectures.map(async (lecture) => ({
      ...lecture,
      video_url: protectVideoUrl(await resolveContentUrl(lecture.video_url)),
    })),
  );
}
function buildPublicNoteDataUrl(material: Row<"materials">) {
  const title = material.title || "KKCC Study Note";
  // The public fallback gets the same safe, repeated print header/footer as the
  // protected reader. The 2 KB copy of our logo avoids inflating catalog JSON.
  const html = notesPrintDocument({
    title,
    subject: [material.subject, material.class_level].filter(Boolean).join(" · "),
    chapter: material.chapter,
    materialType: material.material_type,
    text: material.description || `${title} — Complete Study Note & Revision Points.`,
    logoSrc: NOTES_PRINT_LOGO_COMPACT,
  });
  return `data:text/html;charset=utf-8,${encodeURIComponent(html)}`;
}

async function publicMaterials(materials: Row<"materials">[]) {
  return mapNoteBodyReads(materials, async (material) => {
    const effectiveAccessType = materialAccessMode(material);
    const isFreePreview = Boolean(material.is_free_preview);
    const isPubliclyReadable = effectiveAccessType === "free" || isFreePreview;
    const publicMaterial = { ...material };
    delete publicMaterial.body_storage_path;
    delete publicMaterial.body_storage_sha256;
    delete publicMaterial.body_storage_bytes;
    const description = isPubliclyReadable
      ? await resolveNoteImages(await readNoteBody(material))
      : "";
    const resolved = isPubliclyReadable ? await resolveContentUrl(material.file_url) : null;
    return {
      ...publicMaterial,
      description,
      access_type: isPubliclyReadable ? "free" : effectiveAccessType,
      file_url: isPubliclyReadable
        ? resolved || buildPublicNoteDataUrl({ ...material, description })
        : null,
    };
  });
}
export type PublicPlatformStats = {
  studentsJoined: number;
  activeStudents: number;
  publishedCourses: number;
  publishedLectures: number;
  publishedMaterials: number;
  publishedTests: number;
};
export const EMPTY_PUBLIC_PLATFORM_STATS: PublicPlatformStats = {
  studentsJoined: 0,
  activeStudents: 0,
  publishedCourses: 0,
  publishedLectures: 0,
  publishedMaterials: 0,
  publishedTests: 0,
};

export const listPublishedCourses = createServerFn({ method: "GET" }).handler(async () =>
  applySharedBatchPriceToCourses(
    unwrap(
      await projectContent
        .from("courses")
        .select("*")
        .eq("status", "published")
        .order("sort_order")
        .order("created_at"),
    ),
  ),
);

export const getCourseDetail = createServerFn({ method: "GET" })
  .validator((input: unknown) => z.object({ slug: z.string().trim().min(1).max(140) }).parse(input))
  .handler(async ({ data }) => {
    const course = unwrap(
      await projectContent
        .from("courses")
        .select("*")
        .eq("slug", data.slug)
        .eq("status", "published")
        .maybeSingle(),
    );
    if (!course) return null;
    const pricedCourse = await applySharedBatchPriceToCourse(course);
    const [lectures, materials] = await Promise.all([
      projectContent.from("lectures").select("*").eq("course_id", course.id).order("sort_order"),
      projectContent
        .from("materials")
        .select("*")
        .eq("course_id", course.id)
        .eq("is_published", true)
        .order("sort_order"),
    ]);
    return {
      course: pricedCourse,
      lectures: await protectLectures(
        unwrap(lectures).filter((lecture) => isFreeCourse(pricedCourse) || lecture.is_free),
      ),
      materials: await publicMaterials(unwrap(materials)),
    };
  });

export const getMyCourseLearningDeck = createServerFn({ method: "GET" })
  .middleware([requireSupabaseAuth])
  .validator((input: unknown) => z.object({ slug: z.string().trim().min(1).max(140) }).parse(input))
  .handler(async ({ context, data }) => {
    const course = unwrap(
      await projectContent
        .from("courses")
        .select("*")
        .eq("slug", data.slug)
        .eq("status", "published")
        .maybeSingle(),
    );
    if (!course) throw new Error("Course not found.");
    const pricedCourse = await applySharedBatchPriceToCourse(course);
    let hasAccess = isFreeCourse(pricedCourse);
    if (!hasAccess) {
      const result = await context.supabase
        .from("course_enrollments")
        .select("*")
        .eq("user_id", context.userId)
        .eq("course_id", course.id)
        .maybeSingle();
      const enrollment = unwrap(result);
      hasAccess = Boolean(enrollment && isCurrentEnrollment(enrollment));
      if (!hasAccess) {
        const admin = unwrap(
          await context.supabase.rpc("has_role", { _user_id: context.userId, _role: "admin" }),
        );
        hasAccess = Boolean(admin);
      }
    }
    const lectures = unwrap(
      await projectContent
        .from("lectures")
        .select("*")
        .eq("course_id", course.id)
        .order("sort_order"),
    );
    return {
      course: pricedCourse,
      lectures: await protectLectures(lectures.filter((lecture) => hasAccess || lecture.is_free)),
      has_access: hasAccess,
    };
  });

export const listPublicMaterials = createServerFn({ method: "GET" }).handler(async () => {
  const rows = unwrap(await projectContent.from("materials").select("*").order("sort_order"));
  // Only admin-published records belong in the live catalogue. The historic
  // built-in study-note bank is not an implicit source of student content.
  return publicMaterials(rows.filter((row) => row.is_published));
});
/** Catalogue cards never read Storage bodies, sign PDFs, or embed duplicate HTML data URLs. */
export const listPublicMaterialCards = createServerFn({ method: "GET" }).handler(async () => {
  const rows = unwrap(
    await projectContent
      .from("materials")
      .select(
        "id,course_id,lecture_id,title,material_type,subject,chapter,class_level,pages,is_published,is_free_preview,sort_order,thumbnail_url,thumbnail_text,module_title,batch,access_type,price,coin_price,created_at,updated_at",
      )
      .order("sort_order"),
  ).filter((row) => row.is_published);
  const notesSeries = await getNotesSeriesMaterialMetadata(rows.map((row) => row.id));
  return rows.map((row) => {
    const membership = notesSeries.membership.get(row.id);
    return {
      ...row,
      description: "",
      file_url: null,
      access_type: materialAccessMode(row),
      notes_series_id: membership?.id ?? null,
      notes_series_name: membership?.name ?? null,
      free_series_preview: notesSeries.freePreviewIds.has(row.id),
      body_storage_path: null,
      body_storage_sha256: null,
      body_storage_bytes: null,
    };
  });
});

/** Fetch a single free note on explicit open; paid/course bodies still use the protected handler. */
export const getPublicMaterialBody = createServerFn({ method: "GET" })
  .validator((input: unknown) => z.object({ id: z.string().uuid() }).parse(input))
  .handler(async ({ data }) => {
    const material = unwrap(
      await projectContent.from("materials").select("*").eq("id", data.id).maybeSingle(),
    );
    if (!material || !material.is_published)
      throw new Error("This note requires access or is no longer published.");
    if (materialAccessMode(material) !== "free" && !(await isFreeNotesSeriesPreview(material.id)))
      throw new Error("This note requires access or is no longer published.");
    return (await publicMaterials([material]))[0]!;
  });

/** Search can display lesson titles from a published syllabus, never a paid video URL/body. */
export const listSearchLectureCards = createServerFn({ method: "GET" }).handler(async () => {
  const [lectures, courses] = await Promise.all([
    projectContent
      .from("lectures")
      .select("id,course_id,title,module_title,duration,sort_order,is_free")
      .order("sort_order"),
    projectContent.from("courses").select("id").eq("status", "published"),
  ]);
  const published = new Set(unwrap(courses).map((course) => course.id));
  return unwrap(lectures).filter((lecture) => published.has(lecture.course_id));
});

export const listPublicLectures = createServerFn({ method: "GET" }).handler(async () => {
  const [lectures, courses] = await Promise.all([
    projectContent.from("lectures").select("*").order("sort_order"),
    projectContent.from("courses").select("*").eq("status", "published"),
  ]);
  const pricedCourses = await applySharedBatchPriceToCourses(unwrap(courses));
  const published = new Map(pricedCourses.map((course) => [course.id, course]));
  return protectLectures(
    unwrap(lectures).filter((lecture) => {
      const course = published.get(lecture.course_id);
      return Boolean(course && (isFreeCourse(course) || lecture.is_free));
    }),
  );
});
export const listPublicTests = createServerFn({ method: "GET" }).handler(async () =>
  unwrap(
    await projectContent.from("tests").select("*").eq("is_published", true).order("sort_order"),
  ),
);

/** Metadata only. All answer-bearing papers go through a protected attempt. */
export const getPublicTest = createServerFn({ method: "GET" })
  .validator((input: unknown) => z.object({ id: z.string().uuid() }).parse(input))
  .handler(async ({ data }) => {
    const test = unwrap(
      await projectContent
        .from("tests")
        .select("*")
        .eq("id", data.id)
        .eq("is_published", true)
        .maybeSingle(),
    );
    return test ? { test, questions: [] as Row<"test_questions">[], locked: test.is_paid } : null;
  });

export const getPublicPlatformStats = createServerFn({ method: "GET" }).handler(async () => {
  const [courses, lectures, materials, tests] = await Promise.all([
    projectContent.from("courses").select("id,status"),
    projectContent.from("lectures").select("course_id"),
    projectContent.from("materials").select("course_id,is_published"),
    projectContent.from("tests").select("is_published"),
  ]);
  const publishedIds = new Set(
    unwrap(courses)
      .filter((course) => course.status === "published")
      .map((course) => course.id),
  );
  let studentsJoined = 0;
  let activeStudents = 0;
  const client = publicStudentClient();
  if (client) {
    const { data, error } = await client.rpc("get_public_student_stats");
    if (!error && data && typeof data === "object") {
      const row = data as Record<string, unknown>;
      studentsJoined = Number(row["students_joined"] || 0);
      activeStudents = Number(row["active_students"] || 0);
    }
  }
  return {
    studentsJoined,
    activeStudents,
    publishedCourses: publishedIds.size,
    publishedLectures: unwrap(lectures).filter((lecture) => publishedIds.has(lecture.course_id))
      .length,
    publishedMaterials: unwrap(materials).filter(
      (material) =>
        material.is_published && (!material.course_id || publishedIds.has(material.course_id)),
    ).length,
    publishedTests: unwrap(tests).filter((test) => test.is_published).length,
  };
});
export const listSeriesOverrides = createServerFn({ method: "GET" }).handler(async () =>
  unwrap(await projectContent.from("test_series_overrides").select("*")),
);

export const getCustomSeriesCatalog = createServerFn({ method: "GET" }).handler(async () =>
  readCustomSeriesCatalog(),
);

/** Public catalogue metadata only; respect Admin's removed/disabled series in search. */
export const listPublicSearchSeries = createServerFn({ method: "GET" }).handler(async () => {
  const [custom, overrideRows] = await Promise.all([
    readCustomSeriesCatalog(),
    projectContent.from("test_series_overrides").select("*"),
  ]);
  // If the override table cannot be checked, don't accidentally advertise a
  // hidden series; other search groups still load independently in the UI.
  if (overrideRows.error) throw new Error("Series visibility could not be checked.");
  const overrides = new Map((overrideRows.data ?? []).map((row) => [row.series_id, row]));
  return getEffectivePaidTestSeries(custom)
    .filter((series) => overrides.get(series.id)?.enabled !== false)
    .map((series) => ({
      id: series.id,
      name: overrides.get(series.id)?.name || series.name,
      exam: series.examTrack,
      group: series.group,
      subjects: series.subjects,
    }));
});
