import { projectContent } from "./project-content.server";
import { supabaseAdmin } from "@/integrations/supabase/client.server";
import { notesSeriesSchema, seriesNoteIds, type NotesSeries } from "./notes-series";
import { readNotesCatalogSetting } from "./notes-catalog-storage.server";

type Probe = {
  label: string;
  data: readonly unknown[] | null;
  error: { message: string } | null;
};

/** Fail closed: missing tables, incomplete reads and existing references all keep the content. */
export function assertUnlinkedForDeletion(item: string, probes: readonly Probe[]) {
  for (const probe of probes) {
    if (probe.error || !probe.data)
      throw new Error(
        `Cannot verify ${probe.label} for this ${item}. Nothing deleted; check backend setup and retry.`,
      );
    if (probe.data.length)
      throw new Error(
        `This ${item} has ${probe.label}. Keep it for student access/history; review exact IDs on a restored backup before any cleanup.`,
      );
  }
}

export function assertUnpublishedForDeletion(
  item: string,
  row: { status?: string; is_published?: boolean } | null,
) {
  if (!row) throw new Error(`${item} not found. Nothing deleted.`);
  if (item === "course" ? row.status !== "draft" : row.is_published !== false)
    throw new Error(
      `Only unpublished ${item === "course" ? "course drafts" : `${item} drafts`} can be deleted here. Unpublish first; student access and saved results must be reviewed separately.`,
    );
}

async function checkedPublic(
  label: string,
  query: PromiseLike<{ data: readonly unknown[] | null; error: { message: string } | null }>,
): Promise<Probe> {
  const result = await query;
  return { label, data: result.data, error: result.error };
}

async function checkedContent(
  label: string,
  query: PromiseLike<{ data: readonly unknown[] | null; error: { message: string } | null }>,
): Promise<Probe> {
  const result = await query;
  return { label, data: result.data, error: result.error };
}

/** Application guard only. It does not replace an atomic database dependency audit. */
export async function requireDisposableCourse(id: string) {
  const course = await projectContent
    .from("courses")
    .select("id,status")
    .eq("id", id)
    .maybeSingle();
  if (course.error) throw new Error("Cannot verify course status. Nothing deleted.");
  assertUnpublishedForDeletion("course", course.data);
  const probes = await Promise.all([
    checkedContent(
      "lectures",
      projectContent.from("lectures").select("id").eq("course_id", id).limit(1),
    ),
    checkedContent(
      "notes",
      projectContent.from("materials").select("id").eq("course_id", id).limit(1),
    ),
    checkedContent("tests", projectContent.from("tests").select("id").eq("course_id", id).limit(1)),
    checkedPublic(
      "course enrollments",
      supabaseAdmin.from("course_enrollments").select("id").eq("course_id", id).limit(1),
    ),
    checkedPublic(
      "offline access grants",
      supabaseAdmin.from("offline_access_grants").select("id").eq("course_id", id).limit(1),
    ),
    checkedPublic(
      "payment history",
      supabaseAdmin.from("payment_transactions").select("id").eq("course_id", id).limit(1),
    ),
    checkedPublic(
      "coupon history",
      supabaseAdmin.from("coupon_redemptions").select("id").eq("course_id", id).limit(1),
    ),
    checkedPublic(
      "coin history",
      supabaseAdmin.from("coin_transactions").select("id").eq("related_id", id).limit(1),
    ),
  ]);
  assertUnlinkedForDeletion("course", probes);
}

export async function requireDisposableMaterial(id: string) {
  const material = await projectContent
    .from("materials")
    .select("id,is_published")
    .eq("id", id)
    .maybeSingle();
  if (material.error) throw new Error("Cannot verify note status. Nothing deleted.");
  assertUnpublishedForDeletion("note", material.data);
  assertUnlinkedForDeletion(
    "note",
    await Promise.all([
      checkedPublic(
        "material purchases",
        supabaseAdmin.from("material_purchases").select("id").eq("material_id", id).limit(1),
      ),
      checkedPublic(
        "manual note grants",
        supabaseAdmin.from("material_access_grants").select("id").eq("material_id", id).limit(1),
      ),
      checkedPublic(
        "coin history",
        supabaseAdmin.from("coin_transactions").select("id").eq("related_id", id).limit(1),
      ),
    ]),
  );
  // Notes-series outlines store references in site_settings, not material grants.
  // Refuse to orphan an outline, including a private/draft sample-notes series.
  const outlines = await projectContent
    .from("site_settings")
    .select("key,value")
    .ilike("key", "notes_series_v1:%")
    .limit(1000);
  if (outlines.error || !outlines.data || outlines.data.length >= 1000)
    throw new Error("Cannot verify all notes-series outlines. Nothing deleted.");
  try {
    const series = await Promise.all(
      outlines.data.map(async (row) => {
        const stored = await readNotesCatalogSetting<NotesSeries>({
          table: "site_settings",
          key: row.key,
          kind: "series",
          id: row.key.slice("notes_series_v1:".length),
          value: row.value,
        });
        return notesSeriesSchema.parse(stored.data);
      }),
    );
    if (series.some((item) => seriesNoteIds(item).includes(id)))
      throw new Error(
        "This note is linked to a notes-series outline. Remove its reference before deleting the draft.",
      );
  } catch (error) {
    if (error instanceof Error && error.message.includes("linked to a notes-series outline"))
      throw error;
    throw new Error("Cannot verify notes-series outlines. Nothing deleted.");
  }
}

export async function requireDisposableTest(id: string) {
  const paper = await projectContent
    .from("tests")
    .select("id,is_published")
    .eq("id", id)
    .maybeSingle();
  if (paper.error) throw new Error("Cannot verify test status. Nothing deleted.");
  assertUnpublishedForDeletion("test", paper.data);
  assertUnlinkedForDeletion(
    "test",
    await Promise.all([
      checkedPublic(
        "saved student attempts/results",
        supabaseAdmin.from("learning_attempts").select("id").eq("test_id", id).limit(1),
      ),
      checkedPublic(
        "test access grants",
        supabaseAdmin.from("test_access_grants").select("id").eq("test_id", id).limit(1),
      ),
      checkedPublic(
        "coin history",
        supabaseAdmin.from("coin_transactions").select("id").eq("related_id", id).limit(1),
      ),
    ]),
  );
}

/** Hide is reversible, but it can interrupt an enrolled learner's route. Refuse if linked. */
export async function requireUnlinkedSeries(ids: string[]) {
  if (!ids.length) return;
  assertUnlinkedForDeletion(
    "test series",
    await Promise.all([
      checkedPublic(
        "series access grants",
        supabaseAdmin.from("series_access_grants").select("id").in("series_id", ids).limit(1),
      ),
      checkedPublic(
        "saved student attempts/results",
        supabaseAdmin.from("learning_attempts").select("id").in("series_id", ids).limit(1),
      ),
    ]),
  );
}
