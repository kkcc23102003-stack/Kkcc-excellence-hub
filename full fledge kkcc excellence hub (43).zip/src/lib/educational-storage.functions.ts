import { createServerFn } from "@tanstack/react-start";
import { requireSupabaseAuth } from "@/integrations/supabase/auth-middleware";
import { assertAdmin } from "@/lib/learning.server";
import {
  ensureEducationalStorageBucket,
  getEducationalStorageStatus,
} from "./educational-storage.server";

export const getAdminEducationalStorageStatus = createServerFn({ method: "GET" })
  .middleware([requireSupabaseAuth])
  .handler(async ({ context }) => {
    await assertAdmin(context);
    return getEducationalStorageStatus();
  });

export const createAdminEducationalStorageBucket = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .handler(async ({ context }) => {
    await assertAdmin(context);
    return ensureEducationalStorageBucket();
  });
