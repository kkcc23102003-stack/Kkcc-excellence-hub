import { createHash } from "node:crypto";
import type { LearningAttemptRow } from "@/integrations/supabase/db";
import { testAnswersSchema } from "./test-answer-schema";

/** Immutable Storage copy of a submitted regular/series result.
 * The current RPC still writes DB answers/score for atomic timers and legacy
 * clients. Deleting or relocating those DB fields needs a separate approved
 * migration, not an implicit data-destructive deployment.
 */
export type LearningResultSnapshot = {
  version: 1;
  attempt_id: string;
  user_id: string;
  test_id: string | null;
  series_id: string | null;
  submitted_at: string;
  score: number;
  total_marks: number;
  correct_count: number;
  attempted_count: number;
  question_count: number;
  answers: Record<string, number>;
  question_ids: string[];
};
const UUID = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i;
const MAX_SNAPSHOT_BYTES = 2 * 1024 * 1024;
/** New attempts carry this marker inside the existing metadata ref; older rows never require a file. */
export const RESULT_REQUIRED_SUFFIX = ":result=v1:snapshot=v1";
export function requiresArchivedLearningResult(row: Pick<LearningAttemptRow, "source_refs">) {
  return (row.source_refs || []).some(
    (ref) => ref.startsWith("__kkcc_meta__:") && ref.endsWith(RESULT_REQUIRED_SUFFIX),
  );
}
export function learningResultPath(attemptId: string) {
  if (!UUID.test(attemptId)) throw new Error("Invalid attempt ID for private result snapshot.");
  return `${attemptId}/result.json`;
}
export function snapshotLearningResult(row: LearningAttemptRow): LearningResultSnapshot {
  learningResultPath(row.id);
  if (
    !UUID.test(row.user_id) ||
    row.status !== "submitted" ||
    !row.submitted_at ||
    !Number.isFinite(Date.parse(row.submitted_at)) ||
    typeof row.score !== "number" ||
    !Number.isFinite(row.score) ||
    ![row.total_marks, row.correct_count, row.attempted_count, row.question_count].every(
      (value) => typeof value === "number" && Number.isFinite(value) && value >= 0,
    )
  )
    throw new Error("Only a complete, owned submitted result can be archived.");
  const answers = testAnswersSchema.parse(row.answers);
  const snapshot: LearningResultSnapshot = {
    version: 1,
    attempt_id: row.id,
    user_id: row.user_id,
    test_id: row.test_id,
    series_id: row.series_id,
    submitted_at: new Date(row.submitted_at).toISOString(),
    score: row.score!,
    total_marks: row.total_marks!,
    correct_count: row.correct_count!,
    attempted_count: row.attempted_count!,
    question_count: row.question_count,
    answers: Object.fromEntries(Object.entries(answers).sort(([a], [b]) => a.localeCompare(b))),
    question_ids: row.source_refs.filter((ref) => !ref.startsWith("__kkcc_meta__:")),
  };
  const ids = new Set(snapshot.question_ids);
  if (
    snapshot.attempted_count !== Object.keys(answers).length ||
    snapshot.correct_count > snapshot.attempted_count ||
    snapshot.attempted_count > snapshot.question_count ||
    snapshot.question_ids.length !== snapshot.question_count ||
    ids.size !== snapshot.question_count ||
    Object.keys(answers).some((id) => !ids.has(id)) ||
    Buffer.byteLength(JSON.stringify(snapshot)) > MAX_SNAPSHOT_BYTES
  )
    throw new Error("Submitted result failed snapshot integrity checks.");
  return snapshot;
}
export function resultSnapshotBytes(row: LearningAttemptRow): Buffer {
  return Buffer.from(JSON.stringify(snapshotLearningResult(row)), "utf8");
}
export function assertResultSnapshot(
  bytes: Uint8Array,
  row: LearningAttemptRow,
): LearningResultSnapshot {
  if (bytes.byteLength > MAX_SNAPSHOT_BYTES) throw new Error("Saved result snapshot is too large.");
  const expected = resultSnapshotBytes(row);
  const digest = (value: Uint8Array) => createHash("sha256").update(value).digest("hex");
  if (digest(bytes) !== digest(expected))
    throw new Error("Private Storage result does not match this student's submitted attempt.");
  return JSON.parse(Buffer.from(bytes).toString("utf8")) as LearningResultSnapshot;
}
