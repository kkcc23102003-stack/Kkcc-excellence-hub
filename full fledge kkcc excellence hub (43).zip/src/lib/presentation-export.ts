import { DEFAULT_SLIDE_SIZE, DEFAULT_SLIDE_BRAND, type Deck, type Slide } from "./document-studio";
import { NOTES_PRINT_LOGO } from "./notes-print-logo";
import { PDFDocument } from "pdf-lib";
import { brandPdfDocument } from "./pdf-brand";
import { layoutSlideRuns } from "./presentation-rich";
import {
  browserSlideMeasure,
  fontFamily,
  wrapSlideText,
  type SlideSize,
  type SlideBrand,
} from "./presentation-design";

export async function exportPowerPoint(deck: Deck): Promise<Blob> {
  const { default: PptxGenJS } = await import("pptxgenjs");
  const pptx = new PptxGenJS(),
    size = deck.size ?? DEFAULT_SLIDE_SIZE,
    brand = deck.brand ?? DEFAULT_SLIDE_BRAND;
  const width = size.width / 96,
    height = size.height / 96;
  pptx.defineLayout({ name: "KKCC_CUSTOM", width, height });
  pptx.layout = "KKCC_CUSTOM";
  pptx.author = brand.appName;
  pptx.subject = "KKCC teaching presentation";
  pptx.title = deck.title;
  for (const [index, source] of deck.slides.entries()) {
    const slide = pptx.addSlide();
    slide.background = { color: source.background.slice(1) };
    if (!source.design || source.design === "legacy") {
      const logo = Math.min(width, height) * 0.075;
      slide.addImage({
        data: NOTES_PRINT_LOGO,
        x: width * 0.014,
        y: height * 0.017,
        w: logo,
        h: logo,
      });
      slide.addText(brand.appName, {
        x: width * 0.1,
        y: height * 0.025,
        w: width * 0.8,
        h: height * 0.06,
        fontSize: Math.min(size.width, size.height) * 0.019,
        align: "center",
        color: "146044",
        fontFace: "Arial",
        margin: 0,
      });
    }
    for (const item of source.elements) {
      const geometry = {
        x: (item.x / 100) * width,
        y: (item.y / 100) * height,
        w: (item.w / 100) * width,
        h: (item.h / 100) * height,
      };
      if (item.type === "text")
        slide.addText(
          item.runs?.length
            ? item.runs.map((run) => ({
                text: run.text,
                options: {
                  bold: !!run.bold,
                  italic: !!run.italic,
                  ...(run.underline
                    ? {
                        underline: {
                          style: "sng" as const,
                          color: (run.color ?? item.colour).slice(1),
                        },
                      }
                    : {}),
                  color: (run.color ?? item.colour).slice(1),
                },
              }))
            : item.text,
          {
            ...geometry,
            fontFace:
              item.font === "condensed"
                ? "Anton"
                : item.font === "display"
                  ? "Great Vibes"
                  : "Nirmala UI",
            italic: item.italic ?? false,
            ...(item.glow ? { glow: { color: item.colour.slice(1), opacity: 0.75, size: 5 } } : {}),
            fontSize: item.fontSize * 0.75,
            color: item.colour.slice(1),
            bold: item.bold,
            align: item.align,
            margin: 0,
            valign: "top",
            wrap: true,
            transparency: Math.round((1 - (item.opacity ?? 1)) * 100),
            lineSpacingMultiple: 1.3,
          },
        );
      else if (item.type === "image" && item.image) {
        const source = await image(item.image);
        const scale = Math.min(geometry.w / source.width, geometry.h / source.height);
        const w = source.width * scale,
          h = source.height * scale;
        slide.addImage({
          data: item.image,
          x: geometry.x + (geometry.w - w) / 2,
          y: geometry.y + (geometry.h - h) / 2,
          w,
          h,
          transparency: Math.round((1 - (item.opacity ?? 1)) * 100),
        });
      } else if (item.type === "rectangle" || item.type === "ellipse")
        slide.addShape(item.type === "ellipse" ? pptx.ShapeType.ellipse : pptx.ShapeType.rect, {
          ...geometry,
          fill: {
            color: item.fill.slice(1),
            transparency: Math.round((1 - (item.opacity ?? 1)) * 100),
          },
          line: { color: item.fill.slice(1), transparency: 100 },
        });
    }
    if (!source.hidePageNumber)
      slide.addText(String(index + 1), {
        x: width * 0.95,
        y: height * 0.96,
        w: width * 0.035,
        h: height * 0.025,
        fontSize: Math.min(size.width, size.height) * 0.012,
        color: "64748B",
        align: "right",
        margin: 0,
      });
    if (source.notes) slide.addNotes(source.notes);
  }
  return (await pptx.write({ outputType: "blob", compression: true })) as Blob;
}
async function image(data: string) {
  const value = new Image();
  value.src = data;
  await value.decode();
  return value;
}
/** One renderer for PDF/PNG/JPG; dimensions and text wrapping match the selected canvas. */
export async function slideCanvas(
  slide: Slide,
  index: number,
  size: SlideSize = DEFAULT_SLIDE_SIZE,
  brand: SlideBrand = DEFAULT_SLIDE_BRAND,
) {
  const canvas = document.createElement("canvas");
  canvas.width = size.width;
  canvas.height = size.height;
  const ctx = canvas.getContext("2d")!;
  ctx.fillStyle = slide.background;
  ctx.fillRect(0, 0, size.width, size.height);
  if (!slide.design || slide.design === "legacy") {
    const logo = Math.min(size.width, size.height) * 0.075;
    ctx.drawImage(
      await image(NOTES_PRINT_LOGO),
      size.width * 0.014,
      size.height * 0.017,
      logo,
      logo,
    );
    ctx.fillStyle = "#146044";
    ctx.textAlign = "center";
    ctx.font = `bold ${Math.min(size.width, size.height) * 0.026}px Arial`;
    ctx.fillText(brand.appName, size.width / 2, size.height * 0.055, size.width * 0.8);
  }
  for (const item of slide.elements) {
    const x = (item.x / 100) * size.width,
      y = (item.y / 100) * size.height,
      w = (item.w / 100) * size.width,
      h = (item.h / 100) * size.height;
    ctx.save();
    ctx.globalAlpha = item.opacity ?? 1;
    ctx.beginPath();
    ctx.rect(x, y, w, h);
    ctx.clip();
    if (item.type === "image" && item.image) {
      const source = await image(item.image),
        scale = Math.min(w / source.width, h / source.height),
        dw = source.width * scale,
        dh = source.height * scale;
      ctx.drawImage(source, x + (w - dw) / 2, y + (h - dh) / 2, dw, dh);
    } else if (item.type === "rectangle") {
      ctx.fillStyle = item.fill;
      ctx.fillRect(x, y, w, h);
    } else if (item.type === "ellipse") {
      ctx.fillStyle = item.fill;
      ctx.beginPath();
      ctx.ellipse(x + w / 2, y + h / 2, w / 2, h / 2, 0, 0, Math.PI * 2);
      ctx.fill();
    } else {
      const setFont = (bold: boolean, italic: boolean) => {
        ctx.font = `${italic ? "italic " : ""}${bold ? "bold " : ""}${item.fontSize}px ${fontFamily(item.font)}`;
      };
      setFont(item.bold, item.italic ?? false);
      ctx.fillStyle = item.colour;
      if (item.glow) {
        ctx.shadowColor = item.colour;
        ctx.shadowBlur = item.fontSize * 0.12;
      }
      ctx.textBaseline = "top";
      if (item.runs?.length) {
        const lines = layoutSlideRuns(item.runs, w * 0.98, (run) => {
          setFont(!!run.bold, !!run.italic);
          return ctx.measureText(run.text).width;
        });
        ctx.textAlign = "left";
        for (const [i, line] of lines.entries()) {
          let offset =
            item.align === "center"
              ? (w - line.width) / 2
              : item.align === "right"
                ? w - line.width
                : 0;
          for (const run of line.runs) {
            setFont(!!run.bold, !!run.italic);
            const width = ctx.measureText(run.text).width;
            ctx.fillStyle = run.color ?? item.colour;
            ctx.fillText(run.text, x + offset, y + i * item.fontSize * 1.3);
            if (run.underline) {
              ctx.fillRect(
                x + offset,
                y + i * item.fontSize * 1.3 + item.fontSize * 1.09,
                width,
                Math.max(1, item.fontSize * 0.045),
              );
            }
            offset += width;
          }
        }
      } else {
        setFont(item.bold, item.italic ?? false);
        ctx.textAlign = item.align;
        const lines = wrapSlideText(
          item.text,
          w * 0.98,
          item.fontSize,
          (text) => ctx.measureText(text).width,
          item.font,
          item.bold,
        );
        for (const [i, text] of lines.entries())
          ctx.fillText(
            text,
            item.align === "center" ? x + w / 2 : item.align === "right" ? x + w : x,
            y + i * item.fontSize * 1.3,
          );
      }
    }
    ctx.restore();
  }
  if (!slide.hidePageNumber) {
    ctx.textAlign = "right";
    ctx.fillStyle = "#64748b";
    ctx.font = `${Math.min(size.width, size.height) * 0.019}px Arial`;
    ctx.fillText(String(index + 1), size.width * 0.98, size.height * 0.985);
  }
  return canvas;
}
export async function slideThumbnail(
  slide: Slide,
  index: number,
  size: SlideSize,
  brand: SlideBrand,
  format: "png" | "jpeg",
) {
  await browserSlideMeasure();
  const canvas = await slideCanvas(slide, index, size, brand);
  try {
    return await new Promise<Blob>((resolve, reject) =>
      canvas.toBlob(
        (blob) => (blob ? resolve(blob) : reject(new Error("Thumbnail encoding failed."))),
        `image/${format}`,
        0.92,
      ),
    );
  } finally {
    canvas.width = 0;
    canvas.height = 0;
  }
}
export async function presentationPdf(
  deck: Deck,
  progress: (n: number) => void,
  cancelled: () => boolean,
) {
  const pdf = await PDFDocument.create(),
    size = deck.size ?? DEFAULT_SLIDE_SIZE;
  await browserSlideMeasure();
  for (const [i, slide] of deck.slides.entries()) {
    if (cancelled()) throw new Error("Export cancelled.");
    progress(i + 1);
    const canvas = await slideCanvas(slide, i, size, deck.brand ?? DEFAULT_SLIDE_BRAND);
    const image = await pdf.embedPng(canvas.toDataURL("image/png"));
    pdf
      .addPage([size.width * 0.75, size.height * 0.75])
      .drawImage(image, { x: 0, y: 0, width: size.width * 0.75, height: size.height * 0.75 });
    canvas.width = 0;
    canvas.height = 0;
    await new Promise((resolve) => setTimeout(resolve, 0));
  }
  await brandPdfDocument(pdf);
  return pdf.save();
}
