import { PDFDocument, StandardFonts, rgb } from "pdf-lib";
import { KKCC_CENTRE_WATERMARK_LOGO } from "./notes-print-watermark-logo";
import { KKCC_CENTRE_WATERMARK_BLACK_LOGO } from "./notes-print-watermark-black-logo";

export type PdfColourMode = "colour" | "black-white";
export type PdfBrandOptions = {
  mode?: PdfColourMode;
  /** Optional progress for browser B&W rasterization; never sent to a server. */
  onProgress?: (page: number, total: number) => void;
};
export const KKCC_PDF_BLACK_WHITE_MARKER = "kkcc-bw-copy-v1";

// v2 deliberately re-stamps older v1 copies that only had a text-only centre mark.
export const KKCC_PDF_BRAND_MARKER = "kkcc-branded-copy-v2";
export const MAX_KKCC_PDF_BYTES = 40 * 1024 * 1024;
const MAX_PAGES = 500;

/**
 * Add a translucent version of KKCC's own logo at the centre of EVERY page,
 * with "KKCC Excellence Hub" directly beneath it. Originals remain untouched.
 * The watermark is deliberately pale so lesson text remains readable; changing
 * a digitally signed PDF invalidates its signature, so keep signed originals.
 */
export async function brandPdfDocument(
  pdf: PDFDocument,
  options: PdfBrandOptions = {},
): Promise<PDFDocument> {
  const monochrome = options.mode === "black-white";
  const pages = pdf.getPages();
  if (!pages.length || pages.length > MAX_PAGES)
    throw new Error(`KKCC PDF copies support 1–${MAX_PAGES} pages. Split a longer file first.`);
  const existingKeywords = pdf.getKeywords() ?? "";
  if (existingKeywords.includes(KKCC_PDF_BRAND_MARKER)) return pdf;

  const logo = await pdf.embedPng(
    monochrome ? KKCC_CENTRE_WATERMARK_BLACK_LOGO : KKCC_CENTRE_WATERMARK_LOGO,
  );
  const font = await pdf.embedFont(StandardFonts.HelveticaBold);
  const signature = "KKCC Excellence Hub";
  for (const [index, page] of pages.entries()) {
    const { width, height } = page.getSize();
    const scale = Math.min(1, width / 595, height / 842);
    const inset = Math.max(7, 12 * scale);
    const logoSize = Math.max(16, 32 * scale);
    const fontSize = Math.max(6, 8 * scale);
    const textX = inset + logoSize + 6 * scale;
    const maximumTextWidth = Math.max(0, width - textX - inset);
    const labelWidth = font.widthOfTextAtSize(signature, fontSize);
    const labelSize = Math.min(fontSize, (fontSize * maximumTextWidth) / Math.max(1, labelWidth));
    // The transparent asset is derived from our real K/book logo, with its dark
    // square background removed. The central image stays faint behind questions.
    const centreSize = Math.min(225, width * 0.42, height * 0.32);
    const centreBottom = height * 0.56 - centreSize / 2;
    page.drawImage(logo, {
      x: (width - centreSize) / 2,
      y: centreBottom,
      width: centreSize,
      height: centreSize,
      opacity: 0.18,
    });
    const captionSize = Math.max(8, Math.min(18, width * 0.029));
    page.drawText(signature, {
      x: (width - font.widthOfTextAtSize(signature, captionSize)) / 2,
      y: centreBottom - captionSize * 1.4,
      font,
      size: captionSize,
      color: monochrome ? rgb(0, 0, 0) : rgb(0.03, 0.43, 0.45),
      opacity: 0.2,
    });

    // Smaller corner identity and page number, also transparent (no dark box).
    page.drawImage(logo, {
      x: inset,
      y: inset,
      width: logoSize,
      height: logoSize,
      opacity: 0.52,
    });
    if (labelSize >= 4)
      page.drawText(signature, {
        x: textX,
        y: inset + logoSize / 2 - labelSize / 3,
        font,
        size: labelSize,
        color: monochrome ? rgb(0, 0, 0) : rgb(0.06, 0.37, 0.35),
        opacity: 0.65,
      });

    const pageNumber = `KKCC  ${index + 1} / ${pages.length}`;
    page.drawText(pageNumber, {
      x: Math.max(inset, width - font.widthOfTextAtSize(pageNumber, fontSize) - inset),
      y: inset + logoSize / 2 - fontSize / 3,
      font,
      size: fontSize,
      color: monochrome ? rgb(0, 0, 0) : rgb(0.16, 0.39, 0.38),
      opacity: 0.6,
    });
  }
  const oldKeywords = existingKeywords
    .split(",")
    .map((word) => word.trim())
    .filter(Boolean);
  pdf.setKeywords([
    ...oldKeywords,
    KKCC_PDF_BRAND_MARKER,
    ...(monochrome ? [KKCC_PDF_BLACK_WHITE_MARKER] : []),
  ]);
  return pdf;
}

/** Colour preserves searchable/vector text. B&W must flatten each page so even
 * coloured text, diagrams, highlights and background images truly become gray.
 * The B&W path runs locally in the browser, with the 100-page raster safety limit. */
export async function brandPdfBytes(
  bytes: Uint8Array,
  options: PdfBrandOptions = {},
): Promise<Uint8Array> {
  if (!bytes.length || bytes.length > MAX_KKCC_PDF_BYTES)
    throw new Error("PDF must be under 40 MB for a KKCC branded copy. Original stays unchanged.");
  if (!new TextDecoder().decode(bytes.slice(0, 1024)).includes("%PDF-"))
    throw new Error("This file is not a PDF. Original stays unchanged.");
  let pdf: PDFDocument;
  try {
    pdf = await PDFDocument.load(bytes);
  } catch {
    throw new Error(
      "This PDF cannot be branded here (it may be password-protected or damaged). Keep the original; never remove a digital signature without permission.",
    );
  }
  if (options.mode === "black-white") {
    if (pdf.getKeywords()?.includes(KKCC_PDF_BLACK_WHITE_MARKER)) return bytes.slice();
    if (pdf.getPageCount() > 100)
      throw new Error(
        "Black & white PDF supports up to 100 pages at once. Extract a smaller range first.",
      );
    // A CSS grayscale preview cannot make the *downloaded* PDF monochrome.
    // Rasterize each source page to neutral pixels BEFORE stamping the black
    // KKCC logo/caption, and never overwrite the user's original file.
    const { rasterPdf } = await import("./pdf-browser");
    const flattened = await rasterPdf(bytes, {
      invert: false,
      grayscale: true,
      scale: 1.5,
      quality: 0.86,
      progress: options.onProgress ?? (() => {}),
      cancelled: () => false,
    });
    const monochrome = await PDFDocument.load(flattened);
    await brandPdfDocument(monochrome, { mode: "black-white" });
    return monochrome.save({ useObjectStreams: true });
  }
  if (pdf.getKeywords()?.includes(KKCC_PDF_BRAND_MARKER)) return bytes.slice();
  await brandPdfDocument(pdf);
  return pdf.save({ useObjectStreams: true });
}

/** Browser-only: fetch *accessible* PDFs without sending cookies to external hosts. */
export async function fetchPdfForBranding(url: string): Promise<Uint8Array> {
  const parsed = new URL(url, window.location.href);
  if (!["http:", "https:", "data:"].includes(parsed.protocol))
    throw new Error("Only an accessible PDF URL can be branded.");
  if (parsed.protocol === "data:" && !parsed.href.startsWith("data:application/pdf"))
    throw new Error("This is not an attached PDF.");
  let response: Response;
  try {
    response = await fetch(parsed.href, {
      credentials: parsed.origin === window.location.origin ? "same-origin" : "omit",
    });
  } catch {
    throw new Error(
      "External PDF could not be opened for branding (access or CORS restriction). Upload it to KKCC storage or use the original link; no unbranded copy was downloaded.",
    );
  }
  if (!response.ok) throw new Error("PDF access expired or failed. Refresh access and try again.");
  const statedSize = Number(response.headers.get("content-length"));
  if (statedSize > MAX_KKCC_PDF_BYTES)
    throw new Error("This PDF exceeds the 40 MB browser-branding limit. Original stays unchanged.");
  const reader = response.body?.getReader();
  if (!reader) {
    const bytes = new Uint8Array(await response.arrayBuffer());
    if (bytes.length > MAX_KKCC_PDF_BYTES) throw new Error("This PDF exceeds the 40 MB limit.");
    return bytes;
  }
  const chunks: Uint8Array[] = [];
  let size = 0;
  try {
    for (;;) {
      const { done, value } = await reader.read();
      if (done) break;
      size += value.length;
      if (size > MAX_KKCC_PDF_BYTES) {
        await reader.cancel();
        throw new Error("This PDF exceeds the 40 MB browser-branding limit.");
      }
      chunks.push(value);
    }
  } finally {
    reader.releaseLock();
  }
  const bytes = new Uint8Array(size);
  let position = 0;
  for (const chunk of chunks) {
    bytes.set(chunk, position);
    position += chunk.length;
  }
  return bytes;
}
