import { normaliseAuthorColour } from "./author-colours";
import {
  formatAuthorRuns,
  normaliseAuthorRuns,
  parseAuthorRuns,
  plainAuthorRuns,
  serializeAuthorRuns,
} from "./author-inline";

/** A visible UTF-16 text selection inside ONE source-backed preview line. */
export type NotePreviewSelection = {
  line: number;
  start: number;
  end: number;
  visibleText: string;
  /** Which visible strip the author tapped (optional for older callers). */
  strip?: "box" | "heading";
};
export type NotePreviewAction =
  | "highlight"
  | "remove-highlight"
  | "clear-line-highlights"
  | "text-colour"
  | "remove-text-colour"
  | "add-strip"
  | "remove-strip";
export type NotePreviewEdit = { ok: true; text: string } | { ok: false; error: string };

type Candidate = { prefix: string; body: string; suffix: string };
type BoxLine = {
  candidate: Candidate;
  boxes: { sourceStart: number; sourceEnd: number; visibleStart: number; visibleEnd: number }[];
  segments: { plainStart: number; visibleStart: number; visibleEnd: number }[];
};
const LIST_PREFIX = /^(?:[-*•‣▪–]|\d{1,2}[.)])\s+/;
const HEADING_PREFIX = /^#{1,4}\s+/;
const MAX_NOTE_LENGTH = 1_500_000;

/** Never apply a change to a guessed duplicate or to directive/table source. */
function lineIsEditable(lines: string[], selected: number): boolean {
  let fence = false;
  for (let i = 0; i <= selected; i++) {
    const text = lines[i]?.trim() ?? "";
    if (text.startsWith(":::")) {
      if (i === selected) return false;
      fence = text !== ":::";
    } else if (i === selected && fence) return false;
  }
  // Inline image fences are removed during rendering, so subsequent preview
  // line numbers no longer match source. Refuse rather than editing a wrong line.
  if (/:::image\b/i.test(lines.slice(0, selected).join("\n"))) return false;
  if (/:::visuals\b/i.test(lines.slice(0, selected).join("\n"))) return false;
  return true;
}

/** Different renderers hide a ##/bullet/[box] prefix; compare real visible text. */
function matchingCandidate(line: string, visibleText: string): Candidate | null {
  const leading = line.match(/^\s*/)?.[0] ?? "";
  const trailing = line.match(/\s*$/)?.[0] ?? "";
  const core = line.slice(leading.length, line.length - trailing.length);
  const queue: Candidate[] = [{ prefix: leading, body: core, suffix: trailing }];
  for (let i = 0; i < queue.length && i < 8; i++) {
    const current = queue[i]!;
    const runs = parseAuthorRuns(current.body);
    if (plainAuthorRuns(runs) === visibleText) return current;
    const marker = HEADING_PREFIX.exec(current.body) ?? LIST_PREFIX.exec(current.body);
    if (marker)
      queue.push({
        ...current,
        prefix: current.prefix + marker[0],
        body: current.body.slice(marker[0].length),
      });
    const boxed = /^\[box\]([\s\S]*)\[\/box\]$/.exec(current.body);
    if (boxed)
      queue.push({
        prefix: current.prefix + "[box]",
        body: boxed[1]!,
        suffix: "[/box]" + current.suffix,
      });
  }
  return null;
}

/**
 * The source toolbar can put [box] AFTER a bullet: `• [box]Fact[/box]`.
 * The preview still shows `• Fact`, while the usual candidate matcher sees
 * the invisible box tokens and refuses to edit it. Map each visible segment
 * to parsed plain text, without guessing which duplicate box was tapped.
 */
function matchingBoxLine(line: string, visibleText: string): BoxLine | null {
  const heading = HEADING_PREFIX.exec(line)?.[0] ?? "";
  const body = line.slice(heading.length);
  const sourceBoxes = [...body.matchAll(/\[box\]([^\n]*?)\[\/box\]/g)];
  if (
    !sourceBoxes.length ||
    sourceBoxes.length > 16 ||
    (body.match(/\[\/?box\]/g) ?? []).length !== sourceBoxes.length * 2 ||
    sourceBoxes.some((box) => /\[\/?box\]/.test(box[1] ?? ""))
  )
    return null;
  const runs = parseAuthorRuns(body);
  // Formatting that spans across a box's opening/closing marker cannot be
  // serialised safely by the inline-run editor. Refuse it, never split tags.
  if (
    runs.some(
      (run) =>
        /\[\/?box\]/.test(run.text) &&
        (run.bold || run.italic || run.underline || run.color || run.highlight),
    )
  )
    return null;
  const plain = plainAuthorRuns(runs);
  if ((plain.match(/\[\/?box\]/g) ?? []).length !== sourceBoxes.length * 2) return null;
  const boxes: BoxLine["boxes"] = [];
  const segments: BoxLine["segments"] = [];
  let visible = "";
  let cursor = 0;
  const append = (start: number, end: number) => {
    if (end < start) return;
    segments.push({
      plainStart: start,
      visibleStart: visible.length,
      visibleEnd: visible.length + end - start,
    });
    visible += plain.slice(start, end);
  };
  for (const box of sourceBoxes) {
    const open = plain.indexOf("[box]", cursor);
    if (
      open < cursor ||
      (plain.indexOf("[/box]", cursor) < open && plain.indexOf("[/box]", cursor) !== -1)
    )
      return null;
    const close = plain.indexOf("[/box]", open + "[box]".length);
    if (
      close < 0 ||
      (plain.indexOf("[box]", open + "[box]".length) !== -1 &&
        plain.indexOf("[box]", open + "[box]".length) < close)
    )
      return null;
    append(cursor, open);
    const visibleStart = visible.length;
    append(open + "[box]".length, close);
    boxes.push({
      sourceStart: heading.length + box.index!,
      sourceEnd: heading.length + box.index! + box[0].length,
      visibleStart,
      visibleEnd: visible.length,
    });
    cursor = close + "[/box]".length;
  }
  append(cursor, plain.length);
  if (visible !== visibleText) return null;
  return { candidate: { prefix: heading, body, suffix: "" }, boxes, segments };
}

/** Only offer quiz placement when a tapped line is proven to match source. */
export function practiceAnchorFromPreview(
  source: string,
  selection: NotePreviewSelection,
): { afterLine: number; afterText: string } | null {
  if (!Number.isSafeInteger(selection.line) || selection.line < 0) return null;
  const lines = source.replace(/\r\n?/g, "\n").split("\n");
  const raw = lines[selection.line];
  if (!raw || !lineIsEditable(lines, selection.line)) return null;
  const afterText = raw.trim();
  if (
    !afterText ||
    afterText.length > 600 ||
    (!matchingCandidate(raw, selection.visibleText) && !matchingBoxLine(raw, selection.visibleText))
  )
    return null;
  return { afterLine: selection.line, afterText };
}

/**
 * Edits only portable authored markup, never text in the student PDF and never
 * an arbitrary matching phrase elsewhere in the note. Returns an error if the
 * preview is stale or a complex format cannot be mapped to this exact line.
 */
export function editNoteFromPreview(
  source: string,
  selection: NotePreviewSelection,
  action: NotePreviewAction,
  colour?: string,
): NotePreviewEdit {
  if (!Number.isSafeInteger(selection.line) || selection.line < 0)
    return { ok: false, error: "Preview line select karein." };
  const lines = source.split("\n");
  const raw = lines[selection.line];
  if (raw === undefined || !raw.trim() || !lineIsEditable(lines, selection.line))
    return {
      ok: false,
      error: "Is source block ko preview se edit nahi kar sakte. Source editor use karein.",
    };
  const currentLine = raw.replace(/\r$/, "");
  const candidate = matchingCandidate(currentLine, selection.visibleText);
  const boxed = matchingBoxLine(currentLine, selection.visibleText);
  if (!candidate && !boxed)
    return {
      ok: false,
      error:
        "Preview badal gaya ya format complex hai. Dobara line select karein (ya source editor use karein).",
    };

  let edited: string;
  if (action === "add-strip" || action === "remove-strip") {
    const entire = raw.trim();
    const heading = HEADING_PREFIX.exec(entire);
    if (action === "add-strip") {
      if (heading || /\[box\]/.test(entire))
        return { ok: false, error: "Is line par strip pehle se hai." };
      edited = `${raw.match(/^\s*/)?.[0] ?? ""}## ${entire}`;
      edited += raw.match(/[ \t]*\r?$/)?.[0] ?? "";
    } else if (boxed && (selection.strip === "box" || !heading)) {
      const chosen =
        boxed.boxes.find(
          (box) => selection.start === box.visibleStart && selection.end === box.visibleEnd,
        ) ?? (boxed.boxes.length === 1 ? boxed.boxes[0] : null);
      if (!chosen) return { ok: false, error: "Hatane ke liye isi strip par tap karein." };
      // Remove ONLY this pair of formatting markers, not the words or a
      // duplicate callout elsewhere in this source line.
      edited =
        currentLine.slice(0, chosen.sourceStart) +
        currentLine.slice(chosen.sourceStart + "[box]".length, chosen.sourceEnd - "[/box]".length) +
        currentLine.slice(chosen.sourceEnd) +
        (raw.endsWith("\r") ? "\r" : "");
    } else if (heading) {
      edited = `${raw.match(/^\s*/)?.[0] ?? ""}${entire.slice(heading[0].length)}`;
      edited += raw.match(/[ \t]*\r?$/)?.[0] ?? "";
    } else return { ok: false, error: "Is line par strip nahi hai." };
  } else {
    const editTarget = candidate ?? boxed!.candidate;
    const { prefix, body, suffix } = editTarget;
    const runs = parseAuthorRuns(body);
    const length = plainAuthorRuns(runs).length;
    let { start, end } = selection;
    if (!candidate && boxed && action !== "clear-line-highlights") {
      const segment = boxed.segments.find(
        (part) =>
          part.visibleStart <= start &&
          end <= part.visibleEnd &&
          part.visibleStart < part.visibleEnd,
      );
      if (!segment)
        return { ok: false, error: "Box ke andar ya bahar ka ek hi hissa select karein." };
      start = segment.plainStart + start - segment.visibleStart;
      end = segment.plainStart + end - segment.visibleStart;
    }
    if (
      !Number.isSafeInteger(start) ||
      !Number.isSafeInteger(end) ||
      start < 0 ||
      end > length ||
      start > end
    )
      return {
        ok: false,
        error: "Chuna hua text is line se match nahi hua. Phir se select karein.",
      };
    if (action !== "clear-line-highlights" && start === end)
      return {
        ok: false,
        error:
          "Pehle isi line ka text select karein (highlight par tap karke poora highlight chunein).",
      };
    const ink =
      action === "highlight" || action === "text-colour"
        ? normaliseAuthorColour(colour ?? (action === "highlight" ? "#fff0a6" : ""))
        : null;
    if ((action === "highlight" || action === "text-colour") && !ink)
      return { ok: false, error: "Sirf safe HEX colour chun sakte hain." };
    const changed =
      action === "clear-line-highlights"
        ? normaliseAuthorRuns(runs.map(({ highlight: _highlight, ...run }) => run))
        : formatAuthorRuns(
            runs,
            start,
            end,
            action === "text-colour" || action === "remove-text-colour" ? "color" : "highlight",
            ink ?? undefined,
          );
    if (JSON.stringify(changed) === JSON.stringify(runs))
      return { ok: false, error: "Is selection par badalne ke liye highlight nahi mila." };
    edited = prefix + serializeAuthorRuns(changed) + suffix + (raw.endsWith("\r") ? "\r" : "");
  }
  lines[selection.line] = edited;
  const text = lines.join("\n");
  if (text.length > MAX_NOTE_LENGTH)
    return {
      ok: false,
      error: "Note ki 1,500,000 character limit paar ho gayi. Text chhota karein.",
    };
  return { ok: true, text };
}
