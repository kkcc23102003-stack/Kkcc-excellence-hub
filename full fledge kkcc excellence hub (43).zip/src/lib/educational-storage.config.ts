export const EDUCATIONAL_STORAGE_BUCKET = "course-content";
export const EDUCATIONAL_STORAGE_MAX_BYTES = 45 * 1024 * 1024;
