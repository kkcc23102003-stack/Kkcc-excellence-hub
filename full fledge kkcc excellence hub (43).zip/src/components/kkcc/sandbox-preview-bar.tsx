import { useEffect, useState } from "react";
import { Link, useNavigate } from "@tanstack/react-router";
import {
  ShieldCheck,
  GraduationCap,
  Globe,
  Sparkles,
  ChevronDown,
  ChevronUp,
  Loader2,
} from "lucide-react";
import { toast } from "sonner";
import { supabase } from "@/integrations/supabase/client";
import { useAuthUser } from "@/hooks/use-auth-user";
import { Badge } from "@/components/ui/badge";

const LIVE_VISUAL_PREVIEW =
  (import.meta as ImportMeta & { env?: Record<string, string | undefined> }).env?.[
    "VITE_KKCC_LIVE_PREVIEW"
  ] === "1";

export function SandboxPreviewBar() {
  const navigate = useNavigate();
  const { user } = useAuthUser();
  const [visible, setVisible] = useState(false);
  const [minimized, setMinimized] = useState(false);
  const [toolsOpen, setToolsOpen] = useState(false);
  const [lightReview, setLightReview] = useState(false);
  const [switching, setSwitching] = useState<string | null>(null);
  useEffect(() => {
    const metaEnv = (import.meta as ImportMeta & { env?: Record<string, string | undefined> }).env;
    const envEnabled =
      (metaEnv?.["VITE_KKCC_SANDBOX_PREVIEW"] ?? "") === "1" ||
      (metaEnv?.["VITE_SUPABASE_URL"] ?? "") === "/__fixture__/supabase";
    // Never reveal fixture sign-in shortcuts through a query param on a real deployment.
    if (LIVE_VISUAL_PREVIEW && envEnabled) setVisible(true);
  }, []);

  useEffect(() => {
    if (!visible || !LIVE_VISUAL_PREVIEW) return;
    const enabled = window.sessionStorage.getItem("kkcc:light-review") === "1";
    setLightReview(enabled);
    document.documentElement.classList.toggle("kkcc-visual-review", enabled);
    return () => document.documentElement.classList.remove("kkcc-visual-review");
  }, [visible]);

  if (!visible) return null;

  const toggleLightReview = () => {
    const enabled = !lightReview;
    setLightReview(enabled);
    window.sessionStorage.setItem("kkcc:light-review", enabled ? "1" : "0");
    if (enabled) {
      document.documentElement.classList.remove("dark");
      window.localStorage.setItem("kkcc-theme-v5", "light");
      window.dispatchEvent(new Event("kkcc:theme"));
    }
    document.documentElement.classList.toggle("kkcc-visual-review", enabled);
  };

  const currentRole =
    user?.email === "admin@fixture.invalid" ? "Admin" : user?.email ? "Student" : "Guest (Public)";

  const switchRole = async (role: "admin" | "student" | "guest", targetPath: string) => {
    setSwitching(role);
    try {
      if (role === "guest") {
        await supabase.auth.signOut();
        toast.success("Switched to Public / Guest View");
        await navigate({ to: targetPath });
        return;
      }
      const email = role === "admin" ? "admin@fixture.invalid" : "studenta@fixture.invalid";
      await supabase.auth.signOut();
      const { error } = await supabase.auth.signInWithPassword({
        email,
        password: "FixturePass123!",
      });
      if (error) throw error;
      toast.success(
        role === "admin"
          ? "Logged in as KKCC Super Admin! Opening Admin Panel..."
          : "Logged in as Demo Student (1,000 23KAAT Coins)!",
      );
      window.location.href = targetPath;
    } catch (err) {
      toast.error(err instanceof Error ? err.message : "Failed to switch preview role");
    } finally {
      setSwitching(null);
    }
  };

  if (!toolsOpen)
    return (
      <div className="border-b bg-surface" data-testid="preview-toolbar">
        <div className="mx-auto flex max-w-7xl flex-wrap items-center justify-between gap-2 px-4 py-2 text-[11px] sm:px-6">
          <span className="text-muted-foreground">
            Demo preview · {currentRole}
            {lightReview ? " · Light layout review" : ""}
          </span>
          <div className="flex items-center gap-4">
            <span
              className="font-medium text-muted-foreground"
              title="Draft source archive is not a verified release"
            >
              Release ZIP pending
            </span>
            <button
              type="button"
              onClick={() => setToolsOpen(true)}
              className="font-medium text-primary"
              aria-expanded={false}
            >
              Preview tools
            </button>
          </div>
        </div>
      </div>
    );

  return (
    <div className="relative z-40 border-b lg:sticky lg:top-0 lg:z-50 border-primary/30 bg-background/95 backdrop-blur-md">
      <div className="mx-auto max-w-7xl px-3 pt-2 text-right text-xs sm:px-6">
        <button
          type="button"
          onClick={() => setToolsOpen(false)}
          aria-expanded={true}
          className="font-medium text-primary"
        >
          Close preview tools
        </button>
      </div>
      <div className="mx-auto flex w-full max-w-7xl flex-wrap items-center justify-between gap-2 px-3 py-2 text-xs sm:px-6">
        <div className="flex flex-wrap items-center gap-2">
          <Badge className="rounded-full bg-primary text-primary-foreground">
            <Sparkles className="mr-1 h-3 w-3" /> KKCC Live Sandbox Preview
          </Badge>
          <span className="text-muted-foreground">
            Active View: <b className="text-foreground">{currentRole}</b>
          </span>
        </div>

        <div className="flex flex-wrap items-center gap-1.5">
          {LIVE_VISUAL_PREVIEW && (
            <button
              type="button"
              aria-pressed={lightReview}
              onClick={toggleLightReview}
              className="rounded-full border border-primary/30 bg-secondary px-2.5 py-1 font-semibold text-secondary-foreground hover:border-primary"
              title="Preview-only light layout sample. It does not change the published app."
            >
              {lightReview ? "Light review on · turn off" : "Review light layout"}
            </button>
          )}
          <span
            className="rounded-full border px-2.5 py-1 text-muted-foreground"
            title="Source archives are delivered separately after local verification; this preview is not a deployment."
          >
            Source ZIP not bundled in this site
          </span>

          <button
            type="button"
            disabled={switching !== null}
            onClick={() => void switchRole("student", "/dashboard")}
            className="inline-flex items-center gap-1 rounded-full border border-emerald-500/40 bg-emerald-500/10 px-2.5 py-1 font-semibold text-emerald-700 transition hover:bg-emerald-500/20 dark:text-emerald-300"
          >
            {switching === "student" ? (
              <Loader2 className="h-3.5 w-3.5 animate-spin" />
            ) : (
              <GraduationCap className="h-3.5 w-3.5" />
            )}
            1-Click Student View
          </button>

          <button
            type="button"
            disabled={switching !== null}
            onClick={() => void switchRole("admin", "/admin")}
            className="inline-flex items-center gap-1 rounded-full border border-primary/50 bg-primary/15 px-2.5 py-1 font-semibold text-primary transition hover:bg-primary/25"
          >
            {switching === "admin" ? (
              <Loader2 className="h-3.5 w-3.5 animate-spin" />
            ) : (
              <ShieldCheck className="h-3.5 w-3.5" />
            )}
            1-Click Admin Panel
          </button>

          <button
            type="button"
            disabled={switching !== null}
            onClick={() => void switchRole("guest", "/")}
            className="inline-flex items-center gap-1 rounded-full border px-2.5 py-1 font-medium text-muted-foreground transition hover:border-foreground/30 hover:text-foreground"
          >
            <Globe className="h-3.5 w-3.5" />
            Public View
          </button>

          <button
            type="button"
            onClick={() => setMinimized((m) => !m)}
            className="inline-flex items-center gap-0.5 rounded-full border px-2 py-1 text-[11px] text-muted-foreground hover:text-foreground"
            title="Toggle quick jump links"
          >
            {minimized ? (
              <>
                Links <ChevronDown className="h-3 w-3" />
              </>
            ) : (
              <>
                Hide <ChevronUp className="h-3 w-3" />
              </>
            )}
          </button>
        </div>
      </div>

      {!minimized && (
        <div className="border-t border-border/60 bg-muted/40 px-3 py-1.5 sm:px-6">
          <div className="mx-auto flex w-full max-w-7xl flex-wrap items-center gap-1.5 text-[11px]">
            <span className="font-semibold text-muted-foreground">Quick Jump:</span>
            <Link
              to="/"
              className="rounded-full border bg-background px-2.5 py-0.5 hover:border-primary hover:text-primary"
            >
              Home
            </Link>
            <Link
              to="/courses"
              className="rounded-full border bg-background px-2.5 py-0.5 hover:border-primary hover:text-primary"
            >
              Courses
            </Link>
            <Link
              to="/study-material"
              className="rounded-full border bg-background px-2.5 py-0.5 hover:border-primary hover:text-primary"
            >
              Study Material (Notes)
            </Link>
            <Link
              to="/test-series"
              className="rounded-full border bg-background px-2.5 py-0.5 hover:border-primary hover:text-primary"
            >
              Test series
            </Link>
            <Link
              to="/games"
              className="rounded-full border bg-background px-2.5 py-0.5 hover:border-primary hover:text-primary"
            >
              Kit 2 Coins Quiz
            </Link>
            <Link
              to="/coins"
              className="rounded-full border bg-background px-2.5 py-0.5 hover:border-primary hover:text-primary"
            >
              23KAAT Wallet
            </Link>
            <Link
              to="/dashboard"
              className="rounded-full border bg-background px-2.5 py-0.5 hover:border-primary hover:text-primary"
            >
              Student Dashboard
            </Link>
            <Link
              to="/admin"
              className="rounded-full border bg-background px-2.5 py-0.5 font-medium text-primary hover:border-primary"
            >
              Admin Home
            </Link>
            <Link
              to="/admin/exam-bank"
              className="rounded-full border bg-background px-2.5 py-0.5 font-medium text-primary hover:border-primary"
            >
              Test Series & Syllabus Admin
            </Link>
            <Link
              to="/admin/syllabus"
              className="rounded-full border bg-background px-2.5 py-0.5 font-medium text-primary hover:border-primary"
            >
              Syllabus Auto Builder
            </Link>
            <Link
              to="/admin/tests"
              className="rounded-full border bg-background px-2.5 py-0.5 font-medium text-primary hover:border-primary"
            >
              Test Builder
            </Link>
            <Link
              to="/admin/materials"
              className="rounded-full border bg-background px-2.5 py-0.5 font-medium text-primary hover:border-primary"
            >
              Materials Admin
            </Link>
            <Link
              to="/admin/security"
              className="rounded-full border bg-background px-2.5 py-0.5 font-medium text-primary hover:border-primary"
            >
              Security & Health
            </Link>
            <Link
              to="/downloads"
              className="rounded-full border border-emerald-500/50 bg-emerald-500/15 px-2.5 py-0.5 font-bold text-emerald-700 hover:border-emerald-500 dark:text-emerald-300"
            >
              Downloads & SQL Hub
            </Link>
          </div>
        </div>
      )}
    </div>
  );
}
