import {
  forwardRef,
  useEffect,
  useImperativeHandle,
  useLayoutEffect,
  useRef,
  useState,
} from "react";
import type { AuthorRun } from "@/lib/author-inline";
import { formatAuthorRuns, normaliseAuthorRuns, plainAuthorRuns } from "@/lib/author-inline";
import { authorContrast, normaliseAuthorColour } from "@/lib/author-colours";
import { AuthorKeyboardStrip } from "./author-keyboard-strip";

export type VisualInlineHandle = {
  insert: (text: string, backspace?: boolean) => void;
  focus: () => void;
};
type Props = {
  runs: AuthorRun[];
  onChange: (runs: AuthorRun[]) => void;
  label: string;
  toolbarLabel: string;
  placeholder?: string | undefined;
  className?: string | undefined;
  rows?: number | undefined;
  maxLength?: number | undefined;
  disabled?: boolean | undefined;
  readOnly?: boolean | undefined;
  allowHighlight?: boolean | undefined;
  compactColours?: boolean | undefined;
  dockWhileEditing?: boolean | undefined;
  defaultBold?: boolean | undefined;
  defaultColor?: string | undefined;
  lang?: string | undefined;
  describedBy?: string | undefined;
};

type OffsetRange = { start: number; end: number };
function fromDom(root: Node, defaultBold = false): AuthorRun[] {
  const found: AuthorRun[] = [];
  const put = (text: string, style: Omit<AuthorRun, "text">) => {
    if (text) found.push({ text: text.replace(/\r\n?/g, "\n"), ...style });
  };
  const visit = (node: Node, style: Omit<AuthorRun, "text">) => {
    if (node.nodeType === Node.TEXT_NODE) {
      put(node.textContent ?? "", style);
      return;
    }
    if (node.nodeType !== Node.ELEMENT_NODE && node.nodeType !== Node.DOCUMENT_FRAGMENT_NODE)
      return;
    const el = node.nodeType === Node.ELEMENT_NODE ? (node as HTMLElement) : null;
    const tag = el?.tagName.toLowerCase();
    if (tag === "br") {
      put("\n", style);
      return;
    }
    // Every sibling block starts a new line, including empty <div><br></div> lines.
    // Checking the preceding *text* loses consecutive blank lines on Android/Chromium.
    if ((tag === "div" || tag === "p") && node !== root && node.previousSibling) put("\n", style);
    const next = el
      ? {
          ...style,
          ...((el.dataset["kkccBold"] === "true" || tag === "strong" || tag === "b") && {
            bold: true,
          }),
          ...(el.dataset["kkccBold"] === "false" && { bold: false }),
          ...((el.dataset["kkccItalic"] === "true" || tag === "em" || tag === "i") && {
            italic: true,
          }),
          ...((el.dataset["kkccUnderline"] === "true" || tag === "u") && { underline: true }),
          ...(normaliseAuthorColour(el.dataset["kkccColor"] ?? "") && {
            color: normaliseAuthorColour(el.dataset["kkccColor"] ?? "")!,
          }),
          ...(normaliseAuthorColour(el.dataset["kkccHighlight"] ?? "") && {
            highlight: normaliseAuthorColour(el.dataset["kkccHighlight"] ?? "")!,
          }),
        }
      : style;
    // An empty trailing <div><br></div> is the browser's caret line, not two line breaks.
    if (
      (tag === "div" || tag === "p") &&
      el?.childNodes.length === 1 &&
      el.firstChild?.nodeName === "BR"
    )
      return;
    for (const child of node.childNodes) visit(child, next);
  };
  visit(root, defaultBold ? { bold: true } : {});
  return normaliseAuthorRuns(found);
}

function needsDomNormalisation(root: HTMLElement) {
  const attributes = new Set([
    "style",
    "data-kkcc-bold",
    "data-kkcc-italic",
    "data-kkcc-underline",
    "data-kkcc-color",
    "data-kkcc-highlight",
  ]);
  const styles = new Set([
    "font-weight",
    "font-style",
    "text-decoration",
    "color",
    "background-color",
  ]);
  return Array.from(root.querySelectorAll("*")).some((el) => {
    if (el.tagName !== "SPAN") return true;
    if (Array.from(el.attributes).some((attr) => !attributes.has(attr.name))) return true;
    return Array.from((el as HTMLElement).style).some((style) => !styles.has(style));
  });
}

function renderRuns(root: HTMLElement, input: readonly AuthorRun[], defaultBold = false) {
  const fragment = document.createDocumentFragment();
  for (const run of normaliseAuthorRuns(input)) {
    const span = document.createElement("span");
    span.textContent = run.text;
    if (run.bold || defaultBold) {
      span.dataset["kkccBold"] = run.bold ? "true" : "false";
      span.style.fontWeight = run.bold ? "700" : "400";
    }
    if (run.italic) {
      span.dataset["kkccItalic"] = "true";
      span.style.fontStyle = "italic";
    }
    if (run.underline) {
      span.dataset["kkccUnderline"] = "true";
      span.style.textDecoration = "underline";
    }
    if (run.color && normaliseAuthorColour(run.color)) {
      span.dataset["kkccColor"] = run.color;
      span.style.color = run.color;
    }
    if (run.highlight && normaliseAuthorColour(run.highlight)) {
      span.dataset["kkccHighlight"] = run.highlight;
      span.style.backgroundColor = run.highlight;
      if (!run.color)
        span.style.color =
          authorContrast("#172b36", run.highlight) >= authorContrast("#ffffff", run.highlight)
            ? "#172b36"
            : "#ffffff";
    }
    fragment.append(span);
  }
  root.replaceChildren(fragment);
}
function offsetBefore(root: HTMLElement, node: Node, offset: number) {
  const range = document.createRange();
  range.selectNodeContents(root);
  range.setEnd(node, offset);
  return plainAuthorRuns(fromDom(range.cloneContents())).length;
}
function rangeForOffsets(root: HTMLElement, start: number, end: number) {
  const locate = (offset: number) => {
    const walker = document.createTreeWalker(root, NodeFilter.SHOW_TEXT);
    let last: Text | null = null;
    let remaining = offset;
    while (walker.nextNode()) {
      const node = walker.currentNode as Text;
      last = node;
      if (remaining <= node.length) return { node, offset: remaining };
      remaining -= node.length;
    }
    return last ? { node: last, offset: last.length } : { node: root, offset: 0 };
  };
  const from = locate(start),
    to = locate(end),
    range = document.createRange();
  range.setStart(from.node, from.offset);
  range.setEnd(to.node, to.offset);
  return range;
}

/** Native contenteditable/IME: only validated text and styles are stored, never pasted HTML. */
export const VisualInlineEditor = forwardRef<VisualInlineHandle, Props>(function VisualInlineEditor(
  {
    runs,
    onChange,
    label,
    toolbarLabel,
    placeholder,
    className = "",
    rows = 2,
    maxLength,
    disabled,
    readOnly,
    allowHighlight = true,
    compactColours = false,
    dockWhileEditing = false,
    defaultBold = false,
    defaultColor,
    lang,
    describedBy,
  },
  ref,
) {
  const editor = useRef<HTMLDivElement>(null);
  const emitted = useRef("");
  const composing = useRef(false);
  const selected = useRef<OffsetRange>({ start: 0, end: 0 });
  const [focused, setFocused] = useState(false);
  const [message, setMessage] = useState("");
  const [selectionCount, setSelectionCount] = useState(0);
  const signature = JSON.stringify(normaliseAuthorRuns(runs));
  useLayoutEffect(() => {
    const root = editor.current;
    if (!root || composing.current || signature === emitted.current) return;

    // A controlled update can arrive with a semantically equivalent but differently
    // serialised set of runs (notably after Android/IME contentEditable input). Replacing
    // the DOM without restoring the logical selection sends the caret to the first line.
    const selection = window.getSelection();
    const restoreFocus =
      document.activeElement === root ||
      Boolean(
        selection?.rangeCount &&
        root.contains(selection.anchorNode) &&
        root.contains(selection.focusNode),
      );
    const length = plainAuthorRuns(runs).length;
    const start = Math.max(0, Math.min(length, selected.current.start));
    const end = Math.max(start, Math.min(length, selected.current.end));

    renderRuns(root, runs, defaultBold);
    emitted.current = signature;
    selected.current = { start, end };
    if (restoreFocus) focusAt(start, end);
    else setSelectionCount(end - start);
  }, [signature, runs, defaultBold]);

  useEffect(() => {
    // Android long-press selection handles can move after pointerup. Track the real range.
    const track = () => {
      const root = editor.current,
        selection = window.getSelection();
      if (!root || !selection?.rangeCount) return;
      const range = selection.getRangeAt(0);
      if (root.contains(range.startContainer) && root.contains(range.endContainer)) {
        const start = offsetBefore(root, range.startContainer, range.startOffset);
        const end = offsetBefore(root, range.endContainer, range.endOffset);
        selected.current = { start, end };
        setSelectionCount((count) => (count === end - start ? count : end - start));
      }
    };
    document.addEventListener("selectionchange", track);
    return () => document.removeEventListener("selectionchange", track);
  }, []);
  const remember = () => {
    const root = editor.current,
      selection = window.getSelection();
    if (!root || !selection?.rangeCount) return null;
    const range = selection.getRangeAt(0);
    if (!root.contains(range.startContainer) || !root.contains(range.endContainer)) return null;
    const next = {
      start: offsetBefore(root, range.startContainer, range.startOffset),
      end: offsetBefore(root, range.endContainer, range.endOffset),
    };
    selected.current = next;
    setSelectionCount((count) => (count === next.end - next.start ? count : next.end - next.start));
    return next;
  };
  const focusAt = (start: number, end: number) => {
    const root = editor.current;
    if (!root) return;
    root.focus({ preventScroll: true });
    const selection = window.getSelection(),
      range = rangeForOffsets(root, start, end);
    selection?.removeAllRanges();
    selection?.addRange(range);
    selected.current = { start, end };
    setSelectionCount((count) => (count === end - start ? count : end - start));
  };
  const sync = () => {
    const root = editor.current;
    if (!root || composing.current) return;
    const next = fromDom(root, defaultBold);
    const position = remember() ?? selected.current;
    if (maxLength !== undefined && plainAuthorRuns(next).length > maxLength) {
      setMessage(`Maximum ${maxLength.toLocaleString()} characters. Remove some text first.`);
      renderRuns(root, JSON.parse(emitted.current || "[]") as AuthorRun[], defaultBold);
      const previousLength = plainAuthorRuns(
        JSON.parse(emitted.current || "[]") as AuthorRun[],
      ).length;
      focusAt(Math.min(position.start, previousLength), Math.min(position.end, previousLength));
      return;
    }
    // Paste and native IMEs can produce block lines or styled HTML. Preserve the text,
    // then replace that DOM with our known-safe spans without changing the caret.
    if (needsDomNormalisation(root)) {
      renderRuns(root, next, defaultBold);
      focusAt(position.start, position.end);
    }
    setMessage("");
    const nextSignature = JSON.stringify(next);
    if (emitted.current === nextSignature) return;
    emitted.current = nextSignature;
    onChange(next);
  };
  const styleSelection = (
    key: "bold" | "italic" | "underline" | "color" | "highlight",
    value?: boolean | string,
  ) => {
    if (disabled || readOnly || composing.current || !editor.current) return;
    const range = remember() ?? selected.current;
    if (range.start >= range.end) {
      setMessage("Select some existing text first, then tap a formatting button.");
      return;
    }
    const updated = formatAuthorRuns(
      fromDom(editor.current, defaultBold),
      range.start,
      range.end,
      key,
      value,
    );
    emitted.current = JSON.stringify(updated);
    renderRuns(editor.current, updated, defaultBold);
    onChange(updated);
    setMessage("");
    focusAt(range.start, range.end);
  };
  const insert = (text: string, backspace = false) => {
    if (disabled || readOnly || composing.current || !editor.current) return;
    const root = editor.current,
      stored = remember() ?? selected.current;
    const length = plainAuthorRuns(fromDom(root, defaultBold)).length;
    let start = Math.max(0, Math.min(length, stored.start));
    const end = Math.max(start, Math.min(length, stored.end));
    if (backspace && start === end && start > 0) {
      const previous = Array.from(plainAuthorRuns(fromDom(root, defaultBold)).slice(0, start)).at(
        -1,
      )!;
      start -= previous.length;
    }
    if (maxLength !== undefined && length - (end - start) + text.length > maxLength) {
      setMessage(`Maximum ${maxLength.toLocaleString()} characters. Remove some text first.`);
      return;
    }
    focusAt(start, end);
    const range = rangeForOffsets(root, start, end),
      selection = window.getSelection();
    range.deleteContents();
    if (text) {
      const node = document.createTextNode(text);
      range.insertNode(node);
      range.setStartAfter(node);
    }
    range.collapse(true);
    selection?.removeAllRanges();
    selection?.addRange(range);
    sync();
    selected.current = { start: start + text.length, end: start + text.length };
  };
  useImperativeHandle(ref, () => ({ insert, focus: () => editor.current?.focus() }));
  return (
    <div className="min-w-0 space-y-1" data-testid="visual-inline-editor">
      <AuthorKeyboardStrip
        label={toolbarLabel}
        active={focused}
        disabled={disabled || readOnly}
        allowHighlight={allowHighlight}
        compactColours={compactColours}
        dockWhileEditing={dockWhileEditing}
        selectionCount={selectionCount}
        bold={() => styleSelection("bold", true)}
        italic={() => styleSelection("italic", true)}
        underline={() => styleSelection("underline", true)}
        apply={(kind, colour) => styleSelection(kind, colour)}
        clear={(kind) => styleSelection(kind)}
      />
      <div
        ref={editor}
        role="textbox"
        aria-label={label}
        aria-multiline="true"
        aria-placeholder={placeholder}
        aria-describedby={describedBy}
        aria-disabled={disabled || undefined}
        aria-readonly={readOnly || undefined}
        contentEditable={!disabled && !readOnly}
        suppressContentEditableWarning
        spellCheck
        lang={lang}
        dir="auto"
        data-placeholder={placeholder}
        className={`kkcc-visual-inline-editor min-w-0 w-full rounded-md border border-input bg-background px-3 py-2 text-base leading-relaxed text-foreground shadow-xs outline-none focus-visible:border-ring focus-visible:ring-[3px] focus-visible:ring-ring/50 whitespace-pre-wrap break-words ${className}`}
        style={{
          minHeight: `${Math.max(1, Math.min(rows, 12)) * 1.7 + 1.2}rem`,
          ...(defaultColor ? { color: defaultColor } : {}),
          ...(defaultBold ? { fontWeight: 700 } : {}),
          fontFamily:
            '"Noto Sans", "Noto Sans Devanagari", "Noto Sans Gurmukhi", "Nirmala UI", Mangal, Raavi, system-ui, sans-serif',
        }}
        onFocus={() => setFocused(true)}
        onBlur={() => {
          remember();
          setFocused(false);
        }}
        onKeyUp={remember}
        onPointerUp={remember}
        onSelect={remember}
        onBeforeInput={(event) => {
          if (composing.current || (event.nativeEvent as InputEvent).isComposing) return;
          const native = event.nativeEvent as InputEvent;
          if (native.inputType === "insertParagraph" || native.inputType === "insertLineBreak") {
            event.preventDefault();
            insert("\n");
          }
        }}
        onInput={sync}
        onCompositionStart={() => {
          composing.current = true;
        }}
        onCompositionEnd={() => {
          composing.current = false;
          sync();
        }}
        onKeyDown={(event) => {
          if (composing.current || event.nativeEvent.isComposing) return;
          if ((event.ctrlKey || event.metaKey) && !event.altKey) {
            const key = event.key.toLowerCase();
            if (["b", "i", "u"].includes(key)) {
              event.preventDefault();
              styleSelection(key === "b" ? "bold" : key === "i" ? "italic" : "underline", true);
            }
          }
        }}
        onPaste={(event) => {
          event.preventDefault();
          insert(event.clipboardData.getData("text/plain"));
        }}
        onDrop={(event) => {
          event.preventDefault(); // Never insert external HTML, images or files into saved text.
        }}
      />
      {message && (
        <p role="status" className="text-xs text-destructive">
          {message}
        </p>
      )}
    </div>
  );
});
