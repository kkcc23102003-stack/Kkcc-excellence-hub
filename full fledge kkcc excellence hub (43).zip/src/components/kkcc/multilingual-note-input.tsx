import { formatNoteSelection } from "@/lib/notes-office";
import { NotesOfficeToolbar } from "./notes-office-toolbar";
import { AuthorKeyboardStrip } from "./author-keyboard-strip";
import { clearAuthorColour, wrapAuthorSelection } from "@/lib/author-colours";
import { useEffect, useId, useLayoutEffect, useRef, useState } from "react";
import {
  needsNoteSource,
  parseAuthorRuns,
  serializeAuthorRuns,
  splitEditableNoteBody,
} from "@/lib/author-inline";
import { VisualInlineEditor, type VisualInlineHandle } from "./visual-inline-editor";
import type { ComponentProps } from "react";
import { Textarea } from "@/components/ui/textarea";
import { Button } from "@/components/ui/button";
import { NOTE_LANGUAGES, editNoteSelection, type NoteLanguage } from "@/lib/note-language-input";

type Props = Omit<ComponentProps<"textarea">, "value" | "onChange" | "ref"> & {
  formattingTools?: boolean;
  value: string;
  onValueChange: (value: string) => void;
};
export function MultilingualNoteInput({
  value,
  formattingTools = false,
  onValueChange,
  maxLength = 1500000,
  disabled,
  readOnly,
  ...props
}: Props) {
  const id = useId(),
    input = useRef<HTMLTextAreaElement>(null),
    visualInput = useRef<VisualInlineHandle>(null);
  const managed = formattingTools ? splitEditableNoteBody(value) : null;
  const body = managed?.text ?? value;
  const [source, setSource] = useState(() => formattingTools && needsNoteSource(body));
  const visual = formattingTools && !source;
  useEffect(() => {
    if (formattingTools && needsNoteSource(body)) setSource(true);
  }, [formattingTools, body]);
  const range = useRef({ start: 0, end: 0 }),
    pendingCaret = useRef<number | null>(null);
  const [language, setLanguage] = useState<NoteLanguage>("en");
  const [open, setOpen] = useState(false),
    [composing, setComposing] = useState(false);
  const [message, setMessage] = useState("");
  const [focused, setFocused] = useState(false);
  const [selectionCount, setSelectionCount] = useState(0);
  const layout = NOTE_LANGUAGES.find((item) => item.id === language)!;
  const remember = () => {
    if (input.current) {
      const { selectionStart: start, selectionEnd: end } = input.current;
      range.current = { start, end };
      setSelectionCount((count) => (count === end - start ? count : end - start));
    }
  };
  useLayoutEffect(() => {
    if (pendingCaret.current === null || !input.current) return;
    input.current.focus({ preventScroll: true });
    input.current.setSelectionRange(pendingCaret.current, pendingCaret.current);
    range.current = { start: pendingCaret.current, end: pendingCaret.current };
    setSelectionCount(0);
    pendingCaret.current = null;
  }, [value]);
  const insert = (text: string, backspace = false) => {
    if (disabled || readOnly || composing) return;
    if (visual) {
      visualInput.current?.insert(text, backspace);
      return;
    }
    const next = editNoteSelection(
      value,
      range.current.start,
      range.current.end,
      text,
      maxLength,
      backspace,
    );
    if (!next) {
      setMessage(`Maximum ${maxLength.toLocaleString()} characters. Remove some text first.`);
      return;
    }
    setMessage("");
    if (next.text === value) {
      input.current?.focus({ preventScroll: true });
      return;
    }
    pendingCaret.current = next.caret;
    onValueChange(next.text);
  };
  const colourSelectedSource = (kind: "color" | "highlight", colour?: string) => {
    const { start, end } = range.current;
    if (start === end) {
      setMessage("Pehle shabd select karein, phir text colour ya highlight tap karein.");
      return;
    }
    if (end > body.length) {
      setMessage("Note metadata ko colour nahi kar sakte. Sirf likhe hue text ko select karein.");
      return;
    }
    const selected = value.slice(start, end);
    insert(
      colour ? wrapAuthorSelection(selected, kind, colour) : clearAuthorColour(selected, kind),
    );
  };
  return (
    <div className="min-w-0 space-y-2" data-testid="multilingual-note-input">
      {formattingTools && source && (
        <NotesOfficeToolbar
          value={value}
          disabled={disabled || readOnly || composing}
          selection={() => range.current}
          replace={(text) => insert(text)}
          change={(text) => {
            if (text.length > Number(maxLength)) {
              setMessage("This change exceeds the note character limit.");
              return;
            }
            onValueChange(text);
          }}
        />
      )}
      {formattingTools && source && (
        <AuthorKeyboardStrip
          label="Notes formatting above the keyboard"
          active={focused}
          disabled={disabled || readOnly || composing}
          compactColours
          dockWhileEditing
          selectionCount={selectionCount}
          bold={() =>
            insert(formatNoteSelection(value.slice(range.current.start, range.current.end), "b"))
          }
          italic={() =>
            insert(formatNoteSelection(value.slice(range.current.start, range.current.end), "i"))
          }
          underline={() =>
            insert(formatNoteSelection(value.slice(range.current.start, range.current.end), "u"))
          }
          apply={(kind, colour) => colourSelectedSource(kind, colour)}
          clear={(kind) => colourSelectedSource(kind)}
        />
      )}
      {visual ? (
        <VisualInlineEditor
          ref={visualInput}
          runs={parseAuthorRuns(body)}
          onChange={(runs) => {
            const next = serializeAuthorRuns(runs) + (managed?.suffix ?? "");
            setMessage(
              next.length > Number(maxLength)
                ? `This note exceeds ${Number(maxLength).toLocaleString()} stored characters. Shorten the text or formatting before saving.`
                : "",
            );
            // Keep the visible text even when too long; rejecting here would leave
            // the editor showing unsaved text that is missing from the draft backup.
            onValueChange(next);
          }}
          label={props["aria-label"] ?? "Study notes content"}
          toolbarLabel="Notes formatting above the keyboard"
          compactColours
          dockWhileEditing
          placeholder={props.placeholder}
          className={props.className}
          rows={props.rows}
          maxLength={Math.max(0, Number(maxLength) - (managed?.suffix.length ?? 0))}
          disabled={disabled}
          readOnly={readOnly}
          lang={language === "other" ? undefined : language}
          describedBy={`${id}-help`}
        />
      ) : (
        <Textarea
          {...props}
          ref={input}
          value={value}
          maxLength={maxLength}
          disabled={disabled}
          readOnly={readOnly}
          lang={language === "other" ? undefined : language}
          dir="auto"
          aria-describedby={`${id}-help`}
          style={{
            ...props.style,
            fontFamily:
              '"Noto Sans", "Noto Sans Devanagari", "Noto Sans Gurmukhi", "Nirmala UI", Mangal, Raavi, system-ui, sans-serif',
          }}
          onChange={(e) => {
            onValueChange(e.target.value);
            setMessage("");
          }}
          onSelect={(e) => {
            remember();
            props.onSelect?.(e);
          }}
          onClick={(e) => {
            remember();
            props.onClick?.(e);
          }}
          onKeyUp={(e) => {
            remember();
            props.onKeyUp?.(e);
          }}
          onFocus={(e) => {
            setFocused(true);
            props.onFocus?.(e);
          }}
          onBlur={(e) => {
            remember();
            setFocused(false);
            props.onBlur?.(e);
          }}
          onKeyDown={(e) => {
            props.onKeyDown?.(e);
            if (!formattingTools || composing || e.nativeEvent.isComposing || disabled || readOnly)
              return;
            if (
              (e.ctrlKey || e.metaKey) &&
              !e.altKey &&
              ["b", "i", "u"].includes(e.key.toLowerCase())
            ) {
              e.preventDefault();
              remember();
              const tag = e.key.toLowerCase();
              insert(formatNoteSelection(value.slice(range.current.start, range.current.end), tag));
            }
          }}
          onCompositionStart={(e) => {
            setComposing(true);
            props.onCompositionStart?.(e);
          }}
          onCompositionEnd={(e) => {
            setComposing(false);
            remember();
            props.onCompositionEnd?.(e);
          }}
        />
      )}
      <details className="rounded-lg border bg-card/60 px-3 py-2 text-sm">
        <summary className="min-h-10 cursor-pointer py-2 font-medium text-foreground">
          Language keyboard &amp; advanced text tools (optional)
        </summary>
        <div className="mt-2 space-y-2">
          <div className="flex flex-wrap items-end gap-2">
            <label htmlFor={`${id}-language`} className="min-w-0 flex-1 text-sm font-medium">
              Typing language
              <select
                id={`${id}-language`}
                className="mt-1 block w-full min-w-0 rounded-md border bg-background p-2 text-sm"
                value={language}
                disabled={disabled || composing}
                onChange={(e) => {
                  const chosen = e.target.value as NoteLanguage;
                  setLanguage(chosen);
                  setOpen(chosen !== "other");
                  setMessage("");
                }}
              >
                {NOTE_LANGUAGES.map((item) => (
                  <option key={item.id} value={item.id}>
                    {item.label}
                  </option>
                ))}
              </select>
            </label>
            {language !== "other" && (
              <Button
                type="button"
                variant="outline"
                disabled={disabled}
                aria-expanded={open}
                aria-controls={`${id}-keyboard`}
                onClick={() => setOpen(!open)}
              >
                {open ? "Hide keyboard" : "Show keyboard"}
              </Button>
            )}
          </div>
          <p id={`${id}-help`} className="text-xs text-muted-foreground">
            Type/paste in any language, or tap the letters below. For Roman-to-Hindi/Punjabi typing,
            enable your device’s transliteration keyboard (e.g. Gboard). This selector does not
            switch your physical keyboard or translate notes. Add consonants first, then vowel
            signs/matras.
          </p>
          {formattingTools && (
            <div className="flex flex-wrap items-center gap-2 text-xs text-muted-foreground">
              <button
                type="button"
                className="min-h-9 text-primary underline underline-offset-2"
                onClick={() => setSource(!source)}
              >
                {source ? "Visual text formatting" : "Advanced note source · tables / formulas"}
              </button>
              {source
                ? "Source mode retains tables, diagrams and original markup."
                : "Select existing text for B / I / U or colour; no raw tags while typing."}
            </div>
          )}
          {open && language !== "other" && (
            <div
              id={`${id}-keyboard`}
              role="group"
              aria-label={`${layout.label} on-screen keyboard`}
              className="space-y-1 rounded-lg border bg-muted/30 p-2"
            >
              {layout.rows.map((row, index) => (
                <div key={index} className="flex flex-wrap gap-1">
                  {row.split(" ").map((key) => (
                    <button
                      key={key}
                      type="button"
                      aria-label={`Insert ${key}`}
                      disabled={disabled || readOnly || composing}
                      className="min-h-11 min-w-10 rounded border bg-background px-2 text-lg hover:bg-accent focus-visible:outline focus-visible:outline-2 focus-visible:outline-primary disabled:opacity-50"
                      onMouseDown={(e) => e.preventDefault()}
                      onClick={() => insert(key)}
                    >
                      {key}
                    </button>
                  ))}
                </div>
              ))}
              <div className="flex flex-wrap gap-2 pt-1">
                {(["Space", "New line", "Backspace"] as const).map((label) => (
                  <Button
                    key={label}
                    type="button"
                    variant="outline"
                    disabled={disabled || readOnly || composing}
                    onMouseDown={(e) => e.preventDefault()}
                    onClick={() =>
                      insert(
                        label === "Space" ? " " : label === "New line" ? "\n" : "",
                        label === "Backspace",
                      )
                    }
                  >
                    {label}
                  </Button>
                ))}
              </div>
            </div>
          )}
        </div>
      </details>
      {message && (
        <p role="status" className="text-xs text-destructive">
          {message}
        </p>
      )}
    </div>
  );
}
