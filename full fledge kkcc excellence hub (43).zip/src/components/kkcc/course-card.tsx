import { memo } from "react";
import { Link } from "@tanstack/react-router";
import { Star, PlayCircle, FileCheck2, BookOpen } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { coinPriceOf, coursePriceLabel, discountOf, isFreeCourse, type Course } from "@/lib/cms";
import { CourseThumb } from "./course-thumb";
import { KaatCoin } from "./kaat-coin";

export const CourseCard = memo(function CourseCard({
  course,
  enrolled = false,
  validity,
}: {
  course: Course;
  enrolled?: boolean;
  validity?: string | undefined;
}) {
  const off = discountOf(course);
  const free = isFreeCourse(course);
  const coinPrice = coinPriceOf(course);
  const rating = Number(course.rating);
  const hasRating = Number.isFinite(rating) && rating > 0 && rating <= 5;
  return (
    <article
      data-testid={`course-card-${course.id}`}
      className="learning-card hover-lift group flex h-full flex-col overflow-hidden rounded-2xl border bg-card shadow-soft"
    >
      <Link
        to="/courses/$slug"
        params={{ slug: course.slug }}
        aria-label={`Open ${course.title}`}
        className="block focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring"
      >
        <CourseThumb course={course} className="aspect-[16/8]" />
      </Link>

      <div className="flex flex-1 flex-col p-5">
        <div className="flex flex-wrap items-center gap-2">
          <Badge variant="secondary" className="rounded-lg">
            {enrolled ? "Enrolled" : course.course_type}
          </Badge>
          <span className="text-xs font-semibold text-study-blue">{course.class_level}</span>
          {hasRating && (
            <span
              className="ml-auto inline-flex items-center gap-1 text-xs font-semibold text-study-gold"
              aria-label={`Course rating: ${rating.toFixed(1)} out of 5`}
            >
              <Star aria-hidden="true" className="h-3.5 w-3.5 fill-accent text-accent" />
              {rating.toFixed(1)}
            </span>
          )}
        </div>

        <h3 className="mt-3 text-base font-bold leading-snug">
          <Link to="/courses/$slug" params={{ slug: course.slug }} className="hover:text-primary">
            {course.title}
          </Link>
        </h3>
        <p className="mt-1 text-xs text-muted-foreground">{course.faculty}</p>
        {enrolled && validity && (
          <p className="mt-2 text-xs font-medium text-success">{validity}</p>
        )}

        <div className="mt-4 flex flex-wrap gap-x-4 gap-y-1.5 text-xs text-muted-foreground">
          <span className="inline-flex items-center gap-1.5">
            <PlayCircle className="h-3.5 w-3.5 text-study-teal" /> {course.lectures_count ?? "—"}{" "}
            lectures
          </span>
          <span className="inline-flex items-center gap-1.5">
            <FileCheck2 className="h-3.5 w-3.5 text-study-blue" /> {course.tests_count ?? "—"} tests
          </span>
          <span className="inline-flex items-center gap-1.5">
            <BookOpen className="h-3.5 w-3.5 text-study-rose" /> {course.materials_count ?? "—"}{" "}
            resources
          </span>
        </div>

        <div className="mt-auto pt-5">
          <div className="border-t pt-4">
            <div>
              <p className="font-display text-lg font-bold text-study-teal">
                {coursePriceLabel(course)}
              </p>
              {!free && (
                <p className="mt-1 inline-flex items-center gap-1.5 text-xs font-semibold text-primary">
                  <KaatCoin size="xs" /> {coinPrice} 23KAAT
                  {coinPrice < course.price ? (
                    <span className="text-success">· cheaper</span>
                  ) : null}
                </p>
              )}
              {course.original_price > course.price && (
                <p className="text-xs text-muted-foreground">
                  <span className="line-through">
                    {coursePriceLabel({ price: course.original_price })}
                  </span>{" "}
                  <span className="text-success">{free ? "No payment" : `${off}% off`}</span>
                </p>
              )}
            </div>
            <div className="mt-4 grid grid-cols-2 gap-2">
              <Button asChild size="sm" variant="outline" className="h-10 rounded-lg">
                <Link
                  to="/courses/$slug"
                  params={{ slug: course.slug }}
                  aria-label={`View details for ${course.title}`}
                >
                  View details
                </Link>
              </Button>
              <Button asChild size="sm" className="h-10 rounded-lg">
                {free || enrolled ? (
                  <Link to="/learn" search={{ course: course.slug }}>
                    {enrolled ? "Start Learning" : "Start Free"}
                  </Link>
                ) : (
                  <Link to="/checkout" search={{ course: course.slug }}>
                    Enroll
                  </Link>
                )}
              </Button>
            </div>
          </div>
        </div>
      </div>
    </article>
  );
});
