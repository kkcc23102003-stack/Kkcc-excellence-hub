import { Link, useRouterState } from "@tanstack/react-router";
import { useMemo, useState } from "react";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { useServerFn } from "@tanstack/react-start";
import {
  BookOpen,
  BarChart3,
  Sparkles,
  ClipboardList,
  FileText,
  Database,
  BrainCircuit,
  Users,
  KeyRound,
  HelpCircle,
  MessageSquarePlus,
  Bell,
  CreditCard,
  TicketPercent,
  Gift,
  ShieldAlert,
  Palette,
  LayoutTemplate,
  Type,
  Code2,
  Share2,
  HardDrive,
  ShieldCheck,
  Search,
  Compass,
  Download,
  Zap,
  SlidersHorizontal,
  Loader2,
  RotateCcw,
} from "lucide-react";
import { toast } from "sonner";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import {
  adminGetCustomSeriesCatalog,
  adminOptimizeAndCleanServer,
  adminToggleBuiltInSeries,
} from "@/lib/admin.functions";
import { getAdminAppControls, saveAdminAppControls } from "@/lib/app-controls.functions";
import { safeServerCall } from "@/lib/safe-server-call";
import { cn } from "@/lib/utils";

type AdminCategory =
  "All" | "Courses & Content" | "Students & Access" | "Payments & Rewards" | "Website & System";

type AdminToolItem = {
  to: string;
  label: string;
  hint: string;
  category: Exclude<AdminCategory, "All">;
  icon: typeof BookOpen;
  badge?: string;
};

export const ADMIN_TOOLS: AdminToolItem[] = [
  {
    to: "/admin/analytics",
    label: "Business Dashboard",
    hint: "Revenue, sales, students, coupons and the pending admin queue",
    category: "Payments & Rewards",
    icon: BarChart3,
    badge: "New",
  },
  {
    to: "/admin",
    label: "Course Manager",
    hint: "Create, edit & publish courses, lectures and chapters",
    category: "Courses & Content",
    icon: BookOpen,
  },
  {
    to: "/admin/syllabus",
    label: "Syllabus Auto Builder",
    hint: "Paste syllabus → Subject, Chapter & Topic tree + 1-click tests",
    category: "Courses & Content",
    icon: Sparkles,
    badge: "New",
  },
  {
    to: "/admin/tests",
    label: "Test Builder & Questions",
    hint: "Write MCQs, set timers, syllabus tags & chapterwise tests",
    category: "Courses & Content",
    icon: ClipboardList,
  },
  {
    to: "/admin/document-studio",
    label: "Presentation & PDF Studio",
    hint: "Create PPTX slides, merge/compress/invert PDFs and read documents",
    category: "Courses & Content",
    icon: FileText,
  },
  {
    to: "/admin/materials",
    label: "Study Material & Notes",
    hint: "Upload PDFs or link Google Drive notes, PYQs & formula sheets",
    category: "Courses & Content",
    icon: FileText,
  },
  {
    to: "/admin/exam-bank",
    label: "Question Bank & Test Series",
    hint: "All Template Questions + Add Your Questions + AI Generator + Set Question Count",
    category: "Courses & Content",
    icon: Database,
    badge: "Question Bank",
  },
  {
    to: "/admin/ai-question-engine",
    label: "AI Question Engine",
    hint: "Research & verify high-yield practice questions",
    category: "Courses & Content",
    icon: BrainCircuit,
  },
  {
    to: "/admin/students",
    label: "Student Access",
    hint: "Grant or revoke course, test & series access, or block accounts",
    category: "Students & Access",
    icon: Users,
  },
  {
    to: "/admin/offline-access",
    label: "Offline Access",
    hint: "Pre-activate access by student Gmail after UPI/cash payment",
    category: "Students & Access",
    icon: KeyRound,
  },
  {
    to: "/admin/doubts",
    label: "Doubts Inbox",
    hint: "Read student subject doubts and send direct answers",
    category: "Students & Access",
    icon: HelpCircle,
  },
  {
    to: "/admin/enquiries",
    label: "Admission Enquiries",
    hint: "Lead CRM for website enquiries, coin requests & follow-ups",
    category: "Students & Access",
    icon: MessageSquarePlus,
  },
  {
    to: "/admin/notifications",
    label: "Notifications",
    hint: "Broadcast announcements or send personal alerts to students",
    category: "Students & Access",
    icon: Bell,
  },
  {
    to: "/admin/payments",
    label: "Payments & Razorpay",
    hint: "Switch between offline UPI/Cash mode and live Razorpay checkout",
    category: "Payments & Rewards",
    icon: CreditCard,
  },
  {
    to: "/admin/coupons",
    label: "Coupons & Discounts",
    hint: "Create promo codes up to 100% off with usage & expiry limits",
    category: "Payments & Rewards",
    icon: TicketPercent,
  },
  {
    to: "/admin/vouchers",
    label: "Amazon / Flipkart Rewards",
    hint: "Manage monthly Kit 2 Coins reward vouchers & student claims",
    category: "Payments & Rewards",
    icon: Gift,
  },
  {
    to: "/admin/users",
    label: "Admin Team Users",
    hint: "Grant or remove admin privileges for trusted KKCC staff",
    category: "Payments & Rewards",
    icon: ShieldAlert,
  },
  {
    to: "/admin/branding",
    label: "Branding & Theme",
    hint: "Customize app name, logo, hero highlights & color palette",
    category: "Website & System",
    icon: Palette,
  },
  {
    to: "/admin/content",
    label: "Website Content",
    hint: "Edit navigation menus, page headers, contact info & custom blocks",
    category: "Website & System",
    icon: LayoutTemplate,
  },
  {
    to: "/admin/text-manager",
    label: "Hybrid Text Manager",
    hint: "Safely override student-facing labels and dashboard copy",
    category: "Website & System",
    icon: Type,
  },
  {
    to: "/admin/app-builder",
    label: "App Builder (HTML/CSS/JS)",
    hint: "Inject live custom HTML sections, CSS styles or JS scripts",
    category: "Website & System",
    icon: Code2,
  },
  {
    to: "/admin/settings",
    label: "Social & App Links",
    hint: "Manage YouTube, Telegram, WhatsApp, Instagram & footer links",
    category: "Website & System",
    icon: Share2,
  },
  {
    to: "/admin/storage",
    label: "Storage Provider",
    hint: "Configure Supabase Storage, Cloudflare R2, AWS S3 or Backblaze B2",
    category: "Website & System",
    icon: HardDrive,
  },
  {
    to: "/admin/security",
    label: "Security & App Controls",
    hint: "Content protection, feature switches, Kit 2 Coins caps & health",
    category: "Website & System",
    icon: ShieldCheck,
  },
  {
    to: "/downloads",
    label: "Release files & setup",
    hint: "Source and optional manual setup files; no one-click database reset",
    category: "Website & System",
    icon: Download,
    badge: "Files",
  },
];

const CATEGORIES: AdminCategory[] = [
  "All",
  "Courses & Content",
  "Students & Access",
  "Payments & Rewards",
  "Website & System",
];

const LIVE_VISUAL_PREVIEW =
  (import.meta as ImportMeta & { env?: Record<string, string | undefined> }).env?.[
    "VITE_KKCC_LIVE_PREVIEW"
  ] === "1";
const AVAILABLE_TOOLS = LIVE_VISUAL_PREVIEW
  ? ADMIN_TOOLS.filter((tool) => tool.to !== "/downloads")
  : ADMIN_TOOLS;

export function AdminCommandBar({ compact = false }: { compact?: boolean }) {
  const pathname = useRouterState({ select: (s) => s.location.pathname });
  const qc = useQueryClient();
  const [category, setCategory] = useState<AdminCategory>("All");
  const [search, setSearch] = useState("");
  const [expanded, setExpanded] = useState(!compact);
  const [showMasterControls, setShowMasterControls] = useState(false);

  const getControlsFn = useServerFn(getAdminAppControls);
  const saveControlsFn = useServerFn(saveAdminAppControls);
  const optimizeServerFn = useServerFn(adminOptimizeAndCleanServer);
  const toggleBuiltInFn = useServerFn(adminToggleBuiltInSeries);
  const getCustomCatalogFn = useServerFn(adminGetCustomSeriesCatalog);

  const controlsQuery = useQuery({
    queryKey: ["admin", "app-controls"],
    queryFn: () => safeServerCall(() => getControlsFn(), null),
    staleTime: 60_000,
    enabled: showMasterControls,
  });

  const customCatalogQuery = useQuery({
    queryKey: ["admin", "custom-series-catalog"],
    queryFn: () => getCustomCatalogFn({} as never),
    staleTime: 60_000,
    enabled: showMasterControls,
  });

  const toggleFeatureMutation = useMutation({
    mutationFn: async (patch: Record<string, boolean>) => {
      const current = controlsQuery.data;
      if (!current) throw new Error("App controls not loaded yet");
      return saveControlsFn({
        data: {
          maintenanceMode: current.maintenanceMode,
          maintenanceMessage: current.maintenanceMessage,
          protectionEnabled: current.protectionEnabled,
          copyGuardEnabled: current.copyGuardEnabled,
          contextMenuGuardEnabled: current.contextMenuGuardEnabled,
          shortcutGuardEnabled: current.shortcutGuardEnabled,
          watermarkEnabled: current.watermarkEnabled,
          screenshotBlurEnabled: current.screenshotBlurEnabled,
          printGuardEnabled: current.printGuardEnabled,
          kittuQuizEnabled: current.kittuQuizEnabled,
          testSeriesEnabled: current.testSeriesEnabled,
          studyMaterialEnabled: current.studyMaterialEnabled,
          kittuDailyRewardCap: current.kittuRewards.dailyRewardCap,
          kittuDailyPracticeHours: current.kittuRewards.dailyPracticeHours,
          kittuDailyGift: current.kittuRewards.dailyGift,
          kittuPracticeBatches: current.kittuPracticeBatches,
          ...patch,
        },
      });
    },
    onSuccess: () => {
      void qc.invalidateQueries({ queryKey: ["admin", "app-controls"] });
      void qc.invalidateQueries({ queryKey: ["public", "app-controls"] });
      toast.success("Master App Control updated live!");
    },
    onError: (err: Error) => toast.error(err.message),
  });

  const refreshMutation = useMutation({
    mutationFn: () => optimizeServerFn({} as never),
    onSuccess: (res) => {
      void qc.invalidateQueries({ queryKey: ["admin"] });
      toast.success(`Admin data refreshed (${res.clearedSelectEntries} server cache entries).`, {
        description: "No browser drafts, student attempts or access grants were deleted.",
      });
    },
    onError: (err: Error) => toast.error(err.message),
  });

  const toggleBuiltInMutation = useMutation({
    mutationFn: (includeBuiltIn: boolean) => toggleBuiltInFn({ data: { includeBuiltIn } }),
    onSuccess: (res) => {
      void qc.invalidateQueries({ queryKey: ["admin", "custom-series-catalog"] });
      void qc.invalidateQueries({ queryKey: ["public", "custom-series-catalog"] });
      toast.success(
        res.includeBuiltIn
          ? "Built-in series shown again."
          : "Built-in series hidden from the public catalogue. Existing grants remain unchanged.",
      );
    },
    onError: (err: Error) => toast.error(err.message),
  });

  const filtered = useMemo(() => {
    const q = search.trim().toLowerCase();
    return AVAILABLE_TOOLS.filter((tool) => {
      if (category !== "All" && tool.category !== category) return false;
      if (!q) return true;
      return (
        tool.label.toLowerCase().includes(q) ||
        tool.hint.toLowerCase().includes(q) ||
        tool.category.toLowerCase().includes(q)
      );
    });
  }, [category, search]);

  const controls = controlsQuery.data;
  const includeBuiltIn = Boolean(customCatalogQuery.data?.includeBuiltIn);

  return (
    <div className="surface-panel mb-6 p-4 sm:p-5" data-testid="admin-command-bar">
      {/* Top Header */}
      <div className="flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
        <div className="flex items-center gap-2.5">
          <div className="flex h-9 w-9 items-center justify-center rounded-xl bg-primary/10 text-primary">
            <Compass className="h-5 w-5" />
          </div>
          <div>
            <div className="flex flex-wrap items-center gap-2">
              <h2 className="text-sm font-bold tracking-tight">Admin tools</h2>
              <Badge variant="secondary" className="rounded-full text-[10px]">
                {AVAILABLE_TOOLS.length} tools
              </Badge>
              {!LIVE_VISUAL_PREVIEW && (
                <Badge className="rounded-full bg-emerald-500/15 text-[10px] text-emerald-600 dark:text-emerald-400">
                  <Zap className="mr-1 h-3 w-3" /> Protected admin workspace
                </Badge>
              )}
            </div>
            <p className="text-xs text-muted-foreground">
              {LIVE_VISUAL_PREVIEW
                ? "Explore admin tools with fixture data. Release downloads and database cleanup are unavailable."
                : "Search all tools when needed. Daily work stays on the admin home screen."}
            </p>
          </div>
        </div>

        <div className="flex flex-wrap items-center gap-2">
          <Button
            type="button"
            size="sm"
            variant={showMasterControls ? "default" : "outline"}
            className="h-8 rounded-full text-xs font-bold"
            onClick={() => setShowMasterControls((v) => !v)}
          >
            <SlidersHorizontal className="mr-1.5 h-3.5 w-3.5" />
            {showMasterControls
              ? LIVE_VISUAL_PREVIEW
                ? "Hide admin controls"
                : "Hide app switches"
              : LIVE_VISUAL_PREVIEW
                ? "Show admin controls"
                : "App switches & release files"}
          </Button>
          <div className="relative flex-1 sm:w-56">
            <Search className="pointer-events-none absolute left-3 top-1/2 h-3.5 w-3.5 -translate-y-1/2 text-muted-foreground" />
            <Input
              value={search}
              onChange={(e) => {
                setSearch(e.target.value);
                if (!expanded) setExpanded(true);
              }}
              placeholder="Search admin tools..."
              className="h-8 rounded-full pl-8 text-xs"
            />
          </div>
          {compact && (
            <button
              type="button"
              onClick={() => setExpanded((prev) => !prev)}
              aria-expanded={expanded}
              className="rounded-full border px-3 py-1.5 text-xs font-medium transition hover:border-primary/50 hover:text-primary"
            >
              {expanded ? "Compact view" : `Show all ${AVAILABLE_TOOLS.length} tools`}
            </button>
          )}
        </div>
      </div>

      {/* Optional controls; no mass deletion or automatic SQL cleanup. */}
      {showMasterControls && (
        <div className="mt-4 space-y-3 rounded-2xl border border-primary/30 bg-gradient-to-br from-primary/10 via-background/90 to-cyan-500/10 p-3.5 sm:p-4">
          {/* Release and maintenance tools are withheld in the shared visual preview. */}
          {LIVE_VISUAL_PREVIEW ? (
            <p className="rounded-xl border bg-card px-3 py-2 text-xs text-muted-foreground">
              Preview mode: release downloads and database changes are unavailable.
            </p>
          ) : (
            <div className="flex flex-wrap items-center justify-between gap-2">
              <div className="flex flex-wrap items-center gap-2">
                <Link
                  to="/downloads"
                  className="inline-flex min-h-9 items-center gap-1 rounded-full border bg-background px-3 py-1 text-xs font-semibold hover:border-primary hover:text-primary"
                >
                  <Download className="h-3.5 w-3.5" /> Release &amp; setup files
                </Link>
                <span className="text-xs text-muted-foreground">
                  Setup SQL is manual. This button never changes Supabase data.
                </span>
              </div>
              <button
                type="button"
                disabled={refreshMutation.isPending}
                onClick={() => refreshMutation.mutate()}
                className="inline-flex min-h-9 items-center gap-1 rounded-full border border-primary/40 bg-primary/10 px-3 py-1 text-xs font-semibold text-primary hover:bg-primary/15"
              >
                {refreshMutation.isPending ? (
                  <Loader2 className="h-3.5 w-3.5 animate-spin" />
                ) : (
                  <Zap className="h-3.5 w-3.5" />
                )}
                Refresh admin data · no deletion
              </button>
            </div>
          )}

          {/* Live feature switches; disabling a feature never deletes existing work. */}
          <div className="flex flex-wrap items-center justify-between gap-2 border-t border-border/60 pt-2.5">
            <div className="flex flex-wrap items-center gap-1.5">
              <span className="mr-1 text-[11px] font-black uppercase tracking-wider text-muted-foreground">
                Live Feature Switches:
              </span>
              {!controls && (
                <span role="status" className="text-xs text-muted-foreground">
                  {controlsQuery.isPending
                    ? "Loading switches…"
                    : "Switches unavailable — no settings changed."}
                </span>
              )}
              {controls && (
                <>
                  {(
                    [
                      ["testSeriesEnabled", "Test Series", controls.testSeriesEnabled],
                      ["studyMaterialEnabled", "Study Material", controls.studyMaterialEnabled],
                      ["kittuQuizEnabled", "Kit 2 Coins Quiz", controls.kittuQuizEnabled],
                      ["protectionEnabled", "Content Shield", controls.protectionEnabled],
                      ["copyGuardEnabled", "Anti-Copy Guard", controls.copyGuardEnabled],
                      ["maintenanceMode", "Maintenance Mode", controls.maintenanceMode],
                    ] as const
                  ).map(([key, label, active]) => (
                    <button
                      key={key}
                      type="button"
                      disabled={toggleFeatureMutation.isPending}
                      onClick={() => {
                        const affectsStudents =
                          (active &&
                            (key === "testSeriesEnabled" || key === "studyMaterialEnabled")) ||
                          (!active && key === "maintenanceMode");
                        if (
                          affectsStudents &&
                          !window.confirm(
                            `${label} will be ${active ? "turned off" : "turned on"} for students until you reverse this setting. No accounts or saved work are deleted. Continue?`,
                          )
                        )
                          return;
                        toggleFeatureMutation.mutate({ [key]: !active });
                      }}
                      className={cn(
                        "inline-flex items-center gap-1 rounded-full border px-2.5 py-0.5 text-[11px] font-bold transition",
                        active
                          ? "border-emerald-500/50 bg-emerald-500/15 text-emerald-700 dark:text-emerald-300"
                          : "border-rose-500/40 bg-rose-500/10 text-rose-600 dark:text-rose-400",
                      )}
                    >
                      <span
                        className={cn(
                          "h-1.5 w-1.5 rounded-full",
                          active ? "bg-emerald-500" : "bg-rose-500",
                        )}
                      />
                      {label}: {active ? "ON" : "OFF"}
                    </button>
                  ))}
                </>
              )}
            </div>

            <div className="flex flex-wrap items-center gap-1.5">
              <span className="text-[11px] font-black uppercase tracking-wider text-muted-foreground">
                Test Series Control:
              </span>
              <Link
                to="/admin/exam-bank"
                className="inline-flex items-center gap-1 rounded-full bg-primary/15 px-2.5 py-0.5 text-[11px] font-bold text-primary hover:bg-primary/25"
              >
                + Add Series &amp; Syllabus
              </Link>
              {customCatalogQuery.isPending ? (
                <span role="status" className="text-xs text-muted-foreground">
                  Checking series setting…
                </span>
              ) : customCatalogQuery.isError ? (
                <span role="status" className="text-xs text-amber-700 dark:text-amber-300">
                  Series status unavailable
                </span>
              ) : includeBuiltIn ? (
                <button
                  type="button"
                  disabled={toggleBuiltInMutation.isPending}
                  onClick={() => {
                    if (
                      window.confirm(
                        "Hide built-in test series from the public catalogue? The server refuses if it finds saved attempts or student grants; no definitions or student records are deleted.",
                      )
                    )
                      toggleBuiltInMutation.mutate(false);
                  }}
                  className="inline-flex min-h-9 items-center gap-1 rounded-full border bg-background px-3 py-1 text-xs font-semibold hover:border-primary"
                >
                  <RotateCcw className="h-3 w-3" /> Hide built-in series
                </button>
              ) : (
                <span className="text-xs text-muted-foreground">Built-in series hidden</span>
              )}
            </div>
          </div>
        </div>
      )}

      {/* Category Filter Tabs */}
      {expanded && (
        <div className="mt-3 flex flex-wrap gap-1.5">
          {CATEGORIES.map((cat) => (
            <button
              key={cat}
              type="button"
              onClick={() => {
                setCategory(cat);
                if (!expanded) setExpanded(true);
              }}
              className={cn(
                "rounded-full px-3 py-1 text-xs font-medium transition",
                category === cat
                  ? "bg-primary text-primary-foreground shadow-sm"
                  : "bg-muted/70 text-muted-foreground hover:bg-muted hover:text-foreground",
              )}
            >
              {cat}
            </button>
          ))}
        </div>
      )}

      {/* Modules Grid */}
      {expanded ? (
        <div className="mt-4 grid gap-2.5 sm:grid-cols-2 lg:grid-cols-3">
          {filtered.map((tool) => {
            const Icon = tool.icon;
            const isActive =
              tool.to === "/admin"
                ? pathname === "/admin" || pathname === "/admin/"
                : pathname.startsWith(tool.to);
            return (
              <Link
                key={tool.to}
                to={tool.to}
                className={cn(
                  "group flex items-start gap-3 rounded-2xl border p-3 transition-all",
                  isActive
                    ? "border-primary bg-primary/10 shadow-sm"
                    : "bg-background/60 hover:border-primary/40 hover:bg-muted/40",
                )}
              >
                <div
                  className={cn(
                    "mt-0.5 flex h-8 w-8 shrink-0 items-center justify-center rounded-xl transition-colors",
                    isActive
                      ? "bg-primary text-primary-foreground"
                      : "bg-primary/10 text-primary group-hover:bg-primary group-hover:text-primary-foreground",
                  )}
                >
                  <Icon className="h-4 w-4" />
                </div>
                <div className="min-w-0 flex-1">
                  <div className="flex items-center gap-1.5">
                    <span className="min-w-0 flex-1 truncate text-xs font-semibold text-foreground">
                      {tool.label}
                    </span>
                    {tool.badge && (
                      <Badge className="h-4 shrink-0 rounded-full px-1.5 text-[9px]">
                        {tool.badge}
                      </Badge>
                    )}
                  </div>
                  <p className="mt-0.5 line-clamp-1 text-[11px] text-muted-foreground">
                    {tool.hint}
                  </p>
                </div>
              </Link>
            );
          })}
        </div>
      ) : (
        <div className="mt-3 flex flex-wrap gap-1.5">
          {filtered
            .filter((tool) =>
              [
                "/admin/students",
                "/admin/document-studio",
                "/admin/payments",
                "/admin/security",
              ].includes(tool.to),
            )
            .map((tool) => {
              const isActive =
                tool.to === "/admin"
                  ? pathname === "/admin" || pathname === "/admin/"
                  : pathname.startsWith(tool.to);
              return (
                <Link
                  key={tool.to}
                  to={tool.to}
                  className={cn(
                    "inline-flex items-center gap-1.5 rounded-full border px-3 py-1 text-xs font-medium transition",
                    isActive
                      ? "border-primary bg-primary text-primary-foreground"
                      : "bg-background/70 text-foreground hover:border-primary/50 hover:text-primary",
                  )}
                >
                  <tool.icon className="h-3.5 w-3.5" />
                  {tool.label}
                </Link>
              );
            })}
        </div>
      )}
    </div>
  );
}
