import { getPublicMaterialBody } from "@/lib/content.functions";
import { lazy, Suspense, useEffect, useMemo, useRef, useState } from "react";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { Link } from "@tanstack/react-router";
import { useServerFn } from "@tanstack/react-start";
import { toast } from "sonner";
import {
  BookOpen,
  Copy,
  Download,
  ExternalLink,
  Loader2,
  Lock,
  Printer,
  Sparkles,
  X,
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { KaatCoin } from "@/components/kkcc/kaat-coin";
import { useAuthUser } from "@/hooks/use-auth-user";
import { invalidateLearningQueries } from "@/hooks/use-learning-access";
import { getMyMaterialAccessUrl, spend23KaatForMaterial } from "@/lib/coins.functions";
import { getMyBatchLesson } from "@/lib/notes-batch.functions";
import { coinPriceOf } from "@/lib/cms";
import { videoSource } from "@/lib/video";
import { friendlyError } from "@/lib/storage";
import { downloadFile, safeFilename } from "@/lib/document-studio";
import { NOTES_PRINT_LOGO } from "@/lib/notes-print-logo";
import { parseVisualDirectives } from "@/lib/notes-visuals/directives";
import { notePracticeGroups } from "@/lib/note-practice";
import { NotePracticeQuiz } from "@/components/kkcc/note-practice-quiz";
import { NoteFollowUpGate, NoteFollowUpTest } from "@/components/kkcc/note-follow-up-reader";
import type { PdfColourMode } from "@/lib/pdf-brand";

import {
  KKCC_BRAND_PRIMARY,
  KKCC_BRAND_SECONDARY,
  describeVisuals,
  notesPrintDocument,
  renderNotesBody,
} from "@/lib/notes-visuals";
import { analyzeNotes } from "@/lib/notes-visuals/analyze";

const BrandedPdfPreview = lazy(() =>
  import("./branded-pdf-preview").then(({ BrandedPdfPreview }) => ({ default: BrandedPdfPreview })),
);

type MaterialAccessType = "course" | "free" | "paid";
function normaliseAccessType(
  accessType?: string | null,
  price?: number | null,
  courseId?: string | null,
): MaterialAccessType {
  if (accessType === "paid" || Number(price ?? 0) > 0) return "paid";
  if (accessType === "free" || !courseId) return "free";
  return "course";
}

function toEmbeddedMobilePreviewUrl(url: string | null | undefined): string | null {
  if (!url || url === "#" || url.startsWith("data:")) return null;
  const driveMatch = url.match(/drive\.google\.com\/file\/d\/([a-zA-Z0-9_-]+)/);
  if (driveMatch?.[1]) {
    return `https://drive.google.com/file/d/${driveMatch[1]}/preview`;
  }
  const docsMatch = url.match(/docs\.google\.com\/document\/d\/([a-zA-Z0-9_-]+)/);
  if (docsMatch?.[1]) {
    return `https://docs.google.com/document/d/${docsMatch[1]}/mobilebasic`;
  }
  if (/\.pdf(?:$|[?#])/i.test(url) || url.startsWith("/uploads/")) {
    return url;
  }
  return null;
}

function isPdfAttachment(url: string | null | undefined, materialType?: string | null) {
  if (!url || url === "#" || url.startsWith("data:text/html")) return false;
  if (url.startsWith("data:application/pdf")) return true;
  try {
    const pathname = decodeURIComponent(new URL(url, window.location.href).pathname);
    return /\.pdf$/i.test(pathname) || /\bpdf\b/i.test(materialType ?? "");
  } catch {
    return false;
  }
}

function openPrintableNoteWindow(input: {
  title: string;
  subject?: string | null | undefined;
  chapter?: string | null | undefined;
  materialType?: string | null | undefined;
  /** Plain text notes typed by the admin. Diagrams are generated from it. */
  description?: string | null | undefined;
  fontScale?: number | undefined;
}) {
  // Reading stays colourful; clicking Print creates a separate grayscale copy
  // with the real, faint black centre logo on every printed sheet.
  const html = notesPrintDocument({
    title: input.title || "KKCC Study Note",
    subject: input.subject,
    chapter: input.chapter,
    materialType: input.materialType,
    text: input.description ?? "",
    fontScale: input.fontScale ?? 16,
    mode: "black-white",
  });
  // No retained blob URLs: the print document owns its memory until its tab closes.
  const printWindow = window.open("", "_blank");
  if (!printWindow) {
    toast.error("Allow pop-ups to open the print document.");
    return;
  }
  printWindow.opener = null;
  printWindow.document.open();
  printWindow.document.write(html);
  printWindow.document.close();
}

function showBrandedPdfPrintTab(tab: Window, bytes: Uint8Array, name: string) {
  const url = URL.createObjectURL(new Blob([new Uint8Array(bytes)], { type: "application/pdf" }));
  const doc = tab.document;
  doc.title = `${name} — KKCC grayscale print PDF`;
  const style = doc.createElement("style");
  style.textContent = `body{font:15px/1.55 system-ui,sans-serif;color:#111;max-width:960px;margin:24px auto;padding:0 16px}
    header{display:flex;align-items:center;gap:12px}header img{height:46px;width:46px;object-fit:contain;filter:grayscale(1)}
    iframe{width:100%;height:74vh;border:1px solid #bfd3ce;border-radius:8px;background:#fff}
    a{display:inline-block;margin:12px 0;padding:9px 18px;background:#0f766e;color:white;border-radius:6px;text-decoration:none}
    p{color:#536a67}@media print{iframe{height:92vh}a,p{display:none}header{color:#111;border-color:#777;filter:grayscale(1)}}`;
  doc.head.append(style);
  const header = doc.createElement("header");
  const logo = doc.createElement("img");
  logo.src = NOTES_PRINT_LOGO;
  logo.alt = "KKCC logo";
  const heading = doc.createElement("h1");
  heading.textContent = "KKCC black & white PDF — ready to print";
  header.append(logo, heading);
  const instructions = doc.createElement("p");
  instructions.textContent =
    "Use Print in the PDF viewer below. If your browser downloads PDFs automatically, open the KKCC copy and print it there. The original is unchanged.";
  const viewer = doc.createElement("iframe");
  viewer.src = url;
  viewer.title = "KKCC watermarked PDF to print";
  const download = doc.createElement("a");
  download.href = url;
  download.download = `${safeFilename(name)}-KKCC-BW.pdf`;
  download.textContent = "Download KKCC PDF for printing";
  doc.body.replaceChildren(header, instructions, viewer, download);
  tab.addEventListener("pagehide", () => URL.revokeObjectURL(url), { once: true });
  window.setTimeout(() => URL.revokeObjectURL(url), 30 * 60_000);
}

export function MaterialAccessButton({
  fileUrl,
  deferredBodyId,
  materialId,
  accessType,
  price,
  coinPrice,
  courseId,
  title,
  subject,
  chapter,
  description: publicDescription,
  materialType,
  className = "mt-5 w-full",
  batchCourseId,
  batchCourseSlug,
  batchCourseTitle,
  notesSeriesId,
  autoOpen = false,
  onBatchStartTest,
}: {
  fileUrl: string | null;
  deferredBodyId?: string;
  materialId?: string | undefined;
  accessType?: string | null | undefined;
  price?: number | null | undefined;
  coinPrice?: number | null | undefined;
  courseId?: string | null | undefined;
  title?: string | null | undefined;
  subject?: string | null | undefined;
  chapter?: string | null | undefined;
  description?: string | null | undefined;
  materialType?: string | null | undefined;
  className?: string | undefined;
  /** Server-verified Batch overlay; never change the original note's purchase/access mode. */
  batchCourseId?: string | undefined;
  batchCourseSlug?: string | undefined;
  batchCourseTitle?: string | undefined;
  /** Kept for older callers; paid note membership never blocks individual purchases. */
  bundleRequired?: boolean;
  notesSeriesId?: string | undefined;
  autoOpen?: boolean;
  onBatchStartTest?: () => void;
}) {
  const { user } = useAuthUser();
  const client = useQueryClient();
  const fetchAccess = useServerFn(getMyMaterialAccessUrl);
  const fetchBatchLesson = useServerFn(getMyBatchLesson);
  const spendCoins = useServerFn(spend23KaatForMaterial);
  const [loading, setLoading] = useState(false);
  const [brandingPdf, setBrandingPdf] = useState(false);
  const [previewLoading, setPreviewLoading] = useState(false);
  const [brandedPreviewBytes, setBrandedPreviewBytes] = useState<Uint8Array | null>(null);
  const previewAttempt = useRef(0);
  const [readerOpen, setReaderOpen] = useState(autoOpen && Boolean(batchCourseId));
  const [pdfStatus, setPdfStatus] = useState("");
  const [activePractice, setActivePractice] = useState<number | null>(null);
  const [activeFollowUp, setActiveFollowUp] = useState(false);
  const [followUpAutoUsed, setFollowUpAutoUsed] = useState(false);
  const [pdfLastPageViewed, setPdfLastPageViewed] = useState(false);
  const readerScroll = useRef<HTMLDivElement>(null);
  const noteScrollPosition = useRef(0);
  const [fontScale, setFontScale] = useState<number>(15);
  const changeFont = (delta: number) =>
    setFontScale((scale) => Math.min(22, Math.max(13, scale + delta)));
  const mode = normaliseAccessType(accessType, price, courseId);
  const free = !batchCourseId && mode === "free";
  const access = useQuery({
    queryKey: ["student", user?.id, "material-url", materialId, batchCourseId],
    enabled: Boolean(user && materialId && !free),
    retry: false,
    staleTime: 0,
    gcTime: 60_000,
    refetchOnWindowFocus: readerOpen,
    refetchInterval: readerOpen ? 15_000 : false,
    queryFn: async () => {
      if (batchCourseId) {
        try {
          const result = await fetchBatchLesson({
            data: { courseId: batchCourseId, noteId: materialId! },
          });
          return {
            userId: user!.id,
            url: result.note.file_url || "#",
            description: result.note.description,
            videoUrl: result.video_url,
          };
        } catch (batchError) {
          // A separately purchased note remains readable, but never exposes its batch video.
          const message = batchError instanceof Error ? batchError.message : String(batchError);
          if (!/COURSE_ACCESS_REQUIRED|Batch not available/i.test(message)) throw batchError;
        }
      }
      const result = await fetchAccess({ data: { material_id: materialId! } });
      return {
        userId: user!.id,
        url: result.file_url,
        description: result.description,
        videoUrl: null,
      };
    },
  });

  const publicBody = useQuery({
    queryKey: ["public-note-body", deferredBodyId],
    queryFn: () => getPublicMaterialBody({ data: { id: deferredBodyId! } }),
    enabled: Boolean(free && deferredBodyId && readerOpen),
    staleTime: 0,
    gcTime: 60_000,
    retry: false,
  });
  const deferredBody = !publicBody.isError ? publicBody.data : undefined;
  const description = free
    ? deferredBodyId
      ? deferredBody?.description
      : publicDescription
    : !access.isError && access.data?.userId === user?.id
      ? access.data?.description
      : "";
  const notesAnalysis = useMemo(
    () => (readerOpen ? analyzeNotes(description ?? "") : { blocks: [], visuals: [] }),
    [description, readerOpen],
  );
  const generatedVisualCount = notesAnalysis.visuals.length;
  const noteDirectives = useMemo(
    () => parseVisualDirectives(description ?? "").directives,
    [description],
  );
  const practiceGroups = useMemo(
    () =>
      readerOpen
        ? notePracticeGroups(
            description ?? "",
            noteDirectives.practice,
            new Set(notesAnalysis.blocks.map((block) => block.sourceLine)),
          )
        : [],
    [readerOpen, description, noteDirectives.practice, notesAnalysis.blocks],
  );
  const practicePlacement = useMemo(() => {
    const byLine = new Map<number, { index: number; topic: string; count: number }[]>();
    const atEnd: { index: number; topic: string; count: number }[] = [];
    practiceGroups.forEach((group, index) => {
      const entry = { index, topic: group.topic, count: group.questions.length };
      if (group.afterLine < 0) atEnd.push(entry);
      else byLine.set(group.afterLine, [...(byLine.get(group.afterLine) ?? []), entry]);
    });
    return { byLine, atEnd };
  }, [practiceGroups]);
  const noteBodyHtml = useMemo(
    () =>
      readerOpen
        ? renderNotesBody(description ?? "", {
            fontScale,
            practiceAfterLines: practicePlacement.byLine,
            practiceAtEnd: practicePlacement.atEnd,
          })
        : "",
    [description, fontScale, readerOpen, practicePlacement],
  );
  useEffect(() => {
    if (!readerOpen || (activePractice !== null && !practiceGroups[activePractice]))
      setActivePractice(null);
    if (!readerOpen || !noteDirectives.followUpTest) setActiveFollowUp(false);
    if (!readerOpen) {
      setFollowUpAutoUsed(false);
      noteScrollPosition.current = 0;
    }
  }, [readerOpen, activePractice, practiceGroups, noteDirectives.followUpTest]);
  useEffect(() => {
    if (readerScroll.current)
      readerScroll.current.scrollTop =
        activePractice === null && !activeFollowUp ? noteScrollPosition.current : 0;
  }, [activePractice, activeFollowUp]);
  const startFollowUp = () => {
    if (!readerOpen || !noteDirectives.followUpTest) return;
    if (batchCourseId) {
      setReaderOpen(false);
      onBatchStartTest?.();
      return;
    }
    noteScrollPosition.current = readerScroll.current?.scrollTop ?? 0;
    setFollowUpAutoUsed(true);
    setActiveFollowUp(true);
  };

  const resolvedUrl = free
    ? deferredBodyId
      ? deferredBody?.file_url
      : fileUrl
    : !access.isError && access.data?.userId === user?.id
      ? access.data?.url
      : null;

  const isInlineDataNote =
    !resolvedUrl || resolvedUrl === "#" || resolvedUrl.startsWith("data:text/html");
  const embeddedPreviewUrl = toEmbeddedMobilePreviewUrl(resolvedUrl);
  const batchVideo = videoSource(access.data?.videoUrl);
  const pdfAttachment = isPdfAttachment(resolvedUrl, materialType);
  const hasReadableNote = Boolean(title || description || isInlineDataNote || embeddedPreviewUrl);

  useEffect(() => {
    setPdfLastPageViewed(false);
  }, [readerOpen, materialId]);
  useEffect(() => {
    if (readerOpen && pdfAttachment) return;
    previewAttempt.current++;
    setBrandedPreviewBytes(null);
    setPreviewLoading(false);
  }, [readerOpen, pdfAttachment]);
  const prepareAttachedPdf = async (output: PdfColourMode = "colour"): Promise<Uint8Array> => {
    if (!resolvedUrl) throw new Error("This PDF is no longer available.");
    // Never reuse an expired signed URL or bypass paid/course access on download.
    let currentUrl: string | null = resolvedUrl;
    if (free && (deferredBodyId || materialId)) {
      const fresh = await getPublicMaterialBody({ data: { id: (deferredBodyId || materialId)! } });
      currentUrl = fresh.file_url;
    } else if (!free && materialId) {
      const fresh = await access.refetch();
      if (fresh.error || !fresh.data || fresh.data.userId !== user?.id)
        throw new Error("Your access to this note expired. Sign in and try again.");
      currentUrl = fresh.data.url;
    }
    if (!isPdfAttachment(currentUrl, materialType))
      throw new Error("The attachment is no longer a PDF; no download started.");
    const { fetchPdfForBranding, brandPdfBytes } = await import("@/lib/pdf-brand");
    return brandPdfBytes(await fetchPdfForBranding(currentUrl!), {
      mode: output,
      onProgress: (page, total) =>
        setPdfStatus(`Preparing grayscale print · page ${page}/${total}`),
    });
  };

  const loadBrandedPreview = async () => {
    if (previewLoading || brandedPreviewBytes) return;
    const attempt = ++previewAttempt.current;
    setPreviewLoading(true);
    try {
      const bytes = await prepareAttachedPdf();
      if (attempt !== previewAttempt.current) return; // reader closed or access revoked
      setBrandedPreviewBytes(bytes);
    } catch (error) {
      if (attempt === previewAttempt.current) toast.error(friendlyError(error));
    } finally {
      if (attempt === previewAttempt.current) setPreviewLoading(false);
    }
  };

  const copyAttachedPdf = async (intent: "download" | "print") => {
    if (!resolvedUrl || brandingPdf) return;
    // Reserve the tab before awaiting network/PDF work; mobile browsers block late pop-ups.
    const tab = intent === "print" ? window.open("", "_blank") : null;
    if (intent === "print" && !tab) {
      toast.error("Allow pop-ups to print the KKCC PDF.");
      return;
    }
    if (tab) {
      tab.opener = null;
      tab.document.title = "Preparing KKCC PDF";
      tab.document.body.textContent = "Checking access and adding the KKCC mark to every page…";
    }
    setBrandingPdf(true);
    try {
      const bytes = await prepareAttachedPdf(intent === "print" ? "black-white" : "colour");
      if (intent === "download") {
        downloadFile(bytes, `${safeFilename(title || "Study Note")}-KKCC.pdf`, "application/pdf");
        toast.success("Colour KKCC PDF downloaded. Original file unchanged.");
      } else if (tab && !tab.closed) {
        showBrandedPdfPrintTab(tab, bytes, title || "Study Note");
        toast.success("Grayscale KKCC print copy is ready in the new tab.");
      }
    } catch (error) {
      const message = friendlyError(error);
      if (tab && !tab.closed) tab.document.body.textContent = message;
      toast.error(message);
    } finally {
      setBrandingPdf(false);
      setPdfStatus("");
    }
  };

  if (!free && user && access.isPending)
    return (
      <Button size="sm" variant="outline" className={`${className} rounded-full`} disabled>
        <Loader2 className="mr-1.5 h-3.5 w-3.5 animate-spin" />
        Checking note access…
      </Button>
    );

  /*
   * Paid notes, not unlocked yet: the student gets the exact same checkout as a
   * Batch or Test Series — Razorpay online, 23KAAT coins, or "contact Admin for
   * offline payment" when online payment is switched off.
   */
  const priceInr = Math.max(0, Number(price ?? 0));
  const coins = Math.max(0, Number(coinPrice ?? 0));
  if (!free && mode === "paid" && !resolvedUrl && materialId) {
    const hasIndividualPrice = priceInr > 0 || coins > 0;
    return (
      <div className={`flex flex-col gap-2 ${className}`}>
        {hasIndividualPrice ? (
          <Button asChild size="sm" className="w-full rounded-full font-semibold">
            <Link to="/checkout" search={{ note: materialId }}>
              <Lock className="mr-1.5 h-3.5 w-3.5" />
              Buy this note
              {priceInr > 0 ? ` — ₹${priceInr}` : ""}
              {priceInr > 0 && coins > 0 ? " · " : ""}
              {coins > 0 ? `${coins} 23KAAT` : ""}
            </Link>
          </Button>
        ) : notesSeriesId ? (
          <Button asChild size="sm" className="w-full rounded-full font-semibold">
            <Link to="/checkout" search={{ notes_series: notesSeriesId }}>
              <Lock className="mr-1.5 h-3.5 w-3.5" />
              Buy the complete Notes Series (notes only)
            </Link>
          </Button>
        ) : batchCourseSlug ? (
          <Button asChild size="sm" className="w-full rounded-full font-semibold">
            <Link to="/checkout" search={{ course: batchCourseSlug }}>
              <Lock className="mr-1.5 h-3.5 w-3.5" />
              Buy {batchCourseTitle || "the Batch"} (notes + videos)
            </Link>
          </Button>
        ) : (
          <Button size="sm" className="w-full rounded-full font-semibold" disabled>
            Individual note price not set
          </Button>
        )}
        {hasIndividualPrice && (
          <p className="text-[11px] text-muted-foreground">
            Individual purchase unlocks this note only. A Notes Series or Batch purchase is
            separate.
          </p>
        )}
        {hasIndividualPrice && notesSeriesId && (
          <Button asChild size="sm" variant="outline" className="w-full rounded-full">
            <Link to="/checkout" search={{ notes_series: notesSeriesId }}>
              Buy the complete Notes Series (notes only)
            </Link>
          </Button>
        )}
        {hasIndividualPrice && batchCourseSlug && (
          <Button asChild size="sm" variant="outline" className="w-full rounded-full">
            <Link to="/checkout" search={{ course: batchCourseSlug }}>
              Buy {batchCourseTitle || "the Batch"} (notes + videos)
            </Link>
          </Button>
        )}
        {!hasIndividualPrice && notesSeriesId && batchCourseSlug && (
          <Button asChild size="sm" variant="outline" className="w-full rounded-full">
            <Link to="/checkout" search={{ course: batchCourseSlug }}>
              Buy {batchCourseTitle || "the Batch"} (notes + videos)
            </Link>
          </Button>
        )}
        {!hasIndividualPrice && (notesSeriesId || batchCourseSlug) && (
          <p className="text-[11px] text-muted-foreground">
            This note has no separate individual price. You can still buy the complete{" "}
            {notesSeriesId ? "Notes Series" : "Batch"} to unlock it as part of that product.
          </p>
        )}
        {!hasIndividualPrice && !notesSeriesId && !batchCourseSlug && (
          <p className="text-[11px] text-amber-700 dark:text-amber-300">
            Ask Admin to set an INR or 23KAAT price before this note can be purchased individually.
          </p>
        )}
      </div>
    );
  }

  if (batchCourseId && !resolvedUrl) {
    return (
      <div className={`flex flex-col gap-2 ${className}`}>
        {batchCourseSlug ? (
          <Button asChild size="sm" className="w-full rounded-full font-semibold">
            <Link to="/checkout" search={{ course: batchCourseSlug }}>
              <Lock className="mr-1.5 h-3.5 w-3.5" />
              Unlock notes and videos with {batchCourseTitle || "the full batch"}
            </Link>
          </Button>
        ) : (
          <Button asChild size="sm" className="w-full rounded-full font-semibold">
            <Link to="/courses">
              <Lock className="mr-1.5 h-3.5 w-3.5" />
              View batch access
            </Link>
          </Button>
        )}
        <p className="text-[11px] text-muted-foreground">
          Buying the batch opens every note and linked lesson video in this series.
        </p>
      </div>
    );
  }

  if (free || resolvedUrl) {
    return (
      <>
        <div className={`flex flex-wrap items-center gap-2 ${className}`}>
          {hasReadableNote ? (
            <Button
              type="button"
              size="sm"
              variant="default"
              className="flex-1 rounded-full font-semibold"
              onClick={() => {
                if (!free) void access.refetch();
                setReaderOpen(true);
              }}
            >
              <BookOpen className="mr-1.5 h-3.5 w-3.5" />
              Read Notes
            </Button>
          ) : null}
          {pdfAttachment ? (
            <>
              <Button
                type="button"
                size="sm"
                variant="outline"
                disabled={brandingPdf}
                className="flex-1 rounded-full font-semibold"
                onClick={() => void copyAttachedPdf("download")}
              >
                {brandingPdf ? (
                  <Loader2 className="mr-1.5 h-3.5 w-3.5 animate-spin" />
                ) : (
                  <Download className="mr-1.5 h-3.5 w-3.5" />
                )}
                Download KKCC PDF
              </Button>
              <Button
                type="button"
                size="sm"
                variant="outline"
                disabled={brandingPdf}
                className="rounded-full font-semibold"
                onClick={() => void copyAttachedPdf("print")}
              >
                <Printer className="mr-1.5 h-3.5 w-3.5" />
                Print KKCC PDF
              </Button>
            </>
          ) : !isInlineDataNote && resolvedUrl ? (
            <Button
              asChild
              size="sm"
              variant="outline"
              className="flex-1 rounded-full font-semibold"
            >
              <a href={resolvedUrl} target="_blank" rel="noopener noreferrer">
                <ExternalLink className="mr-1.5 h-3.5 w-3.5" />
                Open external/original file
              </a>
            </Button>
          ) : (
            <Button
              type="button"
              size="sm"
              variant="outline"
              className="rounded-full font-semibold"
              onClick={() => {
                if (deferredBodyId && !deferredBody) {
                  setReaderOpen(true);
                  return;
                }
                openPrintableNoteWindow({
                  title: title || "KKCC Study Note",
                  subject,
                  chapter,
                  materialType,
                  description,
                  fontScale,
                });
              }}
            >
              <Printer className="mr-1.5 h-3.5 w-3.5" />
              {deferredBodyId && !deferredBody ? "Load note / PDF" : "Print / PDF"}
            </Button>
          )}
        </div>
        <p className="mt-2 text-xs text-muted-foreground">
          Screen / download: colour. Print: automatic grayscale with a faint KKCC centre logo.
          {pdfStatus && <span role="status"> {pdfStatus}</span>}
        </p>

        {readerOpen ? (
          <div
            className="fixed inset-0 z-50 flex items-end justify-center bg-black/75 p-0 backdrop-blur-sm sm:items-center sm:p-4"
            onClick={() => setReaderOpen(false)}
          >
            <div
              className="relative flex h-[100dvh] w-full max-w-full flex-col overflow-hidden rounded-none border-0 bg-background shadow-2xl sm:h-auto sm:max-h-[90vh] sm:max-w-3xl sm:rounded-3xl sm:border"
              onClick={(e) => e.stopPropagation()}
            >
              {/* Sticky Mobile-First Header */}
              <div className="sticky top-0 z-10 flex items-start justify-between gap-2 border-b bg-background/95 px-4 py-3 backdrop-blur sm:px-6 sm:py-4">
                <div className="min-w-0 flex-1">
                  <div className="flex flex-wrap items-center gap-1.5">
                    <Badge variant="secondary" className="rounded-full text-[11px]">
                      {materialType || "Study Notes"}
                    </Badge>
                    {subject ? (
                      <Badge variant="outline" className="rounded-full text-[11px]">
                        {subject}
                      </Badge>
                    ) : null}
                    {chapter ? (
                      <Badge variant="outline" className="rounded-full text-[11px]">
                        {chapter}
                      </Badge>
                    ) : null}
                  </div>
                  <h2 className="mt-1.5 break-words text-base font-black leading-snug sm:text-xl">
                    {title || "Study Note"}
                  </h2>
                </div>
                <div className="flex shrink-0 items-center gap-1">
                  <Button
                    type="button"
                    size="sm"
                    variant="outline"
                    className="h-8 rounded-full px-2.5 text-xs font-bold"
                    onClick={() => changeFont(-1)}
                    title="Decrease text size"
                  >
                    A-
                  </Button>
                  <Button
                    type="button"
                    size="sm"
                    variant="outline"
                    className="h-8 rounded-full px-2.5 text-xs font-bold"
                    onClick={() => changeFont(1)}
                    title="Increase text size"
                  >
                    A+
                  </Button>
                  <Button
                    type="button"
                    size="icon"
                    variant="ghost"
                    className="h-8 w-8 rounded-full"
                    onClick={() => setReaderOpen(false)}
                    aria-label="Close note reader"
                  >
                    <X className="h-4 w-4" />
                  </Button>
                </div>
              </div>

              {/* Scrollable Mobile-Responsive Body */}
              <div
                ref={readerScroll}
                className="flex-1 overflow-y-auto overflow-x-hidden px-4 py-4 sm:px-6"
              >
                {activeFollowUp && noteDirectives.followUpTest ? (
                  <NoteFollowUpTest
                    key={`${materialId ?? "note"}-${noteDirectives.followUpTest.title}`}
                    test={noteDirectives.followUpTest}
                    onBack={() => setActiveFollowUp(false)}
                  />
                ) : activePractice !== null && practiceGroups[activePractice] ? (
                  <NotePracticeQuiz
                    key={practiceGroups[activePractice].key}
                    group={practiceGroups[activePractice]}
                    materialId={materialId}
                    persistResults={!batchCourseId}
                    onBack={() => setActivePractice(null)}
                  />
                ) : (
                  <>
                    {free && deferredBodyId && publicBody.isFetching && (
                      <p role="status" className="rounded-xl bg-muted p-6 text-sm">
                        Loading note…
                      </p>
                    )}
                    {free && deferredBodyId && publicBody.isError && (
                      <div role="alert" className="p-4 text-sm">
                        This note could not be loaded. It may require access or have been removed.{" "}
                        <Button variant="outline" onClick={() => void publicBody.refetch()}>
                          Retry note
                        </Button>
                      </div>
                    )}
                    {batchCourseId && batchVideo.kind !== "none" && (
                      <section className="mb-4 overflow-hidden rounded-2xl border bg-muted/10">
                        <h3 className="px-4 py-3 text-sm font-semibold">Batch lesson video</h3>
                        {batchVideo.kind === "file" ? (
                          <video
                            src={batchVideo.src}
                            controls
                            playsInline
                            preload="metadata"
                            className="aspect-video w-full bg-black"
                          />
                        ) : (
                          <iframe
                            src={batchVideo.src}
                            title={`${title || "Notes"} lesson video`}
                            allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
                            allowFullScreen
                            referrerPolicy="strict-origin-when-cross-origin"
                            className="aspect-video w-full border-0"
                          />
                        )}
                        {batchVideo.kind === "external" && (
                          <a
                            href={batchVideo.original}
                            target="_blank"
                            rel="noopener noreferrer"
                            className="block px-4 py-2 text-xs font-medium text-primary underline"
                          >
                            Open video on its original site
                          </a>
                        )}
                      </section>
                    )}
                    {description ? (
                      <>
                        <div className="mb-2 flex flex-wrap items-center gap-1.5 text-[11px] font-semibold text-muted-foreground">
                          <Sparkles className="h-3.5 w-3.5 text-primary" />
                          <span>
                            {generatedVisualCount
                              ? `${describeVisuals(notesAnalysis.visuals.map((entry) => entry.spec))} auto-generated from the text`
                              : "Add steps, points or numbers in the notes to auto-generate diagrams"}
                          </span>
                        </div>
                        <div
                          className="kkcc-note-reader rounded-2xl border bg-card p-4 leading-relaxed text-foreground sm:p-5"
                          dangerouslySetInnerHTML={{ __html: noteBodyHtml }}
                          onClick={(event) => {
                            const target = event.target;
                            if (!(target instanceof Element)) return;
                            const button = target.closest<HTMLElement>(
                              "[data-note-practice-group]",
                            );
                            if (!button || !event.currentTarget.contains(button)) return;
                            const index = Number(button.dataset["notePracticeGroup"]);
                            if (!Number.isSafeInteger(index) || !practiceGroups[index]) return;
                            noteScrollPosition.current = readerScroll.current?.scrollTop ?? 0;
                            setActivePractice(index);
                          }}
                        />
                      </>
                    ) : null}

                    {pdfAttachment ? (
                      <div className="mt-3 overflow-hidden rounded-2xl border bg-muted/10">
                        {brandedPreviewBytes ? (
                          <Suspense
                            fallback={<p className="p-4 text-sm">Opening branded PDF reader…</p>}
                          >
                            <BrandedPdfPreview
                              bytes={brandedPreviewBytes}
                              onLastPageViewed={
                                noteDirectives.followUpTest ? setPdfLastPageViewed : undefined
                              }
                            />
                          </Suspense>
                        ) : (
                          <div className="space-y-2 p-4 text-sm">
                            <p>
                              Preview the attached PDF with KKCC branding. The original is not
                              changed.
                            </p>
                            <Button
                              type="button"
                              variant="outline"
                              size="sm"
                              disabled={previewLoading}
                              onClick={() => void loadBrandedPreview()}
                            >
                              {previewLoading
                                ? "Preparing branded preview…"
                                : "Preview branded PDF"}
                            </Button>
                            <p className="text-xs text-muted-foreground">
                              External hosts may block access; use the original link only if you
                              accept an unbranded file.
                            </p>
                          </div>
                        )}
                      </div>
                    ) : embeddedPreviewUrl ? (
                      <div className="mt-3 overflow-hidden rounded-2xl border bg-muted/10">
                        <iframe
                          src={embeddedPreviewUrl}
                          loading="lazy"
                          title={title || "Study Note Document"}
                          className="h-[62dvh] w-full border-0 sm:h-[480px]"
                        />
                      </div>
                    ) : !description ? (
                      <div
                        style={{ fontSize: `${fontScale}px` }}
                        className="whitespace-pre-wrap break-words rounded-2xl border bg-muted/20 p-4 leading-relaxed text-foreground sm:p-5"
                      >
                        {`${title || "Study Note"}\n\nSubject: ${subject || "General"}\nChapter: ${chapter || "Core Concepts"}\n\nUse the Print / Save PDF or Open File button below to view or save a copy for revision.`}
                      </div>
                    ) : null}
                    {description &&
                      noteDirectives.followUpTest &&
                      (batchCourseId ? (
                        <div className="mt-4 rounded-2xl border border-primary/30 bg-primary/5 p-4">
                          <p className="mb-2 text-sm font-semibold">
                            Ready to practise? Batch results are shown here, never saved.
                          </p>
                          <Button type="button" size="sm" onClick={startFollowUp}>
                            Start Batch Test
                          </Button>
                        </div>
                      ) : (
                        <NoteFollowUpGate
                          test={noteDirectives.followUpTest}
                          scrollRoot={readerScroll}
                          autoEnabled={!followUpAutoUsed && (!pdfAttachment || pdfLastPageViewed)}
                          waitingForPdf={pdfAttachment && !pdfLastPageViewed}
                          onStart={startFollowUp}
                        />
                      ))}
                  </>
                )}
              </div>

              {/* Sticky Mobile-First Footer */}
              <div className="sticky bottom-0 z-10 flex flex-wrap items-center justify-between gap-2 border-t bg-background/95 px-4 py-3 pb-[max(0.75rem,env(safe-area-inset-bottom))] backdrop-blur sm:px-6 sm:py-4">
                <p className="w-full text-xs text-muted-foreground sm:w-auto">
                  Colour on screen · print grayscale + faint KKCC logo
                  {pdfStatus && <span role="status"> · {pdfStatus}</span>}
                </p>
                <div className="flex flex-wrap gap-2">
                  {(!pdfAttachment || Boolean(description?.trim())) && (
                    <Button
                      type="button"
                      size="sm"
                      className="rounded-full font-bold"
                      disabled={Boolean(free && deferredBodyId && !deferredBody)}
                      onClick={() =>
                        openPrintableNoteWindow({
                          title: title || "KKCC Study Note",
                          subject,
                          chapter,
                          materialType,
                          description,
                          fontScale,
                        })
                      }
                    >
                      <Printer className="mr-1.5 h-3.5 w-3.5" />
                      Print / Save as PDF
                    </Button>
                  )}
                  {pdfAttachment && (
                    <>
                      <Button
                        type="button"
                        size="sm"
                        variant="outline"
                        className="rounded-full"
                        disabled={brandingPdf}
                        onClick={() => void copyAttachedPdf("download")}
                      >
                        <Download className="mr-1.5 h-3.5 w-3.5" />
                        Download KKCC PDF
                      </Button>
                      <Button
                        type="button"
                        size="sm"
                        variant="outline"
                        className="rounded-full"
                        disabled={brandingPdf}
                        onClick={() => void copyAttachedPdf("print")}
                      >
                        <Printer className="mr-1.5 h-3.5 w-3.5" />
                        Print KKCC PDF
                      </Button>
                    </>
                  )}
                  <Button
                    type="button"
                    size="sm"
                    variant="outline"
                    className="rounded-full"
                    onClick={async () => {
                      await navigator.clipboard.writeText(
                        `${title || "KKCC Note"}\n\n${parseVisualDirectives(description ?? "").text}`,
                      );
                      toast.success("Notes copied to clipboard!");
                    }}
                  >
                    <Copy className="mr-1.5 h-3.5 w-3.5" />
                    Copy Notes
                  </Button>
                  {!isInlineDataNote && resolvedUrl ? (
                    <Button asChild size="sm" variant="secondary" className="rounded-full">
                      <a href={resolvedUrl} target="_blank" rel="noopener noreferrer">
                        <ExternalLink className="mr-1.5 h-3.5 w-3.5" />
                        {pdfAttachment ? "Open original (unbranded)" : "Open Original File"}
                      </a>
                    </Button>
                  ) : null}
                </div>
                <Button
                  type="button"
                  size="sm"
                  variant="ghost"
                  className="rounded-full"
                  onClick={() => setReaderOpen(false)}
                >
                  Close
                </Button>
              </div>
            </div>
          </div>
        ) : null}
      </>
    );
  }

  if (!free && access.isPending && user)
    return (
      <Button size="sm" variant="outline" className={`${className} rounded-full`} disabled>
        <Loader2 className="mr-1.5 h-3.5 w-3.5 animate-spin" />
        Checking resource access…
      </Button>
    );
  const error = access.error?.message || "";
  if (error && !/ACCESS_REQUIRED/.test(error))
    return (
      <div className={className}>
        <p role="alert" className="text-xs text-destructive">
          {friendlyError(access.error)}
        </p>
        <Button size="sm" variant="outline" onClick={() => void access.refetch()}>
          Retry resource access
        </Button>
      </div>
    );
  if (!batchCourseId && mode === "paid" && materialId)
    return (
      <Button
        size="sm"
        className={`${className} rounded-full`}
        disabled={loading}
        onClick={async () => {
          setLoading(true);
          try {
            await spendCoins({ data: { material_id: materialId } });
            await invalidateLearningQueries(client);
            await access.refetch();
            toast.success("Material access verified. Use Read Notes to view it.");
            window.dispatchEvent(new Event("kkcc:23kaat-refresh"));
          } catch (error) {
            toast.error(friendlyError(error));
          } finally {
            setLoading(false);
          }
        }}
      >
        {loading ? (
          <Loader2 className="mr-1.5 h-3.5 w-3.5 animate-spin" />
        ) : (
          <KaatCoin size="xs" className="mr-1.5" />
        )}
        Unlock {coinPriceOf({ price, coin_price: coinPrice })} 23KAAT
      </Button>
    );
  return (
    <Button size="sm" variant="outline" className={`${className} rounded-full`} disabled>
      <Lock className="mr-1.5 h-3.5 w-3.5" />
      Course enrollment required
    </Button>
  );
}
