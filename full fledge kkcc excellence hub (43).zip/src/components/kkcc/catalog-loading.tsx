import { SiteLayout } from "./site-layout";
import { Skeleton } from "@/components/ui/skeleton";

export function CatalogLoading() {
  return (
    <SiteLayout>
      <section
        aria-busy="true"
        aria-label="Loading catalogue"
        className="mx-auto w-full max-w-7xl px-4 py-8 sm:px-6"
      >
        <p role="status" className="sr-only">
          Loading catalogue…
        </p>
        <Skeleton className="h-8 w-56 max-w-full" />
        <Skeleton className="mb-8 mt-4 h-4 w-80 max-w-full" />
        <div className="grid gap-5 sm:grid-cols-2 lg:grid-cols-3">
          {Array.from({ length: 6 }, (_, index) => (
            <Skeleton key={index} className="h-64 rounded-2xl" />
          ))}
        </div>
      </section>
    </SiteLayout>
  );
}
