import { MultilingualNoteInput } from "./multilingual-note-input";
import { useEffect, useRef, useState } from "react";
import { toast } from "sonner";
import {
  Copy,
  Download,
  Eraser,
  Highlighter,
  ImagePlus,
  Loader2,
  Pen,
  Plus,
  RotateCcw,
  Save,
  Trash2,
  X,
} from "lucide-react";
import { PDFDocument } from "pdf-lib";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { downloadFile } from "@/lib/document-studio";
import { brandPdfBytes, type PdfColourMode } from "@/lib/pdf-brand";
import {
  DEFAULT_NOTE_PAGE,
  NOTE_PAGE_PRESETS,
  STARTER_CUSTOM_NOTE_PAGE,
  notePageLayout,
  notePagePixels,
  paintNotePage,
  validNotePageSize,
  type NotePageLayout,
  type NotePagePreset,
  type NotePaperPattern,
} from "@/lib/note-page";

type Tool = "pen" | "highlighter" | "eraser" | "line" | "rectangle" | "ellipse" | "select";
type Point = { x: number; y: number };
type Box = { x: number; y: number; width: number; height: number };
type Page = {
  id: string;
  preset: NotePagePreset;
  layout: NotePageLayout;
  /** Transparent foreground: erasing ink never destroys the paper/template. */
  ink: string | null;
  /** Resized local raster template; embedded in the exported page, not CSS-only. */
  template: string | null;
  caption: string;
  touched: boolean;
};
export type HandwrittenNotePage = {
  /** Local JPEG bytes; do not fetch a data: URL (production connect-src blocks it). */
  blob: Blob;
  caption: string;
  widthMm: number;
  heightMm: number;
};
export type NotesCanvasEditorProps = {
  /** Upload all pages before modifying the note draft; an incomplete upload cannot publish half a note. */
  onInsertPages: (pages: HandwrittenNotePage[]) => Promise<void> | void;
  onClose: () => void;
  /** The visible Custom page shortcut starts with editable mm dimensions in view. */
  startInCustomPage?: boolean;
};
const MAX_PAGES = 12;
const MAX_HISTORY = 8;
const INK_COLOURS = [
  ["Black", "#172b36"],
  ["Blue", "#1d4ed8"],
  ["Red", "#b91c1c"],
  ["Green", "#047857"],
  ["Purple", "#7e22ce"],
  ["Orange", "#c2410c"],
  ["Yellow", "#f3c43c"],
] as const;
const PAPER_COLOURS = [
  ["White", "#ffffff"],
  ["Cream", "#fffdf2"],
  ["Blue", "#f5faff"],
  ["Peach", "#fcf7f1"],
  ["Mint", "#f4fbf5"],
] as const;
function pageId() {
  return typeof crypto !== "undefined" && "randomUUID" in crypto
    ? crypto.randomUUID()
    : `page-${Date.now()}-${Math.random()}`;
}
function blankPage(from?: Page, startCustom = false): Page {
  return {
    id: pageId(),
    preset: from?.preset ?? (startCustom ? "custom" : "a4"),
    layout: { ...(from?.layout ?? (startCustom ? STARTER_CUSTOM_NOTE_PAGE : DEFAULT_NOTE_PAGE)) },
    ink: null,
    template: from?.template ?? null,
    caption: "",
    touched: false,
  };
}
function copyCanvas(canvas: HTMLCanvasElement): HTMLCanvasElement {
  const copy = document.createElement("canvas");
  copy.width = canvas.width;
  copy.height = canvas.height;
  copy.getContext("2d")!.drawImage(canvas, 0, 0);
  return copy;
}
function loadImage(src: string): Promise<HTMLImageElement> {
  return new Promise((resolve, reject) => {
    const image = new Image();
    image.onload = () => resolve(image);
    image.onerror = () => reject(new Error("Page image could not be loaded. Nothing was saved."));
    image.src = src;
  });
}
function rectBetween(a: Point, b: Point): Box {
  return {
    x: Math.min(a.x, b.x),
    y: Math.min(a.y, b.y),
    width: Math.abs(b.x - a.x),
    height: Math.abs(b.y - a.y),
  };
}
function paintShape(
  ctx: CanvasRenderingContext2D,
  tool: Tool,
  start: Point,
  end: Point,
  colour: string,
  size: number,
) {
  ctx.save();
  ctx.strokeStyle = colour;
  ctx.lineWidth = size * 1.6;
  ctx.lineJoin = "round";
  ctx.beginPath();
  if (tool === "line") {
    ctx.moveTo(start.x, start.y);
    ctx.lineTo(end.x, end.y);
  } else {
    const rect = rectBetween(start, end);
    if (tool === "rectangle") ctx.rect(rect.x, rect.y, rect.width, rect.height);
    else
      ctx.ellipse(
        rect.x + rect.width / 2,
        rect.y + rect.height / 2,
        Math.max(0.1, rect.width / 2),
        Math.max(0.1, rect.height / 2),
        0,
        0,
        Math.PI * 2,
      );
  }
  ctx.stroke();
  ctx.restore();
}
type Gesture =
  | { kind: "draw"; last: Point }
  | { kind: "shape"; start: Point; base: HTMLCanvasElement; tool: Tool }
  | { kind: "select"; start: Point }
  | { kind: "move"; start: Point; box: Box; base: HTMLCanvasElement; cut: HTMLCanvasElement };

/** A mobile-friendly, in-note multi-page drawing composer; ink is editable until saved. */
export function NotesCanvasEditor({
  onInsertPages,
  onClose,
  startInCustomPage = false,
}: NotesCanvasEditorProps) {
  const initial = useRef<Page[]>([blankPage(undefined, startInCustomPage)]);
  const [settingsOpen, setSettingsOpen] = useState(startInCustomPage);
  const pagesRef = useRef(initial.current);
  const [pages, setPages] = useState(initial.current);
  const indexRef = useRef(0);
  const [index, setIndex] = useState(0);
  const active = pages[index]!;
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const photoRef = useRef<HTMLInputElement>(null);
  const templateRef = useRef<HTMLInputElement>(null);
  const history = useRef(new Map<string, string[]>());
  const future = useRef(new Map<string, string[]>());
  const gesture = useRef<Gesture | null>(null);
  const loadGeneration = useRef(0);
  const [tool, setTool] = useState<Tool>("pen");
  const [penColour, setPenColour] = useState("#172b36");
  const [markerColour, setMarkerColour] = useState("#f3c43c");
  const [size, setSize] = useState(4);
  const [zoom, setZoom] = useState(100);
  const [stylusOnly, setStylusOnly] = useState(false);
  const [textToPlace, setTextToPlace] = useState("");
  const [placingText, setPlacingText] = useState(false);
  const [selectedBox, setSelectedBox] = useState<Box | null>(null);
  const [backgroundUrl, setBackgroundUrl] = useState("");
  const [saving, setSaving] = useState(false);
  const [status, setStatus] = useState("");
  const [saveError, setSaveError] = useState("");
  const [pageLoading, setPageLoading] = useState(false);
  const [dirty, setDirty] = useState(false);
  const [pdfMode, setPdfMode] = useState<PdfColourMode>("colour");
  const colour = tool === "highlighter" ? markerColour : penColour;
  const pixels = notePagePixels(active.layout);
  const commit = (next: Page[]) => {
    pagesRef.current = next;
    setPages(next);
  };
  const preserve = (): Page[] => {
    const canvas = canvasRef.current;
    const next = [...pagesRef.current];
    if (canvas && next[indexRef.current] && !pageLoading) {
      next[indexRef.current] = { ...next[indexRef.current]!, ink: canvas.toDataURL("image/png") };
      commit(next);
    }
    return next;
  };
  const modify = (change: (page: Page) => Page) => {
    const next = [...pagesRef.current];
    next[indexRef.current] = change(next[indexRef.current]!);
    commit(next);
    setDirty(true);
  };
  const canvasContext = () => canvasRef.current?.getContext("2d") ?? null;
  const remember = () => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const list = history.current.get(active.id) ?? [];
    list.push(canvas.toDataURL("image/png"));
    history.current.set(active.id, list.slice(-MAX_HISTORY));
    future.current.set(active.id, []);
  };

  // Switching/resizing pages restores only the transparent drawing layer.
  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const generation = ++loadGeneration.current;
    let disposed = false;
    const page = pagesRef.current[index];
    if (!page) return;
    const { width, height } = notePagePixels(page.layout);
    setPageLoading(Boolean(page.ink));
    canvas.width = width;
    canvas.height = height;
    if (page.ink)
      void loadImage(page.ink)
        .then((image) => {
          if (disposed || generation !== loadGeneration.current || !canvasRef.current) return;
          canvas.getContext("2d")?.drawImage(image, 0, 0, width, height);
          setPageLoading(false);
        })
        .catch(() => {
          if (!disposed && generation === loadGeneration.current)
            setStatus("Could not restore this page. Close without saving and try again.");
        });
    return () => {
      disposed = true;
    };
  }, [index, active.id, active.layout.widthMm, active.layout.heightMm]);

  // The SAME paper renderer is used in the visible editor and the exported JPEG/PDF.
  useEffect(() => {
    let valid = true;
    const layout = active.layout;
    const template = active.template;
    if (layout.pattern === "blank" && !template) {
      setBackgroundUrl("");
      return;
    }
    void (async () => {
      const surface = document.createElement("canvas");
      const { width, height } = notePagePixels(layout);
      surface.width = width;
      surface.height = height;
      paintNotePage(
        surface.getContext("2d")!,
        width,
        height,
        layout,
        template ? await loadImage(template) : undefined,
      );
      if (valid) setBackgroundUrl(surface.toDataURL("image/png"));
      surface.width = surface.height = 0;
    })().catch(() => {
      if (valid) setStatus("Background could not load. Choose another template.");
    });
    return () => {
      valid = false;
    };
  }, [index, active.id, active.layout, active.template]);

  const switchPage = (nextIndex: number) => {
    if (nextIndex === indexRef.current || nextIndex < 0 || nextIndex >= pagesRef.current.length)
      return;
    preserve();
    gesture.current = null;
    setSelectedBox(null);
    indexRef.current = nextIndex;
    setIndex(nextIndex);
  };
  const addPage = (duplicate = false) => {
    const stored = preserve();
    if (stored.length >= MAX_PAGES) {
      toast.error(`Ek note mein maximum ${MAX_PAGES} drawing pages rakhein.`);
      return;
    }
    const source = stored[indexRef.current]!;
    const next = duplicate
      ? { ...source, id: pageId(), caption: `${source.caption || "Page"} (copy)` }
      : blankPage(source);
    const at = indexRef.current + 1;
    commit([...stored.slice(0, at), next, ...stored.slice(at)]);
    indexRef.current = at;
    setIndex(at);
    setSelectedBox(null);
    setDirty(true);
  };
  const removePage = () => {
    if (pagesRef.current.length < 2) return;
    if (
      !window.confirm("Delete this unsaved page? Other pages and the saved note remain unchanged.")
    )
      return;
    const stored = preserve();
    const current = indexRef.current;
    history.current.delete(stored[current]!.id);
    future.current.delete(stored[current]!.id);
    const next = stored.filter((_, i) => i !== current);
    const nextIndex = Math.min(current, next.length - 1);
    commit(next);
    indexRef.current = nextIndex;
    setIndex(nextIndex);
    setSelectedBox(null);
    setDirty(true);
  };
  const movePage = (offset: number) => {
    const current = indexRef.current;
    const nextIndex = current + offset;
    if (nextIndex < 0 || nextIndex >= pagesRef.current.length) return;
    const stored = preserve();
    [stored[current], stored[nextIndex]] = [stored[nextIndex]!, stored[current]!];
    commit([...stored]);
    indexRef.current = nextIndex;
    setIndex(nextIndex);
    setDirty(true);
  };
  const resizePage = (widthMm: number, heightMm: number, preset: NotePagePreset = "custom") => {
    if (!validNotePageSize({ widthMm, heightMm })) {
      toast.error("Page 90–420 mm wide aur 90–594 mm tall rakhein.");
      return false;
    }
    preserve();
    modify((page) => ({
      ...page,
      preset,
      layout: notePageLayout({ ...page.layout, widthMm, heightMm }),
    }));
    return true;
  };
  const updateLayout = (patch: Partial<NotePageLayout>) =>
    modify((page) => ({ ...page, layout: notePageLayout({ ...page.layout, ...patch }) }));
  const pointOf = (event: React.PointerEvent<HTMLCanvasElement>): Point => {
    const canvas = event.currentTarget;
    const rect = canvas.getBoundingClientRect();
    return {
      x: Math.max(
        0,
        Math.min(canvas.width, ((event.clientX - rect.left) / rect.width) * canvas.width),
      ),
      y: Math.max(
        0,
        Math.min(canvas.height, ((event.clientY - rect.top) / rect.height) * canvas.height),
      ),
    };
  };
  const startStroke = (event: React.PointerEvent<HTMLCanvasElement>) => {
    if (saving || pageLoading || (stylusOnly && event.pointerType === "touch")) return;
    const ctx = canvasContext();
    const canvas = canvasRef.current;
    if (!ctx || !canvas) return;
    event.preventDefault();
    event.currentTarget.setPointerCapture(event.pointerId);
    const start = pointOf(event);
    if (placingText && textToPlace.trim()) {
      remember();
      ctx.save();
      ctx.fillStyle = penColour;
      ctx.font = `${Math.max(20, size * 6)}px sans-serif`;
      textToPlace
        .split("\n")
        .forEach((line, i) => ctx.fillText(line, start.x, start.y + i * Math.max(26, size * 7)));
      ctx.restore();
      setPlacingText(false);
      modify((page) => ({ ...page, touched: true }));
      return;
    }
    if (tool === "select") {
      const box = selectedBox;
      if (
        box &&
        start.x >= box.x &&
        start.x <= box.x + box.width &&
        start.y >= box.y &&
        start.y <= box.y + box.height
      ) {
        remember();
        const cut = document.createElement("canvas");
        cut.width = Math.max(1, Math.ceil(box.width));
        cut.height = Math.max(1, Math.ceil(box.height));
        cut
          .getContext("2d")!
          .drawImage(canvas, box.x, box.y, box.width, box.height, 0, 0, cut.width, cut.height);
        const base = copyCanvas(canvas);
        base.getContext("2d")!.clearRect(box.x, box.y, box.width, box.height);
        gesture.current = { kind: "move", start, box, base, cut };
      } else {
        gesture.current = { kind: "select", start };
        setSelectedBox(null);
      }
      return;
    }
    remember();
    if (tool === "line" || tool === "rectangle" || tool === "ellipse") {
      gesture.current = { kind: "shape", start, base: copyCanvas(canvas), tool };
      return;
    }
    gesture.current = { kind: "draw", last: start };
    ctx.save();
    ctx.lineCap = "round";
    ctx.lineJoin = "round";
    ctx.globalCompositeOperation = tool === "eraser" ? "destination-out" : "source-over";
    ctx.globalAlpha = tool === "highlighter" ? 0.34 : 1;
    ctx.strokeStyle = colour;
    ctx.lineWidth = tool === "highlighter" ? size * 4 : tool === "eraser" ? size * 6 : size * 1.6;
    ctx.beginPath();
    ctx.moveTo(start.x, start.y);
    ctx.lineTo(start.x + 0.1, start.y + 0.1);
    ctx.stroke();
    modify((page) => ({ ...page, touched: true }));
  };
  const moveStroke = (event: React.PointerEvent<HTMLCanvasElement>) => {
    const current = gesture.current;
    const ctx = canvasContext();
    const canvas = canvasRef.current;
    if (!current || !ctx || !canvas) return;
    event.preventDefault();
    const point = pointOf(event);
    if (current.kind === "select") {
      setSelectedBox(rectBetween(current.start, point));
    } else if (current.kind === "move") {
      const x = Math.max(
        0,
        Math.min(canvas.width - current.box.width, current.box.x + point.x - current.start.x),
      );
      const y = Math.max(
        0,
        Math.min(canvas.height - current.box.height, current.box.y + point.y - current.start.y),
      );
      ctx.clearRect(0, 0, canvas.width, canvas.height);
      ctx.drawImage(current.base, 0, 0);
      ctx.drawImage(current.cut, x, y, current.box.width, current.box.height);
      setSelectedBox({ ...current.box, x, y });
    } else if (current.kind === "shape") {
      ctx.clearRect(0, 0, canvas.width, canvas.height);
      ctx.drawImage(current.base, 0, 0);
      paintShape(ctx, current.tool, current.start, point, penColour, size);
    } else {
      if (event.pointerType === "pen" && tool === "pen")
        ctx.lineWidth = size * 1.6 * Math.max(0.5, Math.min(1.4, event.pressure * 1.8));
      ctx.beginPath();
      ctx.moveTo(current.last.x, current.last.y);
      ctx.lineTo(point.x, point.y);
      ctx.stroke();
      current.last = point;
    }
  };
  const endStroke = (event: React.PointerEvent<HTMLCanvasElement>) => {
    const current = gesture.current;
    if (current?.kind === "move" || current?.kind === "shape")
      modify((page) => ({ ...page, touched: true }));
    if (current?.kind === "select" && (selectedBox?.width ?? 0) < 8) setSelectedBox(null);
    if (current?.kind === "draw") canvasContext()?.restore();
    gesture.current = null;
    if (event.currentTarget.hasPointerCapture(event.pointerId))
      event.currentTarget.releasePointerCapture(event.pointerId);
  };
  const redraw = async (src: string) => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const id = active.id;
    const image = await loadImage(src);
    if (pagesRef.current[indexRef.current]?.id !== id) return;
    const ctx = canvas.getContext("2d")!;
    ctx.clearRect(0, 0, canvas.width, canvas.height);
    ctx.drawImage(image, 0, 0, canvas.width, canvas.height);
    setSelectedBox(null);
    setDirty(true);
  };
  const undo = () => {
    const canvas = canvasRef.current;
    const list = history.current.get(active.id);
    const previous = list?.pop();
    if (!canvas || !previous) return;
    future.current.set(active.id, [
      ...(future.current.get(active.id) ?? []),
      canvas.toDataURL("image/png"),
    ]);
    void redraw(previous);
  };
  const redo = () => {
    const canvas = canvasRef.current;
    const list = future.current.get(active.id);
    const next = list?.pop();
    if (!canvas || !next) return;
    history.current.set(active.id, [
      ...(history.current.get(active.id) ?? []),
      canvas.toDataURL("image/png"),
    ]);
    void redraw(next);
  };
  const clearAll = () => {
    const canvas = canvasRef.current;
    if (
      !canvas ||
      !window.confirm("Clear ink on this page? Undo can restore it; the paper remains.")
    )
      return;
    remember();
    canvasContext()?.clearRect(0, 0, canvas.width, canvas.height);
    setSelectedBox(null);
    modify((page) => ({ ...page, touched: false }));
  };
  const addPhoto = async (file: File) => {
    if (!/^image\/(png|jpeg|webp)$/.test(file.type) || file.size > 8 * 1024 * 1024) {
      toast.error("PNG/JPG/WebP photo under 8 MB choose karein.");
      return;
    }
    const url = URL.createObjectURL(file);
    try {
      const image = await loadImage(url);
      if (image.naturalWidth * image.naturalHeight > 16_000_000)
        throw new Error("Photo resolution too large. Resize below 16 megapixels.");
      const canvas = canvasRef.current!;
      const ctx = canvas.getContext("2d")!;
      remember();
      const scale = Math.min(
        canvas.width / image.naturalWidth,
        canvas.height / image.naturalHeight,
        1.6,
      );
      const width = image.naturalWidth * scale,
        height = image.naturalHeight * scale;
      ctx.drawImage(image, (canvas.width - width) / 2, (canvas.height - height) / 2, width, height);
      modify((page) => ({ ...page, touched: true }));
      setStatus("Photo placed. Use Select to move a rectangular portion of it.");
    } catch (error) {
      toast.error(error instanceof Error ? error.message : "Photo could not load.");
    } finally {
      URL.revokeObjectURL(url);
    }
  };
  const setTemplate = async (file: File) => {
    if (!/^image\/(png|jpeg|webp)$/.test(file.type) || file.size > 4 * 1024 * 1024) {
      toast.error("Custom page background must be PNG/JPG/WebP under 4 MB.");
      return;
    }
    const url = URL.createObjectURL(file);
    try {
      const image = await loadImage(url);
      if (image.naturalWidth * image.naturalHeight > 12_000_000)
        throw new Error("Template resolution too large. Resize below 12 megapixels.");
      const scale = Math.min(1, 1500 / Math.max(image.naturalWidth, image.naturalHeight));
      const surface = document.createElement("canvas");
      surface.width = Math.round(image.naturalWidth * scale);
      surface.height = Math.round(image.naturalHeight * scale);
      surface.getContext("2d")!.drawImage(image, 0, 0, surface.width, surface.height);
      const data = surface.toDataURL("image/jpeg", 0.82);
      surface.width = surface.height = 0;
      modify((page) => ({ ...page, template: data }));
      setStatus("Custom background attached to this page and its PDF export.");
    } catch (error) {
      toast.error(error instanceof Error ? error.message : "Background could not load.");
    } finally {
      URL.revokeObjectURL(url);
    }
  };
  // Paste an image into the current drawing without affecting text input fields.
  useEffect(() => {
    const paste = (event: ClipboardEvent) => {
      if (
        event.target instanceof HTMLElement &&
        event.target.closest("input,textarea,[contenteditable=true]")
      )
        return;
      const item = Array.from(event.clipboardData?.items ?? []).find((entry) =>
        /^image\/(png|jpeg|webp)$/.test(entry.type),
      );
      const file = item?.getAsFile();
      if (file) {
        event.preventDefault();
        void addPhoto(file);
      }
    };
    window.addEventListener("paste", paste);
    return () => window.removeEventListener("paste", paste);
  });

  const outputPage = async (page: Page): Promise<Blob> => {
    const surface = document.createElement("canvas");
    const { width, height } = notePagePixels(page.layout);
    surface.width = width;
    surface.height = height;
    try {
      const ctx = surface.getContext("2d");
      if (!ctx) throw new Error("Drawing page could not be prepared. Try a smaller page size.");
      paintNotePage(
        ctx,
        width,
        height,
        page.layout,
        page.template ? await loadImage(page.template) : undefined,
      );
      if (page.ink) ctx.drawImage(await loadImage(page.ink), 0, 0, width, height);
      // Blob stays in browser memory until uploaded. Converting a data URL with
      // fetch() fails under our production connect-src CSP (and on some phones).
      return await new Promise<Blob>((resolve, reject) =>
        surface.toBlob(
          (blob) =>
            blob?.size
              ? resolve(blob)
              : reject(
                  new Error("Drawing page JPEG could not be prepared. Retry or download a backup."),
                ),
          "image/jpeg",
          0.87,
        ),
      );
    } finally {
      surface.width = surface.height = 0;
    }
  };
  const save = async () => {
    if (saving) return;
    const stored = preserve();
    if (
      stored.length === 1 &&
      !stored[0]!.touched &&
      !stored[0]!.template &&
      stored[0]!.layout.pattern === "blank" &&
      stored[0]!.layout.paperColour === DEFAULT_NOTE_PAGE.paperColour &&
      stored[0]!.preset === "a4"
    ) {
      toast.info("Pehle kuch likhein, photo lagayein ya custom paper chunein.");
      return;
    }
    setSaving(true);
    setSaveError("");
    try {
      const prepared: HandwrittenNotePage[] = [];
      for (const [number, page] of stored.entries()) {
        setStatus(`Preparing page ${number + 1} / ${stored.length}…`);
        prepared.push({
          blob: await outputPage(page),
          caption: `${page.caption.trim() || "Handwritten note"} · page ${number + 1}`,
          widthMm: page.layout.widthMm,
          heightMm: page.layout.heightMm,
        });
      }
      setStatus(`Uploading ${stored.length} page${stored.length === 1 ? "" : "s"}…`);
      await onInsertPages(prepared);
      toast.success(
        `${stored.length} page${stored.length === 1 ? "" : "s"} note draft mein add ho gaye. Save changes dabayein.`,
      );
      onClose();
    } catch (error) {
      const reason = error instanceof Error ? error.message : "Upload could not finish.";
      setStatus("");
      setSaveError(
        `${reason} Pages abhi canvas mein hain; connection/storage check karke Retry karein. Pehle More drawing tools → Download page backup se har page ka backup le sakte hain.`,
      );
      toast.error(`Drawing save failed: ${reason}`);
    } finally {
      setSaving(false);
    }
  };
  const downloadCurrent = async () => {
    const page = preserve()[indexRef.current]!;
    try {
      downloadFile(
        await outputPage(page),
        `kkcc-note-page-${indexRef.current + 1}.jpg`,
        "image/jpeg",
      );
    } catch (error) {
      toast.error(error instanceof Error ? error.message : "Page backup failed.");
    }
  };
  const downloadPagesPdf = async () => {
    if (saving) return;
    setSaving(true);
    try {
      const stored = preserve();
      const pdf = await PDFDocument.create();
      for (const [number, page] of stored.entries()) {
        setStatus(`Rendering page ${number + 1} / ${stored.length} for PDF…`);
        const image = await pdf.embedJpg(await (await outputPage(page)).arrayBuffer());
        const width = (page.layout.widthMm * 72) / 25.4;
        const height = (page.layout.heightMm * 72) / 25.4;
        pdf.addPage([width, height]).drawImage(image, { x: 0, y: 0, width, height });
      }
      const copy = await brandPdfBytes(await pdf.save(), {
        mode: pdfMode,
        onProgress: (page, total) => setStatus(`Making B&W page ${page} / ${total}…`),
      });
      downloadFile(
        copy,
        `KKCC-custom-note-pages${pdfMode === "black-white" ? "-BW" : ""}.pdf`,
        "application/pdf",
      );
      setStatus(
        `Custom-size ${pdfMode === "black-white" ? "B&W" : "colour"} PDF downloaded. Original draft unchanged.`,
      );
    } catch (error) {
      toast.error(error instanceof Error ? error.message : "PDF export failed.");
    } finally {
      setSaving(false);
    }
  };
  const close = () => {
    if (dirty && !window.confirm("Unsaved page edits will be lost. Close the drawing composer?"))
      return;
    onClose();
  };
  return (
    <div
      role="dialog"
      aria-modal="true"
      aria-label="Handwriting canvas"
      className="fixed inset-0 z-[60] flex items-end justify-center bg-black/75 p-0 backdrop-blur-sm sm:items-center sm:p-4"
      onClick={close}
    >
      <div
        className="relative flex h-[100dvh] w-full max-w-4xl flex-col overflow-hidden rounded-none border-0 bg-background shadow-2xl sm:h-auto sm:max-h-[94vh] sm:rounded-3xl sm:border"
        onClick={(event) => event.stopPropagation()}
      >
        <header className="flex shrink-0 items-center justify-between gap-2 border-b px-4 py-2">
          <div>
            <h2 className="text-sm font-black">
              Custom page notebook · {pages.length} page{pages.length === 1 ? "" : "s"}
            </h2>
            <p className="text-[11px] text-muted-foreground">
              Pen, marker, shapes, text, photo · finger/stylus/mouse · real page sizes in PDF
            </p>
          </div>
          <Button
            size="icon"
            variant="ghost"
            className="h-9 w-9 rounded-full"
            aria-label="Close handwriting canvas"
            onClick={close}
          >
            <X className="h-4 w-4" />
          </Button>
        </header>
        <div
          className="flex shrink-0 items-center gap-1.5 overflow-x-auto border-b px-3 py-2"
          aria-label="Note pages"
        >
          {pages.map((page, number) => (
            <button
              key={page.id}
              type="button"
              aria-label={`Page ${number + 1}`}
              aria-current={number === index ? "page" : undefined}
              onClick={() => switchPage(number)}
              className={`min-h-10 min-w-14 shrink-0 rounded-lg border px-2 text-xs font-bold ${number === index ? "border-primary bg-primary/10 text-primary" : "bg-background"}`}
            >
              {number + 1}
              <span className="block text-[9px] font-normal">
                {page.layout.widthMm}×{page.layout.heightMm}
              </span>
            </button>
          ))}
          <Button
            type="button"
            size="sm"
            variant="outline"
            disabled={saving || pages.length >= MAX_PAGES}
            onClick={() => addPage()}
          >
            <Plus className="mr-1 h-3 w-3" />
            Add page
          </Button>
          <Button
            type="button"
            size="sm"
            variant="outline"
            disabled={saving || pages.length >= MAX_PAGES}
            onClick={() => addPage(true)}
          >
            <Copy className="mr-1 h-3 w-3" />
            Duplicate
          </Button>
          <Button
            type="button"
            size="sm"
            variant="outline"
            disabled={saving || index === 0}
            onClick={() => movePage(-1)}
            aria-label="Move page left"
          >
            ←
          </Button>
          <Button
            type="button"
            size="sm"
            variant="outline"
            disabled={saving || index === pages.length - 1}
            onClick={() => movePage(1)}
            aria-label="Move page right"
          >
            →
          </Button>
          <Button
            type="button"
            size="sm"
            variant="outline"
            disabled={saving || pages.length === 1}
            onClick={removePage}
            aria-label="Delete current page"
          >
            <Trash2 className="h-3 w-3" />
          </Button>
        </div>
        <details
          className="max-h-[45dvh] shrink-0 overflow-y-auto border-b px-3 py-1 text-xs"
          open={settingsOpen}
          onToggle={(event) => setSettingsOpen(event.currentTarget.open)}
        >
          <summary className="min-h-10 cursor-pointer py-2 font-semibold">
            Custom page settings · {active.preset.toUpperCase()} · {active.layout.widthMm}×
            {active.layout.heightMm} mm · {active.layout.pattern}
          </summary>
          <div className="flex flex-wrap items-center gap-2 pb-2">
            <label className="font-semibold">
              Page size
              <select
                aria-label="Page size"
                className="ml-1 min-h-10 rounded border bg-background p-1"
                value={active.preset}
                onChange={(event) => {
                  const value = event.target.value as NotePagePreset;
                  if (value === "custom") {
                    modify((page) => ({ ...page, preset: "custom" }));
                    return;
                  }
                  const chosen = NOTE_PAGE_PRESETS[value];
                  const landscape = active.layout.widthMm > active.layout.heightMm;
                  resizePage(
                    landscape ? chosen.heightMm : chosen.widthMm,
                    landscape ? chosen.widthMm : chosen.heightMm,
                    value,
                  );
                }}
              >
                <option value="a4">A4</option>
                <option value="a5">A5</option>
                <option value="letter">US Letter</option>
                <option value="custom">Custom size (mm)</option>
              </select>
            </label>
            <label className="font-semibold">
              Orientation
              <select
                aria-label="Page orientation"
                className="ml-1 min-h-10 rounded border bg-background p-1"
                value={active.layout.widthMm > active.layout.heightMm ? "landscape" : "portrait"}
                onChange={() =>
                  resizePage(active.layout.heightMm, active.layout.widthMm, active.preset)
                }
              >
                <option value="portrait">Portrait</option>
                <option value="landscape">Landscape</option>
              </select>
            </label>
            {active.preset === "custom" && (
              <div className="flex flex-wrap gap-2">
                {(["widthMm", "heightMm"] as const).map((dimension) => (
                  <label
                    key={`${active.id}-${dimension}-${active.layout[dimension]}`}
                    className="font-semibold"
                  >
                    {dimension === "widthMm" ? "Width" : "Height"} mm
                    <Input
                      type="number"
                      min={90}
                      max={dimension === "widthMm" ? 420 : 594}
                      step={1}
                      aria-label={`Custom page ${dimension === "widthMm" ? "width" : "height"} mm`}
                      className="ml-1 inline-block h-10 w-20"
                      defaultValue={active.layout[dimension]}
                      onBlur={(event) => {
                        const value = Number(event.target.value);
                        if (
                          !resizePage(
                            dimension === "widthMm" ? value : active.layout.widthMm,
                            dimension === "heightMm" ? value : active.layout.heightMm,
                          )
                        )
                          event.target.value = String(active.layout[dimension]);
                      }}
                    />
                  </label>
                ))}
              </div>
            )}
            <label className="font-semibold">
              Paper
              <select
                aria-label="Paper pattern"
                className="ml-1 min-h-10 rounded border bg-background p-1"
                value={active.layout.pattern}
                onChange={(event) =>
                  updateLayout({ pattern: event.target.value as NotePaperPattern })
                }
              >
                <option value="blank">Blank</option>
                <option value="ruled">Ruled lines</option>
                <option value="grid">Grid</option>
                <option value="dotted">Dots</option>
              </select>
            </label>
            <label className="font-semibold">
              Paper colour
              <select
                aria-label="Paper colour"
                className="ml-1 min-h-10 rounded border bg-background p-1"
                value={
                  PAPER_COLOURS.some(([, hex]) => hex === active.layout.paperColour)
                    ? active.layout.paperColour
                    : "custom"
                }
                onChange={(event) => {
                  if (event.target.value !== "custom")
                    updateLayout({ paperColour: event.target.value });
                }}
              >
                {PAPER_COLOURS.map(([name, hex]) => (
                  <option key={hex} value={hex}>
                    {name}
                  </option>
                ))}
                <option value="custom">Custom colour</option>
              </select>
            </label>
            <input
              type="color"
              aria-label="Custom paper colour"
              title="Custom paper colour"
              className="h-10 w-10 cursor-pointer rounded border"
              value={active.layout.paperColour}
              onChange={(event) => updateLayout({ paperColour: event.target.value })}
            />
            <Button
              type="button"
              size="sm"
              variant="outline"
              onClick={() => templateRef.current?.click()}
            >
              Upload page background
            </Button>
            {active.template && (
              <Button
                type="button"
                size="sm"
                variant="outline"
                onClick={() => modify((page) => ({ ...page, template: null }))}
              >
                Remove background
              </Button>
            )}
            <input
              ref={templateRef}
              type="file"
              accept="image/png,image/jpeg,image/webp"
              className="hidden"
              aria-label="Choose custom page background"
              onChange={(event) => {
                const file = event.target.files?.[0];
                if (file) void setTemplate(file);
                event.target.value = "";
              }}
            />
          </div>
        </details>
        <div className="flex shrink-0 items-center gap-1 overflow-x-auto border-b px-3 py-1">
          {(
            [
              ["pen", "Pen", Pen],
              ["highlighter", "Marker", Highlighter],
              ["eraser", "Eraser", Eraser],
              ["line", "Line", Pen],
              ["rectangle", "Rectangle", Pen],
              ["ellipse", "Ellipse", Pen],
              ["select", "Select / move", Pen],
            ] as const
          ).map(([id, label, Icon]) => (
            <Button
              key={id}
              type="button"
              size="sm"
              variant={tool === id ? "default" : "outline"}
              className="min-h-10 shrink-0 rounded-full px-2 text-xs"
              onClick={() => {
                setTool(id);
                setPlacingText(false);
                setSelectedBox(null);
              }}
              aria-pressed={tool === id}
            >
              <Icon className="mr-1 h-3.5 w-3.5" />
              {label}
            </Button>
          ))}
        </div>
        <div className="flex shrink-0 items-center gap-1.5 overflow-x-auto border-b px-3 py-1">
          <span className="shrink-0 text-[11px] font-bold">
            {tool === "highlighter" ? "Marker" : "Ink"}
          </span>
          <div className="flex shrink-0 gap-1" role="group" aria-label="Drawing colours">
            {INK_COLOURS.map(([name, hex]) => (
              <button
                key={hex}
                type="button"
                aria-label={`Colour ${hex}`}
                title={`${name} ${tool === "highlighter" ? "marker" : "pen"}`}
                aria-pressed={colour === hex}
                onClick={() => {
                  if (tool === "highlighter") setMarkerColour(hex);
                  else setPenColour(hex);
                  if (tool === "eraser") setTool("pen");
                }}
                className={`h-11 w-11 shrink-0 rounded-full border-2 ${colour === hex ? "border-foreground ring-2 ring-primary ring-offset-1" : "border-foreground/20"}`}
                style={{ backgroundColor: hex }}
              />
            ))}
          </div>
          <input
            type="color"
            aria-label="Custom pen or marker colour"
            value={colour}
            onChange={(event) =>
              tool === "highlighter"
                ? setMarkerColour(event.target.value)
                : setPenColour(event.target.value)
            }
            className="h-10 w-10 cursor-pointer rounded border"
          />
          <label className="ml-1 flex items-center gap-1 text-xs font-semibold">
            Thickness {size}
            <input
              type="range"
              min={1}
              max={16}
              aria-label="Pen or marker thickness"
              value={size}
              onChange={(event) => setSize(Number(event.target.value))}
              className="h-10 w-20 accent-primary"
            />
          </label>
          <Button
            type="button"
            size="sm"
            variant="outline"
            onClick={undo}
            disabled={!history.current.get(active.id)?.length}
          >
            <RotateCcw className="mr-1 h-3 w-3" />
            Undo
          </Button>
          <Button type="button" size="sm" variant="outline" onClick={clearAll}>
            <Trash2 className="mr-1 h-3 w-3" />
            Clear ink
          </Button>
          <Button
            type="button"
            size="sm"
            variant="outline"
            onClick={() => photoRef.current?.click()}
          >
            <ImagePlus className="mr-1 h-3 w-3" />
            Photo
          </Button>
          <input
            ref={photoRef}
            type="file"
            accept="image/png,image/jpeg,image/webp"
            className="hidden"
            aria-label="Choose note photo"
            onChange={(event) => {
              const file = event.target.files?.[0];
              if (file) void addPhoto(file);
              event.target.value = "";
            }}
          />
        </div>
        <details className="max-h-[40dvh] shrink-0 overflow-y-auto border-b px-4 py-1 text-sm">
          <summary className="min-h-11 cursor-pointer py-2 font-semibold">
            More drawing tools · text, redo, backup
          </summary>
          <div className="flex flex-wrap items-center gap-2 pb-3">
            <Button
              type="button"
              size="sm"
              variant="outline"
              onClick={redo}
              disabled={!future.current.get(active.id)?.length}
            >
              Redo
            </Button>
            <label className="text-xs">
              <input
                type="checkbox"
                checked={stylusOnly}
                onChange={(event) => setStylusOnly(event.target.checked)}
              />{" "}
              Pen/mouse only (ignore finger)
            </label>
            <label className="text-xs">
              Zoom {zoom}%{" "}
              <input
                type="range"
                min={50}
                max={200}
                step={25}
                aria-label="Page zoom"
                value={zoom}
                onChange={(event) => setZoom(Number(event.target.value))}
              />
            </label>
            <div className="w-full min-w-0">
              <MultilingualNoteInput
                aria-label="Text to place on page"
                rows={2}
                value={textToPlace}
                onValueChange={setTextToPlace}
                placeholder="Type or paste text for this page"
              />
            </div>
            <Button
              type="button"
              size="sm"
              variant={placingText ? "default" : "outline"}
              disabled={!textToPlace.trim()}
              onClick={() => {
                setPlacingText(!placingText);
                setSelectedBox(null);
              }}
            >
              Text → tap page to place
            </Button>
            <Button
              type="button"
              size="sm"
              variant="outline"
              onClick={() => void downloadCurrent()}
            >
              Download page backup
            </Button>
            <label className="flex items-center gap-1 text-xs">
              PDF output
              <select
                aria-label="Drawing pages PDF colour mode"
                value={pdfMode}
                onChange={(event) => setPdfMode(event.target.value as PdfColourMode)}
                className="min-h-10 rounded border bg-background px-2"
              >
                <option value="colour">Colour</option>
                <option value="black-white">Black &amp; white</option>
              </select>
            </label>
            <Button
              type="button"
              size="sm"
              variant="outline"
              disabled={saving}
              onClick={() => void downloadPagesPdf()}
            >
              <Download className="mr-1 h-3 w-3" />
              Download custom-size pages PDF
            </Button>
            <p className="w-full text-[11px] text-muted-foreground">
              Each custom-size PDF sheet keeps this page’s physical dimensions. Saving pages into a
              typed note fits them into its A4 print layout. Selected ink can be moved while
              composing; after upload it becomes an image (keep the editable composer open until
              satisfied).
            </p>
          </div>
        </details>
        <div className="flex-1 overflow-auto bg-muted/30 p-3">
          <div
            className="relative mx-auto min-w-[200px] rounded-xl border shadow-sm"
            style={{
              width: `${zoom}%`,
              maxWidth: zoom === 100 ? "720px" : undefined,
              aspectRatio: `${pixels.width} / ${pixels.height}`,
              backgroundColor: active.layout.paperColour,
              backgroundImage: backgroundUrl ? `url(${backgroundUrl})` : undefined,
              backgroundSize: "100% 100%",
            }}
          >
            <canvas
              ref={canvasRef}
              aria-label="Drawing page canvas"
              onPointerDown={startStroke}
              onPointerMove={moveStroke}
              onPointerUp={endStroke}
              onPointerCancel={endStroke}
              className="absolute inset-0 block h-full w-full touch-none rounded-xl"
              style={{
                aspectRatio: `${pixels.width} / ${pixels.height}`,
                pointerEvents: pageLoading ? "none" : "auto",
              }}
            />
            {selectedBox && tool === "select" && (
              <div
                aria-hidden="true"
                className="pointer-events-none absolute border-2 border-dashed border-primary"
                style={{
                  left: `${(selectedBox.x / pixels.width) * 100}%`,
                  top: `${(selectedBox.y / pixels.height) * 100}%`,
                  width: `${(selectedBox.width / pixels.width) * 100}%`,
                  height: `${(selectedBox.height / pixels.height) * 100}%`,
                }}
              />
            )}
          </div>
        </div>
        <footer className="shrink-0 space-y-1 border-t px-4 py-2 pb-[max(0.5rem,env(safe-area-inset-bottom))]">
          <div className="flex items-center gap-2">
            <Label className="shrink-0 text-xs">Page caption</Label>
            <Input
              aria-label="Page caption"
              value={active.caption}
              onChange={(event) =>
                modify((page) => ({ ...page, caption: event.target.value.slice(0, 100) }))
              }
              placeholder="e.g. Chapter 1 diagram"
              className="h-9"
            />
          </div>
          {status && (
            <p role="status" className="text-[11px] text-muted-foreground">
              {status}
            </p>
          )}
          {saveError && (
            <p role="alert" className="max-h-20 overflow-y-auto text-xs text-destructive">
              {saveError}
            </p>
          )}
          <Button
            type="button"
            className="w-full rounded-full font-bold"
            disabled={saving}
            onClick={() => void save()}
          >
            {saving ? (
              <Loader2 className="mr-2 h-4 w-4 animate-spin" />
            ) : (
              <Save className="mr-2 h-4 w-4" />
            )}
            {pages.length === 1 ? "Save page into notes" : `Save ${pages.length} pages into notes`}
          </Button>
        </footer>
      </div>
    </div>
  );
}
