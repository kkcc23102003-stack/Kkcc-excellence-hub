import { useEffect, useRef, useState } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { downloadFile, safeFilename, type Deck } from "@/lib/document-studio";
import {
  CUSTOM_PAMPHLET_MAX_PAGES,
  generateCustomPamphlet,
  type CustomPamphletOptions,
} from "@/lib/custom-pamphlet";
import { browserSlideMeasure, type SlideBrand } from "@/lib/presentation-design";
import { exportPowerPoint, slideCanvas } from "@/lib/presentation-export";
import type { ImportedPamphlet } from "@/lib/custom-pamphlet-browser";

const PPTX_TYPE = "application/vnd.openxmlformats-officedocument.presentationml.presentation";
type Form = Omit<CustomPamphletOptions, "pages" | "size">;
type ReadyPpt = { deck: Deck; blob: Blob; url: string; filename: string };

export function CustomPamphletWizard({
  brand,
  onOpenInEditor,
}: {
  brand: SlideBrand;
  onOpenInEditor: (deck: Deck) => boolean;
}) {
  const [imported, setImported] = useState<ImportedPamphlet | null>(null);
  const [form, setForm] = useState<Form>({
    title: "My custom pamphlet",
    topic: brand.subject,
    text: "",
    brand,
    teachingIndex: 0,
    keepSourcePages: false,
    addBranding: false,
    readingPanel: false,
    ink: "dark",
    contentTop: 20,
    contentBottom: 86,
  });
  const [ready, setReady] = useState<ReadyPpt | null>(null),
    [preview, setPreview] = useState(""),
    [message, setMessage] = useState("Choose Canva PDF Standard or JPG/PNG pages to begin."),
    [error, setError] = useState(""),
    [busy, setBusy] = useState<"upload" | "build" | null>(null),
    [canShare, setCanShare] = useState(false);
  const cancelled = useRef(false),
    mounted = useRef(true);
  useEffect(() => {
    mounted.current = true;
    return () => {
      mounted.current = false;
      cancelled.current = true;
    };
  }, []);
  useEffect(
    () => () => {
      if (ready) URL.revokeObjectURL(ready.url);
    },
    [ready],
  );
  useEffect(() => {
    if (!ready) {
      setPreview("");
      setCanShare(false);
      return;
    }
    try {
      const file = new File([ready.blob], ready.filename, { type: PPTX_TYPE });
      setCanShare(
        typeof navigator !== "undefined" &&
          typeof navigator.share === "function" &&
          (typeof navigator.canShare !== "function" || navigator.canShare({ files: [file] })),
      );
    } catch {
      setCanShare(false); // Download still works if a browser lacks file sharing.
    }
    let alive = true;
    const firstText = ready.deck.slides.findIndex((slide) => slide.generated);
    const index = firstText < 0 ? 0 : firstText;
    void slideCanvas(ready.deck.slides[index]!, index, ready.deck.size!, ready.deck.brand!)
      .then((canvas) => {
        if (alive) setPreview(canvas.toDataURL("image/jpeg", 0.82));
        canvas.width = 0;
        canvas.height = 0;
      })
      .catch(() => {
        if (alive) setPreview("");
      });
    return () => {
      alive = false;
    };
  }, [ready]);
  const update = (patch: Partial<Form>) => {
    setForm((old) => ({ ...old, ...patch }));
    setReady(null); // Never offer an out-of-date PPT after the user changes text or layout.
    setMessage("Changes pending. Tap Make my editable PowerPoint again when ready.");
    setError("");
  };
  const importFiles = async (files: File[]) => {
    if (!files.length || busy) return;
    cancelled.current = false;
    setError("");
    setBusy("upload");
    setMessage("Reading Canva pages on this device… nothing is uploaded to our server.");
    try {
      const { importPamphletArtwork } = await import("@/lib/custom-pamphlet-browser");
      const result = await importPamphletArtwork(
        files,
        (done, total) => {
          if (mounted.current) setMessage(`Opening page ${done} / ${total}…`);
        },
        () => cancelled.current || !mounted.current,
      );
      if (!mounted.current || cancelled.current) return;
      setImported(result);
      setReady(null);
      setForm((old) => ({
        ...old,
        title: files[0]!.name.replace(/\.(?:pdf|png|jpe?g|webp)$/i, "").slice(0, 140) || old.title,
        teachingIndex: result.pages.length - 1,
        keepSourcePages: result.pages.length > 1,
      }));
      setMessage(
        `${result.pages.length} page${result.pages.length === 1 ? "" : "s"} ready (${result.size.width} × ${result.size.height}). Choose the blank teaching page, then paste your text.`,
      );
    } catch (cause) {
      if (mounted.current)
        setError(cause instanceof Error ? cause.message : "Could not read the files.");
    } finally {
      if (mounted.current) {
        if (cancelled.current)
          setMessage("Import cancelled. Your previous design, if any, is unchanged.");
        setBusy(null);
      }
    }
  };
  const build = async () => {
    if (!imported || busy) return;
    setBusy("build");
    setError("");
    setMessage("Making editable text slides and the downloadable PowerPoint…");
    try {
      const measure = await browserSlideMeasure();
      if (!mounted.current) return;
      const deck = generateCustomPamphlet({ ...form, ...imported }, measure);
      const blob = await exportPowerPoint(deck);
      if (!mounted.current) return;
      const filename = `${safeFilename(deck.title)}.pptx`;
      const url = URL.createObjectURL(blob);
      setReady({ deck, blob, url, filename });
      setMessage(
        `${deck.slides.length} slides ready. Tap Download editable PPTX to save on your phone.`,
      );
    } catch (cause) {
      if (mounted.current)
        setError(cause instanceof Error ? cause.message : "Could not create the PowerPoint.");
    } finally {
      if (mounted.current) setBusy(null);
    }
  };
  const share = async () => {
    if (!ready || !canShare) return;
    try {
      await navigator.share({
        files: [new File([ready.blob], ready.filename, { type: PPTX_TYPE })],
        title: ready.deck.title,
      });
    } catch (cause) {
      if (cause instanceof Error && cause.name !== "AbortError")
        setError("Share unavailable on this phone. Use Download editable PPTX instead.");
    }
  };
  const setBrand = (key: keyof SlideBrand, value: string) =>
    update({ brand: { ...form.brand, [key]: value } });
  const validArea = form.contentBottom - form.contentTop >= 45;

  return (
    <section
      id="custom-pamphlet"
      className="min-w-0 space-y-5 rounded-2xl border-2 border-emerald-500/40 bg-emerald-50/40 p-3 dark:bg-emerald-950/10 sm:p-5"
      aria-label="Easy custom pamphlet to PowerPoint"
    >
      <div>
        <p className="text-xs font-bold uppercase tracking-wide text-emerald-700 dark:text-emerald-300">
          Simple mode · for one-person admin
        </p>
        <h3 className="text-xl font-bold">Custom pamphlet → editable PPT</h3>
        <p className="mt-1 text-sm text-muted-foreground">
          Canva artwork upload karo → blank teaching page choose karo → text paste karo → phone par
          PowerPoint save karo. Upload/generate se existing Studio project change nahi hota.
        </p>
      </div>
      <fieldset disabled={busy !== null} className="min-w-0 space-y-5">
        <div className="space-y-3 rounded-xl border bg-background p-3 sm:p-4">
          <h4 className="font-semibold">1. Canva design / apne pages upload karo</h4>
          <p className="text-xs text-muted-foreground">
            Canva → Share → Download → PDF Standard (all pages), or PNG/JPG (select multiple). Up to{" "}
            {CUSTOM_PAMPHLET_MAX_PAGES} pages / 25 MB. PPTX file import/OCR nahi: Canva PPTX ko
            pehle PDF export karein.
          </p>
          <Input
            type="file"
            multiple
            accept=".pdf,.png,.jpg,.jpeg,.webp,application/pdf,image/png,image/jpeg,image/webp"
            aria-label="Upload Canva PDF or images"
            onChange={(event) => {
              const files = Array.from(event.target.files ?? []);
              event.target.value = "";
              void importFiles(files);
            }}
          />
          <div
            tabIndex={0}
            aria-label="Drop files or focus here to paste a Canva image"
            className="rounded-lg border border-dashed p-3 text-center text-xs text-muted-foreground focus-visible:outline-2 focus-visible:outline-emerald-600"
            onDragOver={(event) => event.preventDefault()}
            onDrop={(event) => {
              event.preventDefault();
              void importFiles(Array.from(event.dataTransfer.files));
            }}
            onPaste={(event) => {
              const pasted = Array.from(event.clipboardData.files);
              if (pasted.length) {
                event.preventDefault();
                void importFiles(pasted);
              }
            }}
          >
            Phone Files/Gallery se choose, desktop par drag-drop, ya copied image yahan paste
            karein.
          </div>
          {imported && (
            <>
              <p className="text-sm font-medium">
                {imported.pages.length} design pages imported · {imported.size.width} ×{" "}
                {imported.size.height}
              </p>
              {imported.mixedRatios && (
                <p className="text-xs font-medium text-amber-800 dark:text-amber-300">
                  Different page ratios: each page is fitted without cropping into the first page’s
                  size. Check the teaching page and adjust the top/bottom safe margins before
                  download.
                </p>
              )}
              <div
                role="group"
                aria-label="Choose blank teaching page"
                className="grid min-w-0 grid-cols-2 gap-2 sm:grid-cols-3 lg:grid-cols-4"
              >
                {imported.pages.map((page, index) => (
                  <label
                    key={`${page.name}-${index}`}
                    className={`min-w-0 cursor-pointer rounded-lg border bg-background p-2 text-xs ${form.teachingIndex === index ? "ring-2 ring-emerald-500" : ""}`}
                  >
                    <input
                      type="radio"
                      name="custom-teaching-page"
                      aria-label={`Use page ${index + 1} as teaching template`}
                      checked={form.teachingIndex === index}
                      onChange={() => update({ teachingIndex: index })}
                    />
                    <img
                      src={page.image}
                      alt={`Canva design page ${index + 1}`}
                      className="mt-2 max-h-36 w-full rounded object-contain"
                      style={{ aspectRatio: `${imported.size.width}/${imported.size.height}` }}
                    />
                    <span className="mt-1 block truncate" title={page.name}>
                      {index + 1}. {page.name}
                    </span>
                    <span className="font-medium text-emerald-700 dark:text-emerald-300">
                      {form.teachingIndex === index ? "✓ Text page" : "Select for text"}
                    </span>
                  </label>
                ))}
              </div>
              <label className="flex items-start gap-2 text-sm">
                <input
                  type="checkbox"
                  checked={form.keepSourcePages}
                  onChange={(event) => update({ keepSourcePages: event.target.checked })}
                  className="mt-1"
                />
                Keep all original Canva pages first (cover/design pages), then add new text slides.
              </label>
            </>
          )}
        </div>
        <div className="space-y-3 rounded-xl border bg-background p-3 sm:p-4">
          <h4 className="font-semibold">2. Topic aur text likho — page khud banega</h4>
          <div className="grid min-w-0 gap-3 sm:grid-cols-2">
            <label className="min-w-0 text-xs">
              PowerPoint file name
              <Input
                aria-label="Custom PowerPoint name"
                value={form.title}
                maxLength={150}
                onChange={(e) => update({ title: e.target.value })}
              />
            </label>
            <label className="min-w-0 text-xs">
              Default topic / slide title
              <Input
                aria-label="Custom lesson topic"
                value={form.topic}
                maxLength={120}
                onChange={(e) => update({ topic: e.target.value })}
              />
            </label>
          </div>
          <label className="block text-xs">
            Lesson text — paste from notes, Hindi/Punjabi/English allowed
            <Textarea
              aria-label="Lesson text for custom pamphlet"
              rows={7}
              maxLength={60000}
              value={form.text}
              onChange={(e) => update({ text: e.target.value })}
              placeholder="# Chapter 1\nWrite your lesson here.\n\n# Chapter 2\nLong text automatically flows onto more teaching slides."
            />
          </label>
          <p className="text-xs text-muted-foreground">
            # Heading se naya chapter/section slide; lamba text next slides par chalega, content
            silently cut nahi hoga. Text boxes alag editable rahenge, PDF/Canva image ke printed
            words nahi.
          </p>
          <div className="grid min-w-0 gap-3 sm:grid-cols-2">
            <label className="min-w-0 text-xs">
              Content starts below header: {form.contentTop}%
              <input
                type="range"
                aria-label="Keep top branding clear"
                min="10"
                max="35"
                value={form.contentTop}
                onChange={(e) => update({ contentTop: Number(e.target.value) })}
                className="mt-2 w-full"
              />
            </label>
            <label className="min-w-0 text-xs">
              Content ends above footer: {form.contentBottom}%
              <input
                type="range"
                aria-label="Keep bottom branding clear"
                min="65"
                max="92"
                value={form.contentBottom}
                onChange={(e) => update({ contentBottom: Number(e.target.value) })}
                className="mt-2 w-full"
              />
            </label>
          </div>
          {!validArea && (
            <p className="text-xs text-red-600" role="alert">
              Leave at least 45% clear height between header and footer.
            </p>
          )}
          {imported && (
            <div className="mx-auto w-full max-w-xs overflow-hidden rounded-lg border bg-white">
              <div
                className="relative"
                style={{ aspectRatio: `${imported.size.width}/${imported.size.height}` }}
              >
                <img
                  className="absolute inset-0 h-full w-full object-contain"
                  src={imported.pages[form.teachingIndex]!.image}
                  alt="Selected custom design with proposed editable text area"
                />
                <div
                  className="absolute left-[9%] w-[82%] rounded border-2 border-dashed border-emerald-500/90 bg-emerald-400/10 text-center text-[10px] font-bold text-emerald-900"
                  style={{
                    top: `${form.contentTop}%`,
                    height: `${form.contentBottom - form.contentTop}%`,
                  }}
                >
                  Editable text goes here — top &amp; bottom stay clear
                </div>
              </div>
            </div>
          )}
          <div className="flex flex-wrap gap-2">
            <label className="flex items-center gap-2 text-xs">
              <input
                type="radio"
                name="custom-ink"
                checked={form.ink === "dark"}
                onChange={() => update({ ink: "dark" })}
              />{" "}
              Dark text
            </label>
            <label className="flex items-center gap-2 text-xs">
              <input
                type="radio"
                name="custom-ink"
                checked={form.ink === "light"}
                onChange={() => update({ ink: "light" })}
              />{" "}
              White text
            </label>
            <label className="flex items-center gap-2 text-xs">
              <input
                type="checkbox"
                checked={form.readingPanel}
                onChange={(e) => update({ readingPanel: e.target.checked })}
              />{" "}
              Reading panel behind text
            </label>
          </div>
          <label className="flex items-start gap-2 text-sm">
            <input
              type="checkbox"
              checked={form.addBranding}
              onChange={(e) => update({ addBranding: e.target.checked })}
              className="mt-1"
            />
            My Canva design has NO name/logo/footer: add a replaceable KKCC logo and editable
            name/footer.
          </label>
          {form.addBranding && (
            <div className="grid min-w-0 gap-2 rounded-lg bg-muted/40 p-3 sm:grid-cols-2">
              {(["appName", "teacher", "series", "subject"] as const).map((key) => (
                <label key={key} className="min-w-0 text-xs">
                  {
                    {
                      appName: "Top centre name",
                      teacher: "Footer left",
                      series: "Footer right",
                      subject: "Subject",
                    }[key]
                  }
                  <Input
                    aria-label={`Custom brand ${key}`}
                    maxLength={100}
                    value={form.brand[key]}
                    onChange={(e) => setBrand(key, e.target.value)}
                  />
                </label>
              ))}
            </div>
          )}
          <p className="text-xs text-muted-foreground">
            Agar Canva page mein pehle se logo/name/footer hai, checkbox OFF rakhein—image mein wahi
            exactly rahega. Us printed text ko edit karna ho to Canva se blank master export karke
            checkbox ON karein.
          </p>
        </div>
        <div className="space-y-3 rounded-xl border bg-background p-3 sm:p-4">
          <h4 className="font-semibold">3. Generate → phone mein save karo</h4>
          <Button
            className="h-auto w-full whitespace-normal py-3 text-base sm:w-auto"
            onClick={() => void build()}
            disabled={!imported || !validArea || !form.text.trim()}
          >
            Make my editable PowerPoint
          </Button>
          {imported && !form.text.trim() && (
            <p className="text-xs text-muted-foreground">
              Paste lesson text in step 2 to enable generation.
            </p>
          )}
          <p className="text-xs text-muted-foreground">
            Canva artwork replaceable image layer hoti hai. Naya topic, lesson text aur optional
            name/footer native editable text; optional logo alag replaceable image hai. 60 slides /
            24 MB project max; limit par bina kuch delete kiye error milega.
          </p>
          {ready && (
            <div
              className="space-y-3 rounded-lg border-2 border-emerald-500/40 bg-emerald-50/40 p-3 dark:bg-emerald-950/20"
              aria-label="Custom PowerPoint ready"
            >
              <p className="font-semibold text-emerald-800 dark:text-emerald-300">
                ✓ {ready.deck.slides.length} slides ready ·{" "}
                {(ready.blob.size / 1024 / 1024).toFixed(1)} MB
              </p>
              {preview && (
                <img
                  src={preview}
                  alt="Preview of the generated editable-text slide"
                  className="mx-auto max-h-64 w-full rounded border object-contain"
                />
              )}
              <div className="flex flex-wrap gap-2">
                <Button asChild className="h-auto min-h-11 whitespace-normal">
                  <a href={ready.url} download={ready.filename}>
                    Download editable PPTX
                  </a>
                </Button>
                {canShare && (
                  <Button
                    variant="outline"
                    className="h-auto min-h-11 whitespace-normal"
                    onClick={() => void share()}
                  >
                    Share / Save to phone
                  </Button>
                )}
                <Button
                  variant="outline"
                  className="h-auto min-h-11 whitespace-normal"
                  onClick={() =>
                    downloadFile(
                      JSON.stringify(ready.deck),
                      `${safeFilename(ready.deck.title)}.kkcc-presentation.json`,
                      "application/json",
                    )
                  }
                >
                  Save editable project JSON
                </Button>
                <Button
                  variant="outline"
                  className="h-auto min-h-11 whitespace-normal"
                  onClick={() => {
                    if (onOpenInEditor(ready.deck)) {
                      setMessage(
                        "Slides opened in the detailed editor below. Save the project JSON to keep future edits.",
                      );
                      document
                        .getElementById("studio-editor")
                        ?.scrollIntoView({ behavior: "smooth", block: "start" });
                    }
                  }}
                >
                  Edit these slides in Studio
                </Button>
              </div>
              <p className="text-xs text-muted-foreground">
                Android: Download se Files/Downloads mein milega. iPhone: Share (if available) →
                Save to Files; warna browser ke Downloads/Share menu se Files choose karein. PPTX ko
                PowerPoint/compatible editor mein kholein. App mein aur edit karna ho to neeche
                editor kholein ya apna JSON project baad mein reopen karein. Purana project replace
                karne se pehle save karein.
              </p>
            </div>
          )}
        </div>
      </fieldset>
      {busy === "upload" && (
        <Button
          type="button"
          variant="outline"
          onClick={() => {
            cancelled.current = true;
            setMessage("Finishing current page before cancelling…");
          }}
        >
          Cancel import
        </Button>
      )}
      {busy && (
        <p role="status" className="text-sm font-medium">
          {busy === "upload" ? message : "Building your PPT… please keep this tab open."}
        </p>
      )}
      {!busy && !error && (
        <p role="status" className="text-sm text-muted-foreground">
          {message}
        </p>
      )}
      {error && (
        <p role="alert" className="text-sm font-medium text-red-700">
          {error}
        </p>
      )}
    </section>
  );
}
