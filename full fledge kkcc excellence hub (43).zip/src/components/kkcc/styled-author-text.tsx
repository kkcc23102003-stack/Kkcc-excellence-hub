import { officeInline } from "@/lib/notes-office";

/** Safely render teacher-authored bracket formatting and earlier PR #2 inline styles. */
export function StyledAuthorText({ text }: { text: string }) {
  return (
    <span
      className="whitespace-pre-wrap break-words"
      dangerouslySetInnerHTML={{ __html: officeInline(text ?? "") }}
    />
  );
}
