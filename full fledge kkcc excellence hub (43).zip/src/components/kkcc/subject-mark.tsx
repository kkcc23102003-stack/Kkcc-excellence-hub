import { Atom, BookOpen, Calculator, Globe2, Languages, Landmark } from "lucide-react";
import { cn } from "@/lib/utils";

/** Quiet subject identifiers, not decorative 3D artwork or third-party branding. */
export function SubjectMark({ subject, className }: { subject: string; className?: string }) {
  const Icon = /math|algebra|geometry|reasoning|account|commerce|गणित|ਗਣਿਤ/i.test(subject)
    ? Calculator
    : /science|physics|chemistry|biology|medical|neet|ਵਿਗਿਆਨ|विज्ञान/i.test(subject)
      ? Atom
      : /geography|world|environment/i.test(subject)
        ? Globe2
        : /history|polity|sst|general knowledge|punjab gk/i.test(subject)
          ? Landmark
          : /punjabi|hindi|english|language|ਪੰਜਾਬੀ|हिन्दी/i.test(subject)
            ? Languages
            : BookOpen;
  return (
    <span aria-hidden="true" className={cn("subject-mark", className)}>
      <Icon strokeWidth={1.6} className="h-[52%] w-[52%]" />
    </span>
  );
}
