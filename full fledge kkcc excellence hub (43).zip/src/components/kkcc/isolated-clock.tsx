import { useEffect, useRef, useState } from "react";

/** Only the clock rerenders on ticks. Exam state updates at question boundaries or expiry. */
export function AttemptClock({
  getElapsed,
  duration,
  questionSeconds,
  active,
  onBoundary,
}: {
  getElapsed: () => number;
  duration: number;
  questionSeconds: number;
  active: boolean;
  onBoundary: (elapsed: number) => void;
}) {
  const [elapsed, setElapsed] = useState(getElapsed);
  const lastBoundary = useRef<string | number | null>(null);
  useEffect(() => {
    if (!active || duration <= 0) return;
    const tick = () => {
      const next = getElapsed();
      setElapsed(next);
      const boundary =
        next >= duration
          ? "expired"
          : questionSeconds > 0
            ? Math.floor(next / questionSeconds)
            : "running";
      if (boundary !== lastBoundary.current) {
        lastBoundary.current = boundary;
        onBoundary(next);
      }
    };
    tick();
    const id = window.setInterval(tick, 250);
    document.addEventListener("visibilitychange", tick);
    return () => {
      window.clearInterval(id);
      document.removeEventListener("visibilitychange", tick);
    };
  }, [active, duration, questionSeconds, getElapsed, onBoundary]);
  const remaining = Math.max(0, duration - elapsed);
  return (
    <span data-testid="attempt-clock">
      {duration <= 0
        ? "No timer"
        : `${String(Math.floor(remaining / 60)).padStart(2, "0")}:${String(remaining % 60).padStart(2, "0")}`}
    </span>
  );
}

/** Separate leaves may share a deadline; none update their question-page parent per second. */
export function QuizClock({
  deadline,
  active,
  total,
  onExpire,
  variant = "text",
}: {
  deadline: number;
  active: boolean;
  total: number;
  onExpire?: () => void;
  variant?: "text" | "bar";
}) {
  const [remaining, setRemaining] = useState(total);
  const callback = useRef(onExpire);
  useEffect(() => {
    callback.current = onExpire;
  }, [onExpire]);
  useEffect(() => {
    setRemaining(total);
  }, [deadline, total]);
  useEffect(() => {
    if (!active) return;
    let fired = false;
    const tick = () => {
      const next = Math.max(0, Math.ceil((deadline - Date.now()) / 1000));
      setRemaining(next);
      if (next === 0 && !fired) {
        fired = true;
        callback.current?.();
      }
    };
    tick();
    const id = window.setInterval(tick, 250);
    document.addEventListener("visibilitychange", tick);
    return () => {
      window.clearInterval(id);
      document.removeEventListener("visibilitychange", tick);
    };
  }, [deadline, active]);
  return variant === "bar" ? (
    <div
      className="h-full rounded-full bg-primary"
      style={{ width: `${(remaining / total) * 100}%` }}
    />
  ) : (
    <span>{remaining}s</span>
  );
}
