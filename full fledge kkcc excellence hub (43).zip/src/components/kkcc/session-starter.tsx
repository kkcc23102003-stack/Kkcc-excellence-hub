import { useState } from "react";
import { Link } from "@tanstack/react-router";
import { ArrowRight, BookOpen, NotebookPen, FileCheck2, Check } from "lucide-react";
import { Button } from "@/components/ui/button";

const intentions = [
  {
    label: "Understand a topic",
    icon: BookOpen,
    title: "Make room for one new idea.",
    description:
      "Choose a lesson from your learning space. Go at your own pace, and pause whenever you need.",
    action: "Explore my learning",
    to: "/learn",
  },
  {
    label: "Revise a chapter",
    icon: NotebookPen,
    title: "Turn familiar into confident.",
    description: "Open your notes, choose one chapter and revisit the ideas you want to remember.",
    action: "Find my notes",
    to: "/study-material",
  },
  {
    label: "Test my understanding",
    icon: FileCheck2,
    title: "See what clicks. Learn what’s next.",
    description:
      "Choose a practice test that fits your preparation. Use your results to decide what to revisit.",
    action: "Choose a practice test",
    to: "/test-series",
  },
] as const;

/** A voluntary study intention, not a tracked goal, streak or invented progress. */
export function SessionStarter() {
  const [selected, setSelected] = useState(0);
  const intention = intentions[selected]!;
  return (
    <section className="session-starter" aria-labelledby="session-title">
      <div className="session-starter-intro">
        <p className="text-[10px] font-bold uppercase tracking-[.18em] text-primary">
          Small steps, real learning
        </p>
        <h2 id="session-title" className="mt-2 text-xl font-bold sm:text-2xl">
          What feels right today?
        </h2>
        <p className="mt-2 text-sm leading-relaxed text-muted-foreground">
          One topic is a good place to start.
        </p>
        <div
          className="mt-5 flex flex-wrap gap-2"
          role="group"
          aria-label="Choose a study intention"
        >
          {intentions.map(({ label, icon: Icon }, index) => (
            <button
              key={label}
              type="button"
              className="intention-choice"
              aria-pressed={selected === index}
              onClick={() => setSelected(index)}
            >
              <Icon className="h-4 w-4 shrink-0" aria-hidden="true" />
              {label}
              {selected === index && <Check className="h-3.5 w-3.5 shrink-0" aria-hidden="true" />}
            </button>
          ))}
        </div>
      </div>
      <div className="session-starter-detail">
        <div aria-live="polite" aria-atomic="true">
          <p className="text-base font-semibold leading-snug">{intention.title}</p>
          <p className="mt-2 text-sm leading-relaxed text-muted-foreground">
            {intention.description}
          </p>
        </div>
        <Button asChild className="mt-5 h-auto min-h-11 whitespace-normal py-2 text-left">
          <Link to={intention.to}>
            {intention.action}
            <ArrowRight className="h-4 w-4 shrink-0" aria-hidden="true" />
          </Link>
        </Button>
        <p className="mt-3 text-[11px] text-muted-foreground">Your pace. Your next step.</p>
      </div>
    </section>
  );
}
