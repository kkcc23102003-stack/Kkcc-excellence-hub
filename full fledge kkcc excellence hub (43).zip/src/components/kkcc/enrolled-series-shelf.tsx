import { SubjectMark } from "./subject-mark";
import { Link } from "@tanstack/react-router";
import { useQuery } from "@tanstack/react-query";
import { getCustomSeriesCatalog, listSeriesOverrides } from "@/lib/content.functions";
import { getEffectiveLearningSeries } from "@/lib/test-series-catalog";
import { accessValidity } from "@/lib/subject-artwork";
import { Button } from "@/components/ui/button";

export function EnrolledSeriesShelf({
  grants,
}: {
  grants: readonly { series_id: string; expires_at: string | null }[];
}) {
  const catalog = useQuery({
    queryKey: ["public", "custom-series-catalog"],
    queryFn: () => getCustomSeriesCatalog(),
    enabled: grants.length > 0,
  });
  const overrides = useQuery({
    queryKey: ["public", "series-overrides"],
    queryFn: () => listSeriesOverrides(),
    enabled: grants.length > 0,
  });
  if (!grants.length) return null;
  const entries = new Map(
    getEffectiveLearningSeries(catalog.data ?? {}).map((series) => [series.id, series]),
  );
  return (
    <div className="mt-5">
      <h3 className="text-sm font-semibold">Your enrolled series</h3>
      {(catalog.isError || overrides.isError) && (
        <p role="alert" className="mt-2 text-sm">
          Series names could not load.{" "}
          <Button
            variant="link"
            onClick={() => {
              void catalog.refetch();
              void overrides.refetch();
            }}
          >
            Retry
          </Button>
        </p>
      )}
      <div className="mt-3 grid gap-3 md:grid-cols-2 xl:grid-cols-3">
        {[...new Set(grants.map((grant) => grant.series_id))].map((id) => {
          const series = entries.get(id),
            override = overrides.data?.find((row) => row.series_id === id);
          const title = override?.name || series?.name || id;
          return (
            <article
              key={id}
              className="surface-panel flex min-w-0 flex-col p-4"
              data-testid="home-enrolled-series"
            >
              <div className="flex items-center gap-3">
                <SubjectMark subject={title} />
                <div className="min-w-0">
                  <h4 className="text-sm font-semibold break-words">{title}</h4>
                  <p className="mt-1 text-xs text-muted-foreground">
                    {accessValidity(grants.filter((grant) => grant.series_id === id))}
                  </p>
                </div>
              </div>
              <Button asChild variant="secondary" className="mt-4">
                <Link to="/test-series/learn/$seriesId" params={{ seriesId: id }}>
                  Start Learning
                </Link>
              </Button>
            </article>
          );
        })}
      </div>
    </div>
  );
}
