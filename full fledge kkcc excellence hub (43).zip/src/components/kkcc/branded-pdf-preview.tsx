import { useEffect, useRef, useState } from "react";
import type { PDFDocumentProxy } from "pdfjs-dist";
import { Button } from "@/components/ui/button";
import { openBrowserPdf, renderPdfPage } from "@/lib/pdf-browser";

/** Renders branded bytes in our own canvas, not a native PDF iframe that may download originals. */
export function BrandedPdfPreview({
  bytes,
  onLastPageViewed,
}: {
  bytes: Uint8Array;
  onLastPageViewed?: ((viewed: boolean) => void) | undefined;
}) {
  const host = useRef<HTMLDivElement>(null);
  const [pdf, setPdf] = useState<PDFDocumentProxy | null>(null);
  const [page, setPage] = useState(1);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");

  useEffect(() => {
    let active = true;
    let current: PDFDocumentProxy | null = null;
    void (async () => {
      try {
        current = await openBrowserPdf(bytes);
        if (active) {
          setPdf(current);
          setPage(1);
        } else await current.loadingTask.destroy();
      } catch (cause) {
        if (active)
          setError(cause instanceof Error ? cause.message : "Could not open this branded PDF.");
      }
    })();
    return () => {
      active = false;
      if (current) void current.loadingTask.destroy().catch(() => {});
    };
  }, [bytes]);

  useEffect(() => {
    if (!pdf) return;
    let active = true;
    let canvas: HTMLCanvasElement | null = null;
    const canvasHost = host.current;
    void renderPdfPage(pdf, page, 1.35)
      .then((result) => {
        canvas = result.canvas;
        if (!active) {
          canvas.width = 0;
          canvas.height = 0;
          return;
        }
        canvas.style.maxWidth = "100%";
        canvas.style.height = "auto";
        canvas.setAttribute("aria-label", `KKCC branded PDF page ${page}`);
        canvasHost?.replaceChildren(canvas);
        setLoading(false);
        if (page === pdf.numPages) onLastPageViewed?.(true);
      })
      .catch((cause) => {
        if (active)
          setError(cause instanceof Error ? cause.message : "Could not display this PDF page.");
      });
    return () => {
      active = false;
      if (canvas) {
        canvas.width = 0;
        canvas.height = 0;
      }
      canvasHost?.replaceChildren();
    };
  }, [pdf, page, onLastPageViewed]);

  return (
    <div className="space-y-3 p-3" data-testid="branded-pdf-preview">
      <div className="flex flex-wrap items-center gap-2 text-sm">
        <strong>KKCC branded preview</strong>
        <Button
          size="sm"
          variant="outline"
          disabled={!pdf || page <= 1}
          onClick={() => {
            setLoading(true);
            setPage((number) => number - 1);
          }}
        >
          Previous PDF page
        </Button>
        <span>
          Page {page} / {pdf?.numPages ?? "…"}
        </span>
        <Button
          size="sm"
          variant="outline"
          disabled={!pdf || page >= pdf.numPages}
          onClick={() => {
            setLoading(true);
            setPage((number) => number + 1);
          }}
        >
          Next PDF page
        </Button>
      </div>
      {loading && !error && <p role="status">Rendering branded PDF page…</p>}
      {error && <p role="alert">{error}. No original PDF was displayed.</p>}
      <div ref={host} className="flex min-h-24 justify-center overflow-auto bg-white" />
    </div>
  );
}
