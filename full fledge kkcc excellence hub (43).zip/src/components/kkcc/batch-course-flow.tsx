import { useEffect, useMemo, useRef, useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { Link } from "@tanstack/react-router";
import { BookOpen, ChevronRight, PlayCircle } from "lucide-react";
import { SiteLayout } from "./site-layout";
import { StudentJourney } from "./student-journey";
import { MaterialAccessButton } from "./material-access-button";
import { NoteFollowUpTest } from "./note-follow-up-reader";
import { Button } from "@/components/ui/button";
import { getMyBatchLesson } from "@/lib/notes-batch.functions";
import { nextChapterVideo, type BatchLesson, type BatchOutline } from "@/lib/notes-batch";
import type { Course } from "@/lib/cms";
import { parseVisualDirectives } from "@/lib/notes-visuals/directives";
import { videoSource } from "@/lib/video";

export function BatchCourseFlow({
  course,
  outline,
  userId,
  hasAccess,
}: {
  course: Course;
  outline: BatchOutline;
  userId: string | null;
  hasAccess: boolean;
}) {
  const [activeId, setActiveId] = useState(
    outline.lessons.find((lesson) => lesson.hasVideo)?.noteId ?? outline.lessons[0]?.noteId ?? "",
  );
  const [autoplayId, setAutoplayId] = useState("");
  const navigateTo = (noteId: string, afterCountdown = false) => {
    setAutoplayId(afterCountdown ? noteId : "");
    setActiveId(noteId);
  };
  const active = outline.lessons.find((lesson) => lesson.noteId === activeId) ?? outline.lessons[0];
  useEffect(() => {
    if (!outline.lessons.some((lesson) => lesson.noteId === activeId))
      setActiveId(
        outline.lessons.find((lesson) => lesson.hasVideo)?.noteId ??
          outline.lessons[0]?.noteId ??
          "",
      );
  }, [outline, activeId]);
  const subjects = useMemo(
    () => [
      ...new Map(outline.lessons.map((lesson) => [lesson.subjectId, lesson.subject])).entries(),
    ],
    [outline.lessons],
  );

  return (
    <SiteLayout>
      <div className="mx-auto w-full max-w-7xl px-4 pt-6 sm:px-6">
        <StudentJourney active="learn" courseSlug={course.slug} courseTitle={course.title} />
      </div>
      <div className="mx-auto grid w-full max-w-7xl gap-6 px-4 py-8 sm:px-6 lg:grid-cols-[290px_minmax(0,1fr)]">
        <aside
          className="h-fit min-w-0 rounded-2xl border bg-card p-4 lg:sticky lg:top-20"
          aria-label="Batch syllabus"
        >
          <p className="text-xs font-bold uppercase tracking-wider text-primary">Video Batch</p>
          <h1 className="mt-1 break-words text-lg font-bold">{course.title}</h1>
          <p className="mt-1 text-xs text-muted-foreground">
            {outline.seriesName} · Subject → Chapter → Topic → Video
          </p>
          {subjects.map(([subjectId, subject]) => {
            const subjectLessons = outline.lessons.filter(
              (lesson) => lesson.subjectId === subjectId,
            );
            const chapters = [
              ...new Map(
                subjectLessons.map((lesson) => [lesson.chapterId, lesson.chapter]),
              ).entries(),
            ];
            return (
              <details
                key={subjectId}
                open={active?.subjectId === subjectId ? true : undefined}
                className="mt-3 rounded-xl border p-2"
              >
                <summary className="cursor-pointer break-words rounded-lg border border-primary/20 bg-secondary/60 p-2 text-sm font-bold text-secondary-foreground hover:bg-secondary-hover focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring">
                  {subject}
                </summary>
                {chapters.map(([chapterId, chapter]) => (
                  <details
                    key={chapterId}
                    open={active?.chapterId === chapterId ? true : undefined}
                    className="ml-2 border-l pl-2"
                  >
                    <summary className="cursor-pointer break-words rounded-md bg-primary/10 px-2 py-2 text-xs font-semibold hover:bg-secondary-hover focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring">
                      {chapter}
                    </summary>
                    {subjectLessons
                      .filter((lesson) => lesson.chapterId === chapterId)
                      .map((lesson) => (
                        <button
                          type="button"
                          key={lesson.noteId}
                          aria-current={active?.noteId === lesson.noteId ? "step" : undefined}
                          className={`my-1 flex min-h-11 w-full cursor-pointer items-start gap-2 rounded-lg border p-2 text-left text-xs focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring ${active?.noteId === lesson.noteId ? "border-primary bg-primary/25 font-bold text-foreground" : "border-primary/20 bg-secondary/60 text-secondary-foreground hover:border-primary/50 hover:bg-secondary-hover"}`}
                          onClick={() => navigateTo(lesson.noteId)}
                        >
                          {lesson.hasVideo ? (
                            <PlayCircle className="mt-0.5 h-4 w-4 shrink-0" />
                          ) : (
                            <BookOpen className="mt-0.5 h-4 w-4 shrink-0" />
                          )}
                          <span className="min-w-0 break-words">
                            {lesson.topic && (
                              <span className="block text-[11px] text-muted-foreground">
                                {lesson.topic}
                              </span>
                            )}
                            {lesson.title}
                            {!lesson.hasVideo && " · Video coming soon"}
                          </span>
                        </button>
                      ))}
                  </details>
                ))}
              </details>
            );
          })}
          {!outline.lessons.length && (
            <p className="mt-4 text-sm">No published notes in this Batch yet.</p>
          )}
        </aside>
        <main className="min-w-0 space-y-5">
          {!userId ? (
            <div className="rounded-2xl border bg-card p-6">
              <h2 className="text-xl font-bold">Sign in to open your Batch</h2>
              <Button asChild className="mt-4">
                <Link
                  to="/login"
                  search={{ redirectTo: `/learn?course=${encodeURIComponent(course.slug)}` }}
                >
                  Sign in
                </Link>
              </Button>
            </div>
          ) : !hasAccess ? (
            <div className="rounded-2xl border bg-card p-6">
              <h2 className="text-xl font-bold">Batch enrolment required</h2>
              <p className="mt-2 text-sm text-muted-foreground">
                Notes-only purchases do not unlock videos. Batch access is purchased separately.
              </p>
              <Button asChild className="mt-4">
                <Link to="/checkout" search={{ course: course.slug }}>
                  Get Batch access
                </Link>
              </Button>
            </div>
          ) : active ? (
            <BatchLessonView
              key={`${course.id}:${active.noteId}`}
              courseId={course.id}
              userId={userId}
              lesson={active}
              next={nextChapterVideo(outline.lessons, active.noteId)}
              autoPlayRequested={autoplayId === active.noteId}
              onNavigate={navigateTo}
            />
          ) : (
            <p className="rounded-2xl border p-6">
              Publish a note and link a video in Course Admin to begin.
            </p>
          )}
        </main>
      </div>
    </SiteLayout>
  );
}

function BatchLessonView({
  courseId,
  userId,
  lesson,
  next,
  autoPlayRequested,
  onNavigate,
}: {
  courseId: string;
  userId: string;
  lesson: BatchLesson;
  next: BatchLesson | null;
  autoPlayRequested: boolean;
  onNavigate: (noteId: string, afterCountdown?: boolean) => void;
}) {
  const lessonQuery = useQuery({
    queryKey: ["batch-lesson", userId, courseId, lesson.noteId],
    queryFn: () => getMyBatchLesson({ data: { courseId, noteId: lesson.noteId } }),
    retry: false,
    staleTime: 0,
    gcTime: 0,
    refetchInterval: 15_000,
    refetchOnWindowFocus: true,
  });
  const [phase, setPhase] = useState<"video" | "choice" | "notes" | "test">("video");
  const [choiceRemaining, setChoiceRemaining] = useState(5);
  const [resultSubmitted, setResultSubmitted] = useState(false);
  const [nextRemaining, setNextRemaining] = useState<number | null>(null);
  const [nextPaused, setNextPaused] = useState(false);
  const frame = useRef<HTMLIFrameElement>(null);
  const data = lessonQuery.isError ? undefined : lessonQuery.data;
  const test = useMemo(
    () => (data ? parseVisualDirectives(data.note.description).directives.followUpTest : null),
    [data],
  );
  const source = videoSource(data?.video_url);
  const finishVideo = () => {
    setChoiceRemaining(5);
    setPhase("choice");
  };
  useEffect(() => {
    if (phase !== "video" || source.kind !== "youtube") return;
    const onEnded = (event: MessageEvent) => {
      if (
        event.origin === window.location.origin &&
        event.source === frame.current?.contentWindow &&
        event.data?.type === "kkcc:video-ended"
      )
        finishVideo();
    };
    window.addEventListener("message", onEnded);
    return () => window.removeEventListener("message", onEnded);
  }, [phase, source.kind]);
  useEffect(() => {
    if (phase !== "choice" || !test) return;
    if (choiceRemaining <= 0) {
      setPhase("test");
      return;
    }
    const timer = window.setTimeout(() => setChoiceRemaining((value) => value - 1), 1000);
    return () => window.clearTimeout(timer);
  }, [phase, test, choiceRemaining]);
  useEffect(() => {
    if (!data || !resultSubmitted || !next || nextPaused || nextRemaining === null) return;
    if (nextRemaining <= 0) {
      onNavigate(next.noteId, true);
      return;
    }
    const timer = window.setTimeout(() => setNextRemaining((value) => (value ?? 1) - 1), 1000);
    return () => window.clearTimeout(timer);
  }, [data, resultSubmitted, next, nextPaused, nextRemaining, onNavigate]);
  if (lessonQuery.isPending)
    return (
      <p role="status" className="rounded-2xl border p-6">
        Checking Batch access and loading this lesson…
      </p>
    );
  if (lessonQuery.isError || !data)
    return (
      <div role="alert" className="rounded-2xl border bg-card p-6">
        <h2 className="text-lg font-bold">Lesson unavailable</h2>
        <p className="mt-2 text-sm">{lessonQuery.error?.message ?? "Try again."}</p>
        <Button className="mt-3" variant="outline" onClick={() => void lessonQuery.refetch()}>
          Retry access check
        </Button>
      </div>
    );
  return (
    <>
      <div className="rounded-2xl border bg-card p-4 sm:p-6">
        <p className="text-xs font-semibold text-primary">
          {lesson.subject} <ChevronRight className="inline h-3 w-3" /> {lesson.chapter}
          {lesson.topic ? ` / ${lesson.topic}` : ""}
        </p>
        <h2 className="mt-1 break-words text-xl font-bold">{lesson.title}</h2>
        {phase === "video" && (
          <>
            <div className="relative mt-4 aspect-video overflow-hidden rounded-xl bg-black text-white">
              {source.kind === "youtube" ? (
                <iframe
                  ref={frame}
                  title={`${lesson.title} video`}
                  src={autoPlayRequested ? `${source.src}&autoplay=1` : source.src}
                  className="absolute inset-0 h-full w-full border-0"
                  allow="autoplay; encrypted-media; picture-in-picture; fullscreen"
                  allowFullScreen
                />
              ) : source.kind === "file" ? (
                <video
                  key={source.src}
                  src={source.src}
                  controls
                  playsInline
                  autoPlay={autoPlayRequested}
                  preload="metadata"
                  controlsList="nodownload"
                  onEnded={finishVideo}
                  className="absolute inset-0 h-full w-full"
                />
              ) : source.kind === "external" ? (
                <iframe
                  title={`${lesson.title} hosted video`}
                  src={source.src}
                  className="absolute inset-0 h-full w-full border-0"
                  allow="autoplay; encrypted-media; picture-in-picture; fullscreen"
                  allowFullScreen
                  referrerPolicy="strict-origin-when-cross-origin"
                />
              ) : (
                <div className="grid h-full place-items-center p-4 text-center text-sm">
                  Video not yet linked. Read the notes or choose another lesson.
                </div>
              )}
            </div>
            <div className="mt-3 flex flex-wrap items-center gap-2">
              {source.kind !== "none" && (
                <Button onClick={finishVideo}>Finish video · Notes or Test</Button>
              )}
              {(source.kind === "external" || source.kind === "file") && (
                <Button asChild variant="outline">
                  <a
                    href={source.kind === "external" ? source.original : source.src}
                    target="_blank"
                    rel="noopener noreferrer"
                  >
                    {source.kind === "external"
                      ? "Open on host if blocked"
                      : "Open video on this device"}
                  </a>
                </Button>
              )}
              {source.kind === "none" && (
                <Button onClick={() => setPhase("notes")}>Read Notes</Button>
              )}
            </div>
            <p className="mt-2 text-xs text-muted-foreground">
              {source.kind === "youtube"
                ? "YouTube completion is detected when the enhanced player can report it. Use Finish video if blocked or if basic playback is used."
                : source.kind === "file"
                  ? "Video completion opens Notes or Test. If playback or autoplay is blocked, use Finish video."
                  : "External players may block embedding or completion events; open on host and use Finish video manually."}
            </p>
          </>
        )}
        {phase === "choice" && (
          <div className="mt-4 space-y-3 rounded-xl border border-primary/30 bg-primary/5 p-4">
            <h3 className="font-bold">Video complete · what next?</h3>
            <div className="flex flex-wrap gap-2">
              <Button onClick={() => setPhase("notes")}>Read Notes</Button>
              {test && (
                <Button variant="outline" onClick={() => setPhase("test")}>
                  Start Test
                </Button>
              )}
              {!test && next && (
                <Button variant="outline" onClick={() => onNavigate(next.noteId)}>
                  Open next chapter video
                </Button>
              )}
              <Button variant="ghost" onClick={() => setPhase("video")}>
                Watch video again
              </Button>
            </div>
            {test ? (
              <p role="status" aria-live="polite" className="text-sm">
                No choice? Test starts in {choiceRemaining} seconds.
              </p>
            ) : (
              <p className="text-sm">
                No after-note test is attached to this note yet. Continue with Notes or the next
                chapter.
              </p>
            )}
          </div>
        )}
        {phase === "notes" && (
          <div className="mt-4 space-y-3">
            <p className="text-sm text-muted-foreground">
              The same authored notes are still in the Notes section. Reading through the Batch
              never changes your note purchases.
            </p>
            <MaterialAccessButton
              key={lesson.noteId}
              fileUrl={null}
              materialId={lesson.noteId}
              title={data.note.title}
              subject={data.note.subject}
              chapter={data.note.chapter}
              materialType={data.note.material_type}
              accessType="paid"
              batchCourseId={courseId}
              autoOpen
              onBatchStartTest={() => setPhase("test")}
              className="w-full"
            />
            <div className="flex flex-wrap gap-2">
              {test && <Button onClick={() => setPhase("test")}>Start Test</Button>}
              <Button variant="outline" onClick={() => setPhase("video")}>
                Back to video
              </Button>
            </div>
          </div>
        )}
      </div>
      {phase === "test" && test && (
        <div className="space-y-3">
          <NoteFollowUpTest
            key={`${courseId}-${lesson.noteId}`}
            test={test}
            onBack={() => setPhase("notes")}
            onComplete={() => {
              setResultSubmitted(true);
              setNextPaused(false);
              setNextRemaining(next ? 10 : null);
            }}
            onRetry={() => {
              setResultSubmitted(false);
              setNextRemaining(null);
            }}
          />
          {resultSubmitted && next && (
            <div className="rounded-xl border border-primary/30 bg-primary/5 p-4 text-sm">
              <p role="status" aria-live="polite">
                Next chapter’s video: {next.subject} / {next.chapter} · {nextRemaining} seconds
                {nextPaused ? " (paused)" : ""}.
              </p>
              <p className="mt-1 text-xs text-muted-foreground">
                The next lesson opens automatically. If your browser blocks autoplay, tap Play in
                the video player.
              </p>
              <div className="mt-3 flex flex-wrap gap-2">
                <Button size="sm" onClick={() => onNavigate(next.noteId)}>
                  Open next video now
                </Button>
                <Button
                  size="sm"
                  variant="outline"
                  onClick={() => setNextPaused((value) => !value)}
                >
                  {nextPaused ? "Resume countdown" : "Pause countdown"}
                </Button>
              </div>
            </div>
          )}
          {resultSubmitted && !next && (
            <p role="status" className="rounded-xl border p-4 text-sm">
              Score sirf screen par dikhaya gaya hai; answers aur attempts save nahi hote. No later
              chapter video is available yet; choose another lesson or retry as often as you like.
            </p>
          )}
        </div>
      )}
      {phase === "test" && !test && (
        <div className="rounded-xl border p-4 text-sm">
          No test attached to this note.{" "}
          <Button variant="outline" onClick={() => setPhase("notes")}>
            Read Notes
          </Button>
        </div>
      )}
      {phase !== "test" && next && !test && (
        <Button variant="outline" onClick={() => onNavigate(next.noteId)}>
          Next chapter video: {next.chapter}
        </Button>
      )}
    </>
  );
}
