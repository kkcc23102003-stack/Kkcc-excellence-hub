import { formatNoteSelection } from "@/lib/notes-office";
import { clearAuthorColour, wrapAuthorSelection } from "@/lib/author-colours";
import { AuthorColourMixer } from "./author-colour-mixer";
import { QUICK_NOTE_TEXT_COLOURS, QUICK_NOTE_HIGHLIGHTS } from "@/lib/author-quick-colours";
import { useEffect, useRef, useState } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";

type Props = {
  value: string;
  disabled?: boolean | undefined;
  selection: () => { start: number; end: number };
  replace: (text: string) => void;
  change: (text: string) => void;
};
export function NotesOfficeToolbar({ value, disabled, selection, replace, change }: Props) {
  const history = useRef({
    past: [] as string[],
    future: [] as string[],
    current: value,
    navigating: false,
  });
  const [, refresh] = useState(0);
  const [find, setFind] = useState("");
  const [replacement, setReplacement] = useState("");
  const [colourHint, setColourHint] = useState("");
  const oneTapColour = (kind: "color" | "highlight", hex: string) => {
    const { start, end } = selection();
    if (start >= end) {
      setColourHint("Pehle note ke shabd select karein; phir colour tap karein.");
      return;
    }
    setColourHint("");
    replace(wrapAuthorSelection(value.slice(start, end), kind, hex));
  };
  const [cells, setCells] = useState([
    ["Heading 1", "Heading 2"],
    ["", ""],
  ]);
  useEffect(() => {
    const h = history.current;
    if (h.current === value) return;
    if (!h.navigating) {
      h.past.push(h.current);
      if (h.past.length > 30) h.past.shift();
      h.future = [];
    }
    h.current = value;
    h.navigating = false;
    refresh((n) => n + 1);
  }, [value]);
  const wrap = (tag: string) => {
    const { start, end } = selection();
    replace(formatNoteSelection(value.slice(start, end), tag));
  };
  const lines = (prefix: string) => {
    const { start, end } = selection();
    replace(
      "\n" +
        (value.slice(start, end) || "Heading or point")
          .split("\n")
          .map((line, i) => `${prefix === "number" ? `${i + 1}. ` : prefix}${line}`)
          .join("\n") +
        "\n",
    );
  };
  const navigate = (undo: boolean) => {
    const h = history.current,
      source = undo ? h.past : h.future;
    const next = source.pop();
    if (next === undefined) return;
    (undo ? h.future : h.past).push(value);
    h.navigating = true;
    change(next);
  };
  return (
    <fieldset
      disabled={disabled}
      className="min-w-0 max-w-full space-y-3 overflow-hidden rounded-xl border bg-muted/20 p-3"
      aria-label="Notes formatting tools"
    >
      <p className="text-sm font-semibold">Notes formatting studio</p>
      <p className="text-xs text-muted-foreground">
        Select text, then choose a tool. The preview and PDF show the finished design. A colon never
        auto-highlights a label; topic strips are only for headings you mark with ## or choose in
        the preview. Text and formatting stay editable without accepting unsafe HTML.
      </p>
      <div role="group" aria-label="Text formatting" className="flex flex-wrap gap-2">
        {[
          ["b", "Bold"],
          ["i", "Italic"],
          ["u", "Underline"],
          ["mark", "Highlight"],
          ["sup", "Superscript"],
          ["sub", "Subscript"],
          ["box", "Important box"],
        ].map(([tag, label]) => (
          <Button
            key={tag}
            type="button"
            size="sm"
            variant="outline"
            onMouseDown={(e) => e.preventDefault()}
            onClick={() => wrap(tag!)}
          >
            {label}
          </Button>
        ))}
        <Button type="button" size="sm" variant="outline" onClick={() => lines("## ")}>
          Heading
        </Button>
        <Button type="button" size="sm" variant="outline" onClick={() => lines("- ")}>
          Bullets
        </Button>
        <Button type="button" size="sm" variant="outline" onClick={() => lines("number")}>
          Numbering
        </Button>
        <Button
          type="button"
          size="sm"
          variant="outline"
          onClick={() => replace("\nx = \\frac{a}{b}\n")}
        >
          Formula
        </Button>
        <Button
          type="button"
          size="sm"
          variant="outline"
          disabled={!history.current.past.length}
          onClick={() => navigate(true)}
        >
          Undo formatting / typing
        </Button>
        <Button
          type="button"
          size="sm"
          variant="outline"
          disabled={!history.current.future.length}
          onClick={() => navigate(false)}
        >
          Redo
        </Button>
      </div>
      <div className="flex flex-wrap gap-3">
        {[
          {
            label: "Text colour",
            key: "color",
            options: ["teal", "blue", "purple", "red", "green"],
          },
          {
            label: "Font size",
            key: "size",
            options: ["12", "14", "16", "18", "20", "24", "28", "32"],
          },
          { label: "Alignment", key: "align", options: ["left", "center", "right", "justify"] },
        ].map((control) => (
          <label key={control.key} className="text-xs">
            {control.label}
            <select
              aria-label={control.label}
              className="ml-2 rounded border bg-background p-2"
              value=""
              onChange={(e) => wrap(`${control.key}=${e.target.value}`)}
            >
              <option value="" disabled>
                Choose
              </option>
              {control.options.map((option) => (
                <option key={option}>{option}</option>
              ))}
            </select>
          </label>
        ))}
      </div>
      <div className="rounded-lg border bg-background p-2">
        <p className="text-xs font-semibold">One-tap colours · select words, then tap</p>
        {(
          [
            ["Text", QUICK_NOTE_TEXT_COLOURS, "color"],
            ["Highlight", QUICK_NOTE_HIGHLIGHTS, "highlight"],
          ] as const
        ).map(([name, choices, kind]) => (
          <div
            key={name}
            role="group"
            aria-label={`Notes ${name.toLowerCase()} quick colours`}
            className="mt-2 flex items-center gap-1 overflow-x-auto"
          >
            <span className="shrink-0 text-[11px] font-bold">{name}</span>
            {choices.map(({ name: colourName, hex }) => (
              <button
                key={hex}
                type="button"
                aria-label={`Notes ${name.toLowerCase()} ${colourName}`}
                title={`${name} ${colourName}`}
                disabled={disabled}
                onMouseDown={(event) => event.preventDefault()}
                onClick={() => oneTapColour(kind, hex)}
                className="grid h-11 w-11 shrink-0 place-items-center rounded-lg border-2 border-foreground/20 font-bold"
                style={
                  kind === "color"
                    ? { background: "white", color: hex, borderBottomColor: hex }
                    : { backgroundColor: hex, color: "#111" }
                }
              >
                {kind === "color" ? "A" : "▬"}
              </button>
            ))}
          </div>
        ))}
        {colourHint && (
          <p role="status" className="mt-1 text-xs text-destructive">
            {colourHint}
          </p>
        )}
      </div>
      <details className="rounded-lg border bg-background p-2">
        <summary className="min-h-11 cursor-pointer py-2 text-sm font-semibold">
          More writing colours · custom mixer
        </summary>
        <AuthorColourMixer
          disabled={disabled}
          onApply={(kind, colour) => {
            const { start, end } = selection();
            replace(wrapAuthorSelection(value.slice(start, end), kind, colour));
          }}
          onClear={(kind) => {
            const { start, end } = selection();
            replace(clearAuthorColour(value.slice(start, end), kind));
          }}
        />
      </details>
      <details>
        <summary className="cursor-pointer text-sm font-medium">
          Table builder / Find and replace
        </summary>
        <div className="mt-3 space-y-3">
          <p className="text-xs text-muted-foreground">
            First row is the header. Tab-separated cells remain editable in the note source after
            insertion. To replace an existing table, select its complete :::table block first.
          </p>
          <div className="overflow-auto">
            <table className="w-full">
              <tbody>
                {cells.map((row, r) => (
                  <tr key={r}>
                    {row.map((cell, c) => (
                      <td key={c}>
                        <Input
                          aria-label={`Table row ${r + 1} column ${c + 1}`}
                          value={cell}
                          onChange={(e) =>
                            setCells((old) =>
                              old.map((line, i) =>
                                i === r
                                  ? line.map((v, j) =>
                                      j === c ? e.target.value.replace(/[\t\r\n]/g, " ") : v,
                                    )
                                  : line,
                              ),
                            )
                          }
                        />
                      </td>
                    ))}
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
          <div className="flex flex-wrap gap-2">
            <Button
              type="button"
              variant="outline"
              size="sm"
              disabled={cells.length >= 30}
              onClick={() => setCells([...cells, cells[0]!.map(() => "")])}
            >
              Add row
            </Button>
            <Button
              type="button"
              variant="outline"
              size="sm"
              disabled={cells[0]!.length >= 8}
              onClick={() => setCells(cells.map((row) => [...row, ""]))}
            >
              Add column
            </Button>
            <Button
              type="button"
              variant="outline"
              size="sm"
              disabled={cells.length <= 1}
              onClick={() => setCells(cells.slice(0, -1))}
            >
              Remove last row
            </Button>
            <Button
              type="button"
              variant="outline"
              size="sm"
              disabled={cells[0]!.length <= 1}
              onClick={() => setCells(cells.map((row) => row.slice(0, -1)))}
            >
              Remove last column
            </Button>
            <Button
              type="button"
              size="sm"
              onClick={() =>
                replace(`\n:::table\n${cells.map((row) => row.join("\t")).join("\n")}\n:::\n`)
              }
            >
              Insert table
            </Button>
          </div>
          <Input
            aria-label="Find note text"
            value={find}
            onChange={(e) => setFind(e.target.value)}
            placeholder="Find exact text (case-sensitive)"
          />
          <Input
            aria-label="Replace note text with"
            value={replacement}
            onChange={(e) => setReplacement(e.target.value)}
            placeholder="Replacement"
          />
          <Button
            type="button"
            variant="outline"
            disabled={!find || !value.includes(find)}
            onClick={() => {
              if (
                window.confirm(
                  "Replace all exact matches in this note, including formatting source?",
                )
              )
                change(value.split(find).join(replacement));
            }}
          >
            Replace all
          </Button>
        </div>
      </details>
    </fieldset>
  );
}
