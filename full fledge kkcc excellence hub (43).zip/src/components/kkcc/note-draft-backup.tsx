import { useEffect, useState } from "react";
import { Button } from "@/components/ui/button";
import { useAuthUser } from "@/hooks/use-auth-user";

/** Local recovery only. Never silently publishes a note or overwrites its server version. */
export function NoteDraftBackup({
  noteId,
  value,
  savedValue,
  restore,
}: {
  noteId: string;
  value: string;
  savedValue: string;
  restore: (text: string) => void;
}) {
  const { user } = useAuthUser();
  const key = user ? `kkcc-note-draft:${user.id}:${noteId}` : null;
  const [recovery, setRecovery] = useState<string | null>(null);
  const [ready, setReady] = useState(false);
  const [status, setStatus] = useState("Preparing draft backup…");
  useEffect(() => {
    setReady(false);
    setRecovery(null);
    if (!key) return;
    try {
      const text = sessionStorage.getItem(key);
      if (text !== null && text !== savedValue) setRecovery(text);
      setStatus("Draft backup ready in this tab.");
      setReady(true);
    } catch {
      setStatus("Draft backup unavailable. Use Save changes to save your work.");
    }
    // Read only when changing notes/users, not when the server confirms a save.
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [key]);
  useEffect(() => {
    if (!key || !ready || recovery !== null) return;
    if (value === savedValue) {
      try {
        sessionStorage.removeItem(key);
        setStatus("No unsaved note text.");
      } catch {
        /* Status below explains storage restrictions. */
      }
      return;
    }
    setStatus("Saving draft in this tab…");
    const timer = setTimeout(() => {
      try {
        sessionStorage.setItem(key, value);
        setStatus("Draft text saved in this tab — not published.");
      } catch {
        setStatus("Draft backup failed (browser storage unavailable/full). Use Save changes.");
      }
    }, 650);
    return () => clearTimeout(timer);
  }, [key, ready, recovery, value, savedValue]);
  return (
    <div className="my-2 rounded-lg border bg-muted/20 px-3 py-2 text-xs">
      <p role="status">
        {recovery !== null ? "An unsaved text draft is available from this tab." : status}
      </p>
      <p className="mt-1 text-muted-foreground">
        Text-only backup in this tab, not a cloud save. Tap Save changes to keep your note.
      </p>
      {recovery !== null && (
        <div className="mt-2 flex gap-2">
          <Button
            type="button"
            variant="outline"
            size="sm"
            onClick={() => {
              restore(recovery);
              setRecovery(null);
            }}
          >
            Restore draft text
          </Button>
          <Button
            type="button"
            variant="ghost"
            size="sm"
            onClick={() => {
              try {
                if (key) sessionStorage.removeItem(key);
              } catch {
                /* No storage available. */
              }
              setRecovery(null);
            }}
          >
            Discard draft text
          </Button>
        </div>
      )}
    </div>
  );
}
