import { useDeferredValue, useMemo, useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { Link } from "@tanstack/react-router";
import { Search } from "lucide-react";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import type { Course, Material } from "@/lib/cms";
import { buildFacultyProfiles } from "@/lib/faculty";
import {
  listPublishedCourses,
  listSearchLectureCards,
  listPublicMaterialCards,
  listPublicSearchSeries,
  listPublicTests,
} from "@/lib/content.functions";

type Hit = {
  group: string;
  label: string;
  sub: string;
  to: string;
  params?: Record<string, string>;
  search?: Record<string, string>;
};

type PublicTest = Awaited<ReturnType<typeof listPublicTests>>[number];
type PublicSeries = Awaited<ReturnType<typeof listPublicSearchSeries>>[number];
type SearchLecture = Awaited<ReturnType<typeof listSearchLectureCards>>[number];

function buildIndex(
  courses: Course[],
  lectures: SearchLecture[],
  materials: Material[],
  tests: PublicTest[],
  series: PublicSeries[],
): Hit[] {
  const hits: Hit[] = [
    {
      group: "Quiz",
      label: "Kit 2 Coins Quiz Zone",
      sub: "Colourful 60-second MCQs for NEET, JEE, CBSE, ICSE, CA, UPSC, Banking and state exams",
      to: "/games",
    },
    {
      group: "Wallet",
      label: "23KAAT coins",
      sub: "Buy coin packs and use coins for courses and notes",
      to: "/coins",
    },
  ];
  courses.forEach((c) =>
    hits.push({
      group: "Courses",
      label: c.title,
      sub: `${c.subject} · ${c.class_level}`,
      to: "/courses/$slug",
      params: { slug: c.slug },
    }),
  );
  const courseById = new Map(courses.map((course) => [course.id, course]));
  lectures.forEach((lecture) => {
    const course = courseById.get(lecture.course_id);
    if (!course) return;
    hits.push({
      group: "Lessons",
      label: lecture.title,
      sub: `${course.title} · ${lecture.module_title || "Lesson"}`,
      to: "/learn",
      search: { course: course.slug, lecture: lecture.id },
    });
  });
  buildFacultyProfiles(courses).forEach((f) =>
    hits.push({
      group: "Faculty",
      label: f.name,
      sub: f.subjectLabel,
      to: "/faculty/$slug",
      params: { slug: f.slug },
    }),
  );
  materials.forEach((m) =>
    hits.push({
      group: m.material_type,
      label: m.title,
      sub: `${m.subject} · ${m.chapter}`,
      to: "/study-material",
      search: { q: m.title },
    }),
  );
  tests.forEach((test) =>
    hits.push({
      group: "Tests",
      label: test.title,
      sub: [test.subject, test.generation_topic, test.is_paid ? "Access required" : "Free"]
        .filter(Boolean)
        .join(" · "),
      to: "/test/$id",
      params: { id: test.id },
    }),
  );
  series.forEach((item) =>
    hits.push({
      group: "Test series",
      label: item.name,
      sub: `${item.exam} · ${item.group} · ${item.subjects.join(", ")}`,
      to: "/test-series/learn/$seriesId",
      params: { seriesId: item.id },
    }),
  );
  return hits;
}

export function GlobalSearch({
  open,
  onOpenChange,
}: {
  open: boolean;
  onOpenChange: (v: boolean) => void;
}) {
  const [query, setQuery] = useState("");
  // Public metadata only; opening search again reuses the shared query cache.
  const { data, isPending, isError, refetch } = useQuery({
    queryKey: ["global-search", "public-content"],
    queryFn: async () => {
      const [courses, lectures, materials, tests, series] = await Promise.all([
        listPublishedCourses(),
        listSearchLectureCards(),
        listPublicMaterialCards(),
        listPublicTests(),
        listPublicSearchSeries(),
      ]);
      return { courses, lectures, materials: materials as Material[], tests, series };
    },
    enabled: open,
    staleTime: 5 * 60 * 1000,
    gcTime: 10 * 60 * 1000,
  });
  const deferredQuery = useDeferredValue(query);
  const index = useMemo(
    () =>
      buildIndex(
        data?.courses ?? [],
        data?.lectures ?? [],
        data?.materials ?? [],
        data?.tests ?? [],
        data?.series ?? [],
      ).map((hit) => ({
        ...hit,
        searchable: `${hit.label} ${hit.sub}`.toLowerCase(),
      })),
    [data],
  );
  const results = useMemo(() => {
    const words = deferredQuery.trim().toLowerCase().split(/\s+/).filter(Boolean);
    const grouped = new Map<string, Hit[]>();
    let count = 0;
    // Stop once the visible result budget is filled, rather than copying every match.
    for (const hit of index) {
      if (words.length && !words.every((word) => hit.searchable.includes(word))) continue;
      const group = grouped.get(hit.group) ?? [];
      group.push(hit);
      grouped.set(hit.group, group);
      if (++count >= (words.length ? 24 : 8)) break;
    }
    return [...grouped.entries()];
  }, [index, deferredQuery]);

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-xl gap-0 overflow-hidden p-0">
        <DialogHeader className="border-b p-4">
          <DialogTitle className="sr-only">Search KKCC</DialogTitle>
          <div className="flex items-center gap-3">
            <Search className="h-4 w-4 shrink-0 text-muted-foreground" />
            <Input
              autoFocus
              value={query}
              onChange={(e) => setQuery(e.target.value)}
              placeholder="Search courses, lessons, notes, tests or series…"
              className="h-9 border-0 bg-transparent p-0 shadow-none focus-visible:ring-0"
              aria-label="Search KKCC"
            />
          </div>
        </DialogHeader>
        {!query.trim() && (
          <nav aria-label="Jump to a KKCC section" className="flex flex-wrap gap-2 border-b p-3">
            {[
              { label: "Courses", to: "/courses" },
              { label: "Batches", to: "/classes" },
              { label: "Notes", to: "/study-material" },
              { label: "Tests", to: "/test-series" },
              { label: "My results", to: "/dashboard/tests" },
            ].map((item) => (
              <Link
                key={item.label}
                to={item.to}
                onClick={() => onOpenChange(false)}
                className="rounded-full border border-primary/25 bg-secondary px-3 py-1.5 text-xs font-semibold text-secondary-foreground hover:bg-secondary-hover focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring"
              >
                {item.label}
              </Link>
            ))}
          </nav>
        )}
        <div
          className="max-h-[60dvh] overflow-y-auto p-2"
          aria-busy={isPending || deferredQuery !== query}
        >
          {isPending && (
            <p role="status" className="p-4 text-sm text-muted-foreground">
              Loading your search library…
            </p>
          )}
          {isError && (
            <div role="status" className="p-4 text-sm text-muted-foreground">
              Search could not load.{" "}
              <button
                type="button"
                className="rounded-lg border border-primary/30 bg-secondary px-2 py-1 font-semibold text-secondary-foreground hover:bg-secondary-hover focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring"
                onClick={() => void refetch()}
              >
                Try again
              </button>
            </div>
          )}
          {!isPending && !isError && results.length === 0 && (
            <p className="p-8 text-center text-sm text-muted-foreground">
              No matches for “{query}”. Try a subject, class or faculty name.
            </p>
          )}
          {results.map(([group, hits]) => (
            <div key={group} className="mb-2">
              <p className="px-3 py-2 text-[11px] font-semibold uppercase tracking-widest text-muted-foreground">
                {group}
              </p>
              {hits.map((h) => (
                <Link
                  key={`${group}-${h.label}`}
                  to={h.to}
                  params={h.params as never}
                  search={h.search as never}
                  onClick={() => onOpenChange(false)}
                  className="flex items-center justify-between gap-3 rounded-lg border border-primary/20 bg-secondary px-3 py-2 text-sm text-secondary-foreground transition-colors hover:bg-secondary-hover focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring"
                >
                  <span className="min-w-0">
                    <span className="block truncate font-medium">{h.label}</span>
                    <span className="block truncate text-xs text-muted-foreground">{h.sub}</span>
                  </span>
                </Link>
              ))}
            </div>
          ))}
        </div>
      </DialogContent>
    </Dialog>
  );
}
