import { Sparkles } from "lucide-react";
import { StyledAuthorText } from "@/components/kkcc/styled-author-text";

type ExplanationBlock = { type: "paragraph"; text: string } | { type: "list"; items: string[] };

/** Keep authored bullet points as a clear list, even when they were pasted inline with asterisks. */
function formatExplanation(text: string): ExplanationBlock[] {
  const clean = text.replace(/^\s*Explanation\s*:\s*/i, "").trim();
  if (!clean) return [];

  const blocks: ExplanationBlock[] = [];
  let paragraph: string[] = [];
  let bullets: string[] = [];
  const flushParagraph = () => {
    if (paragraph.length) blocks.push({ type: "paragraph", text: paragraph.join("\n") });
    paragraph = [];
  };
  const flushBullets = () => {
    if (bullets.length) blocks.push({ type: "list", items: bullets });
    bullets = [];
  };

  for (const rawLine of clean.split(/\r?\n/)) {
    const line = rawLine.trim();
    if (!line) {
      flushParagraph();
      flushBullets();
      continue;
    }
    // Some pasted explanations use `* point * point` on a single line.
    if (line.startsWith("*") && /^\*\s+/.test(line)) {
      flushParagraph();
      const points = line
        .split(/\s+\*\s+/)
        .map((part) => part.trim())
        .filter(Boolean);
      bullets.push(...points.map((part) => part.replace(/^\*\s+/, "")));
      continue;
    }
    const marked = line.match(/^(?:[-*•▪◦]|\d+[.)])\s+(.+)$/);
    if (marked) {
      flushParagraph();
      if (marked[1]) bullets.push(marked[1]);
      continue;
    }
    flushBullets();
    paragraph.push(line);
  }
  flushParagraph();
  flushBullets();
  return blocks;
}

export function ExplanationDisplay({ text, compact = false }: { text: string; compact?: boolean }) {
  const blocks = formatExplanation(text);
  if (!blocks.length) return null;
  const hasPoints = blocks.some((block) => block.type === "list");

  return (
    <section
      aria-label="Explanation"
      className={`rounded-2xl border border-primary/25 bg-secondary/35 shadow-sm ${compact ? "p-3" : "p-4 sm:p-5"}`}
    >
      <header className="mb-3 flex items-center gap-2.5">
        <span className="grid h-8 w-8 shrink-0 place-items-center rounded-xl bg-primary/10 text-primary">
          <Sparkles aria-hidden="true" className="h-4 w-4" />
        </span>
        <div>
          <h3 className="text-sm font-extrabold leading-tight text-foreground">Explanation</h3>
          <p className="mt-0.5 text-xs font-medium text-foreground/75">
            {hasPoints ? "Key points" : "Read through the reasoning"}
          </p>
        </div>
      </header>
      <div className="space-y-3 text-foreground">
        {blocks.map((block, index) =>
          block.type === "list" ? (
            <ul key={`list-${index}`} className="space-y-2.5" aria-label="Explanation points">
              {block.items.map((item, itemIndex) => (
                <li key={`${itemIndex}-${item.slice(0, 32)}`} className="flex items-start gap-3">
                  <span
                    aria-hidden="true"
                    className="mt-[0.7em] h-2 w-2 shrink-0 rounded-full bg-primary ring-4 ring-primary/10"
                  />
                  <span className="min-w-0 text-sm font-medium leading-7 text-foreground sm:text-[15px]">
                    <StyledAuthorText text={item} />
                  </span>
                </li>
              ))}
            </ul>
          ) : (
            <p
              key={`paragraph-${index}`}
              className="whitespace-pre-wrap text-sm font-medium leading-7 text-foreground sm:text-[15px]"
            >
              <StyledAuthorText text={block.text} />
            </p>
          ),
        )}
      </div>
    </section>
  );
}
