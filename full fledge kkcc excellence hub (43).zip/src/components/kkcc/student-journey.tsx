import { Link } from "@tanstack/react-router";
import {
  ArrowRight,
  BookOpenText,
  ClipboardCheck,
  Compass,
  ListTree,
  PlayCircle,
  Trophy,
} from "lucide-react";
import { cn } from "@/lib/utils";

type Stage = "explore" | "curriculum" | "learn" | "notes" | "practice" | "results";
const stages = [
  {
    key: "explore",
    label: "Discover",
    hint: "Courses & batches",
    icon: Compass,
    ink: "text-study-teal",
    wash: "bg-study-teal/10",
  },
  {
    key: "curriculum",
    label: "Syllabus",
    hint: "See the chapters",
    icon: ListTree,
    ink: "text-study-blue",
    wash: "bg-study-blue/10",
  },
  {
    key: "learn",
    label: "Lessons",
    hint: "Watch & follow",
    icon: PlayCircle,
    ink: "text-study-gold",
    wash: "bg-study-gold/10",
  },
  {
    key: "notes",
    label: "Notes",
    hint: "Read & revise",
    icon: BookOpenText,
    ink: "text-study-rose",
    wash: "bg-study-rose/10",
  },
  {
    key: "practice",
    label: "Practice",
    hint: "Tests & series",
    icon: ClipboardCheck,
    ink: "text-study-teal",
    wash: "bg-study-teal/10",
  },
  {
    key: "results",
    label: "Results",
    hint: "Review your work",
    icon: Trophy,
    ink: "text-study-blue",
    wash: "bg-study-blue/10",
  },
] as const;

/** A small navigation map, never a fabricated progress score. Each stop opens real KKCC content. */
export function StudentJourney({
  active,
  courseSlug,
  courseTitle,
  className,
}: {
  active: Stage;
  courseSlug?: string | undefined;
  courseTitle?: string | undefined;
  className?: string | undefined;
}) {
  return (
    <section
      aria-label="KKCC learning path"
      className={cn(
        "relative overflow-hidden rounded-3xl border border-primary/20 bg-card p-4 shadow-sm sm:p-6",
        className,
      )}
    >
      <div className="pointer-events-none absolute -right-10 -top-20 h-40 w-40 rounded-full bg-primary/10 blur-3xl" />
      <div className="relative flex flex-wrap items-center justify-between gap-2">
        <div>
          <p className="text-[11px] font-black uppercase tracking-[0.18em] text-primary">
            KKCC · Your learning path
          </p>
          <h2 className="mt-1 text-lg font-black sm:text-xl">
            {courseTitle ? `Study path · ${courseTitle}` : "Everything for your next study session"}
          </h2>
        </div>
        <span className="inline-flex items-center gap-1 text-xs font-semibold text-primary">
          Learn at your pace <ArrowRight className="h-3.5 w-3.5" />
        </span>
      </div>
      <nav
        aria-label="Discover, study, practise and review"
        className="relative -mx-1 mt-4 overflow-x-auto px-1 pb-1"
      >
        <ol className="flex min-w-max gap-2 md:min-w-0 md:grid md:grid-cols-6">
          {stages.map((stage, index) => {
            const selected = stage.key === active;
            const classes = cn(
              "group flex min-h-16 w-36 items-center gap-2.5 rounded-2xl border px-3 py-2.5 text-left transition focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring md:w-auto",
              selected
                ? "border-primary bg-primary text-primary-foreground shadow-sm"
                : "border-primary/30 bg-secondary/75 hover:border-primary/60 hover:bg-secondary-hover",
            );
            const content = (
              <>
                <span
                  className={cn(
                    "grid h-9 w-9 shrink-0 place-items-center rounded-xl",
                    selected ? "bg-white/20" : [stage.wash, stage.ink],
                  )}
                >
                  <stage.icon className="h-4 w-4" aria-hidden="true" />
                </span>
                <span className="min-w-0">
                  <span
                    className={cn(
                      "block text-[10px] font-bold",
                      selected ? "text-primary-foreground/75" : "text-muted-foreground",
                    )}
                  >
                    STEP {index + 1}
                  </span>
                  <span className={cn("block text-xs font-black", !selected && stage.ink)}>
                    {stage.label}
                  </span>
                  <span
                    className={cn(
                      "block text-[10px]",
                      selected ? "text-primary-foreground/85" : "text-muted-foreground",
                    )}
                  >
                    {stage.hint}
                  </span>
                </span>
              </>
            );
            const shared = {
              className: classes,
              "aria-current": selected ? ("step" as const) : undefined,
              "aria-label": `Step ${index + 1}: ${stage.label} — ${stage.hint}`,
            };
            return (
              <li key={stage.key}>
                {stage.key === "curriculum" && courseSlug ? (
                  <Link
                    {...shared}
                    to="/courses/$slug"
                    params={{ slug: courseSlug }}
                    hash="course-curriculum"
                  >
                    {content}
                  </Link>
                ) : stage.key === "learn" ? (
                  <Link {...shared} to="/learn" search={courseSlug ? { course: courseSlug } : {}}>
                    {content}
                  </Link>
                ) : (
                  <Link
                    {...shared}
                    to={
                      stage.key === "explore" || stage.key === "curriculum"
                        ? "/courses"
                        : stage.key === "notes"
                          ? "/study-material"
                          : stage.key === "practice"
                            ? "/test-series"
                            : "/dashboard/tests"
                    }
                  >
                    {content}
                  </Link>
                )}
              </li>
            );
          })}
        </ol>
      </nav>
      <p className="relative mt-3 text-xs text-muted-foreground">
        {active === "explore"
          ? "Choose a course or batch, then open its syllabus before your first lesson."
          : active === "curriculum"
            ? "Open a chapter to see its lessons, then continue to its notes and tests."
            : active === "learn"
              ? "Your lesson resources and chapter practice stay together below."
              : active === "notes"
                ? "Read your notes, practise inside them, then try the next test."
                : active === "practice"
                  ? "Find a chapter test or series; review your results afterwards."
                  : "See your saved results and explanations, then pick what to revise next."}
      </p>
    </section>
  );
}
