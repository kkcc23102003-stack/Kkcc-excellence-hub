import { useEffect, useState } from "react";
import { Link } from "@tanstack/react-router";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { PagedGrid } from "./paged-grid";
import {
  createBatchCourseForSeries,
  getAdminBatchForSeries,
  saveBatchVideo,
} from "@/lib/notes-batch.functions";
import { friendlyError, humanSize, MAX_UPLOAD_BYTES, uploadContentFile } from "@/lib/storage";

export function BatchVideoManager({
  seriesId,
  unsaved = false,
}: {
  seriesId: string;
  unsaved?: boolean;
}) {
  const qc = useQueryClient();
  const query = useQuery({
    queryKey: ["admin", "notes-batch", seriesId],
    queryFn: () => getAdminBatchForSeries({ data: { id: seriesId } }),
    retry: false,
  });
  const [creating, setCreating] = useState(false);
  const [search, setSearch] = useState("");
  const create = async () => {
    if (unsaved) {
      toast.error("Save your Notes Series changes first.");
      return;
    }
    setCreating(true);
    try {
      await createBatchCourseForSeries({ data: { id: seriesId } });
      await qc.invalidateQueries({ queryKey: ["admin", "notes-batch", seriesId] });
      toast.success(
        "Separate video Batch created as draft. Set its price and publish in Course Admin.",
      );
    } catch (error) {
      toast.error(friendlyError(error));
    } finally {
      setCreating(false);
    }
  };
  return (
    <section
      className="min-w-0 space-y-3 rounded-2xl border border-primary/25 bg-primary/[0.04] p-4"
      aria-label="Video Batch for this Notes Series"
    >
      <h3 className="text-base font-bold">Separate video Batch · same notes</h3>
      <p className="text-xs text-muted-foreground">
        The Notes section and each note’s existing price/purchases stay unchanged. The linked Course
        Admin sets the Batch price independently. Uploads allow up to {humanSize(MAX_UPLOAD_BYTES)}{" "}
        per file; longer videos can use hosted links. Only enrolled Batch students get video and
        reused paid-note content. External players may block embedding or completion detection.
      </p>
      {query.isPending && <p role="status">Loading Batch…</p>}
      {query.isError && (
        <p role="alert">
          Could not load the linked Batch.{" "}
          <Button type="button" variant="outline" size="sm" onClick={() => void query.refetch()}>
            Retry
          </Button>
        </p>
      )}
      {!query.isPending && !query.isError && !query.data && (
        <Button type="button" disabled={creating || unsaved} onClick={() => void create()}>
          {creating ? "Creating draft Batch…" : "Create video Batch for these notes"}
        </Button>
      )}
      {query.data && (
        <>
          {query.data.course ? (
            <div className="flex flex-wrap items-center gap-2 text-sm">
              <strong>{query.data.course.title}</strong>
              <span className="text-muted-foreground">
                · {query.data.course.status} · ₹{query.data.course.price}
              </span>
              {query.data.course.price === 0 && Number(query.data.course.coin_price || 0) === 0 && (
                <span className="text-xs font-semibold text-amber-700 dark:text-amber-300">
                  Set the Batch price before publishing unless you intend a free Batch.
                </span>
              )}
              <Button asChild type="button" size="sm" variant="outline">
                <Link to="/admin/courses/$id" params={{ id: query.data.course.id }}>
                  Set Batch price / publish
                </Link>
              </Button>
            </div>
          ) : (
            <p role="alert">
              Linked course is missing. Do not publish until Admin resolves this link.
            </p>
          )}
          <Input
            aria-label="Search Batch video lessons"
            value={search}
            onChange={(event) => setSearch(event.target.value)}
            placeholder="Find subject, chapter, topic or note"
          />
          <PagedGrid
            items={query.data.outline.lessons.filter((lesson) =>
              `${lesson.subject} ${lesson.chapter} ${lesson.topic ?? ""} ${lesson.title}`
                .toLocaleLowerCase()
                .includes(search.trim().toLocaleLowerCase()),
            )}
            label="Batch video lessons"
            className="space-y-3"
          >
            {(lesson) => (
              <BatchVideoRow
                key={lesson.noteId}
                seriesId={seriesId}
                courseId={query.data!.batch.courseId}
                revision={query.data!.batch.revision}
                noteId={lesson.noteId}
                label={`${lesson.subject} / ${lesson.chapter}${lesson.topic ? ` / ${lesson.topic}` : ""} / ${lesson.title}`}
                savedUrl={query.data!.batch.videos[lesson.noteId] ?? ""}
                onSaved={async () => {
                  await qc.invalidateQueries({ queryKey: ["admin", "notes-batch", seriesId] });
                  await qc.invalidateQueries({ queryKey: ["public-catalog"] });
                }}
              />
            )}
          </PagedGrid>
          {!query.data.outline.lessons.length && (
            <p className="text-sm text-muted-foreground">
              Add notes to a subject/chapter in the Notes Series Builder first.
            </p>
          )}
        </>
      )}
    </section>
  );
}

function BatchVideoRow({
  seriesId,
  courseId,
  noteId,
  label,
  revision,
  savedUrl,
  onSaved,
}: {
  seriesId: string;
  courseId: string;
  noteId: string;
  label: string;
  revision: number;
  savedUrl: string;
  onSaved: () => Promise<void>;
}) {
  const [url, setUrl] = useState(savedUrl);
  const [busy, setBusy] = useState(false);
  useEffect(() => setUrl(savedUrl), [savedUrl]);
  const save = async (videoUrl: string) => {
    setBusy(true);
    try {
      await saveBatchVideo({ data: { seriesId, noteId, revision, videoUrl } });
      await onSaved();
      toast.success(videoUrl ? "Batch video linked" : "Batch video removed; note kept");
    } catch (error) {
      toast.error(friendlyError(error));
    } finally {
      setBusy(false);
    }
  };
  return (
    <div className="min-w-0 space-y-2 rounded-xl border bg-card p-3">
      <label className="block break-words text-sm font-medium">
        {label}
        <Input
          aria-label={`Video URL for ${label}`}
          className="mt-2"
          value={url}
          onChange={(event) => setUrl(event.target.value)}
          placeholder="YouTube, hosted MP4/WebM, Vimeo or other video page URL"
          inputMode="url"
          maxLength={4000}
        />
      </label>
      <div className="flex flex-wrap items-center gap-2">
        <Button
          type="button"
          size="sm"
          disabled={busy || url.trim() === savedUrl}
          onClick={() => void save(url.trim())}
        >
          {busy ? "Saving…" : "Save video link"}
        </Button>
        <label className="cursor-pointer rounded-lg border px-3 py-2 text-xs font-semibold hover:bg-muted">
          Upload video
          <input
            type="file"
            className="sr-only"
            disabled={busy}
            accept="video/mp4,video/webm,video/quicktime,.mp4,.webm,.mov,.m4v"
            onChange={async (event) => {
              const file = event.target.files?.[0];
              event.target.value = "";
              if (!file) return;
              if (file.size > MAX_UPLOAD_BYTES) {
                toast.error(
                  `Videos must be under ${humanSize(MAX_UPLOAD_BYTES)}. Use a hosted URL for larger videos.`,
                );
                return;
              }
              setBusy(true);
              try {
                const uploaded = await uploadContentFile(file, `batch-videos/${courseId}`);
                await saveBatchVideo({
                  data: { seriesId, noteId, revision, videoUrl: uploaded.url },
                });
                await onSaved();
                toast.success("Video uploaded privately and linked to this Batch");
              } catch (error) {
                toast.error(
                  `${friendlyError(error)} If the upload succeeded but linking failed, reload before retrying.`,
                );
              } finally {
                setBusy(false);
              }
            }}
          />
        </label>
        {savedUrl && (
          <span className="text-xs text-muted-foreground">
            Video linked · clear URL and save to unlink (file is not deleted)
          </span>
        )}
      </div>
    </div>
  );
}
