import { useMemo, useState } from "react";
import { useServerFn } from "@tanstack/react-start";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import {
  AlertTriangle,
  Clipboard,
  Clock3,
  History,
  Loader2,
  Search,
  ShieldCheck,
  Undo2,
} from "lucide-react";
import { toast } from "sonner";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { invalidateLearningQueries } from "@/hooks/use-learning-access";
import {
  adminLookupAccessRecovery,
  adminRecoverStudentAccess,
  type AccessRecoveryKind,
  type AccessRecoveryRecord,
} from "@/lib/admin-access-recovery.functions";
import { friendlyError } from "@/lib/storage";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";

const sections: { key: string; title: string; kinds: AccessRecoveryKind[] }[] = [
  { key: "courses", title: "Courses", kinds: ["course"] },
  { key: "tests", title: "Tests", kinds: ["test"] },
  { key: "test-series", title: "Test Series", kinds: ["series"] },
  { key: "notes", title: "Notes & paid Note purchases", kinds: ["note", "note_purchase"] },
  { key: "notes-series", title: "Notes Series", kinds: ["notes_series"] },
];

const kindLabels: Record<AccessRecoveryKind, string> = {
  course: "Course",
  test: "Test",
  series: "Test Series",
  notes_series: "Notes Series",
  note: "Note access",
  note_purchase: "23KAAT Note purchase",
};
const EMPTY_RECORDS: AccessRecoveryRecord[] = [];

function formatDate(value: string | null) {
  if (!value) return "Lifetime";
  const date = new Date(value);
  return Number.isFinite(date.getTime())
    ? date.toLocaleString("en-IN", {
        day: "2-digit",
        month: "short",
        year: "numeric",
        hour: "2-digit",
        minute: "2-digit",
      })
    : "Unknown date";
}

function stateVariant(state: AccessRecoveryRecord["state"]) {
  if (state === "active") return "default" as const;
  if (state === "revoked") return "destructive" as const;
  if (state === "expired") return "secondary" as const;
  return "outline" as const;
}

function actionLabel(action: string) {
  if (action === "renewed") return "renewed";
  if (action === "regranted") return "regranted";
  return "restored";
}

function redemptionHasAccessRecord(
  redemption: { item_kind: string; item_id: string },
  records: AccessRecoveryRecord[],
) {
  const target =
    redemption.item_kind === "notes_series"
      ? `notes-series:${redemption.item_id}`
      : redemption.item_id;
  const matchingKind: AccessRecoveryKind | null =
    redemption.item_kind === "course"
      ? "course"
      : redemption.item_kind === "test"
        ? "test"
        : redemption.item_kind === "series"
          ? "series"
          : redemption.item_kind === "notes_series"
            ? "notes_series"
            : redemption.item_kind === "material"
              ? "note"
              : null;
  return matchingKind
    ? records.some((record) => record.kind === matchingKind && record.product_id === target)
    : true;
}

function replyFor(input: {
  name: string;
  title: string;
  kind: AccessRecoveryKind;
  action: string;
  expiresAt: string | null;
}) {
  const greeting = input.name ? `Hi ${input.name},` : "Hi,";
  const entitlement = `${kindLabels[input.kind]} access to “${input.title}”`;
  const validity = input.expiresAt
    ? ` It is available until ${formatDate(input.expiresAt)}.`
    : " It is available without an expiry date.";
  const historyNote =
    input.kind === "note_purchase"
      ? " Your original 23KAAT purchase and coin history remain unchanged; we added a separate access grant."
      : " Your original purchase, coupon redemption and payment history were not changed.";
  return `${greeting} we checked your access issue and ${actionLabel(input.action)} ${entitlement}.${validity}${historyNote} Please refresh the app and try again. If it still does not open, reply with a screenshot of the error.`;
}

async function copyToClipboard(text: string, label: string) {
  try {
    await navigator.clipboard.writeText(text);
    toast.success(`${label} copied`);
  } catch {
    toast.error(
      "Clipboard access is unavailable in this browser. Select and copy the text manually.",
    );
  }
}

export function AdminAccessRecoveryDesk() {
  const qc = useQueryClient();
  const lookup = useServerFn(adminLookupAccessRecovery);
  const recover = useServerFn(adminRecoverStudentAccess);
  const [emailInput, setEmailInput] = useState("");
  const [lookupEmail, setLookupEmail] = useState("");
  const [dialogRecord, setDialogRecord] = useState<AccessRecoveryRecord | null>(null);
  const [validityMode, setValidityMode] = useState<"keep" | "days" | "lifetime">("keep");
  const [validDays, setValidDays] = useState("30");
  const [reason, setReason] = useState("");
  const [resolvedReply, setResolvedReply] = useState("");

  const accessQuery = useQuery({
    queryKey: ["admin", "access-recovery", lookupEmail],
    queryFn: () => lookup({ data: { email: lookupEmail } }),
    enabled: Boolean(lookupEmail),
    retry: false,
  });
  const result = accessQuery.data;
  const records = result?.records ?? EMPTY_RECORDS;
  const groupedRecords = useMemo(
    () =>
      new Map(
        sections.map((section) => [
          section.key,
          records.filter((record) => section.kinds.includes(record.kind)),
        ]),
      ),
    [records],
  );

  const mutation = useMutation({
    mutationFn: (record: AccessRecoveryRecord) =>
      recover({
        data: {
          user_id: result?.profile?.id ?? "",
          record_kind: record.kind,
          record_id: record.id,
          validity_mode: validityMode,
          valid_days: validityMode === "days" ? Number(validDays) : null,
          reason: reason.trim(),
        },
      }),
    onSuccess: (response, record) => {
      if (result?.profile) {
        setResolvedReply(
          replyFor({
            name: result.profile.full_name || "",
            title: record.product_title,
            kind: record.kind,
            action: response.action,
            expiresAt: response.expires_at,
          }),
        );
      }
      setDialogRecord(null);
      setReason("");
      void invalidateLearningQueries(qc);
      void qc.invalidateQueries({ queryKey: ["admin", "access-recovery", lookupEmail] });
      void qc.invalidateQueries({ queryKey: ["admin", "student-access"] });
      void qc.invalidateQueries({ queryKey: ["admin", "notes-access"] });
      toast.success(
        `${record.product_title} access ${actionLabel(response.action)} for ${result?.profile?.email ?? "student"}.`,
      );
    },
    onError: (error: Error) => toast.error(friendlyError(error)),
  });

  function submitLookup(event: React.FormEvent<HTMLFormElement>) {
    event.preventDefault();
    const normalized = emailInput.trim().toLowerCase();
    if (!normalized) return;
    setResolvedReply("");
    if (normalized === lookupEmail) {
      void accessQuery.refetch();
    } else {
      setLookupEmail(normalized);
    }
  }

  function openRecovery(record: AccessRecoveryRecord) {
    setDialogRecord(record);
    setReason("");
    const expiredExpiry = record.expires_at && Date.parse(record.expires_at) <= Date.now();
    if (record.kind === "note_purchase") setValidityMode("lifetime");
    else setValidityMode(record.state === "expired" || expiredExpiry ? "days" : "keep");
  }

  const copyReply =
    resolvedReply ||
    (result?.profile
      ? `Issue: Student ${result.profile.email} reported an access issue. Checked ${records.length} direct access record${records.length === 1 ? "" : "s"} and ${result.coupon_redemptions.length} coupon redemption record${result.coupon_redemptions.length === 1 ? "" : "s"} across Courses, Tests, Test Series, Notes and Notes Series. ${records.length ? "Current record states are shown above." : "No direct access records were found; verify the exact product and any inherited course/series access."} No changes have been made.`
      : result
        ? `Issue: Access lookup for ${lookupEmail}. No signed-up student profile was found; ${result.pending_offline.length} offline request record${result.pending_offline.length === 1 ? "" : "s"} were found. No access, payment or coupon records were changed.`
        : "");

  return (
    <section
      className="surface-panel mb-6 space-y-5 p-5 sm:p-6"
      aria-labelledby="access-recovery-title"
    >
      <div className="flex flex-wrap items-start justify-between gap-3">
        <div className="flex items-start gap-3">
          <div className="rounded-2xl bg-primary/10 p-3 text-primary">
            <Undo2 className="h-6 w-6" />
          </div>
          <div>
            <h2 id="access-recovery-title" className="text-lg font-bold">
              Access recovery desk
            </h2>
            <p className="mt-1 max-w-3xl text-sm text-muted-foreground">
              Search once to review access, coupon history and past recovery actions across Courses,
              Tests, Test Series, Notes and Notes Series. Recovery changes only the selected student
              and product; payment and coupon history stay untouched.
            </p>
          </div>
        </div>
        <Badge variant="outline" className="rounded-full">
          <ShieldCheck className="mr-1 h-3.5 w-3.5" /> Admin only
        </Badge>
      </div>

      <form onSubmit={submitLookup} className="flex flex-col gap-3 sm:flex-row">
        <div className="min-w-0 flex-1">
          <Label htmlFor="access-recovery-email">Student email</Label>
          <div className="relative mt-1.5">
            <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
            <Input
              id="access-recovery-email"
              className="pl-9"
              type="email"
              autoComplete="email"
              required
              disabled={Boolean(dialogRecord)}
              value={emailInput}
              onChange={(event) => setEmailInput(event.target.value)}
              placeholder="student@example.com"
            />
          </div>
        </div>
        <Button
          className="self-end rounded-full"
          type="submit"
          disabled={accessQuery.isFetching || Boolean(dialogRecord)}
        >
          {accessQuery.isFetching ? (
            <Loader2 className="mr-2 h-4 w-4 animate-spin" />
          ) : (
            <Search className="mr-2 h-4 w-4" />
          )}
          Find access
        </Button>
      </form>

      {accessQuery.isError && (
        <div
          role="alert"
          className="rounded-xl border border-destructive/40 bg-destructive/5 p-4 text-sm"
        >
          <p className="font-medium">Could not look up this student.</p>
          <p className="mt-1 text-muted-foreground">{friendlyError(accessQuery.error)}</p>
        </div>
      )}

      {result && !result.recovery_history_available && (
        <div
          role="status"
          className="flex flex-col gap-3 rounded-xl border border-amber-500/40 bg-amber-500/[0.08] p-4 text-sm sm:flex-row sm:items-center sm:justify-between"
        >
          <p>
            Access lookup is available, but the recovery audit table or its admin read permission
            could not be verified. Apply the SQL and confirm Supabase permissions before retrying;
            this app does not apply migrations automatically.
          </p>
          <Button asChild size="sm" variant="outline" className="shrink-0 rounded-full">
            <a href="/KKCC-Excellence-Hub-ADMIN-ACCESS-RECOVERY.sql" download>
              Download recovery SQL
            </a>
          </Button>
        </div>
      )}

      {result && !result.profile && (
        <div className="space-y-3 rounded-2xl border bg-background/60 p-4">
          <div className="flex items-start gap-3">
            <AlertTriangle className="mt-0.5 h-5 w-5 text-amber-600" />
            <div>
              <p className="font-semibold">No signed-up student account found for {lookupEmail}.</p>
              <p className="mt-1 text-sm text-muted-foreground">
                This is a missing student profile, not proof that payment or coupon redemption
                failed. Pending offline access, if any, is listed below.
              </p>
            </div>
          </div>
          {result.pending_offline.length ? (
            <div className="space-y-2">
              {result.pending_offline.map((entry) => (
                <div key={entry.id} className="rounded-xl border p-3 text-sm">
                  <div className="flex flex-wrap items-center gap-2">
                    <span className="font-medium">{entry.course_title}</span>
                    <Badge
                      variant={entry.status === "pending" ? "outline" : "secondary"}
                      className="capitalize"
                    >
                      {entry.status}
                    </Badge>
                  </div>
                  <p className="mt-1 text-xs text-muted-foreground">
                    {entry.name || entry.email} · {formatDate(entry.expires_at)} ·{" "}
                    {entry.note || "No admin note"}
                  </p>
                </div>
              ))}
            </div>
          ) : (
            <p className="text-sm text-muted-foreground">
              No pending offline-access row was found for this exact email.
            </p>
          )}
        </div>
      )}

      {result && !result.profile && (
        <section className="rounded-2xl border bg-muted/30 p-4">
          <div className="flex flex-wrap items-start justify-between gap-3">
            <div>
              <h3 className="font-semibold">Copy-ready issue summary</h3>
              <p className="mt-1 text-xs text-muted-foreground">
                Account lookup only; no access change has been made.
              </p>
            </div>
            <Button
              type="button"
              size="sm"
              variant="outline"
              className="rounded-full"
              onClick={() => void copyToClipboard(copyReply, "Issue summary")}
            >
              <Clipboard className="mr-1.5 h-3.5 w-3.5" /> Copy summary
            </Button>
          </div>
          <Textarea className="mt-3 min-h-24 text-sm" readOnly value={copyReply} />
        </section>
      )}

      {result?.profile && (
        <div className="space-y-5">
          <div className="flex flex-wrap items-center justify-between gap-3 rounded-2xl border bg-background/60 p-4">
            <div>
              <p className="font-semibold">{result.profile.full_name || "Student"}</p>
              <p className="text-sm text-muted-foreground">{result.profile.email}</p>
            </div>
            <div className="flex flex-wrap items-center gap-2">
              <Badge
                variant={result.blocked ? "destructive" : "secondary"}
                className="rounded-full"
              >
                {result.blocked ? "Account blocked" : "Account active"}
              </Badge>
              {result.blocked && (
                <span className="max-w-sm text-xs text-muted-foreground">
                  Unblock separately before restoring access.
                </span>
              )}
            </div>
          </div>

          {result.pending_offline.length > 0 && (
            <section className="space-y-3" aria-label="Offline course access records">
              <div>
                <h3 className="font-semibold">Offline course access requests</h3>
                <p className="text-xs text-muted-foreground">
                  Pending requests are not active student access. Use the separate Offline access
                  workflow to activate or edit them.
                </p>
              </div>
              {result.pending_offline.map((entry) => (
                <div key={entry.id} className="rounded-xl border bg-background/60 p-3 text-sm">
                  <div className="flex flex-wrap items-center gap-2">
                    <span className="font-medium">{entry.course_title}</span>
                    <Badge variant={stateVariant(entry.status)} className="rounded-full capitalize">
                      {entry.status}
                    </Badge>
                  </div>
                  <p className="mt-1 text-xs text-muted-foreground">
                    {entry.name || entry.email} · created {formatDate(entry.created_at)} · expires{" "}
                    {formatDate(entry.expires_at)}
                  </p>
                  {entry.note && <p className="mt-2 text-xs text-muted-foreground">{entry.note}</p>}
                </div>
              ))}
            </section>
          )}

          {sections.map((section) => {
            const sectionRecords = groupedRecords.get(section.key) ?? [];
            return (
              <section key={section.key} className="space-y-3" aria-label={section.title}>
                <div className="flex items-center justify-between gap-3">
                  <h3 className="font-semibold">{section.title}</h3>
                  <Badge variant="outline" className="rounded-full">
                    {sectionRecords.length} record{sectionRecords.length === 1 ? "" : "s"}
                  </Badge>
                </div>
                {sectionRecords.length ? (
                  sectionRecords.map((record) => (
                    <article
                      key={`${record.kind}:${record.id}`}
                      className="rounded-2xl border bg-background/70 p-4"
                    >
                      <div className="flex flex-col gap-3 sm:flex-row sm:items-start sm:justify-between">
                        <div className="min-w-0 flex-1">
                          <div className="flex flex-wrap items-center gap-2">
                            <Badge
                              variant={stateVariant(record.state)}
                              className="rounded-full capitalize"
                            >
                              {record.state}
                            </Badge>
                            <Badge variant="outline" className="rounded-full">
                              {kindLabels[record.kind]}
                            </Badge>
                            <h4 className="font-semibold">{record.product_title}</h4>
                          </div>
                          <p className="mt-2 text-xs text-muted-foreground">
                            {record.source}
                            {record.amount_label ? ` · ${record.amount_label}` : ""} · added{" "}
                            {formatDate(record.created_at)} ·{" "}
                            {record.expires_at
                              ? `expires ${formatDate(record.expires_at)}`
                              : "lifetime / no expiry"}
                          </p>
                          {record.note && (
                            <p className="mt-2 whitespace-pre-wrap rounded-xl bg-muted/60 px-3 py-2 text-xs text-muted-foreground">
                              {record.note}
                            </p>
                          )}
                          {record.kind === "note_purchase" && (
                            <p className="mt-2 text-xs text-muted-foreground">
                              Read-only purchase history. Regrant adds a separate access grant and
                              leaves coin/purchase records unchanged.
                            </p>
                          )}
                        </div>
                        {record.can_recover && (
                          <Button
                            type="button"
                            size="sm"
                            variant="outline"
                            className="shrink-0 rounded-full"
                            disabled={
                              result.blocked ||
                              !result.recovery_history_available ||
                              mutation.isPending
                            }
                            onClick={() => openRecovery(record)}
                          >
                            <Undo2 className="mr-1.5 h-3.5 w-3.5" />
                            {record.state === "expired" ? "Renew access" : "Restore access"}
                          </Button>
                        )}
                      </div>
                    </article>
                  ))
                ) : (
                  <div className="rounded-xl border border-dashed p-4 text-sm text-muted-foreground">
                    <Badge variant="outline" className="mr-2 rounded-full">
                      Missing
                    </Badge>
                    No direct access record found in this category for this student. A Test may
                    still be unlocked through a course or Test Series entitlement. Check the exact
                    product and coupon history below before taking action.
                  </div>
                )}
              </section>
            );
          })}

          <section className="space-y-3" aria-label="Coupon redemption history">
            <div className="flex flex-wrap items-center justify-between gap-2">
              <h3 className="font-semibold">
                Coupon redemption history{" "}
                <span className="font-normal text-muted-foreground">(read-only)</span>
              </h3>
              <Badge variant="outline" className="rounded-full">
                {result.coupon_redemptions.length} records
              </Badge>
            </div>
            {result.coupon_redemptions.length ? (
              result.coupon_redemptions.map((redemption) => {
                const missingFullDiscountAccess =
                  redemption.discount_percent === 100 &&
                  redemption.final_amount <= 0 &&
                  !redemptionHasAccessRecord(redemption, records);
                return (
                  <div
                    key={redemption.id}
                    className="rounded-xl border bg-background/60 p-3 text-sm"
                  >
                    <div className="flex flex-wrap items-center gap-2">
                      <span className="font-semibold">{redemption.item_title}</span>
                      <Badge variant="outline" className="rounded-full">
                        {redemption.code}
                      </Badge>
                      <Badge variant="secondary" className="rounded-full capitalize">
                        {redemption.status}
                      </Badge>
                      {missingFullDiscountAccess && (
                        <Badge variant="destructive" className="rounded-full">
                          Missing access row
                        </Badge>
                      )}
                      {redemption.hidden && (
                        <Badge variant="outline" className="rounded-full">
                          Hidden from history list
                        </Badge>
                      )}
                    </div>
                    <p className="mt-1 text-xs text-muted-foreground">
                      {redemption.item_kind} · {redemption.discount_percent}% discount · final{" "}
                      {redemption.currency} {redemption.final_amount} ·{" "}
                      {formatDate(redemption.created_at)}
                    </p>
                    {missingFullDiscountAccess && (
                      <p className="mt-2 text-xs text-muted-foreground">
                        The full-discount redemption is preserved, but no matching access row was
                        found. Verify the exact product before advising a retry; do not alter the
                        redemption or payment record.
                      </p>
                    )}
                  </div>
                );
              })
            ) : (
              <p className="rounded-xl border border-dashed p-4 text-sm text-muted-foreground">
                No coupon redemption rows found.
              </p>
            )}
          </section>

          <section className="space-y-3" aria-label="Recovery history">
            <div className="flex items-center justify-between gap-2">
              <div>
                <h3 className="font-semibold">Recovery history</h3>
                <p className="text-xs text-muted-foreground">
                  Append-only audit; every recovery keeps its before/after state and admin reason.
                </p>
              </div>
              <History className="h-4 w-4 text-muted-foreground" />
            </div>
            {result.recovery_events.length ? (
              result.recovery_events.map((event) => (
                <div key={event.id} className="rounded-xl border bg-background/60 p-3 text-sm">
                  <div className="flex flex-wrap items-center gap-2">
                    <Badge variant="secondary" className="rounded-full capitalize">
                      {event.action}
                    </Badge>
                    <span className="font-medium">
                      {kindLabels[event.record_kind]} · {event.product_id}
                    </span>
                    <span className="text-xs text-muted-foreground">
                      {formatDate(event.created_at)}
                    </span>
                  </div>
                  <p className="mt-1 text-xs text-muted-foreground">Reason: {event.reason}</p>
                </div>
              ))
            ) : (
              <p className="rounded-xl border border-dashed p-4 text-sm text-muted-foreground">
                No prior recovery actions for this student.
              </p>
            )}
          </section>

          <section className="rounded-2xl border bg-muted/30 p-4">
            <div className="flex flex-wrap items-start justify-between gap-3">
              <div>
                <h3 className="font-semibold">Copy-ready issue / student reply</h3>
                <p className="mt-1 text-xs text-muted-foreground">
                  After recovery, this becomes a resolution reply. Before that, it is a lookup
                  summary only.
                </p>
              </div>
              <Button
                type="button"
                size="sm"
                variant="outline"
                className="rounded-full"
                disabled={!copyReply}
                onClick={() => void copyToClipboard(copyReply, "Summary")}
              >
                <Clipboard className="mr-1.5 h-3.5 w-3.5" /> Copy summary
              </Button>
            </div>
            <Textarea
              className="mt-3 min-h-24 text-sm"
              readOnly
              value={copyReply || "Search for a student to create a copy-ready support summary."}
            />
          </section>
        </div>
      )}

      <AlertDialog
        open={Boolean(dialogRecord)}
        onOpenChange={(open) => !open && setDialogRecord(null)}
      >
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>
              {dialogRecord?.kind === "note_purchase"
                ? "Regrant Note access?"
                : dialogRecord?.state === "expired"
                  ? "Renew student access?"
                  : "Restore student access?"}
            </AlertDialogTitle>
            <AlertDialogDescription>
              This will change only the selected student’s access for this product. It will not edit
              or hide coupon redemptions, purchases, payments, coin history, or other products. The
              current state and reason will be added to the audit history.
            </AlertDialogDescription>
          </AlertDialogHeader>
          {dialogRecord && (
            <div className="space-y-4 py-2">
              <div className="rounded-xl border bg-muted/30 p-3 text-sm">
                <p className="font-semibold">{dialogRecord.product_title}</p>
                <p className="mt-1 text-xs text-muted-foreground">
                  {kindLabels[dialogRecord.kind]} · current state: {dialogRecord.state} · current
                  expiry: {formatDate(dialogRecord.expires_at)}
                </p>
              </div>
              <div className="space-y-2">
                <Label htmlFor="recovery-validity">Access period</Label>
                <select
                  id="recovery-validity"
                  className="h-10 w-full rounded-md border border-input bg-background px-3 text-sm"
                  value={validityMode}
                  onChange={(event) =>
                    setValidityMode(event.target.value as "keep" | "days" | "lifetime")
                  }
                >
                  {dialogRecord.expires_at &&
                  Date.parse(dialogRecord.expires_at) <= Date.now() ? null : (
                    <option value="keep">Keep current expiry</option>
                  )}
                  <option value="days">Renew for a number of days</option>
                  <option value="lifetime">Lifetime access</option>
                </select>
              </div>
              {validityMode === "days" && (
                <div className="space-y-2">
                  <Label htmlFor="recovery-days">Renewal days (1–3650)</Label>
                  <Input
                    id="recovery-days"
                    type="number"
                    min={1}
                    max={3650}
                    step={1}
                    value={validDays}
                    onChange={(event) => setValidDays(event.target.value)}
                  />
                </div>
              )}
              <div className="space-y-2">
                <Label htmlFor="recovery-reason">Required reason (saved to history)</Label>
                <Textarea
                  id="recovery-reason"
                  rows={3}
                  maxLength={500}
                  value={reason}
                  onChange={(event) => setReason(event.target.value)}
                  placeholder="e.g. Verified course payment; access was revoked by mistake"
                />
                <p className="text-right text-xs text-muted-foreground">
                  {reason.trim().length}/500
                </p>
              </div>
              {dialogRecord.kind === "note_purchase" && (
                <p className="flex gap-2 rounded-xl border border-sky-500/30 bg-sky-500/[0.06] p-3 text-xs text-muted-foreground">
                  <Clock3 className="h-4 w-4 shrink-0 text-sky-600" /> Original Note purchase and
                  coin-ledger history remain unchanged; only the separate access grant is created or
                  renewed.
                </p>
              )}
            </div>
          )}
          <AlertDialogFooter>
            <AlertDialogCancel disabled={mutation.isPending}>Cancel</AlertDialogCancel>
            <AlertDialogAction
              disabled={
                !dialogRecord ||
                reason.trim().length < 4 ||
                mutation.isPending ||
                (validityMode === "days" &&
                  (!Number.isInteger(Number(validDays)) ||
                    Number(validDays) < 1 ||
                    Number(validDays) > 3650))
              }
              onClick={(event) => {
                event.preventDefault();
                if (dialogRecord) mutation.mutate(dialogRecord);
              }}
            >
              {mutation.isPending ? (
                <Loader2 className="mr-2 h-4 w-4 animate-spin" />
              ) : (
                <Undo2 className="mr-2 h-4 w-4" />
              )}
              Confirm recovery
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </section>
  );
}
