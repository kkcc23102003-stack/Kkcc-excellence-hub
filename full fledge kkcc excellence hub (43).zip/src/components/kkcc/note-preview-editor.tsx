import { useEffect, useRef, useState } from "react";
import { Button } from "@/components/ui/button";
import { QUICK_NOTE_TEXT_COLOURS, QUICK_NOTE_HIGHLIGHTS } from "@/lib/author-quick-colours";
import {
  editNoteFromPreview,
  type NotePreviewAction,
  type NotePreviewSelection,
} from "@/lib/note-preview-format";

type Props = {
  source: string;
  renderedSource: string;
  html: string;
  disabled?: boolean | undefined;
  onChange: (text: string) => void;
  onSelectedLine?: (selection: NotePreviewSelection | null) => void;
};

function elementOf(node: Node): Element | null {
  return node.nodeType === Node.ELEMENT_NODE ? (node as Element) : node.parentElement;
}

/** Preview selection offsets use visible UTF-16 text, not guessed source searches. */
function rangeOffsets(block: HTMLElement, range: Range): { start: number; end: number } | null {
  const startBlock = elementOf(range.startContainer)?.closest("[data-note-line]");
  const endBlock = elementOf(range.endContainer)?.closest("[data-note-line]");
  if (startBlock !== block || endBlock !== block) return null;
  try {
    const before = document.createRange();
    before.selectNodeContents(block);
    before.setEnd(range.startContainer, range.startOffset);
    const start = before.toString().length;
    return { start, end: start + range.toString().length };
  } catch {
    return null;
  }
}

/**
 * Edit the real note source from its rendered preview, without contentEditable
 * HTML, text loss, or changing another occurrence of the same sentence.
 */
export function NotePreviewEditor({
  source,
  renderedSource,
  html,
  disabled,
  onChange,
  onSelectedLine,
}: Props) {
  const root = useRef<HTMLDivElement>(null);
  const [selected, setSelected] = useState<NotePreviewSelection | null>(null);
  const [message, setMessage] = useState("");

  const select = (value: NotePreviewSelection | null) => {
    setSelected(value);
    onSelectedLine?.(value);
  };
  useEffect(() => {
    setSelected(null);
    onSelectedLine?.(null);
  }, [source, renderedSource, onSelectedLine]);
  useEffect(() => {
    root.current?.querySelectorAll<HTMLElement>("[data-note-line]").forEach((element) => {
      element.toggleAttribute(
        "data-preview-selected",
        Number(element.dataset["noteLine"]) === selected?.line,
      );
    });
  }, [selected, html]);

  const capture = (target: EventTarget | null) => {
    if (!(target instanceof Element) || !root.current) return;
    const block = target.closest<HTMLElement>("[data-note-line]");
    if (!block || !root.current.contains(block)) return;
    const line = Number(block.dataset["noteLine"]);
    if (!Number.isSafeInteger(line) || line < 0) return;
    const visibleText = block.textContent ?? "";
    const selection = window.getSelection();
    const range = selection?.rangeCount && !selection.isCollapsed ? selection.getRangeAt(0) : null;
    if (range && root.current.contains(range.commonAncestorContainer)) {
      const offsets = rangeOffsets(block, range);
      if (!offsets) {
        select(null);
        setMessage("Sirf ek hi line ke andar text select karein.");
        return;
      }
      select({ line, ...offsets, visibleText });
      setMessage("");
      return;
    }
    // A tap on an existing yellow mark selects exactly that mark; on a phone
    // the author need not drag tiny selection handles to remove it.
    const mark = target.closest("mark");
    if (mark && block.contains(mark)) {
      const marked = document.createRange();
      marked.selectNodeContents(mark);
      const offsets = rangeOffsets(block, marked);
      if (offsets) {
        select({ line, ...offsets, visibleText });
        setMessage("");
        return;
      }
    }
    const strip = target.closest<HTMLElement>(".kkcc-office-callout, h2.kkcc-note-h2");
    if (strip && block.contains(strip)) {
      const inside = document.createRange();
      inside.selectNodeContents(strip);
      const offsets = rangeOffsets(block, inside);
      if (offsets) {
        select({
          line,
          ...offsets,
          visibleText,
          strip: strip.classList.contains("kkcc-office-callout") ? "box" : "heading",
        });
        setMessage("");
        return;
      }
    }
    select({ line, start: 0, end: 0, visibleText });
    setMessage("");
  };

  const change = (action: NotePreviewAction, colour?: string) => {
    if (!selected || disabled) return;
    if (source !== renderedSource) {
      setMessage("Preview update ho raha hai. Ek pal baad line dobara chunein.");
      return;
    }
    const result = editNoteFromPreview(source, selected, action, colour);
    if (!result.ok) {
      setMessage(result.error);
      return;
    }
    onChange(result.text);
    select(null);
    setMessage("Draft badal gaya hai — student ko dikhane ke liye Save changes dabayein.");
  };
  const tools: { label: string; action: NotePreviewAction; needsText?: boolean }[] = [
    { label: "Highlight selected text", action: "highlight", needsText: true },
    { label: "Remove selected highlight", action: "remove-highlight", needsText: true },
    { label: "Clear highlights on line", action: "clear-line-highlights" },
    { label: "Add topic strip here", action: "add-strip" },
    { label: "Remove topic strip", action: "remove-strip" },
  ];
  return (
    <div data-testid="note-preview-editor" className="mt-2 space-y-2">
      <div className="rounded-lg border border-dashed bg-background/70 p-2">
        <p className="text-xs font-semibold">Preview mein highlight / topic strip edit karein</p>
        <p className="mt-1 text-[11px] text-muted-foreground">
          Line tap karein. Highlight badalne ke liye usi line ka text select karein; peele highlight
          par tap karne se poora highlighted hissa select hota hai. Topic strip poori line par lagti
          hai. Shabd delete nahi hote — sirf rang/strip badalte hain. Aakhir mein Save changes
          dabayein.
        </p>
      </div>
      <div
        ref={root}
        role="region"
        aria-label="Editable note preview: click a line or select its text"
        className="kkcc-note-reader kkcc-note-preview-editable max-h-72 overflow-y-auto rounded-xl bg-card p-3 text-foreground"
        dangerouslySetInnerHTML={{ __html: html }}
        onClick={(event) => capture(event.target)}
        onMouseUp={(event) => capture(event.target)}
        onKeyUp={(event) => capture(event.target)}
        onTouchEnd={(event) => {
          const target = event.target;
          requestAnimationFrame(() => capture(target));
        }}
        onKeyDown={(event) => {
          if (event.key === "Enter" || event.key === " ") {
            event.preventDefault();
            capture(event.target);
          }
        }}
      />
      {/* Keep the actions next to the scrolled preview, not above a long note. */}
      <div className="sticky bottom-2 z-10 rounded-xl border bg-background/95 p-2 shadow-sm backdrop-blur">
        <p className="text-xs" role="status" data-testid="preview-format-status">
          {message ||
            (selected
              ? `Line ${selected.line + 1} chuni hai${selected.end > selected.start ? ` · “${selected.visibleText.slice(selected.start, selected.end).slice(0, 70)}”` : ""}`
              : "Preview se koi line chunein.")}
        </p>
        <div
          role="toolbar"
          aria-label="Edit note preview formatting"
          className="mt-2 flex flex-wrap gap-1.5"
        >
          {tools.map(({ label, action, needsText }) => (
            <Button
              key={action}
              type="button"
              size="sm"
              variant={
                (selected?.strip && action === "remove-strip") ||
                (!selected?.strip &&
                  selected?.end !== selected?.start &&
                  action === "remove-highlight")
                  ? "secondary"
                  : "outline"
              }
              className="min-h-10 text-xs"
              disabled={
                disabled ||
                !selected ||
                source !== renderedSource ||
                (!!needsText && selected.start === selected.end)
              }
              onMouseDown={(event) => event.preventDefault()}
              onClick={() => change(action)}
            >
              {label}
            </Button>
          ))}
        </div>
        {(
          [
            ["Text", QUICK_NOTE_TEXT_COLOURS, "text-colour"],
            ["Marker", QUICK_NOTE_HIGHLIGHTS, "highlight"],
          ] as const
        ).map(([label, swatches, action]) => (
          <div
            key={label}
            role="group"
            aria-label={`Preview ${label.toLowerCase()} colours`}
            className="mt-2 flex items-center gap-1 overflow-x-auto pb-1"
          >
            <span className="shrink-0 text-[11px] font-bold">{label}</span>
            {swatches.map(({ name, hex }) => (
              <button
                key={hex}
                type="button"
                title={`${label} ${name}`}
                aria-label={`Preview ${label.toLowerCase()} ${name}`}
                disabled={
                  disabled ||
                  !selected ||
                  selected.start === selected.end ||
                  source !== renderedSource
                }
                onMouseDown={(event) => event.preventDefault()}
                onClick={() => change(action, hex)}
                className="grid h-10 w-10 shrink-0 place-items-center rounded-lg border-2 border-foreground/20 text-xs font-bold text-slate-900 disabled:opacity-40"
                style={
                  label === "Text"
                    ? { backgroundColor: "#fff", color: hex, borderBottomColor: hex }
                    : { backgroundColor: hex }
                }
              >
                {label === "Text" ? "A" : "▬"}
              </button>
            ))}
            {label === "Text" && (
              <Button
                type="button"
                variant="outline"
                size="sm"
                className="min-h-10 shrink-0 text-xs"
                disabled={disabled || !selected || selected.start === selected.end}
                onMouseDown={(event) => event.preventDefault()}
                onClick={() => change("remove-text-colour")}
              >
                Clear text colour
              </Button>
            )}
          </div>
        ))}
      </div>
    </div>
  );
}
