import { useEffect, useRef, useState } from "react";
import type { PDFDocumentProxy } from "pdfjs-dist";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { grayscaleCanvasPixels, openBrowserPdf, renderPdfPage } from "@/lib/pdf-browser";
import { readPdfFile } from "@/lib/pdf-studio";
import { downloadFile } from "@/lib/document-studio";
import { NOTES_PRINT_LOGO } from "@/lib/notes-print-logo";
import { KKCC_CENTRE_WATERMARK_LOGO } from "@/lib/notes-print-watermark-logo";
import { KKCC_CENTRE_WATERMARK_BLACK_LOGO } from "@/lib/notes-print-watermark-black-logo";
import { brandPdfBytes, type PdfColourMode } from "@/lib/pdf-brand";

export function PdfStudioReader({ initialFile = null }: { initialFile?: File | null }) {
  const [file, setFile] = useState<File | null>(null),
    [bytes, setBytes] = useState<Uint8Array | null>(null),
    [pdf, setPdf] = useState<PDFDocumentProxy | null>(null);
  const [password, setPassword] = useState(""),
    [unlock, setUnlock] = useState(""),
    [page, setPage] = useState(1),
    [zoom, setZoom] = useState(1),
    [rotation, setRotation] = useState(0),
    [invert, setInvert] = useState(false);
  const [fullscreen, setFullscreen] = useState(false);
  useEffect(() => {
    const changed = () => setFullscreen(document.fullscreenElement === root.current);
    document.addEventListener("fullscreenchange", changed);
    return () => document.removeEventListener("fullscreenchange", changed);
  }, []);
  const [message, setMessage] = useState("Choose a PDF. Files stay on this device."),
    [pdfMode, setPdfMode] = useState<PdfColourMode>("colour"),
    [busy, setBusy] = useState(false),
    [brandingDownload, setBrandingDownload] = useState(false),
    [query, setQuery] = useState(""),
    [searching, setSearching] = useState(false),
    [results, setResults] = useState<{ page: number; text: string }[]>([]);
  const [thumbs, setThumbs] = useState<{ page: number; src: string }[]>([]),
    [painted, setPainted] = useState(false);
  const canvasHost = useRef<HTMLDivElement>(null),
    root = useRef<HTMLDivElement>(null),
    searchId = useRef(0);
  useEffect(() => {
    if (initialFile) {
      setFile(initialFile);
      setUnlock("");
    }
  }, [initialFile]);
  useEffect(() => {
    let active = true,
      current: PDFDocumentProxy | null = null;
    setPdf(null);
    setBytes(null);
    setPage(1);
    setZoom(1);
    setRotation(0);
    setInvert(false);
    setQuery("");
    setResults([]);
    setSearching(false);
    setThumbs([]);
    setPainted(false);
    const searchGeneration = searchId;
    searchGeneration.current++;
    if (!file) return;
    setBusy(true);
    setMessage("Opening PDF…");
    void (async () => {
      try {
        const data = await readPdfFile(file);
        current = await openBrowserPdf(data, unlock);
        if (current.numPages > 500) throw new Error("Reader limit: 500 pages.");
        if (active) {
          setBytes(data);
          setPdf(current);
          setMessage(`${current.numPages} pages • Local PDF reader`);
        } else await current.loadingTask.destroy();
      } catch (error) {
        if (current) await current.loadingTask.destroy();
        if (active) setMessage(error instanceof Error ? error.message : "Could not open PDF.");
      } finally {
        if (active) setBusy(false);
      }
    })();
    return () => {
      active = false;
      searchGeneration.current++;
      if (current) void current.loadingTask.destroy().catch(() => {});
    };
  }, [file, unlock]);
  useEffect(() => {
    if (!pdf) return;
    let active = true;
    setPainted(false);
    canvasHost.current?.replaceChildren();
    void renderPdfPage(pdf, page, zoom, rotation)
      .then(({ canvas }) => {
        if (active) {
          canvas.style.maxWidth = "100%";
          canvas.style.height = "auto";
          canvas.style.display = "block";
          canvas.setAttribute("aria-label", `PDF page ${page}`);
          canvasHost.current?.replaceChildren(canvas);
          setPainted(true);
        } else {
          canvas.width = 0;
          canvas.height = 0;
        }
      })
      .catch((error) => {
        if (active)
          setMessage(
            `Page rendering failed: ${error instanceof Error ? error.message : "Try another PDF"}`,
          );
      });
    return () => {
      active = false;
    };
  }, [pdf, page, zoom, rotation]);
  const group = Math.floor((page - 1) / 12);
  useEffect(() => {
    if (!pdf) return;
    let active = true;
    setThumbs([]);
    void (async () => {
      const next = [];
      for (let n = group * 12 + 1; n <= Math.min(pdf.numPages, (group + 1) * 12); n++) {
        if (!active) return;
        try {
          const { canvas } = await renderPdfPage(pdf, n, 0.14);
          const src = canvas.toDataURL("image/jpeg", 0.65);
          canvas.width = 0;
          canvas.height = 0;
          next.push({ page: n, src });
          if (active) setThumbs([...next]);
        } catch {
          return;
        }
      }
    })();
    return () => {
      active = false;
    };
  }, [pdf, group]);
  const search = async () => {
    if (!pdf || !query.trim()) return;
    const id = ++searchId.current;
    setSearching(true);
    setResults([]);
    const found: { page: number; text: string }[] = [];
    try {
      for (let n = 1; n <= pdf.numPages; n++) {
        if (id !== searchId.current) return;
        const p = await pdf.getPage(n),
          content = await p.getTextContent();
        const text = content.items.map((item) => ("str" in item ? item.str : "")).join(" ");
        const index = text.toLocaleLowerCase().indexOf(query.toLocaleLowerCase());
        if (index >= 0)
          found.push({ page: n, text: text.slice(Math.max(0, index - 35), index + 120) });
        if (found.length >= 100) break;
      }
      if (id === searchId.current) {
        setResults(found);
        setMessage(
          found.length
            ? `${found.length} matching pages (maximum 100 results).`
            : "No matching text. Scanned image pages need OCR, which is not included.",
        );
      }
    } catch {
      if (id === searchId.current) setMessage("Search interrupted. Reopen the PDF and try again.");
    } finally {
      if (id === searchId.current) setSearching(false);
    }
  };
  const printPage = () => {
    const canvas = canvasHost.current?.querySelector("canvas");
    if (!canvas) return;
    const tab = window.open("", "_blank");
    if (!tab) {
      setMessage("Allow pop-ups to print the current page.");
      return;
    }
    tab.opener = null;
    tab.document.title = "KKCC — branded PDF page";
    const style = tab.document.createElement("style");
    style.textContent = `@page{margin:10mm}body{margin:0;color:${pdfMode === "black-white" ? "#111" : "#164e4b"};font:12px system-ui,sans-serif}
      header{display:flex;align-items:center;gap:10px;border-bottom:1px solid ${pdfMode === "black-white" ? "#777" : "#bfd3ce"};padding:0 0 8px;font-weight:700}
      header img{width:38px;height:38px;object-fit:contain}
      .sheet{position:relative;margin:8px auto 0;max-width:100%;break-inside:avoid}
      .page-image{display:block;max-width:100%;max-height:84vh;object-fit:contain;margin:auto}
      .watermark{position:absolute;left:50%;top:54%;transform:translate(-50%,-50%);display:flex;flex-direction:column;align-items:center;width:44%;pointer-events:none}
      .watermark img{display:block;width:min(100%,210px);height:auto;opacity:.18}
      .watermark span{margin-top:4px;color:${pdfMode === "black-white" ? "rgba(0,0,0,.23)" : "rgba(6,105,108,.23)"};font-size:clamp(9px,1.6vw,16px);font-weight:800;white-space:nowrap}
      footer{border-top:1px solid ${pdfMode === "black-white" ? "#777" : "#bfd3ce"};margin-top:8px;padding-top:5px;color:${pdfMode === "black-white" ? "#333" : "#536a67"};font-size:10px}`;
    tab.document.head.append(style);
    const header = tab.document.createElement("header");
    const logo = tab.document.createElement("img");
    logo.src = NOTES_PRINT_LOGO;
    if (pdfMode === "black-white") logo.style.filter = "grayscale(1)";
    logo.alt = "KKCC logo";
    header.append(
      logo,
      tab.document.createTextNode("KKCC Excellence Hub · Kusum Kartik Coaching Centre"),
    );
    const sheet = tab.document.createElement("div");
    sheet.className = "sheet";
    const watermark = tab.document.createElement("div");
    watermark.className = "watermark";
    watermark.setAttribute("aria-hidden", "true");
    const watermarkLogo = tab.document.createElement("img");
    watermarkLogo.src =
      pdfMode === "black-white" ? KKCC_CENTRE_WATERMARK_BLACK_LOGO : KKCC_CENTRE_WATERMARK_LOGO;
    watermarkLogo.alt = "";
    const watermarkCaption = tab.document.createElement("span");
    watermarkCaption.textContent = "KKCC Excellence Hub";
    watermark.append(watermarkLogo, watermarkCaption);
    const image = tab.document.createElement("img");
    image.className = "page-image";
    image.alt = `Branded PDF page ${page}`;
    if (pdfMode === "black-white") {
      const copy = document.createElement("canvas");
      copy.width = canvas.width;
      copy.height = canvas.height;
      copy.getContext("2d")!.drawImage(canvas, 0, 0);
      grayscaleCanvasPixels(copy);
      image.src = copy.toDataURL("image/png");
      copy.width = copy.height = 0;
    } else image.src = canvas.toDataURL("image/png");
    sheet.append(image, watermark);
    const footer = tab.document.createElement("footer");
    footer.textContent = `KKCC branded print copy · page ${page} of ${pdf?.numPages ?? 1}`;
    tab.document.body.append(header, sheet, footer);
    // Wait for the centre artwork as well as the rendered PDF image before
    // opening the print dialog; otherwise a fast print may omit the mark.
    void Promise.all([
      logo.decode(),
      image.decode(),
      watermarkLogo.decode(),
      tab.document.fonts.ready,
    ])
      .then(() => {
        if (!tab.closed) tab.print();
      })
      .catch(() => setMessage("Print images could not load. Please try again."));
  };
  const downloadBranded = async () => {
    if (!bytes || brandingDownload) return;
    setBrandingDownload(true);
    setMessage("Adding KKCC logo and watermark to every page…");
    try {
      const branded = await brandPdfBytes(bytes, {
        mode: pdfMode,
        onProgress: (page, total) => setMessage(`Making black & white PDF · page ${page}/${total}`),
      });
      downloadFile(
        branded,
        pdfMode === "black-white"
          ? (file?.name ?? "KKCC-document.pdf").replace(/\.pdf$/i, "-BW.pdf")
          : (file?.name ?? "KKCC-document.pdf"),
        "application/pdf",
      );
      setMessage("KKCC PDF downloaded. The original file on your device is unchanged.");
    } catch (error) {
      setMessage(
        error instanceof Error ? error.message : "Could not brand this PDF. No download started.",
      );
    } finally {
      setBrandingDownload(false);
    }
  };
  return (
    <section
      ref={root}
      className="min-w-0 space-y-4 rounded-2xl border bg-background p-4"
      data-testid="pdf-reader"
    >
      <h2 className="text-xl font-bold">KKCC PDF Reader</h2>
      <label className="block text-sm">
        Open PDF
        <Input
          aria-label="Reader PDF file"
          type="file"
          accept="application/pdf,.pdf"
          disabled={busy}
          onChange={(e) => {
            setFile(e.target.files?.[0] ?? null);
            setUnlock("");
            setPassword("");
          }}
        />
      </label>
      <details>
        <summary className="cursor-pointer text-sm">Password-protected PDF</summary>
        <div className="mt-2 flex gap-2">
          <Input
            type="password"
            aria-label="PDF password"
            value={password}
            onChange={(e) => setPassword(e.target.value)}
            autoComplete="off"
          />
          <Button disabled={!file || busy} onClick={() => setUnlock(password)}>
            Unlock reader
          </Button>
        </div>
      </details>
      <p role="status" className="text-sm text-muted-foreground">
        {message}
      </p>
      {pdf && (
        <>
          <div className="flex flex-wrap items-center gap-2">
            <Button variant="outline" disabled={page <= 1} onClick={() => setPage((p) => p - 1)}>
              Previous page
            </Button>
            <label className="text-sm">
              Page{" "}
              <select
                aria-label="PDF page number"
                className="rounded border bg-background p-2"
                value={page}
                onChange={(e) => setPage(Number(e.target.value))}
              >
                {Array.from({ length: pdf.numPages }, (_, i) => (
                  <option key={i} value={i + 1}>
                    {i + 1}
                  </option>
                ))}
              </select>{" "}
              / {pdf.numPages}
            </label>
            <Button
              variant="outline"
              disabled={page >= pdf.numPages}
              onClick={() => setPage((p) => p + 1)}
            >
              Next page
            </Button>
            <label className="text-sm">
              Zoom{" "}
              <select
                aria-label="PDF zoom"
                className="rounded border bg-background p-2"
                value={zoom}
                onChange={(e) => setZoom(Number(e.target.value))}
              >
                {[0.5, 0.75, 1, 1.5, 2, 3].map((n) => (
                  <option value={n} key={n}>
                    {n * 100}%
                  </option>
                ))}
              </select>
            </label>
            <Button variant="outline" onClick={() => setRotation((r) => (r + 90) % 360)}>
              Rotate view
            </Button>
            <Button variant="outline" aria-pressed={invert} onClick={() => setInvert((v) => !v)}>
              Invert view
            </Button>
            <Button
              variant="outline"
              onClick={() => {
                const job =
                  document.fullscreenElement === root.current
                    ? document.exitFullscreen()
                    : root.current?.requestFullscreen();
                void job?.catch(() =>
                  setMessage("Fullscreen is not available in this browser frame."),
                );
              }}
            >
              {fullscreen ? "Exit fullscreen" : "Fullscreen"}
            </Button>
            <label className="flex w-full min-w-0 flex-wrap items-center gap-2 text-sm sm:w-auto">
              Output
              <select
                aria-label="Reader PDF colour mode"
                className="min-h-10 min-w-0 w-full max-w-full rounded-lg border bg-background px-2 sm:w-auto"
                value={pdfMode}
                disabled={brandingDownload}
                onChange={(event) => setPdfMode(event.target.value as PdfColourMode)}
              >
                <option value="colour">Colour</option>
                <option value="black-white">Black &amp; white · actual grayscale PDF</option>
              </select>
            </label>
            <Button variant="outline" disabled={!painted} onClick={printPage}>
              Print current page
            </Button>
            <Button disabled={!bytes || brandingDownload} onClick={() => void downloadBranded()}>
              Download KKCC PDF
            </Button>
          </div>
          <div className="flex flex-wrap gap-2">
            <Input
              className="min-w-0 flex-1"
              aria-label="Search PDF text"
              value={query}
              onChange={(e) => setQuery(e.target.value)}
              onKeyDown={(e) => {
                if (e.key === "Enter") void search();
              }}
            />
            <Button disabled={searching || !query.trim()} onClick={() => void search()}>
              {searching ? "Searching…" : "Search text"}
            </Button>
          </div>
          {results.length > 0 && (
            <div className="max-h-40 space-y-1 overflow-auto" aria-label="PDF search results">
              {results.map((hit) => (
                <button
                  key={hit.page}
                  className="block w-full rounded border p-2 text-left text-sm"
                  onClick={() => setPage(hit.page)}
                >
                  Page {hit.page}: {hit.text}
                </button>
              ))}
            </div>
          )}
          <div className="grid min-w-0 gap-4 md:grid-cols-[130px_1fr]">
            <aside
              aria-label="PDF page thumbnails"
              className="flex gap-2 overflow-auto md:max-h-[75vh] md:flex-col"
            >
              {thumbs.map((t) => (
                <button
                  key={t.page}
                  aria-label={`Preview page ${t.page}`}
                  aria-current={page === t.page ? "page" : undefined}
                  className={`min-w-20 rounded border p-2 ${page === t.page ? "ring-2 ring-primary" : ""}`}
                  onClick={() => setPage(t.page)}
                >
                  <img src={t.src} alt="" className="mx-auto max-h-28" />
                  <span className="text-xs">{t.page}</span>
                </button>
              ))}
            </aside>
            <div className="max-h-[80vh] min-w-0 overflow-auto rounded-lg bg-slate-200 p-2">
              {!painted && <p role="status">Rendering page…</p>}
              <div
                ref={canvasHost}
                style={{
                  filter: invert ? "invert(1)" : "none",
                  width: `${Math.max(100, zoom * 100)}%`,
                }}
              />
            </div>
          </div>
          <p className="text-xs text-muted-foreground">
            Invert/rotate affect this view only. The printed page and downloaded PDF include the
            KKCC logo and watermark; the original stays on your device. Downloaded copies of signed
            or password-protected files may not be possible. Export changed pages using PDF Tools.
            Search works on embedded text; this reader does not execute PDF scripts or open embedded
            links.
          </p>
        </>
      )}
    </section>
  );
}
