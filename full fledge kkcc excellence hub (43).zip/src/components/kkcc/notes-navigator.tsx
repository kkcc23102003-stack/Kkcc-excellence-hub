import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { EMPTY_NOTE_PATH, noteGroup, type NoteEntry, type NotePath } from "@/lib/note-navigation";
type Props = {
  notes: NoteEntry[];
  path: NotePath;
  onChange: (path: NotePath) => void;
  onCreate?: (subject: string, chapter: string) => void;
  busy?: boolean;
};
export function NotesNavigator({ notes, path, onChange, onCreate, busy = false }: Props) {
  const [name, setName] = useState("");
  const go = (next: NotePath) => {
    setName("");
    onChange(next);
  };
  const subjects = [...new Set(notes.map((note) => noteGroup(note.subject)))].sort((a, b) =>
    a.localeCompare(b),
  );
  const selected = notes.filter((note) => noteGroup(note.subject) === path.subject);
  const chapters = [...new Set(selected.map((note) => noteGroup(note.chapter)))].sort((a, b) =>
    a.localeCompare(b),
  );
  const chapterNotes = selected.filter((note) => noteGroup(note.chapter) === path.chapter);
  const step = path.subject === null ? "subject" : path.chapter === null ? "chapter" : "notes";
  return (
    <section data-testid="notes-navigator" className="my-5 min-w-0 space-y-4 rounded-xl border p-4">
      <h2 className="text-lg font-bold">Select subject → Select chapter → Select notes</h2>
      <nav aria-label="Notes navigation" className="flex flex-wrap items-center gap-2 text-sm">
        <Button type="button" variant="outline" disabled={busy} onClick={() => go(EMPTY_NOTE_PATH)}>
          All subjects
        </Button>
        {path.subject !== null && (
          <Button
            type="button"
            variant="outline"
            disabled={busy}
            onClick={() => go({ subject: path.subject, chapter: null, noteId: null })}
          >
            {path.subject || "Unassigned subject"}
          </Button>
        )}
        {path.chapter !== null && (
          <span className="break-words">→ {path.chapter || "Unassigned chapter"}</span>
        )}
      </nav>
      <h3 className="font-semibold">
        {step === "subject"
          ? "Select subject"
          : step === "chapter"
            ? "Select chapter"
            : "Select notes"}
      </h3>
      <div className="grid gap-2 sm:grid-cols-2 lg:grid-cols-3">
        {step === "subject" &&
          subjects.map((subject) => (
            <Button
              key={subject}
              type="button"
              variant="outline"
              className="h-auto min-h-11 justify-start whitespace-normal break-words text-left"
              disabled={busy}
              onClick={() => go({ subject, chapter: null, noteId: null })}
            >
              Subject: {subject || "Unassigned subject"}
            </Button>
          ))}
        {step === "chapter" &&
          chapters.map((chapter) => (
            <Button
              key={chapter}
              type="button"
              variant="outline"
              className="h-auto min-h-11 justify-start whitespace-normal break-words text-left"
              disabled={busy}
              onClick={() => go({ subject: path.subject, chapter, noteId: null })}
            >
              Chapter: {chapter || "Unassigned chapter"}
            </Button>
          ))}
        {step === "notes" &&
          chapterNotes.map((note) => (
            <Button
              key={note.id}
              type="button"
              variant={path.noteId === note.id ? "default" : "outline"}
              aria-pressed={path.noteId === note.id}
              className="h-auto min-h-11 justify-start whitespace-normal break-words text-left"
              disabled={busy}
              onClick={() => go({ ...path, noteId: note.id })}
            >
              Note: {note.title}
            </Button>
          ))}
      </div>
      {step === "notes" && (
        <Button
          type="button"
          variant="ghost"
          disabled={busy}
          onClick={() => go({ ...path, noteId: null })}
        >
          Show all notes in this chapter
        </Button>
      )}
      {((step === "subject" && !subjects.length) ||
        (step === "chapter" && !chapters.length) ||
        (step === "notes" && !chapterNotes.length)) && (
        <p className="text-sm text-muted-foreground">
          No {step === "subject" ? "subjects" : step === "chapter" ? "chapters" : "notes"} here yet.
        </p>
      )}
      {onCreate && (
        <div className="space-y-2 border-t pt-3">
          {step !== "notes" ? (
            <>
              <label className="block text-sm">
                {step === "subject" ? "New notes subject" : "New notes chapter"}
                <Input
                  value={name}
                  maxLength={step === "subject" ? 80 : 120}
                  disabled={busy}
                  onChange={(e) => setName(e.target.value)}
                  placeholder={
                    step === "subject" ? "e.g. ਪੰਜਾਬੀ / हिन्दी / Science" : "Chapter name"
                  }
                />
              </label>
              <Button
                type="button"
                disabled={busy || !name.trim()}
                onClick={() =>
                  go(
                    step === "subject"
                      ? { subject: name.trim(), chapter: null, noteId: null }
                      : { subject: path.subject, chapter: name.trim(), noteId: null },
                  )
                }
              >
                {step === "subject" ? "Continue to chapters" : "Continue to notes"}
              </Button>
              <p className="text-xs text-muted-foreground">
                A new subject/chapter is saved when you add its first note. Empty names here are
                draft navigation only.
              </p>
            </>
          ) : (
            <>
              <Button
                type="button"
                disabled={busy}
                onClick={() => onCreate(path.subject!, path.chapter!)}
              >
                Add note in this chapter
              </Button>
              <p className="text-sm text-muted-foreground">
                The subject/chapter is filled automatically. Edit, Free/Paid, publish/unpublish and
                delete controls are below. To move a note, edit its Subject / Chapter fields.
              </p>
            </>
          )}
        </div>
      )}
    </section>
  );
}
