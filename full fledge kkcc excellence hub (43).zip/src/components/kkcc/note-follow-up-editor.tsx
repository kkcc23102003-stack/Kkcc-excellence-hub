import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import {
  MAX_NOTE_FOLLOW_UP_QUESTIONS,
  parseNoteFollowUpTest,
  prepareNoteFollowUpPaste,
  type NoteFollowUpTest,
} from "@/lib/note-follow-up-test";
import type { NotePracticeQuestion } from "@/lib/note-practice";

function questionId() {
  return typeof crypto !== "undefined" && "randomUUID" in crypto
    ? crypto.randomUUID()
    : `n${Date.now().toString(36)}${Math.random().toString(36).slice(2)}`;
}

/** Teacher-approved paste and preview; it modifies the note draft, not the Tests/series table. */
export function NoteFollowUpEditor({
  test,
  defaultTitle,
  disabled,
  onChange,
}: {
  test: NoteFollowUpTest | null;
  defaultTitle: string;
  disabled?: boolean;
  onChange: (value: NoteFollowUpTest | null) => boolean;
}) {
  const [title, setTitle] = useState(test?.title ?? "");
  const [paste, setPaste] = useState("");
  const [preview, setPreview] = useState<NotePracticeQuestion[] | null>(null);
  const [message, setMessage] = useState("");
  const name =
    title.trim() || defaultTitle.trim().slice(0, 100) || "Lesson test";
  const previewPaste = () => {
    const parsed = prepareNoteFollowUpPaste(paste, name, questionId);
    if (!parsed.test) {
      setMessage(parsed.error);
      return;
    }
    setTitle(parsed.test.title);
    setPreview(parsed.test.questions);
    setMessage(
      "Preview check karein. Correct answers/explanations edit kar sakte hain; kuch bhi abhi save nahi hua.",
    );
  };
  const updateQuestion = (
    number: number,
    patch: Partial<NotePracticeQuestion>,
  ) =>
    setPreview(
      (current) =>
        current?.map((question, index) =>
          index === number ? { ...question, ...patch } : question,
        ) ?? null,
    );
  const attach = () => {
    const candidate = parseNoteFollowUpTest({
      title: name,
      questions: preview,
    });
    if (!candidate) {
      setMessage(
        `Test preview incomplete hai. 1–${MAX_NOTE_FOLLOW_UP_QUESTIONS} MCQ, 2–4 options, sahi answer aur valid explanation rakhein.`,
      );
      return;
    }
    if (!onChange(candidate)) {
      setMessage(
        "Note ki 1,500,000 character limit paar ho gayi. Test ya note chhota karein.",
      );
      return;
    }
    setPreview(null);
    setPaste("");
    setMessage(
      `${candidate.questions.length} question(s) note draft mein add hue. Main Save changes bhi dabayein.`,
    );
  };
  return (
    <section
      className="mt-4 rounded-2xl border border-primary/30 bg-primary/5 p-3 sm:p-4"
      aria-label="After-note test editor"
    >
      <h3 className="font-bold">Notes ke baad next test · 5 seconds</h3>
      <p className="mt-1 text-xs text-muted-foreground">
        Yeh test sirf is note se linked hai, test series nahi. Student note ke
        end par aayega to 5-second countdown ke baad test khulega. Admin → Tests
        wala Q1 / A) / B) / Answer: / Explanation: format paste karein; ek note
        test mein 200 tak MCQs add ho sakte hain. Student ek waqt mein ek sawal
        answer karega; feedback aur explanation foran milegi. Attempt data save
        nahi hota. AI sahi answer guess nahi karega. Preview approve aur phir
        main Save changes zaroor dabayein.
      </p>
      {test && (
        <div className="mt-3 flex flex-wrap items-center gap-2 rounded-xl border bg-background p-3 text-sm">
          <span className="min-w-0 flex-1">
            <strong>{test.title}</strong> · {test.questions.length} MCQ linked
            to this note
          </span>
          <Button
            type="button"
            size="sm"
            variant="outline"
            disabled={disabled}
            onClick={() => {
              setTitle(test.title);
              setPreview(
                test.questions.map((question) => ({
                  ...question,
                  options: [...question.options],
                })),
              );
              setMessage(
                "Existing test ka preview edit karke dobara attach karein.",
              );
            }}
          >
            Edit linked test
          </Button>
          <Button
            type="button"
            size="sm"
            variant="outline"
            disabled={disabled}
            onClick={() => {
              if (onChange(null)) {
                setPreview(null);
                setMessage(
                  "Test draft se hata diya. Main Save changes dabayein.",
                );
              }
            }}
          >
            Remove linked test
          </Button>
        </div>
      )}
      <div className="mt-3 space-y-2">
        <Label htmlFor="after-note-test-title">Next test title</Label>
        <Input
          id="after-note-test-title"
          value={title}
          maxLength={100}
          onChange={(event) => setTitle(event.target.value)}
          placeholder={defaultTitle || "Chapter test"}
          disabled={disabled}
        />
        <Label htmlFor="after-note-test-paste">Paste MCQ test text</Label>
        <Textarea
          id="after-note-test-paste"
          aria-label="Paste MCQs for after-note test"
          rows={7}
          value={paste}
          onChange={(event) => setPaste(event.target.value)}
          disabled={disabled}
          placeholder={
            "Q1. Plants need what to grow?\nA) Sunlight\nB) Darkness\nAnswer: A\nExplanation: Sunlight helps photosynthesis."
          }
          className="font-mono text-xs"
        />
        <p className="text-xs text-muted-foreground">
          Hindi Devanagari format bhi supported: प्रश्न १:, (क), (ख), उत्तर: ख,
          व्याख्या:. English Q1/A)/Answer format bhi chalega.
        </p>
        <Button
          type="button"
          size="sm"
          className="min-h-11 rounded-full"
          disabled={disabled || !paste.trim()}
          onClick={previewPaste}
        >
          Preview pasted questions
        </Button>
      </div>
      {preview && (
        <div
          className="mt-4 space-y-3"
          role="region"
          aria-label="After-note test preview"
        >
          <p className="font-semibold">
            Check all {preview.length} MCQs before attaching
          </p>
          <ol className="max-h-[65vh] space-y-3 overflow-y-auto pr-1">
            {preview.map((question, index) => (
              <li
                key={question.id}
                className="space-y-2 rounded-xl border bg-background p-3"
              >
                <Label htmlFor={`after-test-question-${index}`}>
                  Question {index + 1}
                </Label>
                <Textarea
                  id={`after-test-question-${index}`}
                  value={question.question}
                  maxLength={500000}
                  onChange={(event) =>
                    updateQuestion(index, { question: event.target.value })
                  }
                  disabled={disabled}
                />
                {question.options.map((option, optionIndex) => (
                  <label
                    key={optionIndex}
                    className="block text-xs font-semibold"
                  >
                    Option {String.fromCharCode(65 + optionIndex)}
                    <Input
                      aria-label={`After-test question ${index + 1} option ${optionIndex + 1}`}
                      value={option}
                      maxLength={500000}
                      className="mt-1"
                      onChange={(event) =>
                        updateQuestion(index, {
                          options: question.options.map((current, i) =>
                            i === optionIndex ? event.target.value : current,
                          ),
                        })
                      }
                      disabled={disabled}
                    />
                  </label>
                ))}
                <label className="block text-xs font-semibold">
                  Correct answer
                  <select
                    aria-label={`Correct answer for after-test question ${index + 1}`}
                    value={question.correctIndex ?? ""}
                    onChange={(event) =>
                      updateQuestion(index, {
                        correctIndex: Number(event.target.value),
                      })
                    }
                    disabled={disabled}
                    className="mt-1 block min-h-11 w-full rounded-md border bg-background px-2"
                  >
                    {question.options.map((_, optionIndex) => (
                      <option value={optionIndex} key={optionIndex}>
                        {String.fromCharCode(65 + optionIndex)}
                      </option>
                    ))}
                  </select>
                </label>
                <label className="block text-xs font-semibold">
                  Explanation shown after submission · up to 500,000 characters
                  <Textarea
                    aria-label={`Explanation for after-test question ${index + 1}`}
                    value={question.explanation}
                    maxLength={500000}
                    className="mt-1"
                    onChange={(event) =>
                      updateQuestion(index, { explanation: event.target.value })
                    }
                    disabled={disabled}
                  />
                </label>
                <Button
                  type="button"
                  size="sm"
                  variant="outline"
                  disabled={disabled}
                  onClick={() =>
                    setPreview(
                      (current) =>
                        current?.filter((_, i) => i !== index) ?? null,
                    )
                  }
                >
                  Remove question {index + 1}
                </Button>
              </li>
            ))}
          </ol>
          <Button
            type="button"
            className="min-h-11 rounded-full"
            disabled={disabled || !preview.length}
            onClick={attach}
          >
            Attach {preview.length} questions to note draft
          </Button>
        </div>
      )}
      {message && (
        <p role="status" className="mt-2 text-xs font-medium">
          {message}
        </p>
      )}
    </section>
  );
}
