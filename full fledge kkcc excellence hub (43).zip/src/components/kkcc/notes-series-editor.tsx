import { useEffect, useState, type ReactNode } from "react";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { useRouter } from "@tanstack/react-router";
import { useServerFn } from "@tanstack/react-start";
import { toast } from "sonner";
import {
  getAdminNotesSeries,
  saveNotesSeries,
  deleteNotesSeries,
  getAdminNotesSeriesPricing,
  saveAdminNotesSeriesPricing,
} from "@/lib/notes-series.functions";
import type { NotesSeriesPricing } from "@/lib/notes-series-pricing.server";
import { getAdminNotesBatchPricing, saveAdminNotesBatchPricing } from "@/lib/notes-batch.functions";
import type { NotesBatchPricing } from "@/lib/notes-batch-pricing.server";
import {
  isSampleNote,
  seriesNoteIds,
  type NotesSeries,
  type NotesSubject,
  type NotesChapter,
  type NotesTopic,
  type SeriesMaterial,
} from "@/lib/notes-series";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { ThumbnailEditor } from "./thumbnail-editor";
import { PagedGrid } from "./paged-grid";
import { BatchVideoManager } from "./batch-video-manager";

type EditableNote = SeriesMaterial & { is_published: boolean };
export function NotesSeriesEditor({
  materials,
  onCreateNote,
  onDeleteNote,
  renderNoteEditor,
}: {
  materials: EditableNote[];
  onCreateNote: (subject: string, chapter: string, kind: "paid" | "sample") => Promise<string>;
  onDeleteNote: (id: string) => Promise<unknown>;
  renderNoteEditor: (id: string) => ReactNode;
}) {
  const qc = useQueryClient();
  const router = useRouter();
  const query = useQuery({
    queryKey: ["admin", "notes-series"],
    queryFn: () => getAdminNotesSeries(),
  });
  const pricingQuery = useQuery({
    queryKey: ["admin", "notes-series-pricing"],
    queryFn: () => getAdminNotesSeriesPricing(),
  });
  const batchPricingQuery = useQuery({
    queryKey: ["admin", "notes-batch-pricing"],
    queryFn: () => getAdminNotesBatchPricing(),
  });
  const savePricing = useServerFn(saveAdminNotesSeriesPricing);
  const saveBatchPricing = useServerFn(saveAdminNotesBatchPricing);
  const [pricingDraft, setPricingDraft] = useState<NotesSeriesPricing>({
    mode: "per_series",
    priceInr: 0,
    priceCoins: 0,
  });
  const [pricingBusy, setPricingBusy] = useState(false);
  const [batchPricingDraft, setBatchPricingDraft] = useState<NotesBatchPricing>({
    mode: "per_batch",
    priceInr: 0,
    priceCoins: 0,
  });
  const [batchPricingBusy, setBatchPricingBusy] = useState(false);
  useEffect(() => {
    if (pricingQuery.data) setPricingDraft(pricingQuery.data);
  }, [pricingQuery.data]);
  useEffect(() => {
    if (batchPricingQuery.data) setBatchPricingDraft(batchPricingQuery.data);
  }, [batchPricingQuery.data]);
  const [draft, setDraft] = useState<NotesSeries | null>(null);
  const [snapshot, setSnapshot] = useState("");
  const [path, setPath] = useState<string[]>([]);
  const [newName, setNewName] = useState("");
  const [newSeriesName, setNewSeriesName] = useState("");
  const [busy, setBusy] = useState(false);
  const [thumbnailBusy, setThumbnailBusy] = useState(false);
  const [editingNote, setEditingNote] = useState<string | null>(null);
  const [attachOpen, setAttachOpen] = useState(false);
  const [noteSearch, setNoteSearch] = useState("");
  const dirty = Boolean(draft && JSON.stringify(draft) !== snapshot);
  const subject = draft?.subjects.find((item) => item.id === path[0]);
  const chapter = subject?.chapters.find((item) => item.id === path[1]);
  const topic = chapter?.topics.find((item) => item.id === path[2]);
  const currentNotes = topic?.noteIds ?? chapter?.noteIds ?? [];
  const invalidate = async () => {
    await Promise.all([
      qc.invalidateQueries({ queryKey: ["admin", "notes-series"] }),
      qc.invalidateQueries({ queryKey: ["notes-series-library"] }),
      qc.invalidateQueries({ queryKey: ["public-catalog"] }),
    ]);
    await router.invalidate();
  };
  const run = async (action: () => Promise<void>) => {
    setBusy(true);
    try {
      await action();
    } catch (error) {
      toast.error(error instanceof Error ? error.message : "Could not save. Retry.");
    } finally {
      setBusy(false);
    }
  };
  const commit = async (value: NotesSeries) => {
    const saved = await saveNotesSeries({ data: value });
    setDraft(saved);
    setSnapshot(JSON.stringify(saved));
    await invalidate();
    toast.success("Notes series saved");
    return saved;
  };
  const savePricingSettings = async () => {
    setPricingBusy(true);
    try {
      const saved = await savePricing({ data: pricingDraft });
      setPricingDraft(saved);
      await Promise.all([
        qc.invalidateQueries({ queryKey: ["admin", "notes-series-pricing"] }),
        qc.invalidateQueries({ queryKey: ["notes-series-library"] }),
        qc.invalidateQueries({ queryKey: ["public-catalog"] }),
      ]);
      await router.invalidate();
      toast.success("Notes Series pricing control saved");
    } catch (error) {
      toast.error(error instanceof Error ? error.message : "Could not save pricing control.");
    } finally {
      setPricingBusy(false);
    }
  };
  const saveBatchPricingSettings = async () => {
    setBatchPricingBusy(true);
    try {
      const saved = await saveBatchPricing({ data: batchPricingDraft });
      setBatchPricingDraft(saved);
      await Promise.all([
        qc.invalidateQueries({ queryKey: ["admin", "notes-batch-pricing"] }),
        qc.invalidateQueries({ queryKey: ["public-catalog", "listPublishedCourses"] }),
        qc.invalidateQueries({ queryKey: ["admin", "courses"] }),
        qc.invalidateQueries({ queryKey: ["admin", "notes-batch"] }),
      ]);
      await router.invalidate();
      toast.success("Batch pricing control saved");
    } catch (error) {
      toast.error(error instanceof Error ? error.message : "Could not save Batch pricing control.");
    } finally {
      setBatchPricingBusy(false);
    }
  };
  const move = (next: string[]) => {
    setPath(next);
    setNewName("");
    setEditingNote(null);
    setAttachOpen(false);
  };
  const edit = (change: (next: NotesSeries) => void) => {
    const next = structuredClone(draft!);
    change(next);
    return next;
  };
  const at = (next: NotesSeries) => {
    const sub = next.subjects.find((item) => item.id === path[0]);
    const chap = sub?.chapters.find((item) => item.id === path[1]);
    const top = chap?.topics.find((item) => item.id === path[2]);
    return { sub, chap, top };
  };
  const updateLinks = (id: string, remove = false) =>
    edit((next) => {
      const { chap, top } = at(next);
      const target = top ?? chap;
      if (target)
        target.noteIds = remove
          ? target.noteIds.filter((item) => item !== id)
          : [...target.noteIds, id];
    });
  const addNode = () =>
    run(async () => {
      const name = newName.trim();
      if (!name) throw new Error("Enter a name first.");
      const id = crypto.randomUUID();
      const next = edit((item) => {
        const { sub, chap } = at(item);
        if (!sub) item.subjects.push({ id, name, chapters: [] });
        else if (!chap) sub.chapters.push({ id, name, noteIds: [], topics: [] });
        else chap.topics.push({ id, name, noteIds: [] });
      });
      await commit(next);
      setNewName("");
    });
  const rows: (NotesSubject | NotesChapter | NotesTopic)[] = subject
    ? chapter
      ? chapter.topics
      : subject.chapters
    : (draft?.subjects ?? []);
  const level = subject ? (chapter ? "topic" : "chapter") : "subject";
  const removeNode = (id: string) =>
    run(async () => {
      if (
        !window.confirm(
          `Remove this ${level} and its organisation? Notes and purchased access are kept; unassigned notes remain available separately.`,
        )
      )
        return;
      await commit(
        edit((next) => {
          const { sub, chap } = at(next);
          if (chap) chap.topics = chap.topics.filter((item) => item.id !== id);
          else if (sub) sub.chapters = sub.chapters.filter((item) => item.id !== id);
          else next.subjects = next.subjects.filter((item) => item.id !== id);
        }),
      );
    });
  const renameNode = (id: string, name: string) =>
    setDraft(
      edit((next) => {
        const { sub, chap } = at(next);
        const list = chap?.topics ?? sub?.chapters ?? next.subjects;
        const node = list.find((item) => item.id === id);
        if (node) node.name = name;
      }),
    );
  const used = new Set(draft ? seriesNoteIds(draft) : []);
  const available = materials.filter(
    (note) =>
      !used.has(note.id) &&
      isSampleNote(note) === (draft?.kind === "sample") &&
      `${note.title} ${note.subject} ${note.chapter}`
        .toLocaleLowerCase()
        .includes(noteSearch.trim().toLocaleLowerCase()),
  );
  return (
    <section
      data-testid="notes-series-editor"
      className="mb-8 min-w-0 space-y-5 rounded-2xl border bg-card p-4 sm:p-6"
    >
      <h2 className="text-xl font-bold">Notes Series Builder</h2>
      <p className="text-sm text-muted-foreground">
        Series → Subject → Chapter → Topic (optional) → Notes. Choose one shared price for every
        paid Notes Series, or set each series separately. A linked batch remains a separate product.
      </p>
      <section className="space-y-3 rounded-2xl border border-primary/25 bg-primary/5 p-4">
        <div>
          <h3 className="font-semibold">Notes Series pricing control</h3>
          <p className="text-xs text-muted-foreground">
            Shared mode applies to every paid series, including new series. Individual mode uses the
            price saved inside each series.
          </p>
        </div>
        {pricingQuery.isError ? (
          <p role="alert" className="text-sm text-destructive">
            Could not load Notes Series pricing controls.
          </p>
        ) : (
          <>
            <label className="block max-w-md text-sm">
              Pricing mode
              <select
                aria-label="Notes Series pricing mode"
                className="mt-1 min-h-11 w-full rounded-lg border bg-background p-2"
                value={pricingDraft.mode}
                onChange={(event) =>
                  setPricingDraft({
                    ...pricingDraft,
                    mode: event.target.value as NotesSeriesPricing["mode"],
                  })
                }
                disabled={pricingQuery.isPending || pricingBusy}
              >
                <option value="shared">Same price for all Notes Series</option>
                <option value="per_series">Set a different price for each series</option>
              </select>
            </label>
            {pricingDraft.mode === "shared" ? (
              <div className="grid gap-3 sm:grid-cols-2">
                <label className="text-sm">
                  Shared Notes Series price (₹)
                  <Input
                    aria-label="Shared Notes Series rupee price"
                    type="number"
                    min={0}
                    max={1_000_000}
                    step={1}
                    value={pricingDraft.priceInr}
                    onChange={(event) =>
                      setPricingDraft({
                        ...pricingDraft,
                        priceInr: Math.min(
                          1_000_000,
                          Math.round(Math.max(0, Number(event.target.value) || 0)),
                        ),
                      })
                    }
                  />
                </label>
                <label className="text-sm">
                  Shared Notes Series price (23KAAT coins)
                  <Input
                    aria-label="Shared Notes Series coin price"
                    type="number"
                    min={0}
                    max={1_000_000}
                    step={1}
                    value={pricingDraft.priceCoins}
                    onChange={(event) =>
                      setPricingDraft({
                        ...pricingDraft,
                        priceCoins: Math.min(
                          1_000_000,
                          Math.round(Math.max(0, Number(event.target.value) || 0)),
                        ),
                      })
                    }
                  />
                </label>
              </div>
            ) : (
              <p className="text-xs text-muted-foreground">
                Shared prices are off. Edit each paid series below to set its own INR and/or 23KAAT
                price.
              </p>
            )}
            {pricingDraft.mode === "shared" &&
              pricingDraft.priceInr <= 0 &&
              pricingDraft.priceCoins <= 0 && (
                <p className="text-xs text-amber-700">
                  Set at least one shared price above zero before students can buy a series.
                </p>
              )}
            <Button
              onClick={() => void savePricingSettings()}
              disabled={pricingQuery.isPending || pricingBusy}
            >
              {pricingBusy ? "Saving pricing…" : "Save Notes Series pricing mode"}
            </Button>
          </>
        )}
      </section>
      <section className="space-y-3 rounded-2xl border border-secondary/40 bg-muted/20 p-4">
        <div>
          <h3 className="font-semibold">Batch pricing control</h3>
          <p className="text-xs text-muted-foreground">
            Shared mode overrides the linked Batch courses’ INR and 23KAAT prices everywhere
            students see or pay them. Individual mode uses each Batch course’s price in the course
            editor. Notes Series pricing is configured separately above.
          </p>
        </div>
        {batchPricingQuery.isError ? (
          <p role="alert" className="text-sm text-destructive">
            Could not load Batch pricing controls.
          </p>
        ) : (
          <>
            <label className="block max-w-md text-sm">
              Pricing mode
              <select
                aria-label="Batch pricing mode"
                className="mt-1 min-h-11 w-full rounded-lg border bg-background p-2"
                value={batchPricingDraft.mode}
                onChange={(event) =>
                  setBatchPricingDraft({
                    ...batchPricingDraft,
                    mode: event.target.value as NotesBatchPricing["mode"],
                  })
                }
                disabled={batchPricingQuery.isPending || batchPricingBusy}
              >
                <option value="shared">Same price for all Batches</option>
                <option value="per_batch">Set a different price for each Batch</option>
              </select>
            </label>
            {batchPricingDraft.mode === "shared" ? (
              <div className="grid gap-3 sm:grid-cols-2">
                <label className="text-sm">
                  Shared Batch price (₹)
                  <Input
                    aria-label="Shared Batch rupee price"
                    type="number"
                    min={0}
                    max={1_000_000}
                    step={1}
                    value={batchPricingDraft.priceInr}
                    onChange={(event) =>
                      setBatchPricingDraft({
                        ...batchPricingDraft,
                        priceInr: Math.min(
                          1_000_000,
                          Math.round(Math.max(0, Number(event.target.value) || 0)),
                        ),
                      })
                    }
                  />
                </label>
                <label className="text-sm">
                  Shared Batch price (23KAAT coins)
                  <Input
                    aria-label="Shared Batch coin price"
                    type="number"
                    min={0}
                    max={1_000_000}
                    step={1}
                    value={batchPricingDraft.priceCoins}
                    onChange={(event) =>
                      setBatchPricingDraft({
                        ...batchPricingDraft,
                        priceCoins: Math.min(
                          1_000_000,
                          Math.round(Math.max(0, Number(event.target.value) || 0)),
                        ),
                      })
                    }
                  />
                </label>
              </div>
            ) : (
              <p className="text-xs text-muted-foreground">
                Shared prices are off. Set each Batch price on its linked course in the course
                editor.
              </p>
            )}
            {batchPricingDraft.mode === "shared" &&
              batchPricingDraft.priceInr <= 0 &&
              batchPricingDraft.priceCoins <= 0 && (
                <p className="text-xs text-amber-700">
                  Set at least one shared price above zero before students can buy a Batch.
                </p>
              )}
            <Button
              onClick={() => void saveBatchPricingSettings()}
              disabled={batchPricingQuery.isPending || batchPricingBusy}
            >
              {batchPricingBusy ? "Saving pricing…" : "Save Batch pricing mode"}
            </Button>
          </>
        )}
      </section>
      {query.isError && (
        <p role="alert">
          Could not load series.{" "}
          <Button variant="outline" onClick={() => void query.refetch()}>
            Retry series
          </Button>
        </p>
      )}
      {query.isPending && <p role="status">Loading notes series…</p>}
      {!draft ? (
        <>
          <div className="flex flex-wrap items-end gap-3">
            <label className="min-w-0 flex-1 text-sm">
              Notes series name
              <Input
                aria-label="New notes series name"
                value={newSeriesName}
                onChange={(e) => setNewSeriesName(e.target.value)}
                maxLength={200}
                placeholder="e.g. ETT Complete Notes"
              />
            </label>
            <Button
              disabled={busy || !newSeriesName.trim()}
              onClick={() =>
                void run(async () => {
                  await commit({
                    id: crypto.randomUUID(),
                    name: newSeriesName.trim(),
                    kind: "paid",
                    priceInr: 0,
                    priceCoins: 0,
                    published: false,
                    revision: 0,
                    subjects: [],
                    thumbnail_url: null,
                    thumbnail_text: null,
                  });
                  move([]);
                  setNewSeriesName("");
                })
              }
            >
              Create notes series
            </Button>
          </div>
          <PagedGrid
            items={query.data ?? []}
            label="Admin notes series"
            className="grid gap-3 sm:grid-cols-2"
          >
            {(item) => (
              <article key={item.id} className="min-w-0 rounded-xl border p-4">
                <h3 className="break-words font-semibold">{item.name}</h3>
                <p className="my-2 text-xs text-muted-foreground">
                  {item.kind === "sample" ? "Free notes" : "Paid notes"} ·{" "}
                  {item.published ? "Published" : "Draft"} · {seriesNoteIds(item).length} linked
                  notes
                </p>
                {item.kind === "paid" && (
                  <p className="mb-2 text-xs text-muted-foreground">
                    {item.priceInr > 0 || item.priceCoins > 0
                      ? `Full Notes Series: ${item.priceInr > 0 ? `₹${item.priceInr}` : ""}${item.priceInr > 0 && item.priceCoins > 0 ? " · " : ""}${item.priceCoins > 0 ? `${item.priceCoins} coins` : ""}`
                      : "Set a full-series price to enable Buy Notes Only."}
                  </p>
                )}
                <Button
                  variant="outline"
                  onClick={() => {
                    setDraft(item);
                    setSnapshot(JSON.stringify(item));
                    move([]);
                  }}
                >
                  Edit series
                </Button>
              </article>
            )}
          </PagedGrid>
          {!query.data?.length && !query.isPending && (
            <p className="text-sm text-muted-foreground">
              Create your first series above. Existing notes are kept; attach them after adding a
              chapter.
            </p>
          )}
        </>
      ) : (
        <fieldset disabled={busy || thumbnailBusy} className="min-w-0 space-y-5">
          <div className="flex flex-wrap gap-2">
            <Button
              variant="outline"
              onClick={() => {
                if (dirty && !window.confirm("Discard unsaved series changes?")) return;
                setDraft(null);
                move([]);
              }}
            >
              All notes series
            </Button>
            <Button
              className="h-auto max-w-full whitespace-normal break-all"
              variant="ghost"
              onClick={() => move([])}
            >
              {draft.name}
            </Button>
            {subject && (
              <Button
                className="h-auto max-w-full whitespace-normal break-all"
                variant="ghost"
                onClick={() => move([subject.id])}
              >
                {subject.name}
              </Button>
            )}
            {chapter && (
              <Button
                className="h-auto max-w-full whitespace-normal break-all"
                variant="ghost"
                onClick={() => move([subject!.id, chapter.id])}
              >
                {chapter.name}
              </Button>
            )}
            {topic && <span className="self-center break-words text-sm">{topic.name}</span>}
          </div>
          <details className="rounded-xl border p-4" open={!subject}>
            <summary className="cursor-pointer font-semibold">
              Series name, thumbnail & publication
            </summary>
            <div className="mt-4 space-y-4">
              <label className="block text-sm">
                Notes series name
                <Input
                  aria-label="Notes series name"
                  value={draft.name}
                  onChange={(e) => setDraft({ ...draft, name: e.target.value })}
                  maxLength={200}
                />
              </label>
              <ThumbnailEditor
                title={draft.name}
                value={{
                  thumbnail_url: draft.thumbnail_url ?? null,
                  thumbnail_text: draft.thumbnail_text ?? null,
                }}
                onBusyChange={setThumbnailBusy}
                onChange={(value) => setDraft({ ...draft, ...value })}
              />
              <label className="block text-sm">
                Series section
                <select
                  aria-label="Notes series section"
                  className="mt-1 block min-h-11 w-full rounded-lg border bg-background p-2"
                  value={draft.kind}
                  onChange={(e) =>
                    setDraft({ ...draft, kind: e.target.value as "paid" | "sample" })
                  }
                >
                  <option value="paid">Paid notes</option>
                  <option value="sample">Free notes (optional)</option>
                </select>
              </label>
              {draft.kind === "paid" &&
                (pricingDraft.mode === "shared" ? (
                  <p className="rounded-lg border bg-muted/30 p-3 text-xs text-muted-foreground">
                    Shared pricing is active. All paid Notes Series use the global price shown
                    above. Switch to individual mode to set this series separately.
                  </p>
                ) : (
                  <div className="grid gap-3 sm:grid-cols-2">
                    <label className="text-sm">
                      Full-series price (₹)
                      <Input
                        aria-label="Notes series price in rupees"
                        type="number"
                        min={0}
                        max={1_000_000}
                        step={1}
                        value={draft.priceInr ?? 0}
                        onChange={(e) =>
                          setDraft({
                            ...draft,
                            priceInr: Math.min(
                              1_000_000,
                              Math.round(Math.max(0, Number(e.target.value) || 0)),
                            ),
                          })
                        }
                      />
                    </label>
                    <label className="text-sm">
                      Full-series price (23KAAT coins, optional)
                      <Input
                        aria-label="Notes series price in coins"
                        type="number"
                        min={0}
                        max={1_000_000}
                        step={1}
                        value={draft.priceCoins ?? 0}
                        onChange={(e) =>
                          setDraft({
                            ...draft,
                            priceCoins: Math.min(
                              1_000_000,
                              Math.round(Math.max(0, Number(e.target.value) || 0)),
                            ),
                          })
                        }
                      />
                    </label>
                  </div>
                ))}
              <p className="text-xs text-muted-foreground">
                First published note in each subject is a free preview. Set at least a rupee or coin
                price before offering full-series purchase.
              </p>
              <label className="flex items-center gap-2 text-sm">
                <input
                  aria-label="Publish notes series"
                  type="checkbox"
                  checked={draft.published}
                  onChange={(e) => setDraft({ ...draft, published: e.target.checked })}
                />
                Publish notes series
              </label>
              <p className="text-xs text-muted-foreground">
                Empty series and unpublished notes stay hidden from students. Publish each note in
                its editor too.
              </p>
              <div className="flex flex-wrap gap-2">
                <Button
                  onClick={() =>
                    void run(async () => {
                      await commit(draft);
                    })
                  }
                >
                  Save series
                </Button>
                <Button
                  variant="outline"
                  onClick={() =>
                    void run(async () => {
                      if (dirty && !window.confirm("Discard local changes and reload?")) return;
                      const data = await query.refetch();
                      const fresh = data.data?.find((item) => item.id === draft.id);
                      if (fresh) {
                        setDraft(fresh);
                        setSnapshot(JSON.stringify(fresh));
                      }
                    })
                  }
                >
                  Reload series
                </Button>
                <Button
                  variant="outline"
                  className="text-destructive"
                  onClick={() =>
                    void run(async () => {
                      if (
                        !window.confirm(
                          "Delete this series organisation? Notes, purchases and student accounts will NOT be deleted. Unassigned published notes remain accessible.",
                        )
                      )
                        return;
                      await deleteNotesSeries({ data: { id: draft.id, revision: draft.revision } });
                      setDraft(null);
                      move([]);
                      await invalidate();
                    })
                  }
                >
                  Delete series (keep notes)
                </Button>
              </div>
            </div>
          </details>
          {dirty && (
            <p role="status" className="text-sm text-primary">
              Unsaved series changes — use Save series or a Save name button.
            </p>
          )}
          {draft.kind === "paid" && <BatchVideoManager seriesId={draft.id} unsaved={dirty} />}
          {!topic && (
            <>
              <h3 className="text-lg font-semibold">
                {level === "subject"
                  ? "Subjects"
                  : level === "chapter"
                    ? "Chapters"
                    : "Topics (optional)"}
              </h3>
              <div className="flex flex-wrap gap-2">
                <Input
                  aria-label={`New ${level} name`}
                  className="min-w-0 flex-1"
                  placeholder={`${level} name`}
                  maxLength={200}
                  value={newName}
                  onChange={(e) => setNewName(e.target.value)}
                />
                <Button onClick={() => void addNode()} disabled={!newName.trim()}>
                  Add {level}
                </Button>
              </div>
              <PagedGrid items={rows} label={`Admin ${level} list`} className="space-y-3">
                {(node) => (
                  <div
                    key={node.id}
                    className="flex min-w-0 flex-wrap items-center gap-2 rounded-xl border p-3"
                  >
                    <Input
                      aria-label={`Edit ${level} name: ${node.name}`}
                      className="min-w-0 flex-1"
                      value={node.name}
                      onChange={(e) => renameNode(node.id, e.target.value)}
                    />
                    <Button
                      variant="outline"
                      onClick={() =>
                        void run(async () => {
                          await commit(draft);
                        })
                      }
                    >
                      Save name
                    </Button>
                    <Button
                      aria-label={`Open ${level}: ${node.name}`}
                      onClick={() => move([...path, node.id])}
                    >
                      Open {level}
                    </Button>
                    <Button
                      variant="ghost"
                      className="text-destructive"
                      aria-label={`Remove ${level}: ${node.name}`}
                      onClick={() => void removeNode(node.id)}
                    >
                      Remove
                    </Button>
                  </div>
                )}
              </PagedGrid>
            </>
          )}
          {chapter && (
            <>
              <h3 className="text-lg font-semibold">
                {topic ? `Notes in ${topic.name}` : "Chapter notes — no topic required"}
              </h3>
              <div className="flex flex-wrap gap-2">
                <Button
                  onClick={() =>
                    void run(async () => {
                      const id = await onCreateNote(subject!.name, chapter.name, draft.kind);
                      await commit(updateLinks(id));
                      setEditingNote(id);
                    })
                  }
                >
                  {topic ? "Add note to topic" : "Add note without topic"}
                </Button>
                <Button variant="outline" onClick={() => setAttachOpen(!attachOpen)}>
                  Attach existing note
                </Button>
              </div>
              {attachOpen && (
                <div className="space-y-3 rounded-xl border p-4">
                  <Input
                    aria-label="Find existing note"
                    placeholder="Search existing notes by title, subject or chapter"
                    value={noteSearch}
                    onChange={(e) => setNoteSearch(e.target.value)}
                  />
                  <PagedGrid items={available} label="Attach notes" className="space-y-2">
                    {(note) => (
                      <div
                        key={note.id}
                        className="flex min-w-0 items-center justify-between gap-2"
                      >
                        <span className="break-words text-sm">{note.title}</span>
                        <Button
                          variant="outline"
                          aria-label={`Attach note: ${note.title}`}
                          onClick={() =>
                            void run(async () => {
                              await commit(updateLinks(note.id));
                            })
                          }
                        >
                          Attach
                        </Button>
                      </div>
                    )}
                  </PagedGrid>
                  {!available.length && (
                    <p className="text-sm text-muted-foreground">
                      No matching unlinked {draft.kind === "sample" ? "free" : "paid/course-access"}{" "}
                      notes. Create one above or change an existing note’s access mode in the
                      individual editor.
                    </p>
                  )}
                </div>
              )}
              <PagedGrid items={currentNotes} label="Linked notes" className="space-y-3">
                {(id) => {
                  const note = materials.find((item) => item.id === id);
                  return (
                    <div key={id} className="min-w-0 rounded-xl border p-4">
                      <p className="break-words font-semibold">
                        {note?.title ?? "Removed note — unlink this reference"}
                      </p>
                      <p className="mt-1 text-xs text-muted-foreground">
                        {note?.is_published ? "Published" : "Draft"}
                      </p>
                      <div className="mt-3 flex flex-wrap gap-2">
                        {note && (
                          <Button
                            aria-label={`Edit note: ${note.title}`}
                            onClick={() => setEditingNote(editingNote === id ? null : id)}
                          >
                            Edit note
                          </Button>
                        )}
                        <Button
                          variant="outline"
                          onClick={() =>
                            void run(async () => {
                              await commit(updateLinks(id, true));
                              if (editingNote === id) setEditingNote(null);
                            })
                          }
                        >
                          Unlink (keep note)
                        </Button>
                        {note && !note.is_published && (
                          <Button
                            variant="ghost"
                            className="text-destructive"
                            aria-label={`Delete note: ${note.title}`}
                            onClick={() =>
                              void run(async () => {
                                if (
                                  !window.confirm(
                                    `Delete unpublished note “${note.title}”? This removes the note from every list. Notes with purchases or coin history cannot be deleted; student records remain untouched.`,
                                  )
                                )
                                  return;
                                await onDeleteNote(id);
                                await commit(updateLinks(id, true));
                                setEditingNote(null);
                              })
                            }
                          >
                            Delete note
                          </Button>
                        )}
                      </div>
                      {editingNote === id && renderNoteEditor(id)}
                    </div>
                  );
                }}
              </PagedGrid>
              {!currentNotes.length && (
                <p className="text-sm text-muted-foreground">
                  No notes here yet. Add a note, attach an existing one, or open a topic.
                </p>
              )}
            </>
          )}
        </fieldset>
      )}
    </section>
  );
}
