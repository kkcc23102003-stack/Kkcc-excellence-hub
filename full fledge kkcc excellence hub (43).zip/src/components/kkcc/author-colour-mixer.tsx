import { useEffect, useState } from "react";
import {
  AUTHOR_SWATCHES,
  authorContrast,
  hsvToHex,
  mixAuthorColours,
  normaliseAuthorColour,
} from "@/lib/author-colours";

type Mode = "color" | "highlight";
type Props = {
  disabled?: boolean | undefined;
  allowHighlight?: boolean | undefined;
  onApply: (mode: Mode, colour: string) => void;
  onClear: (mode: Mode) => void;
};
const RECENT_KEY = "kkcc-author-colour-recent-v1";
const FAVOURITE_KEY = "kkcc-author-colour-favourites-v1";
function readColours(key: string): string[] {
  try {
    const raw = JSON.parse(localStorage.getItem(key) || "[]");
    return Array.isArray(raw)
      ? [
          ...new Set(
            raw
              .slice(0, 12)
              .map((item) => (typeof item === "string" ? normaliseAuthorColour(item) : null))
              .filter((item): item is string => !!item),
          ),
        ]
      : [];
  } catch {
    return [];
  }
}

/** Only validated six-digit hex is saved. Recent/favourite preferences are device-local, not note content. */
export function AuthorColourMixer({ disabled, allowHighlight = true, onApply, onClear }: Props) {
  const [mode, setMode] = useState<Mode>("color");
  const [view, setView] = useState<"swatches" | "spectrum">("swatches");
  // Start with a readable KKCC teal rather than a bright, low-contrast mint.
  const [hue, setHue] = useState(174);
  const [saturation, setSaturation] = useState(82);
  const [brightness, setBrightness] = useState(45);
  const [other, setOther] = useState("#1d4ed8");
  const [blend, setBlend] = useState(0);
  const [hexInput, setHexInput] = useState("");
  const [direct, setDirect] = useState<string | null>(null);
  const [recent, setRecent] = useState<string[]>([]);
  const [favourites, setFavourites] = useState<string[]>([]);
  useEffect(() => {
    setRecent(readColours(RECENT_KEY));
    setFavourites(readColours(FAVOURITE_KEY));
  }, []);
  const mixed = mixAuthorColours(hsvToHex(hue, saturation, brightness), other, blend);
  const colour = normaliseAuthorColour(hexInput) ?? direct ?? mixed;
  const badHex = hexInput.trim().length > 0 && !normaliseAuthorColour(hexInput);
  const poorContrast = authorContrast(colour, mode === "color" ? "#ffffff" : "#172b36") < 4.5;
  const pick = (next: string) => {
    setDirect(normaliseAuthorColour(next));
    setHexInput("");
  };
  const updateRecent = (next: string) => {
    const values = [next, ...recent.filter((value) => value !== next)].slice(0, 8);
    setRecent(values);
    try {
      localStorage.setItem(RECENT_KEY, JSON.stringify(values));
    } catch {
      /* Preferences are optional. */
    }
  };
  const toggleFavourite = () => {
    const values = favourites.includes(colour)
      ? favourites.filter((item) => item !== colour)
      : [colour, ...favourites].slice(0, 8);
    setFavourites(values);
    try {
      localStorage.setItem(FAVOURITE_KEY, JSON.stringify(values));
    } catch {
      /* Preferences are optional. */
    }
  };
  return (
    <section
      aria-label="Custom writing colours"
      className="max-w-full space-y-3 rounded-xl border bg-card p-3 text-card-foreground shadow-sm"
    >
      <div className="flex flex-wrap items-center gap-2">
        <strong className="text-sm">Custom colour mixer</strong>
        {allowHighlight && (
          <div role="group" aria-label="Colour target" className="flex gap-1">
            {(
              [
                ["color", "Text"],
                ["highlight", "Highlight"],
              ] as const
            ).map(([key, label]) => (
              <button
                key={key}
                type="button"
                disabled={disabled}
                aria-pressed={mode === key}
                onClick={() => setMode(key)}
                className={`min-h-11 rounded-lg border px-3 text-sm ${mode === key ? "border-primary bg-secondary font-bold" : "bg-background"}`}
              >
                {label}
              </button>
            ))}
          </div>
        )}
      </div>
      <div className="flex flex-wrap gap-1 text-sm" role="tablist" aria-label="Colour picker view">
        {(["swatches", "spectrum"] as const).map((choice) => (
          <button
            key={choice}
            type="button"
            role="tab"
            aria-selected={view === choice}
            disabled={disabled}
            onClick={() => setView(choice)}
            className={`min-h-11 rounded-lg border px-3 capitalize ${view === choice ? "border-primary bg-secondary font-semibold" : "bg-background"}`}
          >
            {choice}
          </button>
        ))}
      </div>
      {view === "swatches" ? (
        <div className="flex flex-wrap gap-1" role="group" aria-label="Preset colours">
          {AUTHOR_SWATCHES.map((swatch) => (
            <button
              key={swatch}
              type="button"
              disabled={disabled}
              aria-label={`Use ${swatch}`}
              title={swatch}
              onClick={() => pick(swatch)}
              className="h-11 w-11 rounded-lg border-2 border-border focus-visible:outline-2 focus-visible:outline-primary"
              style={{ backgroundColor: swatch }}
            />
          ))}
        </div>
      ) : (
        <div
          className="grid grid-cols-12 gap-0.5 rounded-lg border bg-background p-1"
          role="group"
          aria-label="Spectrum colours"
        >
          {[95, 85, 72, 60, 47, 35].flatMap((brightness, row) =>
            Array.from({ length: 12 }, (_, column) => {
              const ink = hsvToHex(column * 30, row < 2 ? 65 : 82, brightness);
              return (
                <button
                  key={`${row}-${column}`}
                  type="button"
                  disabled={disabled}
                  aria-label={`Spectrum ${ink}`}
                  title={ink}
                  onClick={() => pick(ink)}
                  className="h-9 min-w-0 rounded-sm border border-black/10 focus-visible:outline-2 focus-visible:outline-primary"
                  style={{ backgroundColor: ink }}
                />
              );
            }),
          )}
        </div>
      )}
      <div className="grid gap-2 sm:grid-cols-3">
        {(
          [
            ["Hue", hue, 360, setHue],
            ["Saturation", saturation, 100, setSaturation],
            ["Brightness", brightness, 100, setBrightness],
          ] as const
        ).map(([label, value, max, setValue]) => (
          <label key={label} className="block text-xs font-semibold">
            {label}: {value}
            <input
              aria-label={label}
              type="range"
              min={0}
              max={max}
              value={value}
              disabled={disabled}
              className="mt-1 block h-11 w-full accent-primary"
              onChange={(event) => {
                setDirect(null);
                setHexInput("");
                setValue(Number(event.target.value));
              }}
            />
          </label>
        ))}
      </div>
      <div className="grid gap-2 sm:grid-cols-2">
        <label className="text-xs font-semibold">
          Blend with second colour
          <input
            aria-label="Second blend colour"
            type="color"
            value={other}
            disabled={disabled}
            className="mt-1 block h-11 w-full cursor-pointer rounded border"
            onChange={(event) => {
              setOther(event.target.value);
              setDirect(null);
              setHexInput("");
            }}
          />
        </label>
        <label className="text-xs font-semibold">
          Two-colour blend: {blend}%
          <input
            aria-label="Two-colour blend"
            type="range"
            min={0}
            max={100}
            value={blend}
            disabled={disabled}
            className="mt-1 block h-11 w-full accent-primary"
            onChange={(event) => {
              setBlend(Number(event.target.value));
              setDirect(null);
              setHexInput("");
            }}
          />
        </label>
      </div>
      <label className="block text-xs font-semibold">
        Optional HEX
        <input
          aria-label="Custom HEX colour"
          type="text"
          inputMode="text"
          maxLength={7}
          placeholder="#3a7bd5"
          value={hexInput}
          disabled={disabled}
          onChange={(event) => setHexInput(event.target.value)}
          className="mt-1 block min-h-11 w-full rounded-lg border bg-background px-3 font-mono text-sm"
        />
      </label>
      {badHex && (
        <p role="alert" className="text-sm text-destructive">
          Use #RGB or #RRGGBB.
        </p>
      )}
      <div className="flex items-center gap-3 rounded-lg border bg-background p-2 text-sm">
        <span
          aria-hidden="true"
          className="h-11 w-11 shrink-0 rounded-md border"
          style={{ backgroundColor: colour }}
        />
        <span className="min-w-0 flex-1 break-all">
          Preview:{" "}
          <span
            style={
              mode === "color"
                ? { color: colour }
                : {
                    backgroundColor: colour,
                    color:
                      authorContrast("#172b36", colour) >= authorContrast("#ffffff", colour)
                        ? "#172b36"
                        : "#ffffff",
                  }
            }
          >
            Punjabi ਪੰਜਾਬੀ · हिंदी · Text
          </span>{" "}
          · {colour}
        </span>
      </div>
      {poorContrast && (
        <p role="status" className="text-xs text-amber-700 dark:text-amber-300">
          Low contrast against a typical {mode === "color" ? "light page" : "dark text"}. Please
          check both themes. Your colour is not changed.
        </p>
      )}
      <div className="flex flex-wrap gap-2">
        <button
          type="button"
          disabled={disabled || badHex}
          onClick={() => {
            onApply(mode, colour);
            updateRecent(colour);
          }}
          className="min-h-11 rounded-lg bg-primary px-4 text-sm font-semibold text-primary-foreground disabled:opacity-50"
        >
          Apply to selection
        </button>
        <button
          type="button"
          disabled={disabled}
          onClick={() => onClear(mode)}
          className="min-h-11 rounded-lg border bg-background px-3 text-sm"
        >
          Clear {mode === "color" ? "text colour" : "highlight"}
        </button>
        <button
          type="button"
          disabled={disabled}
          onClick={toggleFavourite}
          className="min-h-11 rounded-lg border bg-background px-3 text-sm"
          aria-pressed={favourites.includes(colour)}
        >
          {favourites.includes(colour) ? "★ Saved" : "☆ Favourite"}
        </button>
      </div>
      {recent.length > 0 && (
        <div className="flex flex-wrap items-center gap-1 text-xs">
          <span>Recent</span>
          {recent.map((item) => (
            <button
              key={item}
              type="button"
              title={item}
              aria-label={`Recent ${item}`}
              disabled={disabled}
              onClick={() => pick(item)}
              className="h-11 w-11 rounded-lg border"
              style={{ backgroundColor: item }}
            />
          ))}
        </div>
      )}
      {favourites.length > 0 && (
        <div className="flex flex-wrap items-center gap-1 text-xs">
          <span>Favourite</span>
          {favourites.map((item) => (
            <button
              key={item}
              type="button"
              title={item}
              aria-label={`Favourite ${item}`}
              disabled={disabled}
              onClick={() => pick(item)}
              className="h-11 w-11 rounded-lg border"
              style={{ backgroundColor: item }}
            />
          ))}
        </div>
      )}
    </section>
  );
}
