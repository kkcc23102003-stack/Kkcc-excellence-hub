import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import {
  MAX_NOTE_PRACTICE_QUESTIONS,
  parseNotePracticeQuestion,
  type NotePracticeQuestion,
} from "@/lib/note-practice";

type Anchor = Pick<NotePracticeQuestion, "afterLine" | "afterText">;
type Draft = NotePracticeQuestion & { kind: "mcq" | "self" };
function newDraft(topic: string): Draft {
  return {
    id: "",
    topic: topic.trim().slice(0, 100) || "Chapter practice",
    question: "",
    options: ["", "", "", ""],
    correctIndex: 0,
    answer: "",
    explanation: "",
    afterLine: -1,
    afterText: "",
    kind: "mcq",
  };
}
function makeId(): string {
  return typeof crypto !== "undefined" && "randomUUID" in crypto
    ? crypto.randomUUID()
    : `q${Date.now().toString(36)}${Math.random().toString(36).slice(2)}`;
}

/** Changes only the teacher's note draft; no quiz attempt or score is persisted. */
export function NotePracticeEditor({
  questions,
  topic,
  selectedAnchor,
  disabled,
  onChange,
}: {
  questions: readonly NotePracticeQuestion[];
  topic: string;
  selectedAnchor: Anchor | null;
  disabled?: boolean;
  onChange: (questions: NotePracticeQuestion[]) => boolean;
}) {
  const [draft, setDraft] = useState<Draft>(() => newDraft(topic));
  const [message, setMessage] = useState("");
  const edit = (question: NotePracticeQuestion) => {
    setDraft({
      ...question,
      options: question.options.length
        ? [...question.options, ...Array(4 - question.options.length).fill("")]
        : ["", "", "", ""],
      kind: question.options.length ? "mcq" : "self",
    });
    setMessage("Question ko badal kar Update question dabayein. Phir Save changes dabayein.");
    document.getElementById("note-practice-form")?.scrollIntoView({ block: "nearest" });
  };
  const save = () => {
    const filled = draft.options
      .map((item, index) => ({ value: item.trim(), index }))
      .filter(({ value }) => Boolean(value));
    const options = draft.kind === "mcq" ? filled.map(({ value }) => value) : [];
    const correctIndex = filled.findIndex(({ index }) => index === draft.correctIndex);
    if (draft.kind === "mcq" && options.length < 2) {
      setMessage("MCQ ke liye kam se kam 2 options likhein.");
      return;
    }
    const candidate = parseNotePracticeQuestion({
      ...draft,
      id: draft.id || makeId(),
      options,
      correctIndex: draft.kind === "mcq" ? correctIndex : null,
      answer: draft.kind === "self" ? draft.answer : "",
    });
    if (!candidate) {
      setMessage(
        "Question, topic, answer/options aur placement check karein. Limit: question, option, answer and explanation up to 500,000 characters each (whole note cap 1,500,000).",
      );
      return;
    }
    if (!draft.id && questions.length >= MAX_NOTE_PRACTICE_QUESTIONS) {
      setMessage(`Ek note mein maximum ${MAX_NOTE_PRACTICE_QUESTIONS} questions hain.`);
      return;
    }
    const next = draft.id
      ? questions.map((question) => (question.id === draft.id ? candidate : question))
      : [...questions, candidate];
    if (!onChange(next)) {
      setMessage("Note ki 1,500,000 character limit paar ho gayi. Content chhota karein.");
      return;
    }
    setDraft({
      ...newDraft(candidate.topic),
      afterLine: candidate.afterLine,
      afterText: candidate.afterText,
    });
    setMessage("Question note draft mein hai. Student ko dikhane ke liye Save changes dabayein.");
  };
  return (
    <section
      id="note-practice-editor"
      className="mt-3 rounded-2xl border bg-card/70 p-3"
      aria-label="Practice test inside note"
    >
      <h3 className="font-bold">Chapter / topic practice · inside this note</h3>
      <p className="mt-1 text-xs text-muted-foreground">
        Preview mein chapter/topic ki aakhri line tap karein, phir yahan “After selected line”
        dabayein. Har topic par alag sawal add kar sakte hain. Student isi note mein unlimited
        practice karega. Signed-in student ka har checked response Admin saving ON hone par private
        Storage mein save hota hai; written answer self-check hai, auto-score nahin. Question likhne
        ke baad main Save changes bhi dabayein.
      </p>
      {questions.length > 0 && (
        <ol className="mt-3 space-y-2" aria-label="Authored practice questions">
          {questions.map((item, index) => (
            <li
              key={item.id}
              className="flex flex-wrap items-center gap-2 rounded-lg border bg-background p-2 text-sm"
            >
              <span className="min-w-0 flex-1 break-words">
                <strong>
                  {index + 1}. {item.topic}
                </strong>{" "}
                · {item.question}
                <span className="block text-xs text-muted-foreground">
                  {item.afterLine < 0 ? "End of note" : `After line ${item.afterLine + 1}`}
                </span>
              </span>
              <Button
                type="button"
                size="sm"
                variant="outline"
                disabled={disabled}
                onClick={() => edit(item)}
                aria-label={`Edit practice question ${index + 1}`}
              >
                Edit
              </Button>
              <Button
                type="button"
                size="sm"
                variant="outline"
                disabled={disabled}
                onClick={() => {
                  if (onChange(questions.filter((question) => question.id !== item.id))) {
                    if (draft.id === item.id) setDraft(newDraft(topic));
                    setMessage("Question draft se hat gaya. Save changes dabayein.");
                  }
                }}
                aria-label={`Remove practice question ${index + 1}`}
              >
                Remove
              </Button>
            </li>
          ))}
        </ol>
      )}
      <div id="note-practice-form" className="mt-3 space-y-3 rounded-xl border border-dashed p-3">
        <h4 className="text-sm font-bold">{draft.id ? "Edit question" : "Add a question"}</h4>
        <div>
          <Label htmlFor="practice-topic">Chapter / topic label</Label>
          <Input
            id="practice-topic"
            className="mt-1"
            maxLength={100}
            value={draft.topic}
            onChange={(e) => setDraft({ ...draft, topic: e.target.value })}
            placeholder="e.g. Chapter 2 · Photosynthesis"
          />
        </div>
        <div className="flex flex-wrap items-center gap-2 text-xs">
          <strong>Placement:</strong>
          <span>
            {draft.afterLine < 0
              ? "End of note"
              : `After line ${draft.afterLine + 1}: ${draft.afterText.slice(0, 70)}`}
          </span>
          <Button
            type="button"
            size="sm"
            variant="outline"
            disabled={!selectedAnchor || disabled}
            onClick={() => selectedAnchor && setDraft({ ...draft, ...selectedAnchor })}
          >
            After selected preview line
          </Button>
          <Button
            type="button"
            size="sm"
            variant="outline"
            disabled={disabled}
            onClick={() => setDraft({ ...draft, afterLine: -1, afterText: "" })}
          >
            End of note
          </Button>
        </div>
        <div>
          <Label htmlFor="practice-question">Question</Label>
          <Textarea
            id="practice-question"
            className="mt-1"
            maxLength={500000}
            value={draft.question}
            onChange={(e) => setDraft({ ...draft, question: e.target.value })}
            placeholder="What happens next?"
          />
        </div>
        <div>
          <Label htmlFor="practice-kind">Question type</Label>
          <select
            id="practice-kind"
            className="mt-1 block min-h-10 w-full rounded border bg-background px-2 text-sm"
            value={draft.kind}
            onChange={(e) =>
              setDraft({
                ...draft,
                kind: e.target.value === "self" ? "self" : "mcq",
              })
            }
          >
            <option value="mcq">Multiple choice · check right / wrong</option>
            <option value="self">Short answer · reveal answer and self-check</option>
          </select>
        </div>
        {draft.kind === "mcq" ? (
          <div className="space-y-2">
            <p className="text-xs">Write 2–4 choices and select the correct one.</p>
            {draft.options.map((option, index) => (
              <div key={index} className="flex items-center gap-2">
                <input
                  type="radio"
                  name="practice-correct-option"
                  aria-label={`Option ${index + 1} is correct`}
                  checked={draft.correctIndex === index}
                  onChange={() => setDraft({ ...draft, correctIndex: index })}
                />
                <Input
                  aria-label={`Practice option ${index + 1}`}
                  maxLength={500000}
                  value={option}
                  onChange={(e) =>
                    setDraft({
                      ...draft,
                      options: draft.options.map((item, i) =>
                        i === index ? e.target.value : item,
                      ),
                    })
                  }
                  placeholder={`Option ${index + 1}`}
                />
              </div>
            ))}
          </div>
        ) : (
          <div>
            <Label htmlFor="practice-answer">Expected answer · shown after Reveal</Label>
            <Textarea
              id="practice-answer"
              maxLength={500000}
              className="mt-1"
              value={draft.answer}
              onChange={(e) => setDraft({ ...draft, answer: e.target.value })}
            />
          </div>
        )}
        <div>
          <Label htmlFor="practice-explanation">Explanation · shown after answering</Label>
          <Textarea
            id="practice-explanation"
            maxLength={500000}
            className="mt-1"
            value={draft.explanation}
            onChange={(e) => setDraft({ ...draft, explanation: e.target.value })}
            placeholder="Why is this answer correct?"
          />
        </div>
        <div className="flex flex-wrap items-center gap-2">
          <Button type="button" size="sm" disabled={disabled} onClick={save}>
            {draft.id ? "Update question" : "Add question to note"}
          </Button>
          {draft.id && (
            <Button
              type="button"
              size="sm"
              variant="outline"
              onClick={() => {
                setDraft(newDraft(topic));
                setMessage("");
              }}
            >
              Cancel edit
            </Button>
          )}
          <span role="status" className="text-xs">
            {message}
          </span>
        </div>
      </div>
    </section>
  );
}
