import { useRef, useState } from "react";
import { Volume2, VolumeX } from "lucide-react";
import { useQueryClient } from "@tanstack/react-query";
import { useServerFn } from "@tanstack/react-start";
import { Button } from "@/components/ui/button";
import { ExplanationDisplay } from "@/components/kkcc/explanation-display";
import { useAuthUser } from "@/hooks/use-auth-user";
import { useQuizFeedbackSound } from "@/hooks/use-quiz-feedback-sound";
import {
  notePracticeVersion,
  type NotePracticeGroup,
} from "@/lib/note-practice";
import { saveNotePracticeResult } from "@/lib/note-results.functions";

/** Each checked response is stored privately; self-checked writing has no fabricated score. */
export function NotePracticeQuiz({
  group,
  materialId,
  onBack,
  persistResults = true,
}: {
  group: NotePracticeGroup;
  materialId?: string | undefined;
  onBack: () => void;
  persistResults?: boolean;
}) {
  const { user } = useAuthUser();
  const sound = useQuizFeedbackSound();
  const queryClient = useQueryClient();
  const saveResult = useServerFn(saveNotePracticeResult);
  const attemptId = useRef<string | null>(null);
  const [position, setPosition] = useState(0);
  const [choice, setChoice] = useState<number | null>(null);
  const [typed, setTyped] = useState("");
  const [revealed, setRevealed] = useState(false);
  const [saveState, setSaveState] = useState<
    "idle" | "saving" | "saved" | "error"
  >("idle");
  const [saveError, setSaveError] = useState("");
  const question = group.questions[position];
  if (!question) return null;
  const persist = async () => {
    if (!persistResults) return;
    if (!user || !materialId) {
      setSaveState("error");
      setSaveError(
        !user
          ? "Sign in to save your practice."
          : "This preview has no published note ID.",
      );
      return;
    }
    if (
      (question.options.length && choice === null) ||
      (!question.options.length && !typed.trim())
    )
      return;
    attemptId.current ??= crypto.randomUUID();
    setSaveState("saving");
    setSaveError("");
    try {
      await saveResult({
        data: {
          material_id: materialId,
          attempt_id: attemptId.current,
          question_id: question.id,
          question_version: notePracticeVersion(question),
          response: question.options.length ? choice! : typed.trim(),
        },
      });
      setSaveState("saved");
      void queryClient.invalidateQueries({
        queryKey: ["student", user.id, "practice-results"],
      });
    } catch (error) {
      setSaveState("error");
      setSaveError(
        error instanceof Error
          ? error.message
          : "Practice result was not saved.",
      );
    }
  };
  const next = (index: number) => {
    attemptId.current = null;
    setPosition(index);
    setChoice(null);
    setTyped("");
    setRevealed(false);
    setSaveState("idle");
    setSaveError("");
  };
  return (
    <section
      className="space-y-4 rounded-2xl border bg-card p-4 sm:p-6"
      aria-label={`Practice ${group.topic}`}
    >
      <div className="flex flex-wrap items-center justify-between gap-2">
        <Button
          type="button"
          size="sm"
          variant="outline"
          onClick={onBack}
          disabled={saveState === "saving"}
        >
          ← Back to note
        </Button>
        <Button
          type="button"
          size="sm"
          variant="outline"
          aria-label={
            sound.enabled
              ? "Practice sound on; mute"
              : "Practice sound off; unmute"
          }
          aria-pressed={sound.enabled}
          onClick={sound.toggle}
        >
          {sound.enabled ? (
            <Volume2 aria-hidden="true" />
          ) : (
            <VolumeX aria-hidden="true" />
          )}
          Sound {sound.enabled ? "on" : "off"}
        </Button>
      </div>
      <div>
        <h2 className="text-lg font-bold">
          <span className="text-study-teal">Practice</span> · {group.topic}
        </h2>
        <p className="mt-1 text-xs text-muted-foreground">
          {position + 1} of {group.questions.length} ·{" "}
          {persistResults
            ? "Sign in to save each checked response privately when Admin saving is ON."
            : "Batch practice is not saved."}{" "}
          Retry as many times as you like.
        </p>
      </div>
      <div>
        <span className="inline-flex rounded-full bg-study-gold/10 px-2.5 py-1 text-[11px] font-bold text-study-gold">
          Question {position + 1}
        </span>
        <p className="mt-2 whitespace-pre-wrap text-base font-semibold text-study-question">
          {question.question}
        </p>
      </div>
      {question.options.length ? (
        <fieldset className="space-y-2" disabled={revealed}>
          <legend className="sr-only">Choose one answer</legend>
          {question.options.map((option, index) => (
            <label
              key={index}
              className="flex min-h-11 cursor-pointer items-center gap-3 rounded-lg border border-primary/25 bg-secondary/65 p-3 text-sm hover:border-primary/60 hover:bg-secondary-hover focus-within:ring-2 focus-within:ring-ring"
            >
              <input
                type="radio"
                name={`practice-${question.id}`}
                checked={choice === index}
                onChange={() => setChoice(index)}
              />
              <span className="text-study-answer">{option}</span>
            </label>
          ))}
        </fieldset>
      ) : (
        <div>
          <label
            htmlFor={`practice-response-${question.id}`}
            className="text-sm font-medium"
          >
            {persistResults
              ? "Your answer · private save after Reveal when signed in"
              : "Your answer · Batch practice is not saved"}
          </label>
          <textarea
            id={`practice-response-${question.id}`}
            maxLength={1000}
            className="mt-1 block min-h-20 w-full rounded-lg border bg-background p-3 text-sm text-study-question placeholder:text-muted-foreground"
            value={typed}
            onChange={(event) => setTyped(event.target.value)}
            disabled={revealed}
            placeholder="Think it through, then reveal the answer"
          />
        </div>
      )}
      {!revealed ? (
        <Button
          type="button"
          disabled={question.options.length ? choice === null : !typed.trim()}
          onClick={() => {
            if (question.options.length && choice !== null) {
              sound.play(
                choice === question.correctIndex ? "correct" : "wrong",
              );
            }
            // Written responses are self-checked: don't pretend to grade them.
            setRevealed(true);
            void persist();
          }}
        >
          {question.options.length ? "Check answer" : "Reveal answer"}
        </Button>
      ) : (
        <div
          role="status"
          className="space-y-2 rounded-xl border bg-muted/40 p-3 text-sm"
        >
          {question.options.length ? (
            <p className="font-bold text-foreground">
              <span
                className={
                  choice === question.correctIndex
                    ? "text-study-teal"
                    : "text-destructive"
                }
              >
                {choice === question.correctIndex
                  ? "Correct!"
                  : "Not quite. Try again or review the explanation."}
              </span>{" "}
              <span className="text-study-blue">Correct answer:</span>{" "}
              <span className="text-study-answer">
                {question.options[question.correctIndex!]}
              </span>
            </p>
          ) : (
            <p className="whitespace-pre-wrap">
              <strong className="text-study-blue">Expected answer: </strong>
              <span className="text-study-answer">{question.answer}</span>
            </p>
          )}
          {question.explanation && (
            <ExplanationDisplay text={question.explanation} compact />
          )}
        </div>
      )}
      {revealed && saveState === "saving" && (
        <p role="status" className="text-xs text-primary">
          Saving practice privately…
        </p>
      )}
      {revealed && saveState === "saved" && (
        <p role="status" className="text-xs font-semibold text-primary">
          Practice saved in private Storage · Review it in Tests &amp; results.
        </p>
      )}
      {revealed && saveState === "error" && (
        <div role="alert" className="text-xs text-destructive">
          <p>Practice not saved: {saveError}</p>
          {user && materialId && (
            <Button
              type="button"
              size="sm"
              variant="outline"
              className="mt-2"
              onClick={() => void persist()}
            >
              Retry saving this practice
            </Button>
          )}
        </div>
      )}
      <div className="flex flex-wrap gap-2">
        {revealed && (
          <Button
            type="button"
            variant="outline"
            disabled={saveState === "saving"}
            onClick={() => next(position)}
          >
            Try this question again
          </Button>
        )}
        {revealed && position + 1 < group.questions.length && (
          <Button
            type="button"
            disabled={saveState === "saving"}
            onClick={() => next(position + 1)}
          >
            Next question
          </Button>
        )}
        {revealed && position + 1 === group.questions.length && (
          <Button
            type="button"
            variant="outline"
            disabled={saveState === "saving"}
            onClick={() => next(0)}
          >
            Restart this practice
          </Button>
        )}
      </div>
    </section>
  );
}
