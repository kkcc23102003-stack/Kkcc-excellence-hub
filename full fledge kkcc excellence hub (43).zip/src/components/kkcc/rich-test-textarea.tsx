import { useLayoutEffect, useRef, useState } from "react";
import type { ComponentProps } from "react";
import { Textarea } from "@/components/ui/textarea";
import { AuthorKeyboardStrip } from "./author-keyboard-strip";
import { StyledAuthorText } from "./styled-author-text";
import { clearAuthorColour, wrapAuthorSelection } from "@/lib/author-colours";
import { formatNoteSelection } from "@/lib/notes-office";
import { parseAuthorRuns, serializeAuthorRuns } from "@/lib/author-inline";
import { VisualInlineEditor } from "./visual-inline-editor";

type Props = Omit<ComponentProps<"textarea">, "value" | "onChange" | "ref"> & {
  value: string;
  onValueChange: (text: string) => void;
};

/** Portable bracket markup is kept in the original string; no SQL/schema migration needed. */
function RichTestSourceTextarea({
  value,
  onValueChange,
  maxLength,
  disabled,
  readOnly,
  ...props
}: Props) {
  const ref = useRef<HTMLTextAreaElement>(null);
  const range = useRef({ start: 0, end: 0 });
  const pending = useRef<number | null>(null);
  const [focused, setFocused] = useState(false);
  const [composing, setComposing] = useState(false);
  useLayoutEffect(() => {
    if (pending.current === null || !ref.current) return;
    ref.current.focus({ preventScroll: true });
    ref.current.setSelectionRange(pending.current, pending.current);
    pending.current = null;
  }, [value]);
  const remember = () => {
    if (ref.current)
      range.current = { start: ref.current.selectionStart, end: ref.current.selectionEnd };
  };
  const replace = (text: string) => {
    if (disabled || readOnly || composing) return;
    const { start, end } = range.current;
    const next = value.slice(0, start) + text + value.slice(end);
    if (typeof maxLength === "number" && next.length > maxLength) return;
    pending.current = start + text.length;
    onValueChange(next);
  };
  const selected = () => value.slice(range.current.start, range.current.end);
  return (
    <div className="min-w-0 space-y-1" data-testid="rich-test-textarea">
      <AuthorKeyboardStrip
        label="Test writing tools above the keyboard"
        active={focused}
        disabled={disabled || readOnly || composing}
        bold={() => replace(formatNoteSelection(selected(), "b"))}
        italic={() => replace(formatNoteSelection(selected(), "i"))}
        underline={() => replace(formatNoteSelection(selected(), "u"))}
        apply={(kind, colour) => replace(wrapAuthorSelection(selected(), kind, colour))}
        clear={(kind) => replace(clearAuthorColour(selected(), kind))}
      />
      <Textarea
        {...props}
        ref={ref}
        value={value}
        maxLength={maxLength}
        disabled={disabled}
        readOnly={readOnly}
        dir="auto"
        onChange={(event) => onValueChange(event.target.value)}
        onSelect={(event) => {
          remember();
          props.onSelect?.(event);
        }}
        onClick={(event) => {
          remember();
          props.onClick?.(event);
        }}
        onKeyUp={(event) => {
          remember();
          props.onKeyUp?.(event);
        }}
        onFocus={(event) => {
          setFocused(true);
          props.onFocus?.(event);
        }}
        onBlur={(event) => {
          remember();
          setFocused(false);
          props.onBlur?.(event);
        }}
        onKeyDown={(event) => {
          props.onKeyDown?.(event);
          if (composing || event.nativeEvent.isComposing || disabled || readOnly) return;
          if (
            (event.ctrlKey || event.metaKey) &&
            !event.altKey &&
            ["b", "i", "u"].includes(event.key.toLowerCase())
          ) {
            event.preventDefault();
            remember();
            replace(formatNoteSelection(selected(), event.key.toLowerCase()));
          }
        }}
        onCompositionStart={(event) => {
          setComposing(true);
          props.onCompositionStart?.(event);
        }}
        onCompositionEnd={(event) => {
          setComposing(false);
          remember();
          props.onCompositionEnd?.(event);
        }}
      />
      <details className="text-xs text-muted-foreground">
        <summary className="min-h-7 cursor-pointer">
          Preview formatted text · Punjabi / Hindi supported
        </summary>
        <p className="mt-1 rounded-lg border bg-card p-2 text-sm text-card-foreground">
          <StyledAuthorText text={value || "Your question will appear here."} />
        </p>
      </details>
    </div>
  );
}

/** Visual text is the default; the original raw editor is still available for advanced markup. */
export function RichTestTextarea(props: Props) {
  const [source, setSource] = useState(false);
  return (
    <div className="min-w-0 space-y-1">
      <button
        type="button"
        className="min-h-9 text-xs text-primary underline underline-offset-2"
        onClick={() => setSource(!source)}
      >
        {source ? "Return to visual formatting" : "Edit formatting source (advanced)"}
      </button>
      {source ? (
        <RichTestSourceTextarea {...props} />
      ) : (
        <VisualInlineEditor
          runs={parseAuthorRuns(props.value)}
          onChange={(runs) => props.onValueChange(serializeAuthorRuns(runs))}
          label={props["aria-label"] ?? "Test text"}
          toolbarLabel="Test writing tools above the keyboard"
          className={props.className}
          placeholder={props.placeholder}
          rows={props.rows}
          maxLength={props.maxLength}
          disabled={props.disabled}
          readOnly={props.readOnly}
        />
      )}
    </div>
  );
}
