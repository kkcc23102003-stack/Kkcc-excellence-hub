import { useState } from "react";
import { cn } from "@/lib/utils";
import type { Course } from "@/lib/cms";
import { LogoMark } from "./logo";
import { SubjectMark } from "./subject-mark";
import { useBranding } from "./branding-provider";
import { thumbnailImageUrl } from "@/lib/thumbnail";

export function CourseThumb({
  course,
  className,
}: {
  course: Course;
  className?: string;
}) {
  const [failed, setFailed] = useState<string | null>(null);
  const branding = useBranding();
  const imageUrl = thumbnailImageUrl(course.thumbnail_url);
  if (imageUrl && imageUrl !== failed)
    return (
      <div
        className={cn(
          "learning-cover relative w-full overflow-hidden",
          className,
        )}
      >
        <img
          src={imageUrl}
          alt={course.title}
          loading="lazy"
          decoding="async"
          width={960}
          height={640}
          sizes="(min-width:1024px) 33vw, (min-width:640px) 50vw, 100vw"
          className="h-full w-full object-cover"
          onError={() => setFailed(imageUrl)}
        />
      </div>
    );
  return (
    <div
      aria-hidden="true"
      className={cn("learning-cover course-brand-cover", className)}
    >
      <div className="flex items-center gap-2 text-[10px] font-bold tracking-wide">
        <LogoMark className="h-7 w-7 rounded-md shadow-none" />
        <span>{branding.short_name || "KKCC"}</span>
        <span className="ml-auto max-w-[45%] truncate text-[10px] font-medium text-muted-foreground">
          {course.category}
        </span>
      </div>
      <div className="relative mt-auto flex items-end justify-between gap-3 pt-3">
        <div className="min-w-0">
          <p className="line-clamp-2 text-lg font-bold leading-snug">
            {course.subject || course.title}
          </p>
          <p className="mt-1 text-xs text-muted-foreground">
            {course.class_level}
          </p>
        </div>
        <SubjectMark
          subject={course.subject || course.title}
          className="h-14 w-14"
        />
      </div>
    </div>
  );
}
