import { cn } from "@/lib/utils";

type QuestionPromptProps = {
  text: string;
  sources?: readonly string[] | undefined;
  className?: string | undefined;
};

function separatePyq(text: string): { prompt: string; pyq: string } {
  const match = text.match(
    /\s*(?:\[\s*)?\bPYQ\s*[:：]?\s*(?:\[\s*([^\]]+?)\s*\]|([^\n]+))\s*\]?\s*$/i,
  );
  if (!match || match.index === undefined)
    return { prompt: text.trim(), pyq: "" };
  const pyq = (match[1] ?? match[2] ?? "").replace(/^\[|\]$/g, "").trim();
  const prompt = text
    .slice(0, match.index)
    .replace(/[\s,;:–—-]+$/u, "")
    .trim();
  return prompt && pyq ? { prompt, pyq } : { prompt: text.trim(), pyq: "" };
}

export function QuestionPrompt({
  text,
  sources,
  className,
}: QuestionPromptProps) {
  const { prompt, pyq: embeddedPyq } = separatePyq(text);
  const visibleSources = (sources ?? [])
    .map((source) => source.trim())
    .filter(Boolean);
  const sourceText =
    embeddedPyq ||
    (visibleSources.length
      ? `${visibleSources.slice(0, 6).join(" · ")}${visibleSources.length > 6 ? ` · +${visibleSources.length - 6} more` : ""}`
      : "");

  return (
    <h3
      className={cn(
        "grid min-w-0 items-start gap-2 rounded-xl border-l-4 border-study-blue bg-study-blue/10 px-3 py-3 sm:gap-4 sm:px-4",
        sourceText
          ? "grid-cols-[minmax(0,1fr)_minmax(6.5rem,0.42fr)]"
          : "grid-cols-1",
        className,
      )}
    >
      <span className="quiz-question-text min-w-0 whitespace-pre-wrap break-words text-lg font-semibold leading-relaxed sm:text-xl">
        {prompt}
      </span>
      {sourceText && (
        <span
          role="note"
          aria-label="PYQ references"
          className="min-w-0 rounded-xl border border-accent/35 bg-accent/10 px-3 py-2.5 sm:justify-self-end"
        >
          <span className="block text-[10px] font-bold uppercase tracking-[0.14em] text-accent-foreground">
            PYQ
          </span>
          <span className="mt-1 block break-words text-xs font-normal leading-relaxed text-foreground">
            {sourceText}
          </span>
        </span>
      )}
    </h3>
  );
}
