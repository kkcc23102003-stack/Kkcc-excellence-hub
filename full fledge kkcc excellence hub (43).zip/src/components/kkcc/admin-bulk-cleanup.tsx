import { useMemo, useState } from "react";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { useServerFn } from "@tanstack/react-start";
import { Archive, CheckCircle2, Loader2, Search, ShieldAlert } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import {
  AlertDialog,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import {
  adminApplyBulkCleanup,
  adminListBulkCleanupInventory,
  adminReviewBulkCleanup,
} from "@/lib/admin.functions";
import type { BulkCleanupKind, BulkCleanupSelection } from "@/lib/admin-bulk-cleanup.server";
import { friendlyError } from "@/lib/storage";

type Candidate = {
  id: string;
  kind: BulkCleanupKind;
  title: string;
  status: string;
  eligible: boolean;
};
const emptySelection = (): BulkCleanupSelection => ({
  courseIds: [],
  noteIds: [],
  testIds: [],
  seriesIds: [],
});
const selectionKey: Record<BulkCleanupKind, keyof BulkCleanupSelection> = {
  course: "courseIds",
  note: "noteIds",
  test: "testIds",
  series: "seriesIds",
};
const selectedCount = (selection: BulkCleanupSelection) =>
  Object.values(selection).reduce((sum, ids) => sum + ids.length, 0);

/** Intentionally separate from the quick daily workflow: nothing is selected by default. */
export function AdminBulkCleanup() {
  const [open, setOpen] = useState(false);
  const [search, setSearch] = useState("");
  const [kind, setKind] = useState<BulkCleanupKind | "all">("all");
  const [selected, setSelected] = useState<BulkCleanupSelection>(emptySelection);
  const [review, setReview] = useState<
    Awaited<ReturnType<typeof adminReviewBulkCleanup>> | undefined
  >();
  const [dialogOpen, setDialogOpen] = useState(false);
  const [confirmation, setConfirmation] = useState("");
  const [feedback, setFeedback] = useState("");
  const qc = useQueryClient();
  const list = useServerFn(adminListBulkCleanupInventory);
  const preview = useServerFn(adminReviewBulkCleanup);
  const apply = useServerFn(adminApplyBulkCleanup);
  const inventory = useQuery({
    queryKey: ["admin", "bulk-cleanup-inventory"],
    queryFn: () => list(),
    enabled: open,
    retry: false,
    staleTime: 0,
  });
  const candidates = useMemo<Candidate[]>(() => {
    if (!inventory.data) return [];
    return [
      ...inventory.data.series.map((row) => ({
        id: row.id,
        kind: "series" as const,
        title: row.title,
        status: `${row.source} · visible`,
        eligible: true,
      })),
      ...inventory.data.notes.map((row) => ({
        id: row.id,
        kind: "note" as const,
        title: row.title,
        status: row.isPublished ? "published" : "draft",
        eligible: !row.isPublished,
      })),
      ...inventory.data.tests.map((row) => ({
        id: row.id,
        kind: "test" as const,
        title: row.title,
        status: row.isPublished ? "published" : "draft",
        eligible: !row.isPublished,
      })),
      ...inventory.data.courses.map((row) => ({
        id: row.id,
        kind: "course" as const,
        title: row.title,
        status: row.status,
        eligible: row.status === "draft",
      })),
    ];
  }, [inventory.data]);
  const matches = candidates.filter(
    (row) =>
      (kind === "all" || row.kind === kind) &&
      `${row.title} ${row.id}`.toLocaleLowerCase().includes(search.trim().toLocaleLowerCase()),
  );
  const displayed = matches.slice(0, 80);
  const count = selectedCount(selected);
  const reviewing = useMutation({
    mutationFn: () => preview({ data: selected }),
    onSuccess: (result) => {
      setReview(result);
      setFeedback("");
    },
    onError: (error: Error) => setFeedback(friendlyError(error)),
  });
  const applying = useMutation({
    mutationFn: () => apply({ data: { selection: selected, confirmation: "CLEAN SELECTED" } }),
    onSuccess: (result) => {
      setDialogOpen(false);
      setConfirmation("");
      setReview(undefined);
      setSelected(emptySelection());
      setFeedback(
        result.ok
          ? `${result.completed.length} reviewed item${result.completed.length === 1 ? "" : "s"} updated. Refresh the list to verify.`
          : (result.error ?? "Cleanup stopped. Refresh the inventory and review again."),
      );
      for (const key of [
        ["admin", "bulk-cleanup-inventory"],
        ["admin", "courses"],
        ["admin", "materials"],
        ["admin", "tests"],
        ["admin", "daily-queue"],
        ["admin", "custom-series-catalog"],
        ["public", "custom-series-catalog"],
      ])
        void qc.invalidateQueries({ queryKey: key });
    },
    onError: (error: Error) => {
      setDialogOpen(false);
      setReview(undefined);
      setFeedback(`Could not finish: ${friendlyError(error)}. Refresh and review before retrying.`);
      void qc.invalidateQueries({ queryKey: ["admin", "bulk-cleanup-inventory"] });
    },
  });
  const busy = reviewing.isPending || applying.isPending;

  const changeSelection = (next: BulkCleanupSelection) => {
    setSelected(next);
    setReview(undefined);
    setConfirmation("");
    setFeedback("");
  };
  const toggle = (row: Candidate) => {
    const key = selectionKey[row.kind];
    const exists = selected[key].includes(row.id);
    if (!exists && count >= 100) {
      setFeedback("Review up to 100 items per batch. Finish this batch before selecting more.");
      return;
    }
    changeSelection({
      ...selected,
      [key]: exists ? selected[key].filter((id) => id !== row.id) : [...selected[key], row.id],
    });
  };
  const selectMatches = () => {
    const next = { ...selected };
    let total = count;
    for (const row of matches) {
      const key = selectionKey[row.kind];
      if (!row.eligible || next[key].includes(row.id)) continue;
      if (total >= 100) break;
      next[key] = [...next[key], row.id];
      total += 1;
    }
    changeSelection(next);
  };

  return (
    <section aria-label="Bulk content cleanup" className="surface-panel mt-6 p-4 sm:p-5">
      <div className="flex flex-wrap items-start justify-between gap-3">
        <div className="min-w-0 flex-1">
          <h2 className="flex items-center gap-2 text-lg font-bold">
            <Archive className="h-5 w-5 text-primary" /> Clean up old content in batches
          </h2>
          <p className="mt-1 max-w-2xl text-sm text-muted-foreground">
            Search for sample notes or old tests, select exact records, and check the preview.
            Unused test series are hidden together; only unpublished, unlinked drafts can be
            deleted. Students, grants, purchases and results are never selected for deletion.
          </p>
        </div>
        <Button
          type="button"
          size="sm"
          variant="outline"
          aria-expanded={open}
          aria-controls="bulk-cleanup-panel"
          onClick={() => setOpen((value) => !value)}
        >
          {open ? "Close cleanup" : "Review old content"}
        </Button>
      </div>
      {open && (
        <div id="bulk-cleanup-panel" className="mt-5 space-y-4 border-t border-border/75 pt-4">
          <p className="flex items-start gap-2 rounded-lg border border-amber-500/30 bg-amber-500/[0.07] p-3 text-xs leading-relaxed">
            <ShieldAlert className="mt-0.5 h-4 w-4 shrink-0 text-amber-600" />
            Published items and anything linked to a learner stay untouched. Unpublish a verified
            unused item in its editor first. A linked note must also be removed from its
            notes-series outline. Keep a backup: these application checks cannot replace an atomic
            live database audit, and draft deletion is permanent.
          </p>
          <div className="flex flex-col gap-2 sm:flex-row">
            <div className="relative flex-1">
              <Search
                aria-hidden="true"
                className="absolute left-3 top-3 h-4 w-4 text-muted-foreground"
              />
              <Input
                aria-label="Search cleanup titles"
                placeholder="Search titles or IDs (e.g. sample)"
                value={search}
                onChange={(event) => setSearch(event.target.value)}
                className="pl-9"
              />
            </div>
            <select
              aria-label="Filter cleanup type"
              className="h-10 rounded-md border border-input bg-background px-3 text-sm"
              value={kind}
              onChange={(event) => setKind(event.target.value as BulkCleanupKind | "all")}
            >
              <option value="all">All content</option>
              <option value="series">Test series</option>
              <option value="note">Notes</option>
              <option value="test">Tests</option>
              <option value="course">Courses</option>
            </select>
          </div>
          {inventory.isPending && <p className="text-sm">Loading cleanup inventory…</p>}
          {inventory.isError && (
            <p role="alert" className="text-sm text-destructive">
              Inventory unavailable: {friendlyError(inventory.error)}. No action is possible.
            </p>
          )}
          {inventory.data && (
            <>
              <div className="flex flex-wrap items-center justify-between gap-2 text-xs text-muted-foreground">
                <span>
                  {matches.length} matches · {count} selected · showing up to 80 matches and the
                  newest 1,000 per content type. Search to narrow the list.
                </span>
                <div className="flex gap-2">
                  <Button
                    type="button"
                    size="sm"
                    variant="outline"
                    onClick={selectMatches}
                    disabled={busy || !matches.some((row) => row.eligible)}
                  >
                    Select up to 100 eligible matches
                  </Button>
                  <Button
                    type="button"
                    size="sm"
                    variant="ghost"
                    onClick={() => changeSelection(emptySelection())}
                    disabled={busy || count === 0}
                  >
                    Clear selection
                  </Button>
                </div>
              </div>
              <div
                className="max-h-80 space-y-1 overflow-auto rounded-lg border border-border/75 p-2"
                aria-label="Cleanup candidates"
              >
                {displayed.length === 0 && (
                  <p className="p-3 text-sm text-muted-foreground">
                    No matches. Nothing is selected automatically.
                  </p>
                )}
                {displayed.map((row) => (
                  <label
                    key={`${row.kind}:${row.id}`}
                    className="flex min-h-11 cursor-pointer items-start gap-3 rounded-md px-2 py-2 text-sm hover:bg-muted/65"
                  >
                    <input
                      type="checkbox"
                      checked={selected[selectionKey[row.kind]].includes(row.id)}
                      onChange={() => toggle(row)}
                      disabled={busy}
                      className="mt-1 accent-primary"
                      aria-label={`Select ${row.kind}: ${row.title}`}
                    />
                    <span className="min-w-0 flex-1">
                      <span className="block break-words font-medium">{row.title}</span>
                      <span className="block break-all font-mono text-[10px] text-muted-foreground">
                        {row.id}
                      </span>
                    </span>
                    <Badge
                      variant={row.eligible ? "secondary" : "outline"}
                      className="shrink-0 text-[10px]"
                    >
                      {row.kind} · {row.status}
                    </Badge>
                  </label>
                ))}
              </div>
              <Button
                type="button"
                onClick={() => reviewing.mutate()}
                disabled={busy || count === 0}
              >
                {reviewing.isPending && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
                Preview {count} selected {count === 1 ? "item" : "items"}
              </Button>
            </>
          )}
          {feedback && (
            <p role="status" className="rounded-lg border border-border/70 p-3 text-sm">
              {feedback}
            </p>
          )}
          {review && (
            <div
              className="space-y-3 rounded-xl border border-primary/25 bg-primary/[0.04] p-4"
              aria-label="Cleanup review"
            >
              <h3 className="font-semibold">
                {review.canApply ? "Ready to apply" : "Blocked — no changes allowed"} ·{" "}
                {review.items.filter((item) => item.ready).length} ready,{" "}
                {review.items.filter((item) => !item.ready).length} blocked
              </h3>
              <ul className="max-h-64 space-y-2 overflow-auto text-sm">
                {review.items.map((item) => (
                  <li
                    key={`${item.kind}:${item.id}`}
                    className="rounded-lg border border-border/65 bg-background p-2"
                  >
                    <div className="flex items-center gap-2 font-medium">
                      {item.ready ? (
                        <CheckCircle2 className="h-4 w-4 shrink-0 text-primary" />
                      ) : (
                        <ShieldAlert className="h-4 w-4 shrink-0 text-amber-600" />
                      )}
                      <span className="break-words">
                        {item.title} · {item.action}
                      </span>
                    </div>
                    <span className="ml-6 block break-all font-mono text-[10px] text-muted-foreground">
                      {item.id}
                    </span>
                    {!item.ready && (
                      <p className="ml-6 text-xs text-amber-700 dark:text-amber-300">
                        {item.reason}
                      </p>
                    )}
                  </li>
                ))}
              </ul>
              <p className="text-xs text-muted-foreground">
                Checks are repeated when you apply. If a later item changes, the batch stops and
                reports any earlier completed items. There is no student-data purge or automatic
                removal of published sample notes.
              </p>
              <Button
                type="button"
                disabled={!review.canApply || busy}
                onClick={() => setDialogOpen(true)}
              >
                Continue to final confirmation
              </Button>
            </div>
          )}
        </div>
      )}
      <AlertDialog
        open={dialogOpen}
        onOpenChange={(value) => !applying.isPending && setDialogOpen(value)}
      >
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Apply reviewed cleanup?</AlertDialogTitle>
            <AlertDialogDescription>
              Hide selected unused series (reversible) and permanently delete selected unused
              drafts. This does not remove published content, linked items, student accounts or
              results. Type CLEAN SELECTED to confirm {review?.items.length ?? 0} exact items.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <Input
            aria-label="Type CLEAN SELECTED to confirm"
            autoComplete="off"
            value={confirmation}
            onChange={(event) => setConfirmation(event.target.value)}
            placeholder="CLEAN SELECTED"
          />
          <AlertDialogFooter>
            <AlertDialogCancel disabled={applying.isPending}>Cancel</AlertDialogCancel>
            <Button
              type="button"
              disabled={
                confirmation !== "CLEAN SELECTED" || !review?.canApply || applying.isPending
              }
              onClick={() => applying.mutate()}
            >
              {applying.isPending ? "Rechecking…" : "Apply selected changes"}
            </Button>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </section>
  );
}
