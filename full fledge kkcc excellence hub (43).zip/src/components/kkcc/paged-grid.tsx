import { useRef, useState, type ReactNode } from "react";
import { Button } from "@/components/ui/button";

/** Bounded DOM, not a data cap: every matching item remains reachable. */
export function PagedGrid<T>({
  items,
  children,
  className,
  label = "Results",
  pageSize = 24,
  initialPage = 0,
}: {
  items: readonly T[];
  children: (item: T, index: number) => ReactNode;
  className?: string;
  label?: string;
  pageSize?: number;
  initialPage?: number;
}) {
  const [selection, setSelection] = useState({ items, page: initialPage });
  const region = useRef<HTMLDivElement>(null);
  const size = Math.max(1, pageSize);
  const pages = Math.max(1, Math.ceil(items.length / size));
  const page = selection.items === items ? Math.min(selection.page, pages - 1) : 0;
  const start = page * size;
  const changePage = (next: number) => {
    setSelection({ items, page: Math.max(0, Math.min(next, pages - 1)) });
    region.current?.focus({ preventScroll: true });
    region.current?.scrollIntoView({ block: "start", behavior: "instant" });
  };
  return (
    <div
      ref={region}
      tabIndex={-1}
      role="region"
      aria-label={label}
      className="min-w-0 scroll-mt-36 focus:outline-none"
    >
      <div className={className}>
        {items.slice(start, start + size).map((item, index) => children(item, start + index))}
      </div>
      {pages > 1 && (
        <nav
          aria-label={`${label} pages`}
          className="mt-5 flex flex-wrap items-center justify-between gap-3"
        >
          <p role="status" className="text-xs text-muted-foreground">
            {start + 1}–{Math.min(start + size, items.length)} of {items.length} · Page {page + 1}{" "}
            of {pages}
          </p>
          <div className="flex gap-2">
            <Button variant="outline" disabled={page === 0} onClick={() => changePage(page - 1)}>
              Previous page
            </Button>
            <Button
              variant="outline"
              disabled={page === pages - 1}
              onClick={() => changePage(page + 1)}
            >
              Next page
            </Button>
          </div>
        </nav>
      )}
    </div>
  );
}
