import { useState } from "react";
import { useServerFn } from "@tanstack/react-start";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import {
  BookOpenText,
  CalendarClock,
  Eye,
  EyeOff,
  Loader2,
  Search,
  ShieldCheck,
  XCircle,
} from "lucide-react";
import { toast } from "sonner";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import {
  adminGrantNotesAccess,
  adminListNotesAccess,
  adminRevokeNotesAccess,
  adminSetNotesSeriesHistoryVisibility,
} from "@/lib/admin-notes-access.functions";
import { friendlyError } from "@/lib/storage";

type GrantKind = "note" | "series";
type RevokeKind = GrantKind | "purchase";

function formatDate(value: string | null) {
  if (!value) return "Lifetime";
  return new Date(value).toLocaleString("en-IN", {
    day: "2-digit",
    month: "short",
    year: "numeric",
    hour: "2-digit",
    minute: "2-digit",
  });
}

export function AdminNotesAccessPanel() {
  const qc = useQueryClient();
  const list = useServerFn(adminListNotesAccess);
  const grant = useServerFn(adminGrantNotesAccess);
  const revoke = useServerFn(adminRevokeNotesAccess);
  const [kind, setKind] = useState<GrantKind>("note");
  const [itemId, setItemId] = useState("");
  const [email, setEmail] = useState("");
  const [expiresAt, setExpiresAt] = useState("");
  const [note, setNote] = useState("");
  const [query, setQuery] = useState("");
  const [showRemovedSeriesGrants, setShowRemovedSeriesGrants] = useState(false);

  const accessQuery = useQuery({
    queryKey: ["admin", "notes-access", query],
    queryFn: () => list({ data: { query } }),
    retry: false,
  });
  const catalog = accessQuery.data;
  const options = kind === "note" ? (catalog?.materials ?? []) : (catalog?.series ?? []);

  const grantMutation = useMutation({
    mutationFn: () =>
      grant({
        data: {
          email: email.trim(),
          kind,
          item_id: itemId,
          expires_at: expiresAt ? new Date(expiresAt).toISOString() : null,
          note: note.trim(),
        },
      }),
    onSuccess: (result) => {
      void qc.invalidateQueries({ queryKey: ["admin", "notes-access"] });
      void qc.invalidateQueries({ queryKey: ["student", "learning-validity"] });
      void qc.invalidateQueries({ queryKey: ["learning-access"] });
      toast.success(
        result.already_active
          ? `${result.title} is already active for ${result.email}; existing validity was preserved.`
          : `${result.title} access granted to ${result.email}.`,
      );
      setEmail("");
      setExpiresAt("");
      setNote("");
    },
    onError: (error: Error) => toast.error(friendlyError(error)),
  });

  const revokeMutation = useMutation({
    mutationFn: (input: { id: string; kind: RevokeKind }) => revoke({ data: input }),
    onSuccess: () => {
      void qc.invalidateQueries({ queryKey: ["admin", "notes-access"] });
      void qc.invalidateQueries({ queryKey: ["student", "learning-validity"] });
      void qc.invalidateQueries({ queryKey: ["learning-access"] });
      toast.success("Notes access revoked");
    },
    onError: (error: Error) => toast.error(friendlyError(error)),
  });
  const historyVisibility = useServerFn(adminSetNotesSeriesHistoryVisibility);
  const historyVisibilityMutation = useMutation({
    mutationFn: (input: { id: string; hidden: boolean }) => historyVisibility({ data: input }),
    onSuccess: (result) => {
      void qc.invalidateQueries({ queryKey: ["admin", "notes-access"] });
      toast.success(
        result.hidden
          ? "Notes Series card removed from this list; student access is unchanged."
          : "Notes Series card restored; student access is unchanged.",
      );
    },
    onError: (error: Error) => toast.error(friendlyError(error)),
  });
  const displayedGrants = (catalog?.grants ?? []).filter(
    (entry) => showRemovedSeriesGrants || !entry.admin_hidden_at,
  );
  const removedSeriesGrantCount = (catalog?.grants ?? []).filter(
    (entry) => entry.kind === "series" && entry.admin_hidden_at,
  ).length;

  return (
    <section
      className="surface-panel mb-6 space-y-5 p-5 sm:p-6"
      aria-labelledby="notes-access-title"
    >
      <div className="flex flex-wrap items-start justify-between gap-3">
        <div className="flex items-start gap-3">
          <div className="rounded-2xl bg-primary/10 p-3 text-primary">
            <BookOpenText className="h-6 w-6" />
          </div>
          <div>
            <h2 id="notes-access-title" className="text-lg font-bold">
              Manual Notes Access
            </h2>
            <p className="mt-1 max-w-2xl text-sm text-muted-foreground">
              Unlock one published paid note or a complete paid Notes Series for a student by email.
              Leave expiry blank for lifetime access; a later grant never shortens an existing
              entitlement.
            </p>
          </div>
        </div>
        <Badge variant="outline" className="rounded-full">
          <ShieldCheck className="mr-1 h-3.5 w-3.5" /> Admin only
        </Badge>
      </div>

      <div className="grid gap-5 xl:grid-cols-[0.8fr_1.2fr]">
        <form
          className="space-y-4 rounded-2xl border bg-background/60 p-4"
          onSubmit={(event) => {
            event.preventDefault();
            grantMutation.mutate();
          }}
        >
          <div className="grid gap-4 sm:grid-cols-2 xl:grid-cols-1 2xl:grid-cols-2">
            <div>
              <Label htmlFor="manual-notes-kind">Access type</Label>
              <select
                id="manual-notes-kind"
                className="mt-1.5 h-10 w-full rounded-md border border-input bg-background px-3 text-sm"
                value={kind}
                onChange={(event) => {
                  setKind(event.target.value as GrantKind);
                  setItemId("");
                }}
              >
                <option value="note">Individual note</option>
                <option value="series">Complete Notes Series</option>
              </select>
            </div>
            <div>
              <Label htmlFor="manual-notes-target">Note / Notes Series</Label>
              <select
                id="manual-notes-target"
                className="mt-1.5 h-10 w-full rounded-md border border-input bg-background px-3 text-sm"
                value={itemId}
                onChange={(event) => setItemId(event.target.value)}
                required
                disabled={accessQuery.isLoading || options.length === 0}
              >
                <option value="">Choose {kind === "note" ? "a note" : "a Notes Series"}</option>
                {options.map((item) => (
                  <option key={item.id} value={item.id}>
                    {kind === "note" && "subject" in item
                      ? `${item.title} · ${item.subject}${item.chapter ? ` / ${item.chapter}` : ""}`
                      : "name" in item
                        ? item.name
                        : item.title}
                  </option>
                ))}
              </select>
              {accessQuery.isError && (
                <p className="mt-1 text-xs text-destructive">Could not load the notes catalogue.</p>
              )}
              {!accessQuery.isLoading && !options.length && !accessQuery.isError && (
                <p className="mt-1 text-xs text-muted-foreground">
                  No published paid {kind === "note" ? "notes" : "Notes Series"} available.
                </p>
              )}
            </div>
          </div>

          <div>
            <Label htmlFor="manual-notes-student-email">Student email</Label>
            <Input
              id="manual-notes-student-email"
              className="mt-1.5"
              type="email"
              autoComplete="email"
              placeholder="student@example.com"
              value={email}
              onChange={(event) => setEmail(event.target.value)}
              required
            />
          </div>

          <div>
            <Label htmlFor="manual-notes-expiry">Valid until (optional)</Label>
            <Input
              id="manual-notes-expiry"
              className="mt-1.5"
              type="datetime-local"
              value={expiresAt}
              onChange={(event) => setExpiresAt(event.target.value)}
            />
            <p className="mt-1 text-xs text-muted-foreground">
              Blank means lifetime. Otherwise, access expires at the selected local date and time.
            </p>
          </div>

          <div>
            <Label htmlFor="manual-notes-note">Admin note (optional)</Label>
            <Textarea
              id="manual-notes-note"
              className="mt-1.5"
              rows={2}
              maxLength={500}
              value={note}
              onChange={(event) => setNote(event.target.value)}
              placeholder="Scholarship, offline payment reference, support request…"
            />
          </div>

          <Button
            type="submit"
            className="w-full rounded-full"
            disabled={grantMutation.isPending || !itemId}
          >
            {grantMutation.isPending ? (
              <Loader2 className="mr-2 h-4 w-4 animate-spin" />
            ) : (
              <BookOpenText className="mr-2 h-4 w-4" />
            )}
            Grant notes access
          </Button>
        </form>

        <div className="space-y-3">
          <div className="flex flex-wrap items-end justify-between gap-3">
            <div>
              <h3 className="font-semibold">Recent Notes access</h3>
              <p className="text-xs text-muted-foreground">
                Showing up to 500 grants and paid Note purchases; revoking one record keeps its
                history.
              </p>
            </div>
            <div className="flex w-full flex-wrap items-center gap-2 sm:w-auto sm:justify-end">
              {removedSeriesGrantCount > 0 && (
                <Button
                  type="button"
                  size="sm"
                  variant="outline"
                  className="rounded-full"
                  onClick={() => setShowRemovedSeriesGrants((current) => !current)}
                  aria-pressed={showRemovedSeriesGrants}
                >
                  {showRemovedSeriesGrants ? (
                    <EyeOff className="mr-1.5 h-4 w-4" />
                  ) : (
                    <Eye className="mr-1.5 h-4 w-4" />
                  )}
                  {showRemovedSeriesGrants
                    ? "Hide removed"
                    : `Show removed (${removedSeriesGrantCount})`}
                </Button>
              )}
              <div className="relative w-full sm:w-64">
                <Search className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
                <Input
                  className="pl-9"
                  value={query}
                  onChange={(event) => setQuery(event.target.value)}
                  placeholder="Search grants…"
                  aria-label="Search notes access grants"
                />
              </div>
            </div>
          </div>

          {accessQuery.isLoading ? (
            <div className="rounded-2xl border p-6 text-center text-sm text-muted-foreground">
              <Loader2 className="mx-auto mb-2 h-5 w-5 animate-spin" /> Loading notes access…
            </div>
          ) : accessQuery.isError ? (
            <div className="rounded-2xl border border-destructive/30 p-4 text-sm text-destructive">
              {friendlyError(accessQuery.error)}
            </div>
          ) : displayedGrants.length ? (
            <div className="max-h-[34rem] space-y-3 overflow-y-auto pr-1">
              {displayedGrants.map((entry) => (
                <article
                  key={`${entry.kind}:${entry.id}`}
                  className={`rounded-2xl border bg-background/60 p-4 ${entry.admin_hidden_at ? "opacity-75" : ""}`}
                >
                  <div className="flex flex-wrap items-start justify-between gap-3">
                    <div className="min-w-0">
                      <div className="flex flex-wrap items-center gap-2">
                        <Badge
                          variant={entry.state === "active" ? "default" : "secondary"}
                          className="rounded-full"
                        >
                          {entry.state}
                        </Badge>
                        {entry.admin_hidden_at && (
                          <Badge variant="destructive" className="rounded-full">
                            Removed from list
                          </Badge>
                        )}
                        <Badge variant="outline" className="rounded-full">
                          {entry.kind === "note"
                            ? "Individual note grant"
                            : entry.kind === "purchase"
                              ? "Paid Note purchase"
                              : "Notes Series"}
                        </Badge>
                        <Badge variant="secondary" className="rounded-full capitalize">
                          {entry.method}
                        </Badge>
                      </div>
                      <h4 className="mt-2 font-semibold">{entry.title}</h4>
                      <p className="mt-0.5 break-all text-xs text-muted-foreground">
                        {entry.student_name}
                        {entry.student_email ? ` · ${entry.student_email}` : ""}
                      </p>
                      {(entry.subject || entry.chapter) && (
                        <p className="mt-1 text-xs text-muted-foreground">
                          {[entry.subject, entry.chapter].filter(Boolean).join(" · ")}
                        </p>
                      )}
                    </div>
                    <div className="flex flex-wrap gap-2">
                      {entry.kind === "series" && (
                        <Button
                          type="button"
                          size="sm"
                          variant="outline"
                          className="rounded-full"
                          disabled={historyVisibilityMutation.isPending}
                          onClick={() =>
                            historyVisibilityMutation.mutate({
                              id: entry.id,
                              hidden: !entry.admin_hidden_at,
                            })
                          }
                        >
                          {historyVisibilityMutation.isPending ? (
                            <Loader2 className="mr-1.5 h-4 w-4 animate-spin" />
                          ) : entry.admin_hidden_at ? (
                            <Eye className="mr-1.5 h-4 w-4" />
                          ) : (
                            <EyeOff className="mr-1.5 h-4 w-4" />
                          )}
                          {entry.admin_hidden_at ? "Restore" : "Remove from list"}
                        </Button>
                      )}
                      {entry.state === "active" && (
                        <Button
                          type="button"
                          size="sm"
                          variant="outline"
                          className="rounded-full"
                          disabled={revokeMutation.isPending}
                          onClick={() => {
                            const warning =
                              entry.kind === "purchase"
                                ? `Revoke the paid access record for ${entry.title}? This keeps the purchase history.`
                                : `Revoke ${entry.title} access for ${entry.student_email || entry.student_name}?`;
                            if (window.confirm(warning))
                              revokeMutation.mutate({ id: entry.id, kind: entry.kind });
                          }}
                        >
                          {revokeMutation.isPending ? (
                            <Loader2 className="mr-1.5 h-4 w-4 animate-spin" />
                          ) : (
                            <XCircle className="mr-1.5 h-4 w-4" />
                          )}
                          Revoke
                        </Button>
                      )}
                    </div>
                  </div>
                  <div className="mt-3 grid gap-2 text-xs sm:grid-cols-2">
                    <div className="flex items-center gap-2 rounded-xl border p-3">
                      <CalendarClock className="h-4 w-4 shrink-0 text-primary" />
                      <span>
                        Valid until <strong>{formatDate(entry.expires_at)}</strong>
                      </span>
                    </div>
                    <div className="rounded-xl border p-3">
                      Granted {formatDate(entry.created_at)}
                    </div>
                  </div>
                  {entry.note && (
                    <p className="mt-3 rounded-xl bg-muted/40 p-3 text-xs">{entry.note}</p>
                  )}
                </article>
              ))}
            </div>
          ) : (
            <p className="rounded-2xl border border-dashed p-6 text-center text-sm text-muted-foreground">
              No notes access grants match this search yet.
            </p>
          )}
        </div>
      </div>
    </section>
  );
}
