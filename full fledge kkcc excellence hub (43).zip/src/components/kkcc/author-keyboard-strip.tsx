import { useEffect, useLayoutEffect, useRef, useState } from "react";
import { AuthorColourMixer } from "./author-colour-mixer";
import { QUICK_NOTE_TEXT_COLOURS, QUICK_NOTE_HIGHLIGHTS } from "@/lib/author-quick-colours";

type Mode = "color" | "highlight";
export function AuthorKeyboardStrip({
  disabled,
  active,
  label,
  bold,
  italic,
  underline,
  apply,
  clear,
  allowHighlight = true,
  compactColours = false,
  dockWhileEditing = false,
  selectionCount = 0,
}: {
  disabled?: boolean | undefined;
  allowHighlight?: boolean | undefined;
  /** In the note editor, switch between text and marker instead of stacking two palettes. */
  compactColours?: boolean | undefined;
  /** Keep the note controls above the phone keyboard instead of before a long note. */
  dockWhileEditing?: boolean | undefined;
  selectionCount?: number | undefined;
  active?: boolean;
  label: string;
  bold: () => void;
  italic: () => void;
  underline: () => void;
  apply: (kind: Mode, colour: string) => void;
  clear: (kind: Mode) => void;
}) {
  const [focused, setFocused] = useState(false);
  const [bottom, setBottom] = useState(0);
  const [phone, setPhone] = useState(false);
  const [visibleHeight, setVisibleHeight] = useState(0);
  const [navigationHeight, setNavigationHeight] = useState(0);
  const [placeholderHeight, setPlaceholderHeight] = useState(0);
  const toolsRef = useRef<HTMLDivElement>(null);
  const [picker, setPicker] = useState(false);
  const [palette, setPalette] = useState<Mode>("color");
  useEffect(() => {
    const update = () => {
      const viewport = window.visualViewport;
      setBottom(
        viewport
          ? Math.max(0, Math.round(window.innerHeight - viewport.height - viewport.offsetTop))
          : 0,
      );
      setVisibleHeight(Math.round(viewport?.height ?? window.innerHeight));
      setPhone(window.innerWidth < 768);
      const navigation = document.querySelector<HTMLElement>(".mobile-dock");
      setNavigationHeight(
        navigation && getComputedStyle(navigation).display !== "none"
          ? Math.ceil(navigation.getBoundingClientRect().height)
          : 0,
      );
    };
    update();
    window.visualViewport?.addEventListener("resize", update);
    window.visualViewport?.addEventListener("scroll", update);
    window.addEventListener("resize", update);
    return () => {
      window.visualViewport?.removeEventListener("resize", update);
      window.visualViewport?.removeEventListener("scroll", update);
      window.removeEventListener("resize", update);
    };
  }, []);
  // A bottom-sticky element *before* a long note scrolls out of sight: dock it
  // while editing on phones, even before the OS keyboard reports its height.
  const floating = (active || focused) && (bottom >= 100 || (dockWhileEditing && phone));
  // With no OS keyboard (or in a browser fixture), keep the strip ABOVE the
  // app's fixed bottom navigation instead of placing colour buttons beneath it.
  const dockBottom = bottom >= 100 ? bottom : dockWhileEditing ? navigationHeight + 4 : bottom;
  useLayoutEffect(() => {
    // Reserve the original inline height while docked. Otherwise the editable
    // text shifts up when the toolbar becomes fixed, moving the caret/scroll.
    if (!dockWhileEditing || floating || picker || !toolsRef.current) return;
    const height = Math.ceil(toolsRef.current.getBoundingClientRect().height);
    setPlaceholderHeight((previous) => (previous === height ? previous : height));
  }, [dockWhileEditing, floating, picker, palette, phone]);
  const controls = (
    <div
      ref={toolsRef}
      data-kkcc-author-tools
      data-testid="author-keyboard-strip"
      onFocus={() => setFocused(true)}
      onBlur={(event) => {
        if (!event.currentTarget.contains(event.relatedTarget)) setFocused(false);
      }}
      className={`z-50 max-w-full rounded-xl border border-border bg-card p-2 text-card-foreground shadow-sm ${floating ? "fixed inset-x-2 overflow-y-auto" : dockWhileEditing ? "relative" : "sticky bottom-0"}`}
      style={
        floating
          ? {
              bottom: `${dockBottom}px`,
              maxHeight: `${Math.max(130, Math.floor(visibleHeight * 0.48))}px`,
              paddingBottom: "max(8px, env(safe-area-inset-bottom))",
            }
          : undefined
      }
      role="toolbar"
      aria-label={label}
    >
      <div className="flex flex-wrap items-center gap-1">
        {(
          [
            ["Bold", "B", bold],
            ["Italic", "I", italic],
            ["Underline", "U", underline],
          ] as const
        ).map(([name, text, action]) => (
          <button
            key={name}
            type="button"
            aria-label={name}
            title={name}
            disabled={disabled}
            onMouseDown={(event) => event.preventDefault()}
            onClick={action}
            className={`min-h-11 min-w-11 rounded-lg border bg-background px-2 text-sm ${name === "Bold" ? "font-bold" : name === "Italic" ? "italic" : "underline"}`}
          >
            {text}
          </button>
        ))}
        <button
          type="button"
          aria-label="Text and highlight colours"
          aria-expanded={picker}
          disabled={disabled}
          onMouseDown={(event) => event.preventDefault()}
          onClick={() => setPicker(!picker)}
          className="min-h-11 rounded-lg border bg-background px-3 text-sm"
        >
          Colours ▾
        </button>
        {floating && (
          <span className="text-xs text-muted-foreground">Formatting above keyboard</span>
        )}
      </div>
      {compactColours && (
        <div
          className="mt-2 flex flex-wrap items-center gap-1"
          role="group"
          aria-label="Quick colour mode"
        >
          {(
            [
              ["color", "Text colour mode", "A Text"],
              ["highlight", "Highlight mode", "▰ Highlight"],
            ] as const
          )
            .filter(([mode]) => allowHighlight || mode === "color")
            .map(([mode, name, text]) => (
              <button
                key={mode}
                type="button"
                aria-label={name}
                aria-pressed={palette === mode}
                disabled={disabled}
                onMouseDown={(event) => event.preventDefault()}
                onClick={() => setPalette(mode)}
                className={`min-h-10 rounded-full border px-3 text-xs font-bold ${palette === mode ? "bg-primary text-primary-foreground" : "bg-background"}`}
              >
                {text}
              </button>
            ))}
          <span role="status" className="min-w-0 text-xs text-muted-foreground">
            {selectionCount > 0
              ? "Text selected · ab rang chunein"
              : "Pehle shabd select karein, phir rang chunein"}
          </span>
        </div>
      )}
      {(!compactColours || palette === "color") && (
        <div
          className="mt-2 flex items-center gap-1 overflow-x-auto pb-1"
          role="group"
          aria-label="Quick text colours"
        >
          <span className="shrink-0 text-[11px] font-bold">Text A</span>
          {QUICK_NOTE_TEXT_COLOURS.map(({ name, hex }) => (
            <button
              key={hex}
              type="button"
              aria-label={`Text colour ${name}`}
              title={`Text colour ${name}`}
              disabled={disabled}
              onMouseDown={(event) => event.preventDefault()}
              onClick={() => apply("color", hex)}
              className="grid h-11 w-11 shrink-0 place-items-center rounded-lg border-2 bg-background text-lg font-bold focus-visible:outline-2 focus-visible:outline-primary"
              style={{ color: hex, borderBottomColor: hex }}
            >
              A
            </button>
          ))}
          <button
            type="button"
            aria-label="Clear text colour"
            disabled={disabled}
            onMouseDown={(event) => event.preventDefault()}
            onClick={() => clear("color")}
            className="min-h-11 shrink-0 rounded-lg border px-2 text-[11px]"
          >
            Clear A
          </button>
        </div>
      )}
      {allowHighlight && (!compactColours || palette === "highlight") && (
        <div
          className="flex items-center gap-1 overflow-x-auto pb-1"
          role="group"
          aria-label="Quick highlight colours"
        >
          <span className="shrink-0 text-[11px] font-bold">Marker</span>
          {QUICK_NOTE_HIGHLIGHTS.map(({ name, hex }) => (
            <button
              key={hex}
              type="button"
              aria-label={`Highlight ${name}`}
              title={`Highlight ${name}`}
              disabled={disabled}
              onMouseDown={(event) => event.preventDefault()}
              onClick={() => apply("highlight", hex)}
              className="grid h-11 w-11 shrink-0 place-items-center rounded-lg border-2 border-foreground/20 text-base font-bold text-slate-900 focus-visible:outline-2 focus-visible:outline-primary"
              style={{ backgroundColor: hex }}
            >
              ▬
            </button>
          ))}
          <button
            type="button"
            aria-label="Clear highlight"
            disabled={disabled}
            onMouseDown={(event) => event.preventDefault()}
            onClick={() => clear("highlight")}
            className="min-h-11 shrink-0 rounded-lg border px-2 text-[11px]"
          >
            Clear marker
          </button>
        </div>
      )}
      {picker && (
        <div className="mt-2 max-h-[52vh] overflow-auto">
          <AuthorColourMixer
            disabled={disabled}
            allowHighlight={allowHighlight}
            onApply={(kind, colour) => {
              apply(kind, colour);
              setPicker(false);
            }}
            onClear={(kind) => {
              clear(kind);
              setPicker(false);
            }}
          />
        </div>
      )}
    </div>
  );
  return dockWhileEditing ? (
    <div
      data-kkcc-toolbar-space
      style={floating ? { height: `${placeholderHeight}px` } : undefined}
    >
      {controls}
    </div>
  ) : (
    controls
  );
}
