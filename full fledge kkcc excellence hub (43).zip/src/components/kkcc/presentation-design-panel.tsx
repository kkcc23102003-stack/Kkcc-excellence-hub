import { useState, useRef, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import {
  DEFAULT_SLIDE_BRAND,
  DEFAULT_SLIDE_SIZE,
  deckSchema,
  type Deck,
} from "@/lib/document-studio";
import {
  RATIOS,
  THEMES,
  appendReferenceSlides,
  browserSlideMeasure,
  generateTeachingDeck,
  makeDesignedSlide,
  resizePresentation,
  updateSlideBrand,
  type ThemeName,
  type SlideSize,
} from "@/lib/presentation-design";

export function PresentationDesignPanel({
  deck,
  onCommit,
  onSelect,
}: {
  deck: Deck;
  onCommit: (next: Deck) => boolean;
  onSelect: (index: number) => void;
}) {
  const [theme, setTheme] = useState<ThemeName>("galaxy"),
    [purpose, setPurpose] = useState<"lesson" | "cover" | "thumbnail">("lesson"),
    [text, setText] = useState(""),
    [busy, setBusy] = useState(false),
    [message, setMessage] = useState(
      "Original editable shapes and text — never a flattened copy of your reference photos.",
    );
  const mounted = useRef(true);
  useEffect(() => {
    mounted.current = true;
    return () => {
      mounted.current = false;
    };
  }, []);
  const [custom, setCustom] = useState({ width: 1080, height: 1440 });
  const latest = useRef(deck),
    jobDeck = useRef(deck);
  latest.current = deck;
  const apply = (next: Deck) => {
    if (!mounted.current) return false;
    if (latest.current !== jobDeck.current)
      throw new Error("Project changed while layouts were preparing. Please retry.");
    return onCommit(next);
  };
  const brand = deck.brand ?? DEFAULT_SLIDE_BRAND,
    size = deck.size ?? DEFAULT_SLIDE_SIZE;
  const ratio =
    Object.entries(RATIOS).find(
      ([, value]) => value.width === size.width && value.height === size.height,
    )?.[0] ?? "custom";
  const run = async (work: () => Promise<void>) => {
    jobDeck.current = deck;
    setBusy(true);
    try {
      await new Promise((resolve) => setTimeout(resolve, 0));
      await work();
    } catch (error) {
      if (mounted.current)
        setMessage(error instanceof Error ? error.message : "Could not create slides.");
    } finally {
      if (mounted.current) setBusy(false);
    }
  };
  const resize = (next: SlideSize) =>
    void run(async () => {
      const resized = resizePresentation(deck, next, await browserSlideMeasure());
      if (apply(resized)) {
        onSelect(0);
        setMessage(
          "Size changed: text refitted, generated body text repaginated, image proportions preserved. Review manually positioned objects before export.",
        );
      }
    });
  return (
    <details className="rounded-xl border bg-muted/20 p-4" open>
      <summary className="cursor-pointer font-semibold">
        Editable templates, ratios & text-to-slides
      </summary>
      <fieldset disabled={busy} className="mt-4 min-w-0 space-y-4">
        <section
          aria-label="Your reference templates"
          className="min-w-0 space-y-3 rounded-xl border border-primary/30 bg-background p-3"
        >
          <h3 className="font-semibold">Your photo-reference templates · v2</h3>
          <p className="text-sm text-muted-foreground">
            Ready-made teaching page + Brahmastra / PSTET cover. Adding these keeps every existing
            slide and project setting; it does not automatically save the project to the cloud.
          </p>
          <div className="grid min-w-0 grid-cols-2 gap-3">
            <figure className="min-w-0">
              <img
                src="/templates/kkcc-reference-v2/teaching.png"
                alt="Reference teaching page with galaxy and footer"
                width={1280}
                height={1024}
                loading="lazy"
                className="max-h-48 w-full rounded object-contain"
              />
              <figcaption className="mt-1 text-xs">Blank teaching page</figcaption>
            </figure>
            <figure className="min-w-0">
              <img
                src="/templates/kkcc-reference-v2/cover.png"
                alt="Brahmastra PSTET reference cover"
                width={1280}
                height={1024}
                loading="lazy"
                className="max-h-48 w-full rounded object-contain"
              />
              <figcaption className="mt-1 text-xs">PSTET cover</figcaption>
            </figure>
          </div>
          <div className="flex flex-wrap gap-2">
            <Button
              className="h-auto whitespace-normal"
              onClick={() =>
                void run(async () => {
                  const response = await fetch("/templates/kkcc-reference-v2/project.json");
                  if (!response.ok)
                    throw new Error(
                      "Reference pack could not load. Please retry. If this persists, deploy the complete updated ZIP including public/templates.",
                    );
                  const reference = deckSchema.parse(await response.json());
                  const { deck: next, added } = appendReferenceSlides(
                    deck,
                    reference,
                    await browserSlideMeasure(),
                  );
                  if (!added) {
                    setMessage(
                      "Both reference slides are already in this project. Existing slides are unchanged.",
                    );
                    return;
                  }
                  if (apply(next)) {
                    onSelect(deck.slides.length);
                    setMessage(
                      `Added ${added} reference slide${added === 1 ? "" : "s"} after your ${deck.slides.length} existing slides. No old slides were replaced. Save editable project to keep changes after closing the tab.`,
                    );
                  }
                })
              }
            >
              Load both reference templates (keep old slides)
            </Button>
            <Button variant="outline" className="h-auto whitespace-normal" asChild>
              <a
                href="/templates/kkcc-reference-v2/project.json"
                download="KKCC-reference.kkcc-presentation.json"
              >
                Download separate 5:4 reference project
              </a>
            </Button>
            <Button variant="outline" className="h-auto whitespace-normal" asChild>
              <a
                href="/templates/kkcc-reference-v2/reference-editable.pptx"
                download="KKCC-reference-editable.pptx"
              >
                Download original editable PPTX
              </a>
            </Button>
          </div>
          <p className="text-xs text-muted-foreground">
            Reference layouts are 5:4; they are fitted to the current canvas when its ratio differs.
            Use the separate project/PPTX to keep the original ratio. Text, logo and bands stay
            separate. For lighter mobile editing, the app uses a recreated galaxy image layer;
            individual stars remain editable in the original PPTX. Browser font fitting can differ
            slightly. Your current project stays browser-local until you download Save editable
            project.
          </p>
        </section>

        <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-4">
          {Object.entries(brand).map(([key, value]) => (
            <label key={key} className="text-sm">
              {
                {
                  appName: "Coaching / app name",
                  series: "Series name",
                  subject: "Subject name",
                  teacher: "Teacher name",
                }[key as keyof typeof brand]
              }
              <Input
                aria-label={`Template ${key}`}
                maxLength={100}
                value={value}
                onChange={(e) =>
                  onCommit(updateSlideBrand(deck, { ...brand, [key]: e.target.value }))
                }
              />
            </label>
          ))}
        </div>
        <div className="grid gap-3 sm:grid-cols-2">
          <label className="text-sm">
            Canvas ratio
            <select
              aria-label="Presentation ratio"
              className="mt-1 block w-full rounded border bg-background p-2"
              value={ratio}
              onChange={(e) =>
                e.target.value === "custom"
                  ? resize(custom)
                  : resize(RATIOS[e.target.value as keyof typeof RATIOS])
              }
            >
              <option value="16:9">16:9 — YouTube / widescreen</option>
              <option value="9:16">9:16 — Reels / Shorts / Stories</option>
              <option value="1:1">1:1 — Square</option>
              <option value="4:5">4:5 — Instagram post</option>
              <option value="3:4">3:4 — Portrait</option>
              <option value="4:3">4:3 — Classic slide</option>
              <option value="custom">Custom pixels</option>
            </select>
          </label>
          <div className="flex flex-wrap items-end gap-2">
            <label className="min-w-0 flex-1 text-xs">
              Width px
              <Input
                aria-label="Custom slide width"
                type="number"
                min={320}
                max={2560}
                value={custom.width}
                onChange={(e) => setCustom({ ...custom, width: Number(e.target.value) })}
              />
            </label>
            <label className="min-w-0 flex-1 text-xs">
              Height px
              <Input
                aria-label="Custom slide height"
                type="number"
                min={320}
                max={2560}
                value={custom.height}
                onChange={(e) => setCustom({ ...custom, height: Number(e.target.value) })}
              />
            </label>
            <Button variant="outline" onClick={() => resize(custom)}>
              Apply custom size
            </Button>
          </div>
        </div>
        <p className="text-xs text-muted-foreground">
          Current canvas: {size.width} × {size.height}px. Exported PPTX, PDF and thumbnail use this
          ratio. Custom sizes: 320–2560px, up to 4 megapixels, ratio 1:3 to 3:1.
        </p>
        <div
          role="group"
          aria-label="Editable theme gallery"
          className="grid grid-cols-2 gap-2 sm:grid-cols-5"
        >
          {Object.entries(THEMES).map(([key, palette]) => (
            <button
              type="button"
              key={key}
              aria-pressed={theme === key}
              onClick={() => setTheme(key as ThemeName)}
              className={`rounded-xl border p-4 text-left ${theme === key ? "ring-2 ring-primary" : ""}`}
              style={{ background: palette.background, color: palette.ink }}
            >
              <span className="block text-xl" style={{ color: palette.accent }}>
                ✦ KKCC
              </span>
              <span className="mt-2 block text-sm font-semibold">{palette.name}</span>
              <span className="mt-2 block h-1" style={{ background: palette.accent }} />
            </button>
          ))}
        </div>
        <div className="flex flex-wrap gap-2">
          <select
            aria-label="Designed slide purpose"
            className="min-w-0 max-w-full rounded border bg-background p-2"
            value={purpose}
            onChange={(e) => setPurpose(e.target.value as typeof purpose)}
          >
            <option value="lesson">Teaching page — clear centre</option>
            <option value="cover">Series cover — large title</option>
            <option value="thumbnail">Thumbnail — series / subject / teacher</option>
          </select>
          <Button
            disabled={deck.slides.length >= 60}
            onClick={() =>
              void run(async () => {
                const slide = makeDesignedSlide(
                  theme,
                  purpose,
                  size,
                  brand,
                  await browserSlideMeasure(),
                );
                if (apply({ ...deck, brand, slides: [...deck.slides, slide] })) {
                  onSelect(deck.slides.length);
                  setMessage(
                    "Editable template added. Choose any object using the object selector to edit its text, colour or position.",
                  );
                }
              })
            }
          >
            Add designed slide
          </Button>
        </div>
        <label className="block text-sm">
          Paste lesson text
          <Textarea
            aria-label="Auto presentation text"
            rows={7}
            maxLength={60000}
            value={text}
            onChange={(e) => setText(e.target.value)}
            placeholder={
              "# Chapter heading\nPaste paragraphs or bullet points.\n# Next heading\nMore content…"
            }
          />
        </label>
        <p className="text-xs text-muted-foreground">
          Use # headings to start sections. Text is organised, not AI-written or summarised.
          Header/logo stay above the content; footer stays below it. Long text continues on extra
          slides rather than being cut off. 60 slides maximum; oversized input is rejected without
          replacing the current project.
        </p>
        <Button
          disabled={!text.trim()}
          onClick={() =>
            void run(async () => {
              if (
                !window.confirm(
                  "Replace the current slides with a generated lesson? Save your project first to keep an independent copy. Undo is also available.",
                )
              )
                return;
              const next = generateTeachingDeck(
                text,
                theme,
                size,
                brand,
                await browserSlideMeasure(),
              );
              if (apply(next)) {
                onSelect(0);
                setMessage(
                  `Generated ${next.slides.length} editable slides with reserved branding margins. Review them before exporting.`,
                );
              }
            })
          }
        >
          Generate slides from text
        </Button>
      </fieldset>
      <p className="mt-3 text-sm" role="status">
        {busy ? "Preparing editable layouts…" : message}
      </p>
    </details>
  );
}
