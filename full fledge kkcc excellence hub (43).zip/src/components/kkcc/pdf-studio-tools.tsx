import { useRef, useState, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { downloadFile } from "@/lib/document-studio";
import { brandPdfBytes, type PdfColourMode } from "@/lib/pdf-brand";
import {
  imagesToPdf,
  splitPdfZip,
  mergePdfFiles,
  readPdfFile,
  transformPdf,
  type PdfAction,
} from "@/lib/pdf-studio";
import { prepareStudioImage, rasterPdf, pdfImagesZip } from "@/lib/pdf-browser";

export function PdfStudioTools({ onPreview }: { onPreview: (file: File) => void }) {
  const [files, setFiles] = useState<File[]>([]),
    [images, setImages] = useState<File[]>([]),
    [action, setAction] = useState<
      PdfAction | "merge" | "compress" | "invert" | "images" | "split" | "png"
    >("merge");
  const [pages, setPages] = useState(""),
    [angle, setAngle] = useState(90),
    [watermark, setWatermark] = useState("Kusum Kartik Coaching Centre"),
    [quality, setQuality] = useState("balanced"),
    [consent, setConsent] = useState(false);
  const [busy, setBusy] = useState(false),
    [pdfMode, setPdfMode] = useState<PdfColourMode>("colour"),
    [brandingDownload, setBrandingDownload] = useState(false),
    [message, setMessage] = useState(
      "Original files are never overwritten. All processing stays in your browser.",
    ),
    [output, setOutput] = useState<{ bytes: Uint8Array; name: string } | null>(null);
  const cancel = useRef(false),
    alive = useRef(true);
  useEffect(() => {
    alive.current = true;
    return () => {
      alive.current = false;
      cancel.current = true;
    };
  }, []);
  const run = async () => {
    cancel.current = false;
    setBusy(true);
    setOutput(null);
    setMessage("Processing…");
    try {
      let result: Uint8Array,
        original = 0;
      if (action === "images") {
        if (!images.length) throw new Error("Choose JPG/PNG images first.");
        const converted = [];
        for (const file of images) {
          if (cancel.current) throw new Error("Cancelled.");
          const data = await prepareStudioImage(file);
          const blob = await (await fetch(data)).blob();
          converted.push({ bytes: new Uint8Array(await blob.arrayBuffer()), type: blob.type });
        }
        result = await imagesToPdf(converted);
      } else {
        if (!files.length) throw new Error("Choose PDFs first.");
        if (action !== "merge" && files.length !== 1)
          throw new Error("For this tool choose exactly one PDF; merge multiple PDFs first.");
        const buffers = [];
        for (const file of files) {
          if (cancel.current) throw new Error("Cancelled.");
          buffers.push(await readPdfFile(file));
        }
        original = buffers.reduce((sum, b) => sum + b.length, 0);
        if (action === "merge") result = await mergePdfFiles(buffers);
        else if (action === "split") result = await splitPdfZip(buffers[0]!);
        else if (action === "png")
          result = await pdfImagesZip(
            buffers[0]!,
            (n, total) => {
              if (alive.current) setMessage(`Rendering image ${n} / ${total}`);
            },
            () => cancel.current,
          );
        else if (action === "compress" || action === "invert") {
          if (!consent)
            throw new Error(
              "Confirm image-based export: text search, links and form fields will not be retained.",
            );
          result = await rasterPdf(buffers[0]!, {
            invert: action === "invert",
            scale: quality === "small" ? 1 : quality === "high" ? 2 : 1.5,
            quality: quality === "small" ? 0.5 : quality === "high" ? 0.9 : 0.72,
            progress: (n, total) => {
              if (alive.current) setMessage(`Rendering page ${n} / ${total}…`);
            },
            cancelled: () => cancel.current,
          });
        } else result = await transformPdf(buffers[0]!, action, pages, angle, watermark);
      }
      if (cancel.current || !alive.current) {
        if (alive.current)
          setMessage("Cancelled. Original files are unchanged; no output produced.");
        return;
      }
      const name = `KKCC-${action}.${action === "split" || action === "png" ? "zip" : "pdf"}`;
      setOutput({ bytes: result, name });
      const difference = original
        ? ` Input ${(original / 1024).toFixed(0)} KB → output ${(result.length / 1024).toFixed(0)} KB.`
        : "";
      setMessage(
        `Ready.${difference}${action === "compress" && result.length >= original ? " This PDF did not get smaller. Keep the original or try Small quality." : ""}${action === "optimise" && result.length === original ? " No size reduction was possible; returning original bytes." : ""}`,
      );
    } catch (error) {
      if (alive.current)
        setMessage(
          error instanceof Error ? error.message : "PDF operation failed. Original files are safe.",
        );
    } finally {
      if (alive.current) setBusy(false);
    }
  };
  const downloadResult = async () => {
    if (!output || brandingDownload) return;
    if (output.name.endsWith(".zip")) {
      // Split PDFs inside the ZIP were branded when generated; PNG exports are images.
      downloadFile(output.bytes, output.name, "application/zip");
      return;
    }
    setBrandingDownload(true);
    setMessage("Adding KKCC logo and watermark to every PDF page…");
    try {
      const branded = await brandPdfBytes(output.bytes, {
        mode: pdfMode,
        onProgress: (page, total) => {
          if (alive.current) setMessage(`Making black & white PDF · page ${page}/${total}`);
        },
      });
      if (!alive.current) return;
      downloadFile(
        branded,
        pdfMode === "black-white" ? output.name.replace(/\.pdf$/i, "-BW.pdf") : output.name,
        "application/pdf",
      );
      setMessage(
        "Branded PDF downloaded. The original and the editable tool result are unchanged.",
      );
    } catch (error) {
      if (alive.current)
        setMessage(
          error instanceof Error ? error.message : "Could not brand this PDF. No download started.",
        );
    } finally {
      if (alive.current) setBrandingDownload(false);
    }
  };
  const reorder = (index: number, delta: number) => {
    const next = [...files];
    [next[index], next[index + delta]] = [next[index + delta]!, next[index]!];
    setFiles(next);
    setOutput(null);
  };
  return (
    <section className="space-y-4 rounded-2xl border p-4" data-testid="pdf-tools">
      <h2 className="text-xl font-bold">PDF tools</h2>
      <p className="text-sm text-muted-foreground">
        Up to 40 MB per PDF, 120 MB total / 500 pages for merge. Image-based export: up to 100
        pages. Password-protected files can be read, but require an unlocked copy for editing.
        Processing may flatten/drop forms, bookmarks and signatures; always keep originals.
      </p>
      <fieldset disabled={busy} className="min-w-0 space-y-4">
        <label className="block text-sm">
          Choose PDF tool
          <select
            aria-label="PDF tool"
            className="mt-1 block w-full rounded border bg-background p-3"
            value={action}
            onChange={(e) => {
              setAction(e.target.value as typeof action);
              setOutput(null);
              setConsent(false);
            }}
          >
            {Object.entries({
              merge: "Merge PDFs",
              split: "Split each page into PDFs — ZIP",
              png: "PDF pages to PNG images — ZIP",
              extract: "Extract / split / reorder pages",
              delete: "Delete selected pages",
              reverse: "Reverse page order",
              rotate: "Rotate selected pages",
              watermark: "Add watermark",
              optimise: "Optimise PDF — keep text/vector content",
              compress: "Compress scanned PDF — image-based",
              invert: "Invert colours — image-based PDF",
              images: "JPG / PNG images to PDF",
            }).map(([value, label]) => (
              <option key={value} value={value}>
                {label}
              </option>
            ))}
          </select>
        </label>
        {action === "images" ? (
          <label className="block text-sm">
            JPG/PNG images
            <Input
              type="file"
              aria-label="Images for PDF"
              accept="image/jpeg,image/png"
              multiple
              onChange={(e) => {
                const next = Array.from(e.target.files ?? []);
                if (next.length > 50) {
                  setMessage("Choose up to 50 images.");
                  return;
                }
                setImages(next);
                setOutput(null);
              }}
            />
            <span>{images.length} images • selection order</span>
          </label>
        ) : (
          <>
            <label className="block text-sm">
              PDF files
              <Input
                aria-label="PDF tool files"
                type="file"
                accept="application/pdf,.pdf"
                multiple={action === "merge"}
                onChange={(e) => {
                  const next = Array.from(e.target.files ?? []);
                  if (
                    next.length > 20 ||
                    next.reduce((s, f) => s + f.size, 0) > 120 * 1024 * 1024
                  ) {
                    setMessage("Choose at most 20 PDFs and 120 MB total.");
                    return;
                  }
                  setFiles(next);
                  setOutput(null);
                }}
              />
            </label>
            <ol className="space-y-2">
              {files.map((file, index) => (
                <li
                  key={`${file.name}-${index}`}
                  className="flex flex-wrap items-center gap-2 rounded border p-2"
                >
                  <span className="min-w-0 flex-1 break-all text-sm">
                    {index + 1}. {file.name}
                  </span>
                  <Button
                    variant="outline"
                    size="sm"
                    disabled={index === 0}
                    onClick={() => reorder(index, -1)}
                    aria-label={`Move file ${index + 1} up`}
                  >
                    ↑
                  </Button>
                  <Button
                    variant="outline"
                    size="sm"
                    disabled={index === files.length - 1}
                    onClick={() => reorder(index, 1)}
                    aria-label={`Move file ${index + 1} down`}
                  >
                    ↓
                  </Button>
                  <Button
                    size="sm"
                    variant="ghost"
                    onClick={() => {
                      setFiles(files.filter((_, i) => i !== index));
                      setOutput(null);
                    }}
                  >
                    Remove
                  </Button>
                </li>
              ))}
            </ol>
          </>
        )}
        {["extract", "delete", "rotate", "watermark"].includes(action) && (
          <label className="block text-sm">
            Page selection
            <Input
              aria-label="PDF page selection"
              value={pages}
              onChange={(e) => {
                setPages(e.target.value);
                setOutput(null);
              }}
              placeholder="Blank = all pages. Example: 3,1-2"
            />
            <span className="text-xs text-muted-foreground">
              Extract keeps your entered order; 5-1 reverses that range. Delete removes these pages.
              Page numbers start at 1.
            </span>
          </label>
        )}
        {action === "rotate" && (
          <select
            aria-label="PDF rotation"
            className="rounded border bg-background p-2"
            value={angle}
            onChange={(e) => {
              setAngle(Number(e.target.value));
              setOutput(null);
            }}
          >
            {[90, 180, 270].map((n) => (
              <option key={n} value={n}>
                {n}° clockwise
              </option>
            ))}
          </select>
        )}
        {action === "watermark" && (
          <Input
            aria-label="PDF watermark text"
            value={watermark}
            maxLength={80}
            onChange={(e) => {
              setWatermark(e.target.value);
              setOutput(null);
            }}
          />
        )}
        {(action === "compress" || action === "invert") && (
          <div className="space-y-3 rounded border border-amber-300 p-3">
            <label className="block text-sm">
              Export quality
              <select
                aria-label="Raster PDF quality"
                className="ml-2 rounded border bg-background p-2"
                value={quality}
                onChange={(e) => {
                  setQuality(e.target.value);
                  setOutput(null);
                }}
              >
                <option value="small">Small / 72 dpi</option>
                <option value="balanced">Balanced / 108 dpi</option>
                <option value="high">High / 144 dpi</option>
              </select>
            </label>
            <label className="flex items-start gap-2 text-sm">
              <input
                type="checkbox"
                checked={consent}
                onChange={(e) => setConsent(e.target.checked)}
              />
              I understand pages become images. Searchable text, links, forms and signatures are not
              preserved. Compression may not reduce every file.
            </label>
          </div>
        )}
        <Button onClick={() => void run()}>Process PDF</Button>
      </fieldset>
      <p role="status" className="text-sm">
        {message}
      </p>
      {busy && (
        <Button
          variant="outline"
          onClick={() => {
            cancel.current = true;
            setMessage("Cancellation requested. Finishing the current page safely…");
          }}
        >
          Cancel processing
        </Button>
      )}
      {output && (
        <div className="flex flex-wrap gap-2">
          {!output.name.endsWith(".zip") && (
            <label className="flex w-full min-w-0 flex-wrap items-center gap-2 text-sm sm:w-auto">
              PDF output
              <select
                aria-label="PDF tools colour mode"
                className="min-h-10 min-w-0 w-full max-w-full rounded-lg border bg-background px-2 sm:w-auto"
                value={pdfMode}
                disabled={brandingDownload}
                onChange={(event) => setPdfMode(event.target.value as PdfColourMode)}
              >
                <option value="colour">Colour</option>
                <option value="black-white">Black &amp; white · actual grayscale PDF</option>
              </select>
            </label>
          )}
          <Button disabled={brandingDownload} onClick={() => void downloadResult()}>
            {output.name.endsWith(".zip") ? "Download processed ZIP" : "Download processed PDF"}
          </Button>
          <span className="self-center text-xs text-muted-foreground">
            {output.name.endsWith(".zip")
              ? "Split PDF pages include the KKCC mark. PNG images are not PDFs."
              : "The downloaded copy gets the KKCC logo + watermark on every page. Final bytes may be larger than the size shown above; keep signed originals."}
          </span>
          {!output.name.endsWith(".zip") && (
            <Button
              variant="outline"
              onClick={() =>
                onPreview(
                  new File([new Uint8Array(output.bytes)], output.name, {
                    type: "application/pdf",
                  }),
                )
              }
            >
              Open result in reader
            </Button>
          )}
        </div>
      )}
    </section>
  );
}
