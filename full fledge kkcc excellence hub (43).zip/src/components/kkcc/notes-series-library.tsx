import { useEffect, useMemo, useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { Link } from "@tanstack/react-router";
import { useLearningAccess } from "@/hooks/use-learning-access";
import { ArrowLeft, ArrowRight, BookOpen, FolderOpen } from "lucide-react";
import { getNotesSeriesLibrary } from "@/lib/notes-series.functions";
import { getPublicBatchForSeries } from "@/lib/notes-batch.functions";
import { notesSeriesAccessKey, seriesNoteIds } from "@/lib/notes-series";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import { PagedGrid } from "./paged-grid";
import { ContentThumbnail } from "./content-thumbnail";
import { MaterialAccessButton } from "./material-access-button";

const EMPTY_IDS: string[] = [];

export function NotesSeriesLibrary() {
  const [kind, setKind] = useState<"paid" | "sample">("paid");
  const [path, setPath] = useState<string[]>([]);
  const [search, setSearch] = useState("");
  const query = useQuery({
    queryKey: ["notes-series-library", kind],
    queryFn: () => getNotesSeriesLibrary({ data: { kind } }),
    staleTime: 60_000,
  });
  const data = query.data;
  useEffect(() => {
    if (!query.isError) return;
    const error = query.error;
    console.error("[notes-series] Catalogue request failed", {
      kind,
      name: error instanceof Error ? error.name : "UnknownError",
      message: error instanceof Error ? error.message : "Unknown catalogue error",
    });
  }, [kind, query.error, query.isError]);
  const series = data?.series.find((item) => item.id === path[0]);
  const batchQuery = useQuery({
    queryKey: ["public-notes-batch", series?.id],
    queryFn: () => getPublicBatchForSeries({ data: { id: series!.id } }),
    enabled: Boolean(series && kind === "paid"),
    staleTime: 60_000,
    retry: 1,
  });
  const batchCourse = batchQuery.data ?? null;
  const learningAccess = useLearningAccess();
  const hasBatchAccess = Boolean(
    batchCourse &&
    (learningAccess.data?.is_admin ||
      learningAccess.data?.course_ids.includes(batchCourse.courseId)),
  );
  const hasSeriesAccess = Boolean(
    series &&
    (learningAccess.data?.is_admin ||
      learningAccess.data?.notes_series_grants.some(
        (grant) => grant.series_id === notesSeriesAccessKey(series.id),
      )),
  );
  const isCheckingBatchAccess = Boolean(
    learningAccess.user && learningAccess.isPending && (batchCourse || series),
  );
  const freePreviewIds = useMemo(
    () =>
      new Set(
        (data?.materials ?? []).filter((note) => note.free_series_preview).map((note) => note.id),
      ),
    [data],
  );
  const subject = series?.subjects.find((item) => item.id === path[1]);
  const chapter = subject?.chapters.find((item) => item.id === path[2]);
  const topic = chapter?.topics.find((item) => item.id === path[3]);
  const noteIds = topic?.noteIds ?? chapter?.noteIds ?? EMPTY_IDS;
  const notes = useMemo(
    () => (data?.materials ?? []).filter((note) => noteIds.includes(note.id)),
    [data, noteIds],
  );
  const go = (next: string[]) => {
    setPath(next);
    setSearch("");
  };
  const needle = search.trim().toLocaleLowerCase();
  const has = (value: string) => value.toLocaleLowerCase().includes(needle);
  return (
    <section data-testid="notes-series-library" className="space-y-6">
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div>
          <h2 className="text-2xl font-bold">
            {kind === "paid" ? "Paid Notes Series" : "Free notes"}
          </h2>
          <p className="mt-1 text-sm text-muted-foreground">
            {kind === "paid"
              ? "Choose a series, then a subject and chapter. Existing note purchases and course access still apply."
              : "Published free notes, separate from paid notes."}
          </p>
        </div>
        <Button
          variant="outline"
          onClick={() => {
            setKind(kind === "paid" ? "sample" : "paid");
            go([]);
          }}
        >
          {kind === "paid" ? "View Free Notes" : "Back to Paid Notes"}
        </Button>
      </div>
      {query.isPending && (
        <div
          role="status"
          aria-label="Loading notes series"
          className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3"
        >
          {[0, 1, 2].map((i) => (
            <Skeleton key={i} className="h-44 rounded-2xl" />
          ))}
        </div>
      )}
      {query.isError && (
        <div role="alert" className="rounded-xl border p-5">
          Notes could not be loaded.{" "}
          <Button variant="outline" onClick={() => void query.refetch()}>
            Retry notes
          </Button>
        </div>
      )}
      {!query.isPending && !query.isError && (
        <>
          <nav
            aria-label="Notes series navigation"
            className="flex flex-wrap items-center gap-2 text-sm"
          >
            <Button variant="outline" onClick={() => go([])}>
              <FolderOpen className="h-4 w-4" />
              All series
            </Button>
            {series && (
              <Button
                variant="ghost"
                className="h-auto whitespace-normal text-left"
                onClick={() => go([series.id])}
              >
                {series.name}
              </Button>
            )}
            {subject && (
              <Button
                variant="ghost"
                className="h-auto whitespace-normal text-left"
                onClick={() => go([series!.id, subject.id])}
              >
                {subject.name}
              </Button>
            )}
            {chapter && (
              <Button
                variant="ghost"
                className="h-auto whitespace-normal text-left"
                onClick={() => go([series!.id, subject!.id, chapter.id])}
              >
                {chapter.name}
              </Button>
            )}
            {topic && <span className="break-words">{topic.name}</span>}
          </nav>
          {path.length > 0 && (
            <Button variant="ghost" onClick={() => go(path.slice(0, -1))}>
              <ArrowLeft className="h-4 w-4" />
              Back
            </Button>
          )}
          {series && kind === "paid" && (
            <div className="flex flex-wrap items-center justify-between gap-3 rounded-2xl border border-primary/25 bg-primary/5 p-4">
              <div className="min-w-0 flex-1">
                <p className="font-semibold">
                  {hasSeriesAccess || hasBatchAccess
                    ? "Notes unlocked"
                    : "Choose how to unlock this Notes Series"}
                </p>
                <p className="mt-1 text-sm text-muted-foreground">
                  Buy this complete Notes Series to unlock all its remaining notes. The first
                  published note in each subject is free. This Notes section sells notes only;
                  course videos are purchased separately in the Batch section.
                </p>
              </div>
              <div className="flex flex-wrap gap-2">
                {isCheckingBatchAccess ? (
                  <Button variant="outline" className="rounded-full" disabled>
                    Checking access…
                  </Button>
                ) : hasSeriesAccess || hasBatchAccess ? (
                  <Button asChild className="rounded-full">
                    <Link to="/study-material">Open unlocked notes</Link>
                  </Button>
                ) : (
                  <div className="space-y-1">
                    <Button asChild className="rounded-full">
                      <Link to="/checkout" search={{ notes_series: series.id }}>
                        Buy Notes Only
                        {series.priceInr > 0 ? ` — ₹${series.priceInr}` : ""}
                        {series.priceInr > 0 && series.priceCoins > 0 ? " · " : ""}
                        {series.priceCoins > 0 ? `${series.priceCoins} coins` : ""}
                      </Link>
                    </Button>
                    {series.priceInr <= 0 && series.priceCoins <= 0 && (
                      <p className="text-xs text-muted-foreground">
                        Admin must set the Notes Series price before checkout can complete.
                      </p>
                    )}
                  </div>
                )}
              </div>
            </div>
          )}
          <Input
            aria-label="Search notes series"
            placeholder={
              chapter
                ? "Search notes or topics"
                : subject
                  ? "Search chapters"
                  : series
                    ? "Search subjects"
                    : "Search notes series"
            }
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            className="max-w-xl"
          />
          {!series ? (
            <>
              {!data?.series.length && (
                <div className="rounded-2xl border border-dashed p-8 text-center">
                  <BookOpen className="mx-auto h-8 w-8 text-primary" />
                  <h3 className="mt-3 font-semibold">
                    {kind === "paid"
                      ? "No Notes Series available yet."
                      : "No free notes available yet."}
                  </h3>
                  <p className="mt-2 text-sm text-muted-foreground">
                    {kind === "paid"
                      ? "Published paid notes series will appear here."
                      : "Free notes will appear here when the team publishes them."}
                  </p>
                </div>
              )}
              <PagedGrid
                items={(data?.series ?? []).filter((item) => has(item.name))}
                label="Notes series"
                className="grid gap-5 sm:grid-cols-2 lg:grid-cols-3"
              >
                {(item) => (
                  <article key={item.id} className="surface-panel min-w-0 overflow-hidden p-5">
                    <ContentThumbnail
                      value={{
                        thumbnail_url: item.thumbnail_url ?? null,
                        thumbnail_text: item.thumbnail_text ?? null,
                      }}
                      title={item.name}
                    />
                    <Badge variant="secondary">
                      {kind === "sample" ? "Free notes" : "Paid / course access"}
                    </Badge>
                    <h3 className="mt-3 break-words text-lg font-bold">{item.name}</h3>
                    <p className="mt-2 text-sm text-muted-foreground">
                      {item.subjects.length} subjects · {seriesNoteIds(item).length} notes
                    </p>
                    <Button
                      aria-label={`Series: ${item.name}`}
                      className="mt-5 w-full"
                      onClick={() => go([item.id])}
                    >
                      Open notes series
                      <ArrowRight className="h-4 w-4" />
                    </Button>
                  </article>
                )}
              </PagedGrid>
            </>
          ) : !subject ? (
            <>
              <h3 className="text-lg font-semibold">Select subject</h3>
              <PagedGrid
                items={series.subjects.filter((item) => has(item.name))}
                label="Notes subjects"
                className="grid gap-3 sm:grid-cols-2 lg:grid-cols-3"
              >
                {(item) => (
                  <Button
                    key={item.id}
                    aria-label={`Subject: ${item.name}`}
                    variant="default"
                    className="h-auto min-h-24 w-full justify-between gap-4 whitespace-normal break-words rounded-2xl px-5 py-5 text-left text-base shadow-md hover:-translate-y-0.5 hover:shadow-lg"
                    onClick={() => go([series.id, item.id])}
                  >
                    <span className="min-w-0 flex-1">{item.name}</span>
                    <span
                      aria-hidden="true"
                      className="grid h-10 w-10 shrink-0 place-items-center rounded-xl bg-primary-foreground/20"
                    >
                      <ArrowRight className="h-5 w-5" />
                    </span>
                  </Button>
                )}
              </PagedGrid>
            </>
          ) : !chapter ? (
            <>
              <h3 className="text-lg font-semibold">Select chapter</h3>
              <PagedGrid
                items={subject.chapters.filter((item) => has(item.name))}
                label="Notes chapters"
                className="grid gap-3 sm:grid-cols-2 lg:grid-cols-3"
              >
                {(item) => (
                  <Button
                    key={item.id}
                    aria-label={`Chapter: ${item.name}`}
                    variant="secondary"
                    className="h-auto min-h-20 w-full justify-between gap-4 whitespace-normal break-words rounded-2xl border-primary/40 px-5 py-4 text-left text-base shadow-sm hover:-translate-y-0.5 hover:shadow-md"
                    onClick={() => go([series.id, subject.id, item.id])}
                  >
                    <span className="min-w-0 flex-1">{item.name}</span>
                    <span
                      aria-hidden="true"
                      className="grid h-9 w-9 shrink-0 place-items-center rounded-xl bg-primary/15 text-primary"
                    >
                      <ArrowRight className="h-4 w-4" />
                    </span>
                  </Button>
                )}
              </PagedGrid>
            </>
          ) : (
            <>
              {!topic && chapter.topics.length > 0 && (
                <>
                  <h3 className="text-lg font-semibold">Select topic</h3>
                  <PagedGrid
                    items={chapter.topics.filter((item) => has(item.name))}
                    label="Notes topics"
                    className="grid gap-3 sm:grid-cols-2 lg:grid-cols-3"
                  >
                    {(item) => (
                      <Button
                        key={item.id}
                        aria-label={`Topic: ${item.name}`}
                        variant="secondary"
                        className="h-auto min-h-16 w-full justify-between gap-4 whitespace-normal break-words rounded-2xl border-primary/40 px-5 py-4 text-left text-base shadow-sm hover:-translate-y-0.5 hover:shadow-md"
                        onClick={() => go([...path.slice(0, 3), item.id])}
                      >
                        <span className="min-w-0 flex-1">{item.name}</span>
                        <span
                          aria-hidden="true"
                          className="grid h-9 w-9 shrink-0 place-items-center rounded-xl bg-primary/15 text-primary"
                        >
                          <ArrowRight className="h-4 w-4" />
                        </span>
                      </Button>
                    )}
                  </PagedGrid>
                </>
              )}
              <h3 className="text-lg font-semibold">{topic ? topic.name : "Chapter notes"}</h3>
              {kind === "paid" && series && batchQuery.isPending ? (
                <p role="status" className="rounded-xl border p-4 text-sm text-muted-foreground">
                  Checking full-series access…
                </p>
              ) : batchQuery.isError && kind === "paid" && series ? (
                <div role="alert" className="rounded-xl border p-4 text-sm">
                  Series access could not be checked. Retry before purchasing a note.
                  <Button
                    variant="outline"
                    className="ml-2"
                    onClick={() => void batchQuery.refetch()}
                  >
                    Retry
                  </Button>
                </div>
              ) : (
                <PagedGrid
                  items={notes.filter((note) => has(note.title))}
                  label="Study materials"
                  className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3"
                >
                  {(note) => (
                    <article key={note.id} className="surface-panel min-w-0 p-5">
                      <ContentThumbnail
                        value={note}
                        title={note.title}
                        kind="materials"
                        id={note.id}
                      />
                      <Badge variant="secondary">
                        {kind === "sample"
                          ? "Free notes"
                          : freePreviewIds.has(note.id)
                            ? "First note free"
                            : "Included in full series or batch"}
                      </Badge>
                      <h4 className="mt-3 break-words font-semibold">{note.title}</h4>
                      <MaterialAccessButton
                        fileUrl={note.file_url}
                        deferredBodyId={note.id}
                        materialId={note.id}
                        accessType={freePreviewIds.has(note.id) ? "free" : note.access_type}
                        price={freePreviewIds.has(note.id) ? 0 : note.price}
                        coinPrice={freePreviewIds.has(note.id) ? 0 : note.coin_price}
                        courseId={note.course_id}
                        title={note.title}
                        subject={note.subject}
                        chapter={note.chapter}
                        materialType={note.material_type}
                        batchCourseId={
                          !freePreviewIds.has(note.id) && batchCourse?.hasNotesBatch
                            ? batchCourse.courseId
                            : undefined
                        }
                        batchCourseSlug={batchCourse?.courseSlug}
                        batchCourseTitle={batchCourse?.courseTitle}
                        bundleRequired={kind === "paid" && !freePreviewIds.has(note.id)}
                        notesSeriesId={kind === "paid" ? series.id : undefined}
                      />
                    </article>
                  )}
                </PagedGrid>
              )}
              {!notes.length && (
                <p className="text-sm text-muted-foreground">
                  {chapter.topics.length && !topic
                    ? "Choose a topic above to open its notes."
                    : "No published notes here yet."}
                </p>
              )}
            </>
          )}
        </>
      )}
    </section>
  );
}
