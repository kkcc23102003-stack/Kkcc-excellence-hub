import "@fontsource/anton/400.css";
import "@fontsource/great-vibes/400.css";
import { PresentationDesignPanel } from "./presentation-design-panel";
import { CustomPamphletWizard } from "./custom-pamphlet-wizard";
import { VisualInlineEditor, type VisualInlineHandle } from "./visual-inline-editor";
import type { ImportedPamphlet } from "@/lib/custom-pamphlet-browser";
import { insertCustomPdfSlides } from "@/lib/custom-pamphlet";
import { plainAuthorRuns, type AuthorRun } from "@/lib/author-inline";
import { DEFAULT_SLIDE_SIZE, DEFAULT_SLIDE_BRAND } from "@/lib/document-studio";
import {
  browserSlideMeasure,
  fittedElement,
  fontFamily,
  insertTeachingSlides,
  resizePresentation,
  THEMES,
  type SlideSize,
  type ThemeName,
} from "@/lib/presentation-design";
import { useBlocker } from "@tanstack/react-router";
import "@fontsource/noto-sans-gurmukhi/400.css";
import "@fontsource/noto-sans-gurmukhi/700.css";
import "@fontsource/noto-sans-devanagari/400.css";
import "@fontsource/noto-sans-devanagari/700.css";
import { memo, useEffect, useRef, useState } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import {
  cloneSlide,
  invertHex,
  deckSchema,
  downloadFile,
  parsePageSelection,
  makeSlide,
  safeFilename,
  textElement,
  type Deck,
  type Slide,
  type SlideElement,
} from "@/lib/document-studio";
import { prepareStudioImage } from "@/lib/pdf-browser";
import { exportPowerPoint, presentationPdf, slideThumbnail } from "@/lib/presentation-export";
import { NOTES_PRINT_LOGO } from "@/lib/notes-print-logo";
import type { PdfColourMode } from "@/lib/pdf-brand";

export const SlidePreview = memo(function SlidePreview({
  slide,
  index,
  onSelect,
  selectableIds,
  selected,
  onDrag,
  size = DEFAULT_SLIDE_SIZE,
  brand = DEFAULT_SLIDE_BRAND,
}: {
  slide: Slide;
  size?: SlideSize;
  brand?: typeof DEFAULT_SLIDE_BRAND;
  index: number;
  onSelect?: (id: string) => void;
  selectableIds?: readonly string[];
  selected?: string | undefined;
  onDrag?: (id: string, x: number, y: number) => void;
}) {
  const stage = useRef<HTMLDivElement>(null);
  const [drag, setDrag] = useState<{
    id: string;
    startX: number;
    startY: number;
    x: number;
    y: number;
    dx: number;
    dy: number;
  } | null>(null);
  return (
    <div
      ref={stage}
      className="relative w-full overflow-hidden rounded border shadow-sm"
      style={{
        background: slide.background,
        aspectRatio: `${size.width} / ${size.height}`,
        containerType: "inline-size",
      }}
      aria-label={`Slide ${index + 1} preview`}
    >
      {(!slide.design || slide.design === "legacy") && (
        <>
          <img
            src={NOTES_PRINT_LOGO}
            alt="KKCC logo"
            className="absolute left-[1.4%] top-[1.7%]"
            style={{
              height: `${((Math.min(size.width, size.height) * 0.075) / size.height) * 100}%`,
            }}
          />
          <div
            className="absolute left-[10%] right-[10%] top-[2.5%] text-center font-bold text-emerald-800"
            style={{
              fontSize: `${(Math.min(size.width, size.height) * 0.026) / (size.width / 100)}cqw`,
            }}
          >
            {brand.appName}
          </div>
        </>
      )}
      {slide.elements.map((item, i) => {
        const dx = drag?.id === item.id ? drag.dx : 0,
          dy = drag?.id === item.id ? drag.dy : 0,
          selectable = !!onSelect && (!selectableIds || selectableIds.includes(item.id));
        return (
          <div
            key={item.id}
            role={selectable ? "button" : undefined}
            tabIndex={selectable ? 0 : undefined}
            aria-label={
              selectable && selectableIds
                ? `Edit slide ${item.slot === "title" ? "heading" : "main text"} in preview`
                : `Slide element ${i + 1}: ${item.type}`
            }
            onKeyDown={(e) => {
              if (selectable && (e.key === "Enter" || e.key === " ")) {
                e.preventDefault();
                onSelect?.(item.id);
              }
            }}
            onPointerDown={(e) => {
              if (!selectable) return;
              onSelect?.(item.id);
              if (onDrag) {
                e.currentTarget.setPointerCapture(e.pointerId);
                setDrag({
                  id: item.id,
                  startX: e.clientX,
                  startY: e.clientY,
                  x: item.x,
                  y: item.y,
                  dx: 0,
                  dy: 0,
                });
              }
            }}
            onPointerMove={(e) => {
              if (!drag || drag.id !== item.id || !stage.current) return;
              const rect = stage.current.getBoundingClientRect();
              setDrag({
                ...drag,
                dx: ((e.clientX - drag.startX) / rect.width) * 100,
                dy: ((e.clientY - drag.startY) / rect.height) * 100,
              });
            }}
            onPointerUp={() => {
              if (drag) {
                if (Math.abs(drag.dx) + Math.abs(drag.dy) > 0.1)
                  onDrag?.(
                    item.id,
                    Math.max(0, Math.min(100 - item.w, drag.x + drag.dx)),
                    Math.max(0, Math.min(100 - item.h, drag.y + drag.dy)),
                  );
                setDrag(null);
              }
            }}
            onPointerCancel={() => setDrag(null)}
            style={{
              position: "absolute",
              left: `${item.x + dx}%`,
              top: `${item.y + dy}%`,
              width: `${item.w}%`,
              height: `${item.h}%`,
              color: item.colour,
              fontSize: `${item.fontSize / (size.width / 100)}cqw`,
              opacity: item.opacity ?? 1,
              fontWeight: item.bold ? 700 : 400,
              fontStyle: item.italic ? "italic" : "normal",
              textShadow: item.glow
                ? `0 0 .15em ${item.colour}, 0 0 .045em ${item.colour}`
                : undefined,
              fontFamily: fontFamily(item.font),
              textAlign: item.align,
              lineHeight: 1.3,
              whiteSpace: "pre-wrap",
              overflowWrap: "anywhere",
              overflow: "hidden",
              background:
                item.type === "rectangle" || item.type === "ellipse" ? item.fill : "transparent",
              borderRadius: item.type === "ellipse" ? "50%" : 0,
              outline: selected === item.id ? "2px dashed #0d9488" : undefined,
              cursor: selectable ? (onDrag ? "move" : "text") : "default",
              touchAction: selectable && onDrag ? "none" : "auto",
            }}
          >
            {item.type === "image" ? (
              <img
                draggable={false}
                src={item.image}
                alt="Slide illustration"
                className="h-full w-full object-contain"
              />
            ) : item.type === "text" ? (
              item.runs?.length ? (
                item.runs.map((run, index) => (
                  <span
                    key={index}
                    style={{
                      color: run.color ?? item.colour,
                      fontWeight: run.bold ? 700 : 400,
                      fontStyle: run.italic ? "italic" : "normal",
                      textDecoration: run.underline ? "underline" : "none",
                    }}
                  >
                    {run.text}
                  </span>
                ))
              ) : (
                item.text
              )
            ) : null}
          </div>
        );
      })}
      {!slide.hidePageNumber && (
        <span
          className="absolute bottom-[2%] right-[3%] text-slate-500"
          style={{ fontSize: "1.1cqw" }}
        >
          {index + 1}
        </span>
      )}
    </div>
  );
});

export function PresentationStudio({ onPreview }: { onPreview: (file: File) => void }) {
  const [deck, setDeck] = useState<Deck>(() => ({
    version: 1,
    title: "My KKCC presentation",
    slides: [makeSlide()],
  }));
  const [active, setActive] = useState(0),
    [selected, setSelected] = useState<string | undefined>(),
    [mode, setMode] = useState<"simple" | "advanced">("simple"),
    [template, setTemplate] = useState("lesson"),
    [lessonText, setLessonText] = useState(""),
    [lessonTheme, setLessonTheme] = useState<ThemeName>("paper"),
    [reviewSlides, setReviewSlides] = useState(true),
    [present, setPresent] = useState(false),
    [invert, setInvert] = useState(false),
    [busy, setBusy] = useState(false),
    [message, setMessage] = useState(
      "Save a .kkcc-presentation.json project to keep editing later. No cloud upload occurs.",
    ),
    [dirty, setDirty] = useState(false);
  const history = useRef<Deck[]>([]),
    future = useRef<Deck[]>([]),
    cancel = useRef(false),
    alive = useRef(true),
    latestDeck = useRef(deck),
    simpleEditor = useRef<HTMLDivElement>(null),
    simpleHeadingEditor = useRef<VisualInlineHandle>(null),
    simpleBodyEditor = useRef<VisualInlineHandle>(null),
    host = useRef<HTMLDivElement>(null);
  latestDeck.current = deck;
  const [pdfOutput, setPdfOutput] = useState<Uint8Array | null>(null);
  const [slidePdfMode, setSlidePdfMode] = useState<PdfColourMode>("colour");
  const [customPdf, setCustomPdf] = useState<ImportedPamphlet | null>(null);
  const [pdfPages, setPdfPages] = useState("1");
  const slide = deck.slides[Math.min(active, deck.slides.length - 1)]!,
    element = slide.elements.find((e) => e.id === selected);
  useEffect(() => {
    alive.current = true;
    return () => {
      alive.current = false;
      cancel.current = true;
    };
  }, []);
  useBlocker({
    shouldBlockFn: ({ next }) =>
      dirty &&
      next.pathname !== "/login" &&
      !window.confirm(
        "This presentation has unsaved project changes. Leave without saving a project file?",
      ),
    enableBeforeUnload: dirty,
  });
  useEffect(() => {
    if (!present) return;
    const key = (e: KeyboardEvent) => {
      if (e.key === "Escape") {
        setPresent(false);
        if (document.fullscreenElement) void document.exitFullscreen();
      }
      if (["ArrowRight", "PageDown", " "].includes(e.key)) {
        e.preventDefault();
        setActive((n) => Math.min(deck.slides.length - 1, n + 1));
      }
      if (["ArrowLeft", "PageUp"].includes(e.key)) {
        e.preventDefault();
        setActive((n) => Math.max(0, n - 1));
      }
    };
    window.addEventListener("keydown", key);
    return () => window.removeEventListener("keydown", key);
  }, [present, deck.slides.length]);
  const commit = (next: Deck) => {
    try {
      const valid = deckSchema.parse(next);
      const total = valid.slides.reduce(
        (sum, s) =>
          sum +
          s.elements.reduce(
            (n, e) =>
              n + e.image.length + e.text.length + (e.runs ? JSON.stringify(e.runs).length : 0),
            0,
          ),
        0,
      );
      if (total > 24_000_000)
        throw new Error(
          "Project limit: 24 MB of image/text data. Optimise pictures or split the deck.",
        );
      history.current.push(deck);
      const dataSize = (entry: Deck) =>
        entry.slides.reduce(
          (sum, slide) =>
            sum +
            slide.elements.reduce(
              (n, e) =>
                n + e.image.length + e.text.length + (e.runs ? JSON.stringify(e.runs).length : 0),
              0,
            ),
          0,
        );
      let historyBytes = history.current.reduce((sum, entry) => sum + dataSize(entry), 0);
      while (
        history.current.length > 1 &&
        (history.current.length > 25 || historyBytes > 32_000_000)
      )
        historyBytes -= dataSize(history.current.shift()!);
      future.current = [];
      setDeck({
        ...valid,
        slides: valid.slides.map((slide, index) =>
          next.slides[index] === deck.slides[index] ? deck.slides[index]! : slide,
        ),
      });
      setDirty(true);
      setPdfOutput(null);
      return true;
    } catch (error) {
      setMessage(error instanceof Error ? error.message : "Invalid presentation.");
      return false;
    }
  };
  const editSlide = (change: Partial<Slide>) =>
    commit({
      ...deck,
      slides: deck.slides.map((s, i) => (i === active ? { ...s, ...change } : s)),
    });
  const editElement = (patch: Partial<SlideElement>) =>
    editSlide({
      elements: slide.elements.map((e) => (e.id === selected ? { ...e, ...patch } : e)),
    });
  const navigateHistory = (undo: boolean) => {
    const from = undo ? history.current : future.current,
      to = undo ? future.current : history.current;
    const next = from.pop();
    if (!next) return;
    to.push(deck);
    setDeck(next);
    setActive(0);
    setSelected(undefined);
    setDirty(true);
    setPdfOutput(null);
  };
  const run = async (work: () => Promise<void>) => {
    cancel.current = false;
    setBusy(true);
    try {
      await work();
      if (cancel.current && alive.current)
        setMessage("Operation cancelled. Original project is unchanged.");
    } catch (error) {
      if (alive.current)
        setMessage(error instanceof Error ? error.message : "Presentation operation failed.");
    } finally {
      if (alive.current) setBusy(false);
    }
  };
  const importProject = (file: File | undefined, merge: boolean) => {
    if (!file) return;
    void run(async () => {
      if (file.size > 30 * 1024 * 1024) throw new Error("Project file must be under 30 MB.");
      let incoming = deckSchema.parse(JSON.parse(await file.text()));
      if (merge)
        incoming = resizePresentation(
          incoming,
          deck.size ?? DEFAULT_SLIDE_SIZE,
          await browserSlideMeasure(),
        );
      if (cancel.current || !alive.current) return;
      if (
        !merge &&
        dirty &&
        !window.confirm(
          "Replace the current presentation? Save its project first to keep your work.",
        )
      )
        return;
      const next = merge
        ? { ...deck, slides: [...deck.slides, ...incoming.slides.map(cloneSlide)] }
        : incoming;
      if (commit(next)) {
        setActive(0);
        setSelected(undefined);
        setDirty(merge);
        setMessage(merge ? "Project slides merged." : "Project opened.");
      }
    });
  };
  const size = deck.size ?? DEFAULT_SLIDE_SIZE;
  const brand = deck.brand ?? DEFAULT_SLIDE_BRAND;
  // Brand and decorative lettering can look like a title but is not lesson content.
  // Keep simple edits targeted to the same independent text objects used by PPTX export.
  const editableTexts = slide.elements.filter(
    (item) => item.type === "text" && item.role !== "brand" && item.role !== "decoration",
  );
  const simpleTitle = editableTexts.find((item) => item.slot === "title") ?? editableTexts[0];
  const simpleBody =
    editableTexts.find((item) => item.slot === "body" && item.id !== simpleTitle?.id) ??
    editableTexts.find((item) => item.id !== simpleTitle?.id);
  // Only render seven miniature canvases at once even for a 60-slide lesson.
  const previewFirst = Math.max(0, Math.min(active - 3, deck.slides.length - 7));
  const simpleRuns = (item: SlideElement): AuthorRun[] =>
    item.runs ?? [{ text: item.text, bold: item.bold, italic: !!item.italic, color: item.colour }];
  const updateSimpleRuns = (id: string, runs: AuthorRun[]) =>
    editSlide({
      elements: slide.elements.map((item) =>
        item.id === id ? { ...item, text: plainAuthorRuns(runs), runs } : item,
      ),
    });
  const selectPreviewText = (id: string) => {
    const target =
      id === simpleTitle?.id
        ? simpleHeadingEditor
        : id === simpleBody?.id
          ? simpleBodyEditor
          : null;
    if (!target) return;
    setSelected(id);
    // A tap/Enter on the slide opens the same native-IME, rich-text editor used beside it.
    requestAnimationFrame(() => target.current?.focus());
  };
  const generateLessonSlides = () =>
    void run(async () => {
      const source = deck;
      const measure = await browserSlideMeasure();
      if (cancel.current || !alive.current) return;
      if (latestDeck.current !== source)
        throw new Error("The project changed while slides were being prepared. Please try again.");
      const { deck: next, added } = insertTeachingSlides(
        source,
        lessonText,
        lessonTheme,
        active,
        measure,
      );
      if (commit(next)) {
        setActive(active + 1);
        setSelected(undefined);
        setReviewSlides(true);
        setMessage(
          `Generated ${added} editable slide${added === 1 ? "" : "s"} after slide ${active + 1}. Older slides are unchanged. Select a thumbnail, then tap the heading or main text on the slide to edit before exporting PPTX.`,
        );
        requestAnimationFrame(() => {
          simpleEditor.current?.scrollIntoView({ block: "start" });
          simpleEditor.current?.focus({ preventScroll: true });
        });
      }
    });
  const addPdfPages = (selection: string) => {
    if (!customPdf) return;
    try {
      const indexes = parsePageSelection(selection, customPdf.pages.length);
      const next = insertCustomPdfSlides(
        deck,
        indexes.map((index) => customPdf.pages[index]!),
        active,
      );
      if (commit(next)) {
        setActive(active + 1);
        setSelected(undefined);
        setMessage(
          `Added ${indexes.length} PDF page(s) after slide ${active + 1}. Earlier slides are unchanged. PDF artwork is image-only; add separate editable text if needed.`,
        );
      }
    } catch (error) {
      setMessage(error instanceof Error ? error.message : "Could not add PDF slides.");
    }
  };
  const moveSlide = (delta: number) => {
    const next = [...deck.slides];
    [next[active], next[active + delta]] = [next[active + delta]!, next[active]!];
    if (commit({ ...deck, slides: next })) setActive(active + delta);
  };
  const invertSlide = () =>
    void run(async () => {
      const next = structuredClone(slide);
      next.background = invertHex(next.background);
      for (const item of next.elements) {
        if (cancel.current) throw new Error("Cancelled.");
        item.colour = invertHex(item.colour);
        item.fill = invertHex(item.fill);
        if (item.runs)
          item.runs = item.runs.map((run) => ({
            ...run,
            ...(run.color ? { color: invertHex(run.color) } : {}),
          }));
        if (item.type === "image") {
          const image = new Image();
          image.src = item.image;
          await image.decode();
          const canvas = document.createElement("canvas");
          canvas.width = image.width;
          canvas.height = image.height;
          const ctx = canvas.getContext("2d")!;
          ctx.drawImage(image, 0, 0);
          const pixels = ctx.getImageData(0, 0, canvas.width, canvas.height);
          for (let i = 0; i < pixels.data.length; i += 4) {
            pixels.data[i] = 255 - pixels.data[i]!;
            pixels.data[i + 1] = 255 - pixels.data[i + 1]!;
            pixels.data[i + 2] = 255 - pixels.data[i + 2]!;
          }
          ctx.putImageData(pixels, 0, 0);
          item.image = canvas.toDataURL("image/png");
          canvas.width = 0;
          canvas.height = 0;
        }
      }
      if (alive.current && !cancel.current && editSlide(next))
        setMessage(
          "Slide colours inverted. Text stays editable; Undo restores the original. Branding remains unchanged.",
        );
    });
  const optimise = () =>
    void run(async () => {
      if (
        !window.confirm(
          "Optimise all slide pictures to smaller JPEGs? Transparency becomes white and image detail may decrease. You can Undo or keep your saved original project.",
        )
      )
        return;
      const next = structuredClone(deck);
      let count = 0;
      for (const s of next.slides)
        for (const e of s.elements) {
          if (cancel.current) throw new Error("Cancelled.");
          if (e.type !== "image") continue;
          const img = new Image();
          img.src = e.image;
          await img.decode();
          const scale = Math.min(1, 1024 / Math.max(img.width, img.height)),
            canvas = document.createElement("canvas");
          canvas.width = Math.max(1, Math.round(img.width * scale));
          canvas.height = Math.max(1, Math.round(img.height * scale));
          const ctx = canvas.getContext("2d")!;
          ctx.fillStyle = "#ffffff";
          ctx.fillRect(0, 0, canvas.width, canvas.height);
          ctx.drawImage(img, 0, 0, canvas.width, canvas.height);
          const data = canvas.toDataURL("image/jpeg", 0.7);
          if (data.length < e.image.length) e.image = data;
          canvas.width = 0;
          canvas.height = 0;
          count++;
        }
      if (alive.current && !cancel.current && commit(next))
        setMessage(`Optimised ${count} pictures where smaller. Text stays editable.`);
    });
  const finishPresentation = (edit = false) => {
    setPresent(false);
    if (edit && mode === "simple") setReviewSlides(true);
    if (document.fullscreenElement) void document.exitFullscreen();
    if (edit) requestAnimationFrame(() => simpleEditor.current?.scrollIntoView({ block: "start" }));
  };
  const historyControls = (
    <>
      <Button
        variant="outline"
        disabled={!history.current.length}
        onClick={() => navigateHistory(true)}
      >
        Undo
      </Button>
      <Button
        variant="outline"
        disabled={!future.current.length}
        onClick={() => navigateHistory(false)}
      >
        Redo
      </Button>
    </>
  );
  const projectFileControls = (
    <div className="grid gap-3 sm:grid-cols-2">
      <label className="text-sm">
        Open saved project
        <Input
          type="file"
          aria-label="Open presentation project"
          accept=".json"
          onChange={(e) => {
            importProject(e.target.files?.[0], false);
            e.target.value = "";
          }}
        />
      </label>
      <label className="text-sm">
        Merge another project
        <Input
          type="file"
          aria-label="Merge presentation project"
          accept=".json"
          onChange={(e) => {
            importProject(e.target.files?.[0], true);
            e.target.value = "";
          }}
        />
      </label>
    </div>
  );
  return (
    <section
      ref={host}
      className="space-y-4 rounded-2xl border bg-background p-4"
      data-testid="presentation-studio"
    >
      <div className="flex flex-wrap items-center justify-between gap-2">
        <div>
          <span className="text-xs font-bold uppercase tracking-wider text-primary">
            Your slides
          </span>
          <h2 className="text-xl font-bold">Presentation Studio</h2>
        </div>
        <span className="rounded-full border border-primary/20 bg-primary/[0.07] px-3 py-1 text-xs font-semibold text-primary">
          {deck.slides.length} {deck.slides.length === 1 ? "slide" : "slides"} · editable
        </span>
      </div>
      <p className="max-w-2xl text-sm text-muted-foreground">
        Write a lesson → edit slide text → save your project and download PowerPoint. PDF artwork
        can be added without replacing your slides. Existing saved projects still reopen here.
      </p>
      <nav
        aria-label="Presentation Studio modes"
        className="flex flex-wrap items-center gap-2 text-sm"
      >
        <button
          type="button"
          aria-pressed={mode === "simple"}
          onClick={() => setMode("simple")}
          className={`min-h-11 rounded-lg border px-4 py-2 font-semibold ${mode === "simple" ? "border-primary/40 bg-primary/10 text-primary" : "bg-card text-foreground hover:border-primary/40"}`}
        >
          Simple · make slides
        </button>
        <details className="rounded-lg border border-border/80 bg-card px-3 py-1">
          <summary className="min-h-9 cursor-pointer py-2 font-medium text-foreground">
            More slide tools · optional
          </summary>
          <p className="max-w-xs pb-2 text-xs text-muted-foreground">
            Shapes, templates, speaker notes and editing every object in older projects.
          </p>
          <button
            type="button"
            aria-pressed={mode === "advanced"}
            onClick={() => setMode("advanced")}
            className="mb-2 min-h-11 rounded-lg border border-primary/30 bg-background px-4 py-2 font-semibold text-primary hover:bg-primary/10"
          >
            Advanced · edit every slide
          </button>
        </details>
      </nav>
      <fieldset disabled={busy} className="min-w-0 space-y-4">
        {mode === "advanced" && (
          <PresentationDesignPanel
            deck={deck}
            onCommit={commit}
            onSelect={(index) => {
              setActive(index);
              setSelected(undefined);
            }}
          />
        )}
        <label className="block text-sm">
          Presentation name
          <Input
            aria-label="Presentation name"
            maxLength={150}
            value={deck.title}
            onChange={(e) => commit({ ...deck, title: e.target.value || "Untitled presentation" })}
          />
        </label>
        {mode === "simple" && (
          <section
            aria-label="Long text to editable slides"
            className="min-w-0 space-y-3 rounded-xl border bg-card p-4"
          >
            <span className="text-xs font-bold uppercase tracking-wide text-primary">
              Step 1 · Write
            </span>
            <h3 className="text-lg font-semibold">Long text → editable PPT slides</h3>
            <label className="block text-sm">
              Write or paste your lesson
              <Textarea
                aria-label="Long lesson text for slides"
                className="mt-1"
                rows={7}
                maxLength={60000}
                value={lessonText}
                onChange={(event) => setLessonText(event.target.value)}
                placeholder="Write your full lesson here. For a new topic, start a line with # Topic (optional)."
              />
            </label>
            <details className="rounded-lg border bg-background px-3 py-2 text-sm">
              <summary className="min-h-10 cursor-pointer py-2 font-medium">
                Slide style (optional) · change from paper
              </summary>
              <label className="mt-2 block text-sm sm:max-w-xs">
                Slide style
                <select
                  aria-label="Auto slide style"
                  className="mt-1 block min-h-11 w-full rounded border bg-background p-2"
                  value={lessonTheme}
                  onChange={(event) => setLessonTheme(event.target.value as ThemeName)}
                >
                  {Object.entries(THEMES).map(([key, value]) => (
                    <option key={key} value={key}>
                      {value.name}
                    </option>
                  ))}
                </select>
              </label>
            </details>
            <Button
              type="button"
              className="h-auto min-h-11 w-full whitespace-normal sm:w-auto"
              disabled={!lessonText.trim() || deck.slides.length >= 60}
              onClick={generateLessonSlides}
            >
              Generate slides &amp; preview
            </Button>
            <p className="text-xs text-muted-foreground">
              {lessonText.length} / 60000 characters · New slides are added after the current slide;
              earlier work is never replaced.
            </p>
            <details className="text-xs text-muted-foreground">
              <summary className="min-h-9 cursor-pointer py-2 font-medium">
                How are slides split? · limits
              </summary>
              # headings start optional sections; otherwise your subject is the heading. Long
              paragraphs continue on extra slides without AI rewriting. Up to 60 slides per project.
              Save the editable project JSON to resume later; export PPTX after reviewing.
            </details>
            {deck.slides.length >= 60 && (
              <p className="text-xs text-amber-700 dark:text-amber-300">
                This project already has 60 slides. Save it and start a second project to add more.
              </p>
            )}
          </section>
        )}
        {mode === "simple" && (
          <div
            ref={simpleEditor}
            tabIndex={-1}
            className="space-y-4 rounded-xl border bg-card p-4"
            aria-label="Simple slide editor"
          >
            <div className="flex flex-wrap items-center justify-between gap-3">
              <div>
                <span className="text-xs font-bold uppercase tracking-wide text-primary">
                  Step 2 · Preview &amp; edit
                </span>
                <h3 className="text-lg font-semibold">Edit your slides</h3>
              </div>
              <div className="flex min-w-0 flex-wrap items-center gap-2">
                <Button
                  type="button"
                  size="sm"
                  variant={reviewSlides ? "secondary" : "outline"}
                  className="h-auto min-h-11 whitespace-normal"
                  aria-pressed={reviewSlides}
                  onClick={() => setReviewSlides((value) => !value)}
                >
                  Preview all slides
                </Button>
                <label className="flex min-w-0 flex-wrap items-center gap-2 text-sm">
                  Choose slide
                  <select
                    aria-label="Choose slide"
                    className="min-w-0 max-w-full rounded border bg-background p-2"
                    value={active}
                    onChange={(e) => {
                      setActive(Number(e.target.value));
                      setSelected(undefined);
                    }}
                  >
                    {deck.slides.map((item, index) => (
                      <option key={item.id} value={index}>
                        Slide {index + 1} of {deck.slides.length}
                      </option>
                    ))}
                  </select>
                </label>
              </div>
            </div>
            <div className="grid min-w-0 gap-4 lg:grid-cols-[minmax(0,1fr)_minmax(260px,380px)]">
              <div className="min-w-0">
                <SlidePreview
                  slide={slide}
                  index={active}
                  size={size}
                  brand={brand}
                  {...(reviewSlides ? { selected, onSelect: selectPreviewText } : {})}
                  selectableIds={[simpleTitle?.id, simpleBody?.id].filter(
                    (id): id is string => !!id,
                  )}
                />
                <p className="mt-2 text-xs text-muted-foreground">
                  Tap the heading or text on the slide to edit with your normal keyboard. PDF/Canva
                  artwork is an image; add editable text on top.
                </p>
                {reviewSlides && (
                  <div
                    role="region"
                    aria-label="Slide-by-slide preview"
                    className="mt-3 min-w-0 space-y-3 rounded-lg border bg-muted/20 p-3"
                  >
                    <div className="flex flex-wrap items-center justify-between gap-2">
                      <span className="text-sm font-semibold">
                        Slide {active + 1} of {deck.slides.length}
                      </span>
                      <div className="flex flex-wrap gap-2">
                        <Button
                          type="button"
                          variant="outline"
                          size="sm"
                          className="h-auto min-h-10 whitespace-normal"
                          disabled={active === 0}
                          onClick={() => {
                            setActive((index) => index - 1);
                            setSelected(undefined);
                          }}
                        >
                          Previous preview slide
                        </Button>
                        <Button
                          type="button"
                          variant="outline"
                          size="sm"
                          className="h-auto min-h-10 whitespace-normal"
                          disabled={active === deck.slides.length - 1}
                          onClick={() => {
                            setActive((index) => index + 1);
                            setSelected(undefined);
                          }}
                        >
                          Next preview slide
                        </Button>
                      </div>
                    </div>
                    <nav
                      aria-label="Slide thumbnails"
                      className="flex min-w-0 max-w-full gap-2 overflow-x-auto pb-2"
                    >
                      {deck.slides.slice(previewFirst, previewFirst + 7).map((item, offset) => {
                        const index = previewFirst + offset;
                        return (
                          <button
                            type="button"
                            key={item.id}
                            aria-label={`Preview slide ${index + 1}`}
                            aria-current={index === active ? "page" : undefined}
                            onClick={() => {
                              setActive(index);
                              setSelected(undefined);
                            }}
                            className={`w-[108px] shrink-0 rounded-md border bg-background p-1 text-xs focus-visible:outline-2 focus-visible:outline-primary ${index === active ? "ring-2 ring-primary" : ""}`}
                          >
                            <SlidePreview slide={item} index={index} size={size} brand={brand} />
                            <span className="mt-1 block">Slide {index + 1}</span>
                          </button>
                        );
                      })}
                    </nav>
                    <p className="text-xs text-muted-foreground">
                      Choose a slide, then tap its heading or text to edit with your normal
                      keyboard. Other objects remain available under More slide tools.
                    </p>
                  </div>
                )}
              </div>
              <div className="min-w-0 space-y-3">
                {simpleTitle ? (
                  <div className="text-sm">
                    <p>Slide heading</p>
                    <VisualInlineEditor
                      ref={simpleHeadingEditor}
                      runs={simpleRuns(simpleTitle)}
                      onChange={(runs) => updateSimpleRuns(simpleTitle.id, runs)}
                      label="Simple slide heading"
                      toolbarLabel="Slide heading formatting above the keyboard"
                      maxLength={12000}
                      allowHighlight={false}
                      defaultBold={simpleTitle.bold}
                      defaultColor={simpleTitle.colour}
                    />
                  </div>
                ) : (
                  <Button
                    variant="outline"
                    disabled={slide.elements.length >= 40}
                    onClick={() =>
                      editSlide({
                        elements: [
                          ...slide.elements,
                          {
                            ...textElement("Slide heading", 18),
                            fontSize: 48,
                            bold: true,
                            slot: "title",
                          },
                        ],
                      })
                    }
                  >
                    Add editable heading
                  </Button>
                )}
                {simpleBody ? (
                  <div className="text-sm">
                    <p>Main text</p>
                    <VisualInlineEditor
                      ref={simpleBodyEditor}
                      runs={simpleRuns(simpleBody)}
                      onChange={(runs) => updateSimpleRuns(simpleBody.id, runs)}
                      label="Simple slide text"
                      toolbarLabel="Slide main text formatting above the keyboard"
                      rows={5}
                      maxLength={12000}
                      allowHighlight={false}
                      defaultBold={simpleBody.bold}
                      defaultColor={simpleBody.colour}
                    />
                  </div>
                ) : (
                  <Button
                    variant="outline"
                    disabled={slide.elements.length >= 40}
                    onClick={() =>
                      editSlide({
                        elements: [
                          ...slide.elements,
                          {
                            ...textElement("Add your main idea", 40),
                            h: 48,
                            fontSize: 30,
                            slot: "body",
                          },
                        ],
                      })
                    }
                  >
                    Add editable main text
                  </Button>
                )}
                <div className="flex flex-wrap gap-2">
                  <Button
                    disabled={deck.slides.length >= 60}
                    onClick={() => {
                      if (commit({ ...deck, slides: [...deck.slides, makeSlide("lesson")] }))
                        setActive(deck.slides.length);
                    }}
                  >
                    Add lesson slide
                  </Button>
                  <Button
                    variant="outline"
                    disabled={deck.slides.length >= 60}
                    onClick={() => {
                      const slides = [...deck.slides];
                      slides.splice(active + 1, 0, cloneSlide(slide));
                      if (commit({ ...deck, slides })) setActive(active + 1);
                    }}
                  >
                    Copy this slide
                  </Button>
                </div>
                <details className="rounded-lg border bg-background p-3 text-sm">
                  <summary className="min-h-11 cursor-pointer py-2 font-semibold">
                    Custom slide · add PDF page(s)
                  </summary>
                  <div className="mt-2 space-y-3">
                    <p className="text-xs text-muted-foreground">
                      Choose a PDF (up to 25 MB / 12 pages) locally. Select page numbers, then add
                      them after this slide. Your existing slides will not be replaced. PDF artwork
                      becomes an image; new heading/main text can be edited separately.
                    </p>
                    <label className="block text-xs font-medium">
                      Choose custom slide PDF
                      <Input
                        aria-label="Choose custom slide PDF"
                        type="file"
                        accept=".pdf,application/pdf"
                        className="mt-1"
                        onChange={(event) => {
                          const file = event.target.files?.[0];
                          event.target.value = "";
                          if (!file) return;
                          setCustomPdf(null);
                          void run(async () => {
                            if (!(file.type === "application/pdf" || /\.pdf$/i.test(file.name)))
                              throw new Error("Choose a PDF file for a custom slide.");
                            const { importPamphletArtwork } =
                              await import("@/lib/custom-pamphlet-browser");
                            const imported = await importPamphletArtwork(
                              [file],
                              (done, total) => {
                                if (alive.current)
                                  setMessage(`Reading PDF page ${done} / ${total} locally…`);
                              },
                              () => cancel.current || !alive.current,
                            );
                            if (!alive.current || cancel.current) return;
                            setCustomPdf(imported);
                            setPdfPages("1");
                            setMessage(
                              `${imported.pages.length} PDF page(s) ready. Select page(s) and add them to your current deck.`,
                            );
                          });
                        }}
                      />
                    </label>
                    {customPdf && (
                      <div className="space-y-2">
                        <img
                          src={
                            customPdf.pages[Number(pdfPages) - 1]?.image ??
                            customPdf.pages[0]?.image
                          }
                          alt="Selected PDF page artwork preview"
                          className="max-h-36 max-w-full rounded border object-contain"
                        />
                        <label className="block text-xs">
                          PDF pages to add (1–{customPdf.pages.length}; e.g. 1,3-4)
                          <Input
                            aria-label="PDF pages to add"
                            value={pdfPages}
                            onChange={(event) => setPdfPages(event.target.value)}
                            className="mt-1"
                          />
                        </label>
                        {customPdf.mixedRatios && (
                          <p className="text-xs text-amber-700 dark:text-amber-300">
                            Page sizes differ. Each page is fitted with white margins; artwork is
                            not stretched.
                          </p>
                        )}
                        <div className="flex flex-wrap gap-2">
                          <Button
                            type="button"
                            size="sm"
                            disabled={deck.slides.length >= 60}
                            onClick={() => addPdfPages(pdfPages)}
                          >
                            Add selected PDF page(s)
                          </Button>
                          <Button
                            type="button"
                            size="sm"
                            variant="outline"
                            disabled={deck.slides.length + customPdf.pages.length > 60}
                            onClick={() => addPdfPages("")}
                          >
                            Add all PDF pages
                          </Button>
                        </div>
                      </div>
                    )}
                  </div>
                </details>
              </div>
            </div>
          </div>
        )}
        <div hidden={mode !== "simple"}>
          <details className="rounded-xl border bg-card p-3">
            <summary className="min-h-11 cursor-pointer py-2 font-semibold text-foreground">
              Start with a Canva PDF, JPG or PNG design (optional)
            </summary>
            <CustomPamphletWizard
              brand={deck.brand ?? DEFAULT_SLIDE_BRAND}
              onOpenInEditor={(generated) => {
                if (
                  dirty &&
                  !window.confirm(
                    "Replace your current Studio project with these slides? Save its project JSON first to keep your old work. Cancel leaves it untouched.",
                  )
                )
                  return false;
                if (!commit(generated)) return false;
                setActive(0);
                setSelected(undefined);
                setMessage("Design opened below. Save the project JSON when finished.");
                return true;
              }}
            />
          </details>
        </div>
        {mode === "simple" && (
          <div>
            <span className="text-xs font-bold uppercase tracking-wide text-primary">
              Step 3 · Download
            </span>
            <h3 className="font-semibold">Keep your slides</h3>
            <p className="text-xs text-muted-foreground">
              Save editable project keeps your work for later; Export PowerPoint makes the PPTX. PDF
              is an optional copy, not editable slides.
            </p>
          </div>
        )}
        <div className="flex flex-wrap gap-2">
          <label className="flex w-full min-w-0 flex-wrap items-center gap-2 text-xs font-semibold sm:w-auto">
            Slide PDF output
            <select
              aria-label="Slide PDF colour mode"
              className="min-h-10 min-w-0 w-full max-w-full rounded-lg border bg-background px-2 sm:w-auto"
              value={slidePdfMode}
              disabled={busy}
              onChange={(event) => setSlidePdfMode(event.target.value as PdfColourMode)}
            >
              <option value="colour">Colour</option>
              <option value="black-white">Black &amp; white · grayscale, black logo</option>
            </select>
          </label>
          <Button
            onClick={() => {
              downloadFile(
                JSON.stringify(deck, null, 2),
                `${safeFilename(deck.title)}.kkcc-presentation.json`,
                "application/json",
              );
              setDirty(false);
              setMessage(
                "Project download started. Keep this file to reopen/edit; export PPTX separately for PowerPoint.",
              );
            }}
          >
            Save editable project
          </Button>
          <Button
            variant="outline"
            onClick={() =>
              void run(async () => {
                const blob = await exportPowerPoint(deckSchema.parse(deck));
                if (!alive.current || cancel.current) return;
                downloadFile(blob, `${safeFilename(deck.title)}.pptx`);
                setMessage(
                  "Editable PowerPoint exported. Font availability may affect layout in other apps.",
                );
              })
            }
          >
            Export PowerPoint
          </Button>
          <Button
            variant="outline"
            onClick={() =>
              void run(async () => {
                setMessage("Rendering slide PDF…");
                const bytes = await presentationPdf(
                  deck,
                  (n) => {
                    if (alive.current) setMessage(`Rendering slide ${n} / ${deck.slides.length}`);
                  },
                  () => cancel.current,
                );
                if (alive.current && !cancel.current) {
                  const output =
                    slidePdfMode === "black-white"
                      ? await (
                          await import("@/lib/pdf-brand")
                        ).brandPdfBytes(bytes, {
                          mode: slidePdfMode,
                          onProgress: (page, total) => {
                            if (alive.current) setMessage(`Grayscale slide ${page} / ${total}`);
                          },
                        })
                      : bytes;
                  if (!alive.current || cancel.current) return;
                  setPdfOutput(output);
                  downloadFile(
                    output,
                    `${safeFilename(deck.title)}${slidePdfMode === "black-white" ? "-BW" : ""}.pdf`,
                    "application/pdf",
                  );
                  setMessage(
                    "Slide PDF exported as images; text is not searchable. PPTX remains editable.",
                  );
                }
              })
            }
          >
            Export slide PDF
          </Button>
          {mode === "advanced" &&
            (["png", "jpeg"] as const).map((format) => (
              <Button
                key={format}
                variant="outline"
                onClick={() =>
                  void run(async () => {
                    const blob = await slideThumbnail(slide, active, size, brand, format);
                    if (!cancel.current && alive.current) {
                      downloadFile(
                        blob,
                        `${safeFilename(deck.title)}-slide-${active + 1}.${format === "jpeg" ? "jpg" : "png"}`,
                      );
                      setMessage(`Thumbnail exported at ${size.width} × ${size.height}px.`);
                    }
                  })
                }
              >
                Export {format === "jpeg" ? "JPG" : "PNG"} thumbnail
              </Button>
            ))}
          <Button
            variant="outline"
            onClick={() => {
              setPresent(true);
              void host.current
                ?.requestFullscreen()
                .catch(() =>
                  setMessage(
                    "Presentation mode opened; browser fullscreen unavailable in this frame.",
                  ),
                );
            }}
          >
            Present slides
          </Button>
          {mode === "advanced" && (
            <>
              <Button variant="outline" onClick={optimise}>
                Optimise pictures
              </Button>
              <Button variant="outline" onClick={invertSlide}>
                Invert slide colours
              </Button>
            </>
          )}
        </div>
        {mode === "simple" ? (
          <details className="rounded-xl border bg-card px-3 py-2">
            <summary className="min-h-11 cursor-pointer py-2 font-semibold">
              More project options · undo, open or merge
            </summary>
            <div className="mt-2 flex flex-wrap gap-2">{historyControls}</div>
            <p className="my-2 text-xs text-muted-foreground">
              Open replaces the current project (you'll be asked if you have unsaved edits); merge
              adds slides. Only .kkcc-presentation.json projects can be reopened here.
            </p>
            {projectFileControls}
          </details>
        ) : (
          <>
            <div className="flex flex-wrap gap-2">{historyControls}</div>
            {projectFileControls}
          </>
        )}
        <div hidden={mode !== "advanced"} className="space-y-4">
          <h3 className="text-lg font-semibold">Detailed slide editor</h3>
          <div className="flex flex-wrap gap-2">
            <select
              aria-label="Slide template"
              className="rounded border bg-background p-2"
              value={template}
              onChange={(e) => setTemplate(e.target.value)}
            >
              <option value="lesson">Lesson</option>
              <option value="title">Title</option>
              <option value="quiz">Quiz</option>
              <option value="blank">Blank</option>
            </select>
            <Button
              disabled={deck.slides.length >= 60}
              onClick={() => {
                if (commit({ ...deck, slides: [...deck.slides, makeSlide(template)] })) {
                  setActive(deck.slides.length);
                  setSelected(undefined);
                }
              }}
            >
              Add slide
            </Button>
            <Button
              variant="outline"
              disabled={deck.slides.length >= 60}
              onClick={() => {
                const next = [...deck.slides];
                next.splice(active + 1, 0, cloneSlide(slide));
                if (commit({ ...deck, slides: next })) setActive(active + 1);
              }}
            >
              Duplicate slide
            </Button>
            <Button variant="outline" disabled={active === 0} onClick={() => moveSlide(-1)}>
              Move slide left
            </Button>
            <Button
              variant="outline"
              disabled={active === deck.slides.length - 1}
              onClick={() => moveSlide(1)}
            >
              Move slide right
            </Button>
            <Button
              variant="outline"
              disabled={deck.slides.length === 1}
              onClick={() => {
                if (
                  window.confirm(
                    "Delete this slide? Undo is available until you leave this editor.",
                  )
                ) {
                  if (commit({ ...deck, slides: deck.slides.filter((_, i) => i !== active) })) {
                    setActive(Math.max(0, active - 1));
                    setSelected(undefined);
                  }
                }
              }}
            >
              Delete slide
            </Button>
          </div>
          <div className="flex gap-2 overflow-auto pb-2" aria-label="Presentation slides">
            {deck.slides.map((s, i) => (
              <button
                key={s.id}
                aria-label={`Edit slide ${i + 1}`}
                aria-current={active === i ? "page" : undefined}
                className={`w-36 shrink-0 rounded p-1 text-xs ${active === i ? "ring-2 ring-primary" : "border"}`}
                onClick={() => {
                  setActive(i);
                  setSelected(undefined);
                }}
              >
                <SlidePreview slide={s} index={i} size={size} brand={brand} />
                <span>Slide {i + 1}</span>
              </button>
            ))}
          </div>
          <div className="grid min-w-0 gap-4 xl:grid-cols-[minmax(0,1fr)_270px]">
            <div className="min-w-0">
              <SlidePreview
                slide={slide}
                size={size}
                brand={brand}
                index={active}
                selected={selected}
                onSelect={setSelected}
                onDrag={(id, x, y) =>
                  editSlide({
                    elements: slide.elements.map((e) => (e.id === id ? { ...e, x, y } : e)),
                  })
                }
              />
              <p className="mt-2 text-xs text-muted-foreground">
                Click an object to edit. Drag it or use position fields. Text outside its box is
                clipped: resize the box or reduce font size before export.
              </p>
            </div>
            <div className="min-w-0 space-y-3 rounded border p-3">
              <label className="flex items-center justify-between text-sm">
                Slide background
                <input
                  type="color"
                  aria-label="Slide background"
                  value={slide.background}
                  onChange={(e) => editSlide({ background: e.target.value })}
                />
              </label>
              <label className="block text-sm">
                Select any template object
                <select
                  aria-label="Select slide object"
                  className="w-full rounded border bg-background p-2"
                  value={selected ?? ""}
                  onChange={(e) => setSelected(e.target.value || undefined)}
                >
                  <option value="">Choose an object</option>
                  {slide.elements.map((e, i) => (
                    <option key={e.id} value={e.id}>
                      {i + 1}. {e.slot ?? e.role ?? e.type} — {e.text.slice(0, 35) || e.type}
                    </option>
                  ))}
                </select>
              </label>
              <div className="flex flex-wrap gap-2">
                {["text", "rectangle", "ellipse"].map((type) => (
                  <Button
                    key={type}
                    size="sm"
                    variant="outline"
                    disabled={slide.elements.length >= 40}
                    onClick={() => {
                      const item = {
                        ...textElement(),
                        type: type as SlideElement["type"],
                        w: type === "text" ? 86 : 35,
                        h: 20,
                      };
                      if (editSlide({ elements: [...slide.elements, item] })) setSelected(item.id);
                    }}
                  >
                    Add {type}
                  </Button>
                ))}
              </div>
              <label className="block text-xs">
                Add JPG/PNG image
                <Input
                  aria-label="Slide image"
                  type="file"
                  accept="image/png,image/jpeg"
                  disabled={slide.elements.length >= 40}
                  onChange={(e) => {
                    const file = e.target.files?.[0];
                    e.target.value = "";
                    if (file)
                      void run(async () => {
                        const image = await prepareStudioImage(file);
                        const source = new Image();
                        source.src = image;
                        await source.decode();
                        if (cancel.current || !alive.current) return;
                        const scale = Math.min(
                          (size.width * 0.5) / source.width,
                          (size.height * 0.5) / source.height,
                        );
                        const item = {
                          ...textElement(),
                          type: "image" as const,
                          image,
                          w: Math.max(5, (source.width * scale) / (size.width / 100)),
                          h: Math.max(5, (source.height * scale) / (size.height / 100)),
                        };
                        if (editSlide({ elements: [...slide.elements, item] }))
                          setSelected(item.id);
                      });
                  }}
                />
              </label>
              {element && (
                <div className="space-y-3 border-t pt-3">
                  <h3 className="text-sm font-bold">Selected {element.type}</h3>
                  <label className="block text-xs">
                    Opacity
                    <Input
                      aria-label="Element opacity"
                      type="number"
                      min={0}
                      max={1}
                      step={0.05}
                      value={element.opacity ?? 1}
                      onChange={(e) =>
                        editElement({ opacity: Math.max(0, Math.min(1, Number(e.target.value))) })
                      }
                    />
                  </label>
                  {element.type === "text" && (
                    <>
                      <select
                        aria-label="Text style"
                        className="rounded border bg-background p-2"
                        value={element.font ?? "sans"}
                        onChange={(e) =>
                          editElement({ font: e.target.value as "sans" | "display" | "condensed" })
                        }
                      >
                        <option value="sans">Clear teaching font</option>
                        <option value="display">Decorative title script</option>
                        <option value="condensed">Reference condensed title</option>
                      </select>
                      <label className="flex items-center gap-2 text-sm">
                        <input
                          type="checkbox"
                          checked={element.italic ?? false}
                          onChange={(e) => editElement({ italic: e.target.checked })}
                        />
                        Italic title
                      </label>
                      <label className="flex items-center gap-2 text-sm">
                        <input
                          type="checkbox"
                          checked={element.glow ?? false}
                          onChange={(e) => editElement({ glow: e.target.checked })}
                        />
                        Neon text glow
                      </label>
                      <Button
                        size="sm"
                        variant="outline"
                        onClick={() =>
                          void run(async () => {
                            const fit = fittedElement(element, size, await browserSlideMeasure());
                            editElement({ fontSize: fit.fontSize });
                          })
                        }
                      >
                        Fit text in box
                      </Button>
                    </>
                  )}
                  {element.type === "image" && (
                    <label className="block text-xs">
                      Replace selected image / logo
                      <Input
                        aria-label="Replace selected slide image"
                        type="file"
                        accept="image/png,image/jpeg"
                        onChange={(e) => {
                          const file = e.target.files?.[0];
                          e.target.value = "";
                          if (file)
                            void run(async () => {
                              const image = await prepareStudioImage(file);
                              if (alive.current && !cancel.current) editElement({ image });
                            });
                        }}
                      />
                    </label>
                  )}

                  {element.type === "text" && (
                    <>
                      <VisualInlineEditor
                        key={element.id}
                        label="Slide text"
                        toolbarLabel="Selected slide text formatting above the keyboard"
                        runs={simpleRuns(element)}
                        onChange={(runs) => editElement({ text: plainAuthorRuns(runs), runs })}
                        rows={5}
                        maxLength={12000}
                        allowHighlight={false}
                        defaultBold={element.bold}
                        defaultColor={element.colour}
                      />
                      <label className="block text-xs">
                        Font size
                        <Input
                          aria-label="Slide font size"
                          type="number"
                          min={10}
                          max={140}
                          value={element.fontSize}
                          onChange={(e) =>
                            editElement({
                              fontSize: Math.max(10, Math.min(140, Number(e.target.value))),
                            })
                          }
                        />
                      </label>
                      <label className="flex gap-2 text-sm">
                        <input
                          type="checkbox"
                          checked={element.bold}
                          onChange={(e) => editElement({ bold: e.target.checked })}
                        />
                        Bold slide text
                      </label>
                      <select
                        aria-label="Slide text alignment"
                        className="rounded border bg-background p-2"
                        value={element.align}
                        onChange={(e) =>
                          editElement({ align: e.target.value as SlideElement["align"] })
                        }
                      >
                        {["left", "center", "right"].map((a) => (
                          <option key={a}>{a}</option>
                        ))}
                      </select>
                    </>
                  )}
                  {element.type !== "image" && (
                    <label className="flex justify-between text-sm">
                      {element.type === "text" ? "Text colour" : "Shape fill"}
                      <input
                        type="color"
                        aria-label="Element colour"
                        value={element.type === "text" ? element.colour : element.fill}
                        onChange={(e) =>
                          editElement(
                            element.type === "text"
                              ? { colour: e.target.value }
                              : { fill: e.target.value },
                          )
                        }
                      />
                    </label>
                  )}
                  <div className="grid grid-cols-2 gap-2">
                    {(["x", "y", "w", "h"] as const).map((key) => (
                      <label key={key} className="text-xs">
                        {{ x: "Left %", y: "Top %", w: "Width %", h: "Height %" }[key]}
                        <Input
                          aria-label={`Element ${key}`}
                          type="number"
                          step={1}
                          value={Math.round(element[key] * 10) / 10}
                          onChange={(e) => {
                            const n = Number(e.target.value);
                            const max =
                              key === "x"
                                ? 100 - element.w
                                : key === "y"
                                  ? 100 - element.h
                                  : key === "w"
                                    ? 100 - element.x
                                    : 100 - element.y;
                            editElement({
                              [key]: Math.min(
                                max,
                                Math.max(key === "y" || key === "x" ? 0 : 0.1, n),
                              ),
                            });
                          }}
                        />
                      </label>
                    ))}
                  </div>
                  <div className="flex flex-wrap gap-2">
                    <Button
                      size="sm"
                      variant="outline"
                      onClick={() =>
                        editSlide({
                          elements: [...slide.elements.filter((e) => e.id !== selected), element],
                        })
                      }
                    >
                      Bring to front
                    </Button>
                    <Button
                      size="sm"
                      variant="outline"
                      onClick={() =>
                        editSlide({
                          elements: [element, ...slide.elements.filter((e) => e.id !== selected)],
                        })
                      }
                    >
                      Send to back
                    </Button>
                    <Button
                      size="sm"
                      variant="outline"
                      onClick={() => {
                        editSlide({ elements: slide.elements.filter((e) => e.id !== selected) });
                        setSelected(undefined);
                      }}
                    >
                      Delete object
                    </Button>
                  </div>
                </div>
              )}
            </div>
          </div>
          <label className="block text-sm">
            Speaker notes (included in PPTX, not on slide)
            <Textarea
              aria-label="Speaker notes"
              maxLength={10000}
              value={slide.notes}
              onChange={(e) => editSlide({ notes: e.target.value })}
            />
          </label>
        </div>
      </fieldset>
      <p role="status" className="text-sm">
        {message}
      </p>
      <p className="text-xs text-muted-foreground">
        {dirty
          ? "Unsaved project changes — save your project before navigating away."
          : "No unsaved project changes."}
      </p>
      {busy && (
        <Button
          variant="outline"
          onClick={() => {
            cancel.current = true;
            setMessage("Cancelling after the current export step…");
          }}
        >
          Cancel export
        </Button>
      )}
      {pdfOutput && (
        <Button
          variant="outline"
          onClick={() =>
            onPreview(
              new File([new Uint8Array(pdfOutput)], `${deck.title}.pdf`, {
                type: "application/pdf",
              }),
            )
          }
        >
          Open slide PDF in reader
        </Button>
      )}
      {present && (
        <div
          role="dialog"
          aria-modal="true"
          aria-label="Presentation mode"
          className="fixed inset-0 z-[100] flex flex-col justify-center bg-slate-950 p-3"
        >
          <div
            className="mx-auto w-full max-w-6xl"
            style={{
              maxWidth: `min(100%, ${(72 * size.width) / size.height}vh)`,
              filter: invert ? "invert(1)" : "none",
            }}
          >
            <SlidePreview slide={slide} index={active} size={size} brand={brand} />
          </div>
          <div className="mt-4 flex flex-wrap justify-center gap-2">
            <Button disabled={active === 0} onClick={() => setActive((n) => n - 1)}>
              Previous slide
            </Button>
            <span className="self-center text-white">
              {active + 1} / {deck.slides.length}
            </span>
            <Button
              disabled={active === deck.slides.length - 1}
              onClick={() => setActive((n) => n + 1)}
            >
              Next slide
            </Button>
            <Button aria-pressed={invert} onClick={() => setInvert((v) => !v)}>
              Invert presentation view
            </Button>
            <Button variant="secondary" onClick={() => finishPresentation(true)}>
              Edit this slide
            </Button>
            <Button onClick={() => finishPresentation()}>Exit presentation</Button>
          </div>
        </div>
      )}
    </section>
  );
}
