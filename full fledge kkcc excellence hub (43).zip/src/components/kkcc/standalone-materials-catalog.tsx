import { useEffect, useMemo, useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { Search } from "lucide-react";
import { listPublicMaterialCards } from "@/lib/content.functions";
import { MATERIAL_TYPES } from "@/lib/cms";
import { cn } from "@/lib/utils";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { ContentThumbnail } from "./content-thumbnail";
import { MaterialAccessButton } from "./material-access-button";
import { PagedGrid } from "./paged-grid";

/** Restore the PR #2 all-material catalogue alongside the newer notes-series hierarchy.
 * Cards are metadata only: the private note body is loaded after an authorised reader opens it.
 */
export function StandaloneMaterialsCatalog({
  initialQuery = "",
}: {
  initialQuery?: string | undefined;
}) {
  const query = useQuery({
    queryKey: ["public-catalog", "listPublicMaterialCards"],
    queryFn: () => listPublicMaterialCards(),
    staleTime: 60_000,
  });
  const [search, setSearch] = useState(initialQuery);
  useEffect(() => setSearch(initialQuery), [initialQuery]);
  const [type, setType] = useState("All");
  const [subject, setSubject] = useState("All");
  const materials = useMemo(() => query.data ?? [], [query.data]);
  const subjects = useMemo(
    () => ["All", ...new Set(materials.map((row) => row.subject).filter((v): v is string => !!v))],
    [materials],
  );
  const filtered = useMemo(() => {
    const needle = search.trim().toLocaleLowerCase();
    return materials.filter(
      (row) =>
        (type === "All" || row.material_type === type) &&
        (subject === "All" || row.subject === subject) &&
        `${row.title} ${row.subject} ${row.chapter} ${row.module_title} ${row.batch}`
          .toLocaleLowerCase()
          .includes(needle),
    );
  }, [materials, search, type, subject]);
  return (
    <section className="space-y-5" data-testid="all-study-materials">
      <div>
        <h2 className="text-2xl font-bold">All study material</h2>
        <p className="mt-1 text-sm text-muted-foreground">
          Published notes and PDFs. Notes inside a paid series are unlocked through the complete
          series or its batch; the first published note in each subject is free.
        </p>
      </div>
      <div className="grid min-w-0 gap-3 sm:grid-cols-[minmax(0,1fr)_minmax(150px,220px)]">
        <label className="relative min-w-0 text-sm">
          Search notes and chapters
          <Search className="pointer-events-none absolute bottom-3 left-3 h-4 w-4 text-muted-foreground" />
          <Input
            value={search}
            onChange={(event) => setSearch(event.target.value)}
            aria-label="Search study material"
            placeholder="Title, subject or chapter"
            className="pl-9"
          />
        </label>
        <label className="text-sm">
          Subject
          <select
            aria-label="Filter material subject"
            value={subject}
            onChange={(event) => setSubject(event.target.value)}
            className="block min-h-11 w-full rounded-lg border bg-background px-3 text-sm"
          >
            {subjects.map((entry) => (
              <option key={entry}>{entry}</option>
            ))}
          </select>
        </label>
      </div>
      <div
        className="flex max-w-full gap-2 overflow-x-auto pb-1 sm:flex-wrap sm:overflow-visible"
        role="group"
        aria-label="Material type"
      >
        {["All", ...MATERIAL_TYPES].map((entry) => (
          <button
            key={entry}
            type="button"
            aria-pressed={type === entry}
            onClick={() => setType(entry)}
            className={cn(
              "min-h-11 shrink-0 cursor-pointer rounded-full border px-3 text-sm focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring",
              type === entry
                ? "border-primary bg-primary text-primary-foreground"
                : "border-primary/30 bg-secondary text-secondary-foreground hover:bg-secondary-hover",
            )}
          >
            {entry}
          </button>
        ))}
      </div>
      {query.isPending && <p role="status">Loading study material…</p>}
      {query.isError && (
        <div role="alert" className="rounded-xl border p-4">
          Study material could not be loaded.{" "}
          <Button onClick={() => void query.refetch()}>Retry</Button>
        </div>
      )}
      {query.isSuccess && (
        <>
          <PagedGrid
            items={filtered}
            label="All study materials"
            className="grid gap-4 sm:grid-cols-2 xl:grid-cols-3"
          >
            {(material) => (
              <article key={material.id} className="surface-panel min-w-0 p-4">
                <ContentThumbnail
                  value={material}
                  title={material.title}
                  kind="materials"
                  id={material.id}
                />
                <div className="mt-3 flex flex-wrap items-center gap-2 text-xs">
                  <Badge variant="secondary">{material.material_type}</Badge>
                  {material.free_series_preview || material.access_type === "free" ? (
                    <Badge variant="outline">Free first note</Badge>
                  ) : material.access_type === "paid" ? (
                    <>
                      <Badge>₹{material.price}</Badge>
                      <Badge variant="secondary">{material.coin_price ?? 0} 23KAAT</Badge>
                      {material.notes_series_id && (
                        <Badge variant="outline">Also in a Notes Series / Batch</Badge>
                      )}
                    </>
                  ) : material.notes_series_id ? (
                    <Badge variant="outline">Included in a Notes Series / Batch</Badge>
                  ) : (
                    <Badge variant="outline">Course access</Badge>
                  )}
                </div>
                <h3 className="mt-3 break-words font-semibold">{material.title}</h3>
                <p className="mt-1 break-words text-xs text-muted-foreground">
                  {[material.subject, material.chapter, material.class_level, material.batch]
                    .filter(Boolean)
                    .join(" · ")}
                </p>
                <MaterialAccessButton
                  fileUrl={material.file_url}
                  deferredBodyId={material.id}
                  materialId={
                    material.id.startsWith("note:") || material.id.startsWith("theory:")
                      ? undefined
                      : material.id
                  }
                  accessType={material.free_series_preview ? "free" : material.access_type}
                  price={material.free_series_preview ? 0 : material.price}
                  coinPrice={material.free_series_preview ? 0 : material.coin_price}
                  courseId={material.course_id}
                  title={material.title}
                  subject={material.subject}
                  chapter={material.chapter}
                  materialType={material.material_type}
                  bundleRequired={Boolean(
                    material.notes_series_id && !material.free_series_preview,
                  )}
                  notesSeriesId={material.notes_series_id ?? undefined}
                />
              </article>
            )}
          </PagedGrid>
          {!filtered.length && (
            <p className="rounded-xl border border-dashed p-6 text-sm text-muted-foreground">
              {materials.length
                ? "No material matches those filters."
                : "No study material has been published yet."}
            </p>
          )}
        </>
      )}
    </section>
  );
}
