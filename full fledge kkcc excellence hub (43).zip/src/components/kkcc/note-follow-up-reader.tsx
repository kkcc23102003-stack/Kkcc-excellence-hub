import { useEffect, useRef, useState, type RefObject } from "react";
import {
  CheckCircle2,
  Sparkles,
  Volume2,
  VolumeX,
  XCircle,
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { ExplanationDisplay } from "@/components/kkcc/explanation-display";
import { QuestionPrompt } from "@/components/kkcc/question-prompt";
import { useQuizFeedbackSound } from "@/hooks/use-quiz-feedback-sound";
import type { NoteFollowUpTest as NoteTest } from "@/lib/note-follow-up-test";

/** Countdown begins when the end of the accessible note is actually visible.
 * Short notes fit in the reader, so their end becomes visible on opening; long
 * notes must be scrolled to the bottom. An unread attached PDF delays auto-start. */
export function NoteFollowUpGate({
  test,
  scrollRoot,
  autoEnabled,
  waitingForPdf = false,
  onStart,
}: {
  test: NoteTest;
  scrollRoot: RefObject<HTMLDivElement | null>;
  autoEnabled: boolean;
  waitingForPdf?: boolean;
  onStart: () => void;
}) {
  const gate = useRef<HTMLElement>(null);
  const start = useRef(onStart);
  const [remaining, setRemaining] = useState<number | null>(null);
  const [dismissed, setDismissed] = useState(false);
  useEffect(() => {
    start.current = onStart;
  }, [onStart]);
  useEffect(() => {
    const root = scrollRoot.current;
    const target = gate.current;
    if (!root || !target || !autoEnabled || dismissed) return;
    let visible = false;
    const update = () => {
      // A gate that fits entirely in a short note is already at its end. On a
      // longer note, don't start when merely the top of the gate peeks into view.
      const atEnd =
        root.scrollHeight - root.scrollTop - root.clientHeight <= 24;
      if (visible && atEnd) setRemaining((current) => current ?? 5);
      else setRemaining(null); // Leaving the note's end cancels the timer.
    };
    const observer = new IntersectionObserver(
      ([entry]) => {
        visible = Boolean(entry?.isIntersecting);
        update();
      },
      { root, threshold: 0.2 },
    );
    root.addEventListener("scroll", update, { passive: true });
    observer.observe(target);
    return () => {
      root.removeEventListener("scroll", update);
      observer.disconnect();
    };
  }, [scrollRoot, autoEnabled, dismissed]);
  useEffect(() => {
    if (remaining === null) return;
    const timeout = window.setTimeout(() => {
      if (remaining === 1) start.current();
      else setRemaining(remaining - 1);
    }, 1000);
    return () => window.clearTimeout(timeout);
  }, [remaining]);
  return (
    <section
      ref={gate}
      className="mt-4 space-y-2 rounded-2xl border border-primary/30 bg-primary/5 p-4"
      aria-label="Next test after this note"
      data-testid="note-follow-up-gate"
    >
      <h3 className="text-base font-bold">
        Notes complete →{" "}
        <span className="text-study-blue">Next test: {test.title}</span>
      </h3>
      <p className="text-xs text-muted-foreground">
        {test.questions.length} MCQ ·{" "}
        {waitingForPdf
          ? "Pehle colour PDF ka aakhri page dekhein; phir is note ke end par 5 seconds mein test khulega."
          : autoEnabled
            ? "Notes ke end par 5 seconds ke baad test apne aap khulega."
            : "Test phir se shuru kar sakte hain."}{" "}
        Har answer ke baad turant feedback aur explanation milegi. Attempt data
        save nahi hota.
      </p>
      {remaining !== null && (
        <p role="status" aria-live="polite" className="font-semibold">
          Test {remaining} seconds mein shuru hoga…
        </p>
      )}
      <div className="flex flex-wrap gap-2">
        {remaining === null && autoEnabled ? (
          <Button type="button" size="sm" onClick={() => setRemaining(5)}>
            Finish note · start in 5 seconds
          </Button>
        ) : remaining !== null ? (
          <Button
            type="button"
            size="sm"
            variant="outline"
            onClick={() => {
              setRemaining(null);
              setDismissed(true);
            }}
          >
            Stay on notes
          </Button>
        ) : null}
        <Button type="button" size="sm" variant="outline" onClick={onStart}>
          Start test now
        </Button>
      </div>
    </section>
  );
}

/** One MCQ at a time with immediate game-style feedback; attempts remain in memory only. */
export function NoteFollowUpTest({
  test,
  onBack,
  onComplete,
  onRetry,
}: {
  test: NoteTest;
  onBack: () => void;
  onComplete?: () => void;
  onRetry?: () => void;
}) {
  const sound = useQuizFeedbackSound();
  const [current, setCurrent] = useState(0);
  const [choice, setChoice] = useState<number | null>(null);
  const [correctCount, setCorrectCount] = useState(0);
  const [finished, setFinished] = useState(false);
  const question = test.questions[current];
  if (!question) return null;
  const answered = choice !== null;
  const choose = (index: number) => {
    if (answered) return;
    const correct = index === question.correctIndex;
    setChoice(index);
    sound.play(correct ? "correct" : "wrong");
    if (correct) setCorrectCount((count) => count + 1);
  };
  const advance = () => {
    if (current + 1 < test.questions.length) {
      setCurrent((index) => index + 1);
      setChoice(null);
      return;
    }
    setFinished(true);
    onComplete?.();
  };
  const retry = () => {
    onRetry?.();
    setCurrent(0);
    setChoice(null);
    setCorrectCount(0);
    setFinished(false);
  };
  const progress = Math.round(((current + 1) / test.questions.length) * 100);

  return (
    <section
      className="space-y-4 rounded-2xl border bg-card p-4 sm:p-6"
      role="region"
      aria-label={`After-note test ${test.title}`}
      data-testid="note-follow-up-quiz"
    >
      <div className="flex flex-wrap items-center justify-between gap-2">
        <Button type="button" size="sm" variant="outline" onClick={onBack}>
          ← Back to notes
        </Button>
        <Button
          type="button"
          size="sm"
          variant="outline"
          aria-label={
            sound.enabled ? "Quiz sound on; mute" : "Quiz sound off; unmute"
          }
          aria-pressed={sound.enabled}
          onClick={sound.toggle}
        >
          {sound.enabled ? (
            <Volume2 aria-hidden="true" />
          ) : (
            <VolumeX aria-hidden="true" />
          )}
          Sound {sound.enabled ? "on" : "off"}
        </Button>
      </div>
      <div>
        <h2 className="text-xl font-bold text-study-blue">{test.title}</h2>
        <p className="mt-1 text-xs text-muted-foreground">
          One question at a time · Tap an answer for instant feedback · Attempt
          and score are not saved.
        </p>
      </div>
      {finished ? (
        <div
          className="space-y-3 rounded-xl border border-study-teal/30 bg-study-teal/5 p-4"
          role="status"
        >
          <h3 className="text-lg font-bold text-study-teal">Test complete!</h3>
          <p className="font-semibold">
            Score: {correctCount} / {test.questions.length}
          </p>
          <p className="text-sm text-muted-foreground">
            Yeh score sirf abhi screen par hai; attempt data kahin save nahi
            hota.
          </p>
          <div className="flex flex-wrap gap-2">
            <Button type="button" onClick={retry}>
              Try test again
            </Button>
            <Button type="button" variant="outline" onClick={onBack}>
              Back to notes
            </Button>
          </div>
        </div>
      ) : (
        <>
          <div className="space-y-2" aria-label="Question progress">
            <div className="flex items-center justify-between text-xs font-semibold text-muted-foreground">
              <span>
                Question {current + 1} of {test.questions.length}
              </span>
              <span>{progress}%</span>
            </div>
            <div
              className="h-2 overflow-hidden rounded-full bg-muted"
              role="progressbar"
              aria-label="Test progress"
              aria-valuemin={0}
              aria-valuemax={test.questions.length}
              aria-valuenow={current + 1}
            >
              <div
                className="h-full rounded-full bg-primary transition-[width]"
                style={{ width: `${progress}%` }}
              />
            </div>
          </div>
          <article className="space-y-4 rounded-xl border p-4 sm:p-5">
            <QuestionPrompt text={question.question} />
            <div
              className="space-y-2"
              role="group"
              aria-label={`Answers for question ${current + 1}`}
            >
              {question.options.map((option, index) => {
                const isCorrect = index === question.correctIndex;
                const isWrongChoice =
                  answered && index === choice && !isCorrect;
                const stateColour = [
                  "flex items-center justify-between gap-3 rounded-2xl border border-primary/25 bg-secondary/65 px-4 py-3 text-left text-sm font-semibold transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring",
                  !answered &&
                    "cursor-pointer hover:border-primary/60 hover:bg-secondary-hover",
                  answered &&
                    isCorrect &&
                    "border-success bg-success/10 text-success",
                  answered &&
                    isWrongChoice &&
                    "border-destructive bg-destructive/10 text-destructive",
                ]
                  .filter(Boolean)
                  .join(" ");
                return (
                  <button
                    key={index}
                    type="button"
                    aria-pressed={choice === index}
                    disabled={answered}
                    onClick={() => choose(index)}
                    className={stateColour}
                  >
                    <span className="flex min-w-0 items-center">
                      <span className="mr-3 grid h-7 w-7 shrink-0 place-items-center rounded-xl border bg-muted text-xs font-black">
                        {String.fromCharCode(65 + index)}
                      </span>
                      <span className="min-w-0 whitespace-pre-wrap text-study-answer">
                        {option}
                      </span>
                    </span>
                    {answered && isCorrect && (
                      <CheckCircle2 className="h-4 w-4 shrink-0" />
                    )}
                    {isWrongChoice && <XCircle className="h-4 w-4 shrink-0" />}
                  </button>
                );
              })}
            </div>
            {answered && (
              <div
                role="status"
                aria-live="polite"
                className="rounded-3xl border bg-muted/35 p-5"
              >
                <p className="flex items-center gap-2 text-sm font-black text-primary">
                  <Sparkles className="h-4 w-4" />
                  {choice === question.correctIndex
                    ? "Correct!"
                    : "Incorrect — review this answer."}
                </p>
                <p className="mt-2 text-sm font-semibold text-foreground">
                  <span className="text-study-teal">Correct answer:</span>{" "}
                  <span className="text-study-answer">
                    {question.options[question.correctIndex!]}
                  </span>
                </p>
                {question.explanation && (
                  <div className="mt-4">
                    <ExplanationDisplay text={question.explanation} />
                  </div>
                )}
              </div>
            )}
          </article>
          {answered && (
            <Button
              type="button"
              onClick={advance}
              className="w-full sm:w-auto"
            >
              {current + 1 < test.questions.length
                ? "Next question →"
                : "Finish test"}
            </Button>
          )}
        </>
      )}
    </section>
  );
}
