import { LogoMark } from "./logo";
import { useEffect, type ReactNode } from "react";
import { useRouter, useRouterState } from "@tanstack/react-router";
import { useAuthUser } from "@/hooks/use-auth-user";
import { appAccessRedirect, isAuthCompletionRoute } from "@/lib/app-access";

/** Hide the previous route immediately on sign-out, expiry or cross-tab identity change. */
export function AppSessionGate({ children }: { children: ReactNode }) {
  const { user, loading } = useAuthUser();
  const router = useRouter();
  const pathname = useRouterState({ select: (state) => state.location.pathname });
  const destination = loading ? null : appAccessRedirect(pathname, !!user);
  useEffect(() => {
    if (destination) void router.navigate({ to: destination, replace: true });
  }, [destination, router]);
  // Token-exchange screens must mount before session initialisation finishes.
  if (isAuthCompletionRoute(pathname)) return children;
  if (loading || destination) return <SessionLoading />;
  return children;
}

export function SessionLoading() {
  return (
    <div
      className="flex min-h-screen items-center justify-center bg-background text-foreground"
      role="status"
      aria-live="polite"
      data-testid="session-splash"
    >
      <LogoMark className="h-24 w-24 rounded-2xl object-contain shadow-none ring-0 sm:h-28 sm:w-28" />
      <span className="sr-only">Loading KKCC…</span>
    </div>
  );
}
