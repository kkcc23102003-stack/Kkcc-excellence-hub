import { useEffect, useRef, useState } from "react";
import {
  playQuizFeedback,
  quizSoundEnabled,
  QUIZ_SOUND_KEY,
  type QuizFeedback,
} from "@/lib/quiz-feedback-sound";

const SOUND_EVENT = "kkcc:quiz-sound";

function readSoundPreference(): boolean {
  try {
    return quizSoundEnabled(window.localStorage.getItem(QUIZ_SOUND_KEY));
  } catch {
    return true;
  }
}

/** Shared on this device across quizzes, note practice, and graded test review. */
export function useQuizFeedbackSound() {
  // Deterministic on the server; sync a stored preference after hydration.
  const [enabled, setEnabled] = useState(true);
  const enabledRef = useRef(true);
  useEffect(() => {
    const sync = (event?: Event) => {
      const chosen = event instanceof CustomEvent ? event.detail : undefined;
      enabledRef.current = typeof chosen === "boolean" ? chosen : readSoundPreference();
      setEnabled(enabledRef.current);
    };
    const acrossTabs = (event: StorageEvent) => {
      if (event.key === QUIZ_SOUND_KEY || event.key === null) sync();
    };
    sync();
    window.addEventListener(SOUND_EVENT, sync);
    window.addEventListener("storage", acrossTabs);
    return () => {
      window.removeEventListener(SOUND_EVENT, sync);
      window.removeEventListener("storage", acrossTabs);
    };
  }, []);
  const toggle = () => {
    const next = !enabledRef.current;
    enabledRef.current = next;
    setEnabled(next);
    try {
      window.localStorage.setItem(QUIZ_SOUND_KEY, next ? "on" : "off");
    } catch {
      // If Storage is blocked, the current page still honours mute.
    }
    window.dispatchEvent(new CustomEvent(SOUND_EVENT, { detail: next }));
  };
  const play = (result: QuizFeedback) => {
    if (enabledRef.current) playQuizFeedback(result);
  };
  return { enabled, toggle, play };
}
