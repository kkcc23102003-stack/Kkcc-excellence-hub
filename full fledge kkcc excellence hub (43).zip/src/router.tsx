import { QueryClient } from "@tanstack/react-query";
import { createRouter } from "@tanstack/react-router";
import { routeTree } from "./routeTree.gen";

export const getRouter = () => {
  const queryClient = new QueryClient({
    defaultOptions: {
      queries: {
        staleTime: 2 * 60 * 1000,
        gcTime: 20 * 60 * 1000,
        retry: 1,
        retryDelay: (attempt) => Math.min(1000 * 2 ** attempt, 5000),
        refetchOnWindowFocus: false,
        refetchOnReconnect: "always",
      },
      mutations: {
        retry: 0,
      },
    },
  });

  const router = createRouter({
    routeTree,
    context: { queryClient },
    scrollRestoration: true,
    // Do not download hovered routes speculatively on constrained connections/devices.
    defaultPreload:
      typeof document !== "undefined" &&
      (document.documentElement.classList.contains("save-data") ||
        document.documentElement.classList.contains("lite-motion"))
        ? false
        : "intent",
    defaultPreloadStaleTime: 2 * 60 * 1000,
  });

  return router;
};
