> **Current professional KKCC theme:** these earlier illustrations are retained for compatibility, but are no longer the default hero/course/test/subject artwork. The current default UI uses the existing KKCC logo, teal/gold brand panels and lightweight subject icons. Custom uploaded thumbnails still take priority.

# KKCC educational artwork

Four AI-generated, 3D-style raster illustrations, created for this redesign. These are rendered-looking images, **not** live 3D models or photographs of physical objects. No external image provider or rendering engine is used at runtime.

- `learning.webp`: books, pencil, graduation cap; general learning/languages fallback and welcome hero.
- `math.webp`: calculator, drawing compass, geometric prism, notebook; mathematics/reasoning/commerce.
- `science.webp`: microscope, flask, molecule; science/medical subjects.
- `world.webp`: globe, books, compass; geography/history/general knowledge.

All four are optimised WebP, at most 960px wide, **127,938 bytes total**. Below-fold covers lazy-load. The hero has intrinsic dimensions and high fetch priority. Custom uploaded course/content thumbnails retain precedence; text-only thumbnails remain text-only. Notes with no thumbnail stay calm and image-free.
