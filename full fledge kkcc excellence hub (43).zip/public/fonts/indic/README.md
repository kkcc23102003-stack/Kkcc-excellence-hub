# Indic web-font subsets

The Gurmukhi and Devanagari 400/700 WOFF2 subsets here are from `@fontsource/noto-sans-gurmukhi@5.3.0` and `@fontsource/noto-sans-devanagari@5.3.0` (The Noto Project Authors, SIL Open Font License 1.1). Their respective full OFL notices are retained beside the fonts. The existing Latin typography is not changed; these fonts are used only for their Indic Unicode ranges so Punjabi/Hindi Notes and Tests render when the OS supplies no fallback font. No runtime CDN/network dependency is required.
