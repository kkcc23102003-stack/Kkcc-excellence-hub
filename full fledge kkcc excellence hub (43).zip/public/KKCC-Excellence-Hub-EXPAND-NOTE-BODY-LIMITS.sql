-- Expand private note-body storage to support up to 1.5M UTF-16 note characters.
-- The 8 MiB object cap allows for Punjabi/Hindi UTF-8 plus directive JSON overhead.
BEGIN;
UPDATE storage.buckets SET file_size_limit=8388608
WHERE id='kkcc-note-bodies' AND public=false;
DO $$ BEGIN
 IF NOT EXISTS(SELECT 1 FROM storage.buckets WHERE id='kkcc-note-bodies' AND public=false AND file_size_limit>=8388608)
 THEN RAISE EXCEPTION 'Private kkcc-note-bodies bucket is missing or could not be expanded'; END IF;
END $$;
CREATE OR REPLACE FUNCTION public.move_note_body_to_storage(
 p_actor uuid,p_id uuid,p_updated timestamptz,p_source_md5 text,
 p_path text,p_sha256 text,p_bytes bigint
) RETURNS boolean LANGUAGE plpgsql SECURITY DEFINER SET search_path=public,pg_temp AS $$
DECLARE changed integer;
BEGIN
 IF auth.role() IS DISTINCT FROM 'service_role' OR NOT coalesce(public.has_role(p_actor,'admin'),false)
 THEN RAISE EXCEPTION 'Admin server only'; END IF;
 IF p_path IS NULL OR p_path NOT LIKE p_id::text || '/%.txt'
 OR p_path LIKE '%..%' OR p_sha256 IS NULL OR p_sha256 !~ '^[a-f0-9]{64}$'
 OR p_bytes IS NULL OR p_bytes NOT BETWEEN 1 AND 8388608
 THEN RAISE EXCEPTION 'Invalid verified note reference'; END IF;
 UPDATE public.kkcc_materials SET description='',body_storage_path=p_path,
 body_storage_sha256=p_sha256,body_storage_bytes=p_bytes,updated_at=clock_timestamp()
 WHERE id=p_id AND body_storage_path IS NULL
 AND updated_at IS NOT DISTINCT FROM p_updated
 AND md5(coalesce(description,''))=p_source_md5;
 GET DIAGNOSTICS changed=ROW_COUNT;
 RETURN changed=1;
END $$;
REVOKE ALL ON FUNCTION public.move_note_body_to_storage(uuid,uuid,timestamptz,text,text,text,bigint) FROM PUBLIC,anon,authenticated;
GRANT EXECUTE ON FUNCTION public.move_note_body_to_storage(uuid,uuid,timestamptz,text,text,text,bigint) TO service_role;
CREATE OR REPLACE FUNCTION public.move_legacy_note_body(
 p_actor uuid,p_id uuid,p_updated timestamptz,p_source_md5 text,
 p_path text,p_sha256 text,p_bytes bigint
) RETURNS boolean LANGUAGE plpgsql SECURITY DEFINER SET search_path=public,pg_temp AS $$
DECLARE changed integer;
BEGIN
 IF auth.role() IS DISTINCT FROM 'service_role' OR NOT coalesce(public.has_role(p_actor,'admin'),false)
 THEN RAISE EXCEPTION 'Admin server only'; END IF;
 IF p_path IS NULL OR p_path NOT LIKE p_id::text || '/%.txt'
 OR p_path LIKE '%..%' OR p_sha256 IS NULL OR p_sha256 !~ '^[a-f0-9]{64}$'
 OR p_bytes IS NULL OR p_bytes NOT BETWEEN 1 AND 8388608
 THEN RAISE EXCEPTION 'Invalid verified note reference'; END IF;
 UPDATE public.materials SET description='',body_storage_path=p_path,
 body_storage_sha256=p_sha256,body_storage_bytes=p_bytes,updated_at=clock_timestamp()
 WHERE id=p_id AND body_storage_path IS NULL
 AND updated_at IS NOT DISTINCT FROM p_updated
 AND md5(coalesce(description,''))=p_source_md5;
 GET DIAGNOSTICS changed=ROW_COUNT;
 RETURN changed=1;
END $$;
REVOKE ALL ON FUNCTION public.move_legacy_note_body(uuid,uuid,timestamptz,text,text,text,bigint) FROM PUBLIC,anon,authenticated;
GRANT EXECUTE ON FUNCTION public.move_legacy_note_body(uuid,uuid,timestamptz,text,text,text,bigint) TO service_role;
NOTIFY pgrst,'reload schema';
COMMIT;
